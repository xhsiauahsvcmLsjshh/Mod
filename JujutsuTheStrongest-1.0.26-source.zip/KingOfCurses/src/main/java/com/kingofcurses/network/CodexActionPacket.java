package com.kingofcurses.network;

import com.kingofcurses.ability.CinematicDirector;
import com.kingofcurses.ability.EndingLogic;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CodexActionPacket {
    public static final int SKIP_CINEMATIC = 0, REPLAY_INTRO = 1, SUMMON_BOSS = 2, OPEN_ENDING = 3, RIP_FINGER = 4, TOGGLE_MODE = 5;
    public final int action;

    public CodexActionPacket(int action) { this.action = action; }
    public CodexActionPacket(FriendlyByteBuf buf) { this(buf.readVarInt()); }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(action); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        if (sp == null) return;
        switch (action) {
            case SKIP_CINEMATIC -> { CinematicDirector.skip(sp); com.kingofcurses.ability.GojoIntroDirector.skip(sp); com.kingofcurses.ability.FullFightDirector.skip(sp); com.kingofcurses.ability.YutaIntroDirector.skip(sp); }
            case REPLAY_INTRO -> CinematicDirector.replay(sp);
            case SUMMON_BOSS -> EndingLogic.requestBoss(sp);
            case OPEN_ENDING -> EndingLogic.requestEndingScreen(sp);
            case RIP_FINGER -> com.kingofcurses.ability.VesselLogic.rip(sp);
            case TOGGLE_MODE -> com.kingofcurses.ability.KocMode.toggle(sp);
            default -> { }
        }
    }
}
