package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** v1.0.22 Full Fight Video (start / timeline sync / stop / Mahoraga id). */
public class FullFightPacket {
    public static final int START = 0, SYNC = 1, STOP = 2, MAHORAGA = 3, YUTA_START = 4, YUTA_RIKA = 5, YUTA_SYNC = 6, YUTA_STOP = 7;   // v1.0.25 Yuta opening
    public final int action, a, b, tick, x, y, z;

    public FullFightPacket(int action, int a, int b, int tick, int x, int y, int z) { this.action = action; this.a = a; this.b = b; this.tick = tick; this.x = x; this.y = y; this.z = z; }
    public FullFightPacket(FriendlyByteBuf buf) { this(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readInt(), buf.readInt(), buf.readInt()); }
    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(action); buf.writeVarInt(a); buf.writeVarInt(b); buf.writeVarInt(tick); buf.writeInt(x); buf.writeInt(y); buf.writeInt(z); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleFullFight(this));
    }
}
