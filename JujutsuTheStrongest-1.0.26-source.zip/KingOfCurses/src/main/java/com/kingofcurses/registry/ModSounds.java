package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, KingOfCurses.MODID);

    public static final RegistryObject<SoundEvent> SUKUNA_LAUGH = register("sukuna_laugh");
    public static final RegistryObject<SoundEvent> SUKUNA_ROAR = register("sukuna_roar");
    public static final RegistryObject<SoundEvent> SUKUNA_VOICE = register("sukuna_voice");
    public static final RegistryObject<SoundEvent> DISMANTLE = register("dismantle");
    public static final RegistryObject<SoundEvent> CLEAVE = register("cleave");
    public static final RegistryObject<SoundEvent> FUGA_IGNITE = register("fuga_ignite");
    public static final RegistryObject<SoundEvent> FUGA_EXPLODE = register("fuga_explode");
    public static final RegistryObject<SoundEvent> DOMAIN_EXPANSION = register("domain_expansion");
    public static final RegistryObject<SoundEvent> DOMAIN_SLASH = register("domain_slash");
    public static final RegistryObject<SoundEvent> FINGER_EAT = register("finger_eat");
    public static final RegistryObject<SoundEvent> HEARTBEAT = register("heartbeat");
    public static final RegistryObject<SoundEvent> CINEMATIC_SLASH = register("cinematic_slash");
    public static final RegistryObject<SoundEvent> CINEMATIC_STING = register("cinematic_sting");
    public static final RegistryObject<SoundEvent> GOJO_INFINITY = register("gojo_infinity");
    public static final RegistryObject<SoundEvent> BLOOD_SPLATTER = register("blood_splatter");
    public static final RegistryObject<SoundEvent> CURSE_AMBIENT = register("curse_ambient");
    public static final RegistryObject<SoundEvent> CURSE_HURT = register("curse_hurt");
    public static final RegistryObject<SoundEvent> CURSE_DEATH = register("curse_death");
    public static final RegistryObject<SoundEvent> SORCERER_HURT = register("sorcerer_hurt");
    public static final RegistryObject<SoundEvent> SORCERER_DEATH = register("sorcerer_death");
    public static final RegistryObject<SoundEvent> RCT_HEAL = register("rct_heal");
    public static final RegistryObject<SoundEvent> TAKEOVER = register("takeover");
    public static final RegistryObject<SoundEvent> RESONANCE_PULSE = register("resonance_pulse");
    public static final RegistryObject<SoundEvent> SEAL_RITUAL = register("seal_ritual");
    public static final RegistryObject<SoundEvent> CURSED_ENERGY_BURST = register("cursed_energy_burst");
    public static final RegistryObject<SoundEvent> WORLD_SLASH = register("world_slash");
    public static final RegistryObject<SoundEvent> BOSS_THEME = register("boss_theme");
    public static final RegistryObject<SoundEvent> TRAILER_FUGA = register("trailer_fuga");
    public static final RegistryObject<SoundEvent> TRAILER_METEOR = register("trailer_meteor");
    public static final RegistryObject<SoundEvent> TRAILER_BURN = register("trailer_burn");
    public static final RegistryObject<SoundEvent> TRAILER_THEME = register("trailer_theme");

    private ModSounds() {}

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(KingOfCurses.MODID, name)));
    }
}
