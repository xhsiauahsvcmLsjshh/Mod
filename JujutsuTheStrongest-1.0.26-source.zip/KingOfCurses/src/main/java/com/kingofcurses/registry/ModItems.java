package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.item.*;
import net.minecraft.world.item.*;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, KingOfCurses.MODID);

    /** v1.0.4: every finger is the same item. Eat it to absorb the next of the twenty. */
    public static final RegistryObject<Item> SUKUNA_FINGER = ITEMS.register("sukuna_finger",
            () -> new SukunaFingerItem(new Item.Properties().stacksTo(20).rarity(Rarity.EPIC).fireResistant()));
    /** Old numbered fingers (1.0.0 - 1.0.3): kept only so old worlds convert them into {@link #SUKUNA_FINGER}. */
    public static final List<RegistryObject<Item>> LEGACY_FINGERS;
    static {
        List<RegistryObject<Item>> list = new ArrayList<>();
        for (int i = 1; i <= 20; i++) list.add(ITEMS.register("sukuna_finger_" + i, () -> new LegacyFingerItem(new Item.Properties().stacksTo(20))));
        LEGACY_FINGERS = Collections.unmodifiableList(list);
    }

    public static final RegistryObject<Item> CURSED_CODEX = ITEMS.register("cursed_codex", () -> new CursedCodexItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> SUKUNA_CLUE = ITEMS.register("sukuna_clue", () -> new com.kingofcurses.item.ClueItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> SUKUNA_ARM = ITEMS.register("sukuna_arm", () -> new com.kingofcurses.item.SukunaArmItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> HEIAN_SEAL = ITEMS.register("heian_seal", () -> new com.kingofcurses.item.HeianSealItem(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> REMAINS_COMPASS = ITEMS.register("remains_compass", () -> new com.kingofcurses.item.RemainsCompassItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE).fireResistant()));
    public static final RegistryObject<Item> CURSED_COMPASS = ITEMS.register("cursed_compass", () -> new CursedCompassItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> CURSED_ENERGY_SHARD = ITEMS.register("cursed_energy_shard", () -> new Item(new Item.Properties().rarity(Rarity.COMMON)));
    public static final RegistryObject<Item> CURSE_RESIDUE = ITEMS.register("curse_residue", () -> new Item(new Item.Properties().rarity(Rarity.COMMON)));
    public static final RegistryObject<Item> BONE_WHITE_FRAGMENT = ITEMS.register("bone_white_fragment", () -> new Item(new Item.Properties().rarity(Rarity.COMMON)));
    public static final RegistryObject<Item> CRIMSON_THREAD = ITEMS.register("crimson_thread", () -> new Item(new Item.Properties().rarity(Rarity.COMMON)));
    public static final RegistryObject<Item> JUJUTSU_CLOTH = ITEMS.register("jujutsu_cloth", () -> new Item(new Item.Properties().rarity(Rarity.COMMON)));
    public static final RegistryObject<Item> CURSED_INK = ITEMS.register("cursed_ink", () -> new Item(new Item.Properties().rarity(Rarity.COMMON)));
    public static final RegistryObject<Item> BLANK_TALISMAN = ITEMS.register("blank_talisman", () -> new Item(new Item.Properties().rarity(Rarity.COMMON)));
    public static final RegistryObject<Item> SPECIAL_GRADE_CORE = ITEMS.register("special_grade_core", () -> new Item(new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> SEALING_TALISMAN = ITEMS.register("sealing_talisman", () -> new TalismanItem(TalismanItem.Type.SEALING, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> WARDING_TALISMAN = ITEMS.register("warding_talisman", () -> new TalismanItem(TalismanItem.Type.WARDING, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> BINDING_TALISMAN = ITEMS.register("binding_talisman", () -> new TalismanItem(TalismanItem.Type.BINDING, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> FLAME_TALISMAN = ITEMS.register("flame_talisman", () -> new TalismanItem(TalismanItem.Type.FLAME, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> CURSED_ENERGY_VIAL = ITEMS.register("cursed_energy_vial", () -> new CursedVialItem(60f, 0f, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> GREATER_CURSED_ENERGY_VIAL = ITEMS.register("greater_cursed_energy_vial", () -> new CursedVialItem(200f, 0f, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> REVERSE_CURSE_TONIC = ITEMS.register("reverse_curse_tonic", () -> new CursedVialItem(0f, 12f, new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> CURSED_KATANA = ITEMS.register("cursed_katana", () -> new CursedWeaponItem(KocTiers.CURSED, 4, -2.4f, CursedWeaponItem.Perk.NONE, new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> SLAUGHTER_DEMON = ITEMS.register("slaughter_demon", () -> new CursedWeaponItem(KocTiers.CURSED, 2, -1.6f, CursedWeaponItem.Perk.BLEED, new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> INVERTED_SPEAR_OF_HEAVEN = ITEMS.register("inverted_spear_of_heaven", () -> new CursedWeaponItem(KocTiers.SPECIAL, 4, -2.6f, CursedWeaponItem.Perk.NULLIFY, new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> PLAYFUL_CLOUD = ITEMS.register("playful_cloud", () -> new CursedWeaponItem(KocTiers.SPECIAL, 6, -3.0f, CursedWeaponItem.Perk.KNOCKBACK, new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> CHAIN_OF_A_THOUSAND_MILES = ITEMS.register("chain_of_a_thousand_miles", () -> new CursedWeaponItem(KocTiers.CURSED, 3, -2.2f, CursedWeaponItem.Perk.PULL, new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> SPLIT_SOUL_KATANA = ITEMS.register("split_soul_katana", () -> new CursedWeaponItem(KocTiers.SPECIAL, 5, -2.4f, CursedWeaponItem.Perk.SOUL, new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> DRAGON_BONE = ITEMS.register("dragon_bone", () -> new CursedWeaponItem(KocTiers.SPECIAL, 6, -2.8f, CursedWeaponItem.Perk.CURSE_SLAYER, new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> KINGS_CLEAVER = ITEMS.register("kings_cleaver", () -> new CursedWeaponItem(KocTiers.SPECIAL, 7, -2.9f, CursedWeaponItem.Perk.CLEAVER, new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> CURSED_PICKAXE = ITEMS.register("cursed_pickaxe", () -> new PickaxeItem(KocTiers.CURSED, 1, -2.8f, new Item.Properties()));
    public static final RegistryObject<Item> CURSED_AXE = ITEMS.register("cursed_axe", () -> new AxeItem(KocTiers.CURSED, 5.0f, -3.0f, new Item.Properties()));
    public static final RegistryObject<Item> CURSED_SHOVEL = ITEMS.register("cursed_shovel", () -> new ShovelItem(KocTiers.CURSED, 1.5f, -3.0f, new Item.Properties()));
    public static final RegistryObject<Item> CURSED_HOE = ITEMS.register("cursed_hoe", () -> new HoeItem(KocTiers.CURSED, -3, 0.0f, new Item.Properties()));
    public static final RegistryObject<Item> JUJUTSU_UNIFORM_HELMET = ITEMS.register("jujutsu_uniform_helmet", () -> new ArmorItem(KocArmorMaterials.JUJUTSU_UNIFORM, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> JUJUTSU_UNIFORM_CHESTPLATE = ITEMS.register("jujutsu_uniform_chestplate", () -> new ArmorItem(KocArmorMaterials.JUJUTSU_UNIFORM, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> JUJUTSU_UNIFORM_LEGGINGS = ITEMS.register("jujutsu_uniform_leggings", () -> new ArmorItem(KocArmorMaterials.JUJUTSU_UNIFORM, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> JUJUTSU_UNIFORM_BOOTS = ITEMS.register("jujutsu_uniform_boots", () -> new ArmorItem(KocArmorMaterials.JUJUTSU_UNIFORM, ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final RegistryObject<Item> CURSED_ARMOR_HELMET = ITEMS.register("cursed_armor_helmet", () -> new ArmorItem(KocArmorMaterials.CURSED_ARMOR, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> CURSED_ARMOR_CHESTPLATE = ITEMS.register("cursed_armor_chestplate", () -> new ArmorItem(KocArmorMaterials.CURSED_ARMOR, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> CURSED_ARMOR_LEGGINGS = ITEMS.register("cursed_armor_leggings", () -> new ArmorItem(KocArmorMaterials.CURSED_ARMOR, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> CURSED_ARMOR_BOOTS = ITEMS.register("cursed_armor_boots", () -> new ArmorItem(KocArmorMaterials.CURSED_ARMOR, ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final RegistryObject<Item> SUKUNA_ROBES_HELMET = ITEMS.register("sukuna_robes_helmet", () -> new ArmorItem(KocArmorMaterials.SUKUNA_ROBES, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> SUKUNA_ROBES_CHESTPLATE = ITEMS.register("sukuna_robes_chestplate", () -> new ArmorItem(KocArmorMaterials.SUKUNA_ROBES, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> SUKUNA_ROBES_LEGGINGS = ITEMS.register("sukuna_robes_leggings", () -> new ArmorItem(KocArmorMaterials.SUKUNA_ROBES, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> SUKUNA_ROBES_BOOTS = ITEMS.register("sukuna_robes_boots", () -> new ArmorItem(KocArmorMaterials.SUKUNA_ROBES, ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final RegistryObject<Item> TECHNIQUE_DISMANTLE = ITEMS.register("technique_dismantle", () -> new TechniqueItem(com.kingofcurses.ability.Ability.DISMANTLE, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_CLEAVE = ITEMS.register("technique_cleave", () -> new TechniqueItem(com.kingofcurses.ability.Ability.CLEAVE, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_REVERSE_CURSED_TECHNIQUE = ITEMS.register("technique_reverse_cursed_technique", () -> new TechniqueItem(com.kingofcurses.ability.Ability.REVERSE_CURSED_TECHNIQUE, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_SPIDERWEB = ITEMS.register("technique_spiderweb", () -> new TechniqueItem(com.kingofcurses.ability.Ability.SPIDERWEB, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_FUGA = ITEMS.register("technique_fuga", () -> new TechniqueItem(com.kingofcurses.ability.Ability.FUGA, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_WORLD_SLASH = ITEMS.register("technique_world_slash", () -> new TechniqueItem(com.kingofcurses.ability.Ability.WORLD_SLASH, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_DOMAIN_EXPANSION = ITEMS.register("technique_domain_expansion", () -> new TechniqueItem(com.kingofcurses.ability.Ability.DOMAIN_EXPANSION, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_BLUE = ITEMS.register("technique_blue", () -> new TechniqueItem(com.kingofcurses.ability.Ability.BLUE, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_RED = ITEMS.register("technique_red", () -> new TechniqueItem(com.kingofcurses.ability.Ability.RED, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_HOLLOW_PURPLE = ITEMS.register("technique_hollow_purple", () -> new TechniqueItem(com.kingofcurses.ability.Ability.HOLLOW_PURPLE, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_INFINITY = ITEMS.register("technique_infinity", () -> new TechniqueItem(com.kingofcurses.ability.Ability.INFINITY, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_BLINK = ITEMS.register("technique_blink", () -> new TechniqueItem(com.kingofcurses.ability.Ability.BLINK, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> TECHNIQUE_INFINITE_VOID = ITEMS.register("technique_infinite_void", () -> new TechniqueItem(com.kingofcurses.ability.Ability.INFINITE_VOID, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> PRISON_REALM = ITEMS.register("prison_realm", () -> new CursedObjectItem(CursedObjectItem.Kind.PRISON_REALM, CursedObjectItem.props(CursedObjectItem.Kind.PRISON_REALM)));
    public static final RegistryObject<Item> BLACK_ROPE = ITEMS.register("black_rope", () -> new CursedObjectItem(CursedObjectItem.Kind.BLACK_ROPE, CursedObjectItem.props(CursedObjectItem.Kind.BLACK_ROPE)));
    public static final RegistryObject<Item> DEATH_PAINTING = ITEMS.register("death_painting", () -> new CursedObjectItem(CursedObjectItem.Kind.DEATH_PAINTING, CursedObjectItem.props(CursedObjectItem.Kind.DEATH_PAINTING)));
    public static final RegistryObject<Item> CURSED_SPIRIT_ORB = ITEMS.register("cursed_spirit_orb", () -> new CursedObjectItem(CursedObjectItem.Kind.CURSED_SPIRIT_ORB, CursedObjectItem.props(CursedObjectItem.Kind.CURSED_SPIRIT_ORB)));
    public static final RegistryObject<Item> INVENTORY_CURSE = ITEMS.register("inventory_curse", () -> new CursedObjectItem(CursedObjectItem.Kind.INVENTORY_CURSE, CursedObjectItem.props(CursedObjectItem.Kind.INVENTORY_CURSE)));
    public static final RegistryObject<Item> PROMISE_RING = ITEMS.register("promise_ring", () -> new CursedObjectItem(CursedObjectItem.Kind.PROMISE_RING, CursedObjectItem.props(CursedObjectItem.Kind.PROMISE_RING)));
    public static final RegistryObject<Item> RIPPED_FINGER = ITEMS.register("ripped_finger", () -> new RippedFingerItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> RIKA_RING = ITEMS.register("rika_ring", () -> new com.kingofcurses.item.RikaRingItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> YUTA_KATANA = ITEMS.register("yuta_katana", () -> new com.kingofcurses.item.YutaKatanaItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> GOJO_BLINDFOLD = ITEMS.register("gojo_blindfold", () -> new CollectibleArmorItem(KocArmorMaterials.GOJO_BLINDFOLD, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> RYOMEN_SUKUNA_SPAWN_EGG = ITEMS.register("ryomen_sukuna_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.RYOMEN_SUKUNA, 0x1a0505, 0xb3122e, new Item.Properties()));
    public static final RegistryObject<Item> SUKUNA_TRUE_FORM_SPAWN_EGG = ITEMS.register("sukuna_true_form_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SUKUNA_TRUE_FORM, 0x0c0202, 0xe0233f, new Item.Properties()));
    public static final RegistryObject<Item> GOJO_SATORU_SPAWN_EGG = ITEMS.register("gojo_satoru_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.GOJO_SATORU, 0x111122, 0xf2f2ff, new Item.Properties()));
    public static final RegistryObject<Item> FLY_HEAD_SPAWN_EGG = ITEMS.register("fly_head_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.FLY_HEAD, 0x3a2f2a, 0x8a1c1c, new Item.Properties()));
    public static final RegistryObject<Item> CRAWLING_EYE_SPAWN_EGG = ITEMS.register("crawling_eye_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.CRAWLING_EYE, 0x2d1f33, 0xd9d4c5, new Item.Properties()));
    public static final RegistryObject<Item> ROPPONGI_CURSE_SPAWN_EGG = ITEMS.register("roppongi_curse_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.ROPPONGI_CURSE, 0x2b2b2b, 0x6b1f5e, new Item.Properties()));
    public static final RegistryObject<Item> LANTERN_HAG_SPAWN_EGG = ITEMS.register("lantern_hag_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.LANTERN_HAG, 0x1f1a14, 0xff7a1a, new Item.Properties()));
    public static final RegistryObject<Item> HANGED_BRIDE_SPAWN_EGG = ITEMS.register("hanged_bride_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.HANGED_BRIDE, 0xe8e4da, 0x5a0d1a, new Item.Properties()));
    public static final RegistryObject<Item> BONE_CENTIPEDE_SPAWN_EGG = ITEMS.register("bone_centipede_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.BONE_CENTIPEDE, 0xd9d0bd, 0x2a0f12, new Item.Properties()));
    public static final RegistryObject<Item> FINGER_BEARER_SPAWN_EGG = ITEMS.register("finger_bearer_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.FINGER_BEARER, 0x3d0c12, 0xd9d0bd, new Item.Properties()));
    public static final RegistryObject<Item> SMALLPOX_DEITY_SPAWN_EGG = ITEMS.register("smallpox_deity_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SMALLPOX_DEITY, 0x4a3b2b, 0x9e8f6a, new Item.Properties()));
    public static final RegistryObject<Item> CURSED_WOMB_SPAWN_EGG = ITEMS.register("cursed_womb_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.CURSED_WOMB, 0x5c1027, 0xff4f6d, new Item.Properties()));
    public static final RegistryObject<Item> SHRINE_WARDEN_SPAWN_EGG = ITEMS.register("shrine_warden_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SHRINE_WARDEN, 0x14090a, 0xb08d57, new Item.Properties()));
    public static final RegistryObject<Item> JUJUTSU_SORCERER_SPAWN_EGG = ITEMS.register("jujutsu_sorcerer_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.JUJUTSU_SORCERER, 0x101018, 0x2f63c9, new Item.Properties()));
    public static final RegistryObject<Item> SORCERER_ELITE_SPAWN_EGG = ITEMS.register("sorcerer_elite_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SORCERER_ELITE, 0x0a0a12, 0xc9b02f, new Item.Properties()));
    public static final RegistryObject<Item> JUJUTSU_STUDENT_SPAWN_EGG = ITEMS.register("jujutsu_student_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.JUJUTSU_STUDENT, 0x1b1b2b, 0xdfe3ea, new Item.Properties()));
    public static final RegistryObject<Item> GOJO_KENJAKU_SPAWN_EGG = ITEMS.register("gojo_kenjaku_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.GOJO_KENJAKU, 0x0e0e1a, 0x7a2ad6, new Item.Properties()));
    public static final RegistryObject<Item> YUTA_OKKOTSU_SPAWN_EGG = ITEMS.register("yuta_okkotsu_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.YUTA_OKKOTSU, 0x0f0f14, 0xeeeeee, new Item.Properties()));
    public static final RegistryObject<Item> KINJI_HAKARI_SPAWN_EGG = ITEMS.register("kinji_hakari_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.KINJI_HAKARI, 0x161618, 0x3c968c, new Item.Properties()));
    public static final RegistryObject<Item> MAKI_ZENIN_SPAWN_EGG = ITEMS.register("maki_zenin_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.MAKI_ZENIN, 0x141a18, 0xaa1420, new Item.Properties()));
    public static final RegistryObject<Item> MEGUMI_FUSHIGURO_SPAWN_EGG = ITEMS.register("megumi_fushiguro_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.MEGUMI_FUSHIGURO, 0x12121e, 0x28205a, new Item.Properties()));
    public static final RegistryObject<Item> AOI_TODO_SPAWN_EGG = ITEMS.register("aoi_todo_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.AOI_TODO, 0xc49676, 0x1e1e2c, new Item.Properties()));
    public static final RegistryObject<Item> KENTO_NANAMI_SPAWN_EGG = ITEMS.register("kento_nanami_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.KENTO_NANAMI, 0xc8b896, 0xaa7832, new Item.Properties()));
    public static final RegistryObject<Item> SEALING_MASTER_SPAWN_EGG = ITEMS.register("sealing_master_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SEALING_MASTER, 0xf0ead8, 0x2c2c6e, new Item.Properties()));
    public static final RegistryObject<Item> TOJI_FUSHIGURO_SPAWN_EGG = ITEMS.register("toji_fushiguro_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.TOJI_FUSHIGURO, 0x101014, 0x76399a, new Item.Properties()));
    public static final RegistryObject<Item> SUGURU_GETO_SPAWN_EGG = ITEMS.register("suguru_geto_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SUGURU_GETO, 0x15151c, 0xc8a050, new Item.Properties()));
    public static final RegistryObject<Item> CURSE_USER_SPAWN_EGG = ITEMS.register("curse_user_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.CURSE_USER, 0x0d0a10, 0x8a1020, new Item.Properties()));
    public static final RegistryObject<Item> HEIAN_SUKUNA_SPAWN_EGG = ITEMS.register("heian_sukuna_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.HEIAN_SUKUNA, 0xd8a640, 0x8a0c1a, new Item.Properties()));
    public static final RegistryObject<Item> RYU_ISHIGORI_SPAWN_EGG = ITEMS.register("ryu_ishigori_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.RYU_ISHIGORI, 0x2a1e1a, 0xe8e0c8, new Item.Properties()));
    public static final RegistryObject<Item> MAHORAGA_SPAWN_EGG = ITEMS.register("mahoraga_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.MAHORAGA, 0xd8d4cc, 0xc9a227, new Item.Properties()));

    private ModItems() {}
}
