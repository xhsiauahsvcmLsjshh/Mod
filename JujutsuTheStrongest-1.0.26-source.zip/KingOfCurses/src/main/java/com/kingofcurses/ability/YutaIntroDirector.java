package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.RikaEntity;
import com.kingofcurses.network.FullFightPacket;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.OpenScreenPacket;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModItems;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * v1.0.25 YUTA OKKOTSU opening (world mode 3). The player IS Yuta: no Yuta actor is spawned, the camera films the player.
 * At dusk he puts on the ring, the shadows behind him boil and Rika rises out of the ground, roars, and sinks back into the ring.
 * Then the game starts with Rika's Ring and Yuta's Katana.
 */
public final class YutaIntroDirector {
    public static final int LENGTH = 620;
    public static final int T_RING = 150, T_DARK = 175, T_RIKA = 215, T_RISEN = 250, T_ROAR = 262, T_SWIPE = 330, T_VANISH = 500, T_GONE = 520, T_END = LENGTH;
    private static final DustParticleOptions LOVE = new DustParticleOptions(new Vector3f(0.62f, 0.32f, 1.0f), 1.6f);
    private static final String KIT = "koc_yuta_kit";

    private static final Map<UUID, Integer> PENDING = new HashMap<>();
    private static final Map<UUID, Scene> SCENES = new HashMap<>();

    private static final class Scene {
        final UUID player; final ServerLevel level; final Vec3 stand; final float yaw;
        int tick, rikaId = -1;
        Scene(UUID p, ServerLevel l, Vec3 stand, float yaw) { player = p; level = l; this.stand = stand; this.yaw = yaw; }
        /** Behind the player, d blocks. */
        Vec3 behind(double d) {
            double r = Math.toRadians(yaw);
            return stand.add(Math.sin(r) * d, 0, -Math.cos(r) * d);
        }
    }

    private YutaIntroDirector() {}

    public static boolean isInScene(UUID id) { return SCENES.containsKey(id) || PENDING.containsKey(id); }
    public static void clear() { SCENES.clear(); PENDING.clear(); }

    public static void schedule(ServerPlayer sp, int delay) {
        if (isInScene(sp.getUUID())) return;
        PENDING.put(sp.getUUID(), delay);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.LOADING, delay + 40, 0f));
    }

    public static void skip(ServerPlayer sp) {
        Scene s = SCENES.remove(sp.getUUID());
        if (s != null) finish(sp, s);
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Integer>> pit = PENDING.entrySet().iterator();
        while (pit.hasNext()) {
            Map.Entry<UUID, Integer> en = pit.next();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) { pit.remove(); continue; }
            int left = en.getValue() - 1;
            if (left > 0 || (!sp.onGround() && left > -100)) { en.setValue(left); continue; }   // wait for the world, at most 5 s more
            pit.remove();
            if (sp.isAlive()) start(sp);
        }
        Iterator<Map.Entry<UUID, Scene>> it = SCENES.entrySet().iterator();
        while (it.hasNext()) {
            Scene s = it.next().getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(s.player);
            if (sp == null || sp.level() != s.level) { cleanup(s); it.remove(); continue; }
            s.tick++;
            if (sp.position().distanceToSqr(s.stand) > 0.05) sp.connection.teleport(s.stand.x, s.stand.y, s.stand.z, s.yaw, 0);
            sp.setDeltaMovement(Vec3.ZERO); sp.fallDistance = 0;
            if (s.tick % 20 == 0) ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.YUTA_SYNC, 0, 0, s.tick, 0, 0, 0));
            if (s.tick % 20 == 0) for (Entity e : s.level.getEntities((Entity) null, new AABB(BlockPos.containing(s.stand)).inflate(24, 12, 24), e -> e instanceof Enemy)) e.discard();
            try { run(s, sp); } catch (RuntimeException ex) {
                com.kingofcurses.KingOfCurses.LOGGER.error("Yuta opening error, skipping", ex);
                it.remove(); finish(sp, s); continue;
            }
            if (s.tick >= T_END) { it.remove(); finish(sp, s); }
        }
    }

    private static void start(ServerPlayer sp) {
        ServerLevel sl = sp.serverLevel();
        Scene s = new Scene(sp.getUUID(), sl, sp.position(), sp.getYRot());
        sl.setDayTime(12600);                                  // sunset
        sl.setWeatherParameters(12000, 0, false, false);
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, LENGTH + 40, 4, true, false, false));
        sp.connection.teleport(s.stand.x, s.stand.y, s.stand.z, s.yaw, 0);
        SCENES.put(sp.getUUID(), s);
        ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.YUTA_START, 0, Math.round(s.yaw * 100), 0,
                (int) Math.floor(s.stand.x * 100), (int) Math.floor(s.stand.y * 100), (int) Math.floor(s.stand.z * 100)));
    }

    private static void sound(ServerLevel sl, Vec3 p, SoundEvent e, float vol, float pitch) { sl.playSound(null, BlockPos.containing(p), e, SoundSource.PLAYERS, vol, pitch); }
    private static void fx(ServerPlayer sp, int type, int dur, float k) { ModNetwork.sendTo(sp, new ScreenFxPacket(type, dur, k)); }

    private static void run(Scene s, ServerPlayer sp) {
        ServerLevel sl = s.level;
        int t = s.tick;
        Vec3 hand = s.stand.add(0, 1.0, 0);
        Vec3 spot = s.behind(2.6);
        // ---- the ring
        if (t == T_RING) { sound(sl, hand, ModSounds.RCT_HEAL.get(), 1.4f, 0.6f); sl.sendParticles(LOVE, hand.x, hand.y, hand.z, 30, 0.2, 0.2, 0.2, 0.02); }
        if (t > T_RING && t < T_RIKA && t % 3 == 0) sl.sendParticles(LOVE, hand.x, hand.y, hand.z, 4, 0.15, 0.15, 0.15, 0.01);
        // ---- the shadows behind him boil
        if (t == T_DARK) { sound(sl, spot, ModSounds.HEARTBEAT.get(), 1.6f, 0.7f); fx(sp, ScreenFxPacket.SHAKE, 20, 0.4f); }
        if (t >= T_DARK && t < T_RISEN && t % 2 == 0) {
            sl.sendParticles(ParticleTypes.SQUID_INK, spot.x, spot.y + 0.2, spot.z, 6, 1.0, 0.1, 1.0, 0.02);
            sl.sendParticles(ParticleTypes.REVERSE_PORTAL, spot.x, spot.y + 0.5, spot.z, 4, 0.8, 0.3, 0.8, 0.04);
        }
        // ---- Rika rises
        if (t == T_RIKA) {
            RikaEntity r = ModEntities.RIKA_ORIMOTO.get().create(sl);
            if (r != null) {
                r.setupCinematic();
                r.moveTo(spot.x, spot.y - 3.2, spot.z, s.yaw, 0);
                r.setYHeadRot(s.yaw); r.setYBodyRot(s.yaw);
                sl.addFreshEntity(r);
                s.rikaId = r.getId();
                ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.YUTA_RIKA, r.getId(), 0, t, 0, 0, 0));
                sound(sl, spot, SoundEvents.WARDEN_EMERGE, 2.0f, 0.8f);
                fx(sp, ScreenFxPacket.SHAKE, 30, 0.8f);
            }
        }
        RikaEntity rika = sl.getEntity(s.rikaId) instanceof RikaEntity rr ? rr : null;
        if (rika != null && t <= T_RISEN) {
            double k = Math.min(1.0, (t - T_RIKA) / (double) (T_RISEN - T_RIKA));
            k = k * k * (3 - 2 * k);
            rika.moveTo(spot.x, spot.y - 3.2 + 3.4 * k, spot.z, s.yaw, 0);
            rika.setYHeadRot(s.yaw); rika.setYBodyRot(s.yaw);
        }
        if (t == T_ROAR && rika != null) {
            rika.triggerAnim("main", "cast");
            sound(sl, spot, SoundEvents.RAVAGER_ROAR, 2.5f, 0.55f);
            sound(sl, spot, ModSounds.CURSE_HURT.get(), 2.0f, 0.5f);
            fx(sp, ScreenFxPacket.SHAKE, 40, 1.2f);
            sl.sendParticles(LOVE, spot.x, spot.y + 3, spot.z, 60, 1.2, 1.2, 1.2, 0.08);
        }
        if (t == T_SWIPE && rika != null) { rika.triggerAnim("main", "slash"); sound(sl, spot, SoundEvents.PLAYER_ATTACK_SWEEP, 1.6f, 0.5f); }
        // ---- back into the ring
        if (t == T_VANISH && rika != null) {
            sl.sendParticles(ParticleTypes.SQUID_INK, spot.x, spot.y + 1.6, spot.z, 50, 1.0, 1.2, 1.0, 0.04);
            sl.sendParticles(LOVE, hand.x, hand.y, hand.z, 40, 0.3, 0.3, 0.3, 0.05);
            sound(sl, hand, ModSounds.CURSED_ENERGY_BURST.get(), 1.2f, 1.2f);
        }
        if (t == T_GONE && rika != null) rika.discard();
    }

    private static void cleanup(Scene s) {
        if (s.level.getEntity(s.rikaId) instanceof RikaEntity r) r.discard();
    }

    private static void finish(ServerPlayer sp, Scene s) {
        cleanup(s);
        ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.YUTA_STOP, 0, 0, 0, 0, 0, 0));
        sp.removeEffect(MobEffects.DAMAGE_RESISTANCE);
        sp.fallDistance = 0;
        CursedData d = KocSync.data(sp);
        d.setIntroSeen(true);
        if (!sp.getPersistentData().getBoolean(KIT)) {   // the kit only once per player
            sp.getPersistentData().putBoolean(KIT, true);
            give(sp, new ItemStack(ModItems.RIKA_RING.get()));
            give(sp, new ItemStack(ModItems.YUTA_KATANA.get()));
            give(sp, new ItemStack(ModItems.JUJUTSU_UNIFORM_CHESTPLATE.get()));
        }
        KocSync.sync(sp);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.yuta_start").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), false);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.yuta_start2").withStyle(ChatFormatting.GRAY), false);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.yuta_start3").withStyle(ChatFormatting.GRAY), false);
        if (d.controlMode() == CursedData.CONTROL_NONE) ModNetwork.sendTo(sp, new OpenScreenPacket(OpenScreenPacket.CONTROL_MODE));
    }

    private static void give(ServerPlayer sp, ItemStack st) { if (!sp.getInventory().add(st)) sp.drop(st, false); }
}
