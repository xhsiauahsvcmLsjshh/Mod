package com.kingofcurses.ability;

import com.kingofcurses.entity.RikaEntity;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * v1.0.25 Yuta Okkotsu's techniques, used through Rika's Ring and Yuta's Katana (no Sukuna fingers needed):
 * summon Rika (5 minutes), Pure Love beam, Cursed Speech "Don't move!", cursed-energy slash, Reverse Cursed Technique.
 */
public final class YutaPowers {
    public static final int RIKA_TICKS = 20 * 60 * 5;
    private static final String RIKA_KEY = "koc_rika", CD = "koc_yuta_cd_";
    private static final DustParticleOptions LOVE = new DustParticleOptions(new Vector3f(0.62f, 0.32f, 1.0f), 2.0f);
    private static final DustParticleOptions WHITE = new DustParticleOptions(new Vector3f(0.95f, 0.95f, 1.0f), 1.4f);
    private YutaPowers() {}

    /** True if the action is ready; otherwise tells the player how long to wait. Starts the cooldown when ready. */
    private static boolean ready(ServerPlayer sp, String key, int ticks) {
        CompoundTag t = sp.getPersistentData();
        long now = sp.serverLevel().getGameTime(), until = t.getLong(CD + key);
        if (now < until) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.yuta_cooldown", (int) Math.ceil((until - now) / 20.0)).withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        t.putLong(CD + key, now + ticks);
        return true;
    }

    /** Hostile creatures, and anything that is attacking the player. Never players, Rika or pets. */
    public static boolean isFoe(ServerPlayer sp, Entity e) {
        if (!(e instanceof LivingEntity le) || !le.isAlive() || e == sp || e instanceof Player || e instanceof RikaEntity) return false;
        if (e instanceof TamableAnimal ta && ta.isTame()) return false;
        return e instanceof Enemy || (e instanceof Mob m && m.getTarget() == sp) || KocTargets.isFoe(le);
    }

    public static RikaEntity rika(ServerPlayer sp) {
        CompoundTag t = sp.getPersistentData();
        if (!t.hasUUID(RIKA_KEY)) return null;
        UUID id = t.getUUID(RIKA_KEY);
        Entity e = sp.serverLevel().getEntity(id);
        return e instanceof RikaEntity r && r.isAlive() && r.isOwnedBy(sp) ? r : null;
    }

    // ------------------------------------------------------------------ Rika's Ring
    public static void ring(ServerPlayer sp) {
        RikaEntity r = rika(sp);
        if (sp.isShiftKeyDown()) { cursedSpeech(sp); return; }
        if (r == null) summon(sp); else pureLove(sp, r);
    }

    private static void summon(ServerPlayer sp) {
        if (!ready(sp, "rika", 20 * 30)) return;
        ServerLevel sl = sp.serverLevel();
        RikaEntity r = ModEntities.RIKA_ORIMOTO.get().create(sl);
        if (r == null) return;
        Vec3 back = sp.getLookAngle().multiply(1, 0, 1);
        if (back.lengthSqr() < 1.0E-4) back = new Vec3(0, 0, 1);
        back = back.normalize().scale(-2.5);
        r.moveTo(sp.getX() + back.x, sp.getY(), sp.getZ() + back.z, sp.getYRot(), 0);
        r.bind(sp, RIKA_TICKS);
        sl.addFreshEntity(r);
        r.triggerAnim("main", "rise");
        sp.getPersistentData().putUUID(RIKA_KEY, r.getUUID());
        sl.sendParticles(ParticleTypes.SQUID_INK, r.getX(), r.getY() + 0.5, r.getZ(), 50, 1.0, 0.3, 1.0, 0.04);
        sl.sendParticles(LOVE, r.getX(), r.getY() + 2, r.getZ(), 60, 0.8, 1.2, 0.8, 0.05);
        sl.playSound(null, r.blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.6f, 0.6f);
        sl.playSound(null, r.blockPosition(), ModSounds.CURSE_AMBIENT.get(), SoundSource.PLAYERS, 1.2f, 0.7f);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.rika_summon").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), true);
    }

    /** Yuta and Rika fire one beam together, straight where he looks. */
    private static void pureLove(ServerPlayer sp, RikaEntity r) {
        if (!ready(sp, "beam", 20 * 15)) return;
        ServerLevel sl = sp.serverLevel();
        Vec3 eye = sp.getEyePosition(), dir = sp.getLookAngle().normalize();
        r.triggerAnim("main", "cast");
        Set<Integer> hit = new HashSet<>();
        for (double d = 1.5; d <= 32; d += 0.5) {
            Vec3 p = eye.add(dir.scale(d));
            if (!sl.getBlockState(net.minecraft.core.BlockPos.containing(p)).getCollisionShape(sl, net.minecraft.core.BlockPos.containing(p)).isEmpty()) {
                sl.sendParticles(ParticleTypes.EXPLOSION, p.x, p.y, p.z, 1, 0, 0, 0, 0);
                break;
            }
            if (((int) (d * 2)) % 2 == 0) {
                sl.sendParticles(LOVE, p.x, p.y, p.z, 3, 0.15, 0.15, 0.15, 0);
                sl.sendParticles(WHITE, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0);
            }
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(p, p).inflate(1.4), e -> isFoe(sp, e))) {
                if (!hit.add(e.getId())) continue;
                e.invulnerableTime = 0;
                e.hurt(sp.damageSources().indirectMagic(r, sp), 26f);
                e.setDeltaMovement(e.getDeltaMovement().add(dir.scale(1.2)).add(0, 0.3, 0)); e.hurtMarked = true;
            }
        }
        sl.playSound(null, sp.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 2.0f, 0.7f);
        sl.playSound(null, sp.blockPosition(), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.PLAYERS, 1.4f, 0.8f);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.pure_love").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), true);
    }

    /** Copied from Inumaki: "Don't move!". Every foe around freezes; it hurts Yuta's throat a little. */
    private static void cursedSpeech(ServerPlayer sp) {
        if (!ready(sp, "speech", 20 * 20)) return;
        ServerLevel sl = sp.serverLevel();
        int n = 0;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(14), e -> isFoe(sp, e))) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 9, false, true));
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 3, false, true));
            if (e instanceof Mob m) m.getNavigation().stop();
            sl.sendParticles(ParticleTypes.ENCHANT, e.getX(), e.getY() + e.getBbHeight(), e.getZ(), 20, 0.3, 0.3, 0.3, 0.4);
            n++;
        }
        sp.hurt(sp.damageSources().magic(), 2f);
        sl.sendParticles(WHITE, sp.getX(), sp.getEyeY(), sp.getZ(), 30, 0.4, 0.2, 0.4, 0.05);
        sl.playSound(null, sp.blockPosition(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.PLAYERS, 1.6f, 0.6f);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.cursed_speech", n).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), true);
    }

    // ------------------------------------------------------------------ Yuta's Katana
    public static void katana(ServerPlayer sp) {
        if (sp.isShiftKeyDown()) { reverseTechnique(sp); return; }
        if (!ready(sp, "slash", 25)) return;
        ServerLevel sl = sp.serverLevel();
        Vec3 dir = sp.getLookAngle().multiply(1, 0, 1);
        if (dir.lengthSqr() < 1.0E-4) dir = new Vec3(0, 0, 1);
        dir = dir.normalize();
        Vec3 c = sp.position().add(0, 1.1, 0);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(6), e -> isFoe(sp, e))) {
            Vec3 to = e.position().subtract(sp.position()).multiply(1, 0, 1);
            if (to.lengthSqr() > 36 || (to.lengthSqr() > 0.01 && to.normalize().dot(dir) < 0.35)) continue;
            e.invulnerableTime = 0;
            e.hurt(sp.damageSources().playerAttack(sp), 12f);
            sl.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ(), 10, 0.2, 0.2, 0.2, 0.3);
        }
        for (int i = -2; i <= 2; i++) {
            Vec3 side = new Vec3(-dir.z, 0, dir.x).scale(i * 0.9);
            Vec3 p = c.add(dir.scale(3)).add(side);
            sl.sendParticles(ParticleTypes.SWEEP_ATTACK, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            sl.sendParticles(LOVE, p.x, p.y, p.z, 2, 0.1, 0.1, 0.1, 0);
        }
        sl.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.4f, 0.8f);
    }

    private static void reverseTechnique(ServerPlayer sp) {
        if (!ready(sp, "rct", 20 * 25)) return;
        ServerLevel sl = sp.serverLevel();
        sp.heal(10f);
        sp.removeEffect(MobEffects.POISON); sp.removeEffect(MobEffects.WITHER);
        sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, sp.getX(), sp.getY() + 1, sp.getZ(), 24, 0.4, 0.7, 0.4, 0);
        sl.sendParticles(WHITE, sp.getX(), sp.getY() + 1, sp.getZ(), 30, 0.5, 0.8, 0.5, 0.02);
        sl.playSound(null, sp.blockPosition(), ModSounds.RCT_HEAL.get(), SoundSource.PLAYERS, 1.0f, 1.2f);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.yuta_rct").withStyle(ChatFormatting.GREEN), true);
    }
}
