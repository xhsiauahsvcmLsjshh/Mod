package com.kingofcurses.client.trailer;

import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/** Each actor carries its own geo / texture / animation files. */
public final class TrailerGeoModel extends GeoModel<TrailerActor> {
    @Override
    public ResourceLocation getModelResource(TrailerActor a) { return a.model; }

    @Override
    public ResourceLocation getTextureResource(TrailerActor a) { return a.texture; }

    @Override
    public ResourceLocation getAnimationResource(TrailerActor a) { return a.animation; }

    @Override
    public RenderType getRenderType(TrailerActor a, ResourceLocation texture) {
        // fire is additive and self-lit (cheap on Mali: no extra passes); the rest is plain cutout
        return a.emissive ? RenderType.eyes(texture) : RenderType.entityCutoutNoCull(texture);
    }
}
