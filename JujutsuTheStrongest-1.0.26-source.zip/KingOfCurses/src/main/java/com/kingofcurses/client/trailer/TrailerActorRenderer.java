package com.kingofcurses.client.trailer;

import software.bernie.geckolib.core.object.Color;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** GeckoLib object renderer: draws a TrailerActor anywhere (no level needed), tinted by the scene light. */
public final class TrailerActorRenderer extends GeoObjectRenderer<TrailerActor> {
    public TrailerActorRenderer(boolean glowLayer) {
        super(new TrailerGeoModel());
        if (glowLayer) addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    @Override
    public Color getRenderColor(TrailerActor a, float partialTick, int packedLight) {
        int r = (int) (a.red * 255f), g = (int) (a.green * 255f), b = (int) (a.blue * 255f);
        return new Color(0xFF000000 | (r << 16) | (g << 8) | b);
    }
}
