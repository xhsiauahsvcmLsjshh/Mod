package com.kingofcurses.client;

import com.kingofcurses.ability.YutaIntroDirector;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * v1.0.25 client camera of the Yuta Okkotsu opening. The player is Yuta and stays visible: the camera is a separate marker
 * that films his body, the ring and Rika rising behind him. Every shot is pulled out of walls.
 */
public final class YutaIntroCinematic {
    private static boolean active;
    private static int tick, rikaId = -1;
    private static Entity camera;
    private static Vec3 stand = Vec3.ZERO;
    private static float yaw;
    private static final int[] CUTS = {70, 150, 210, 250, 330, 430, 500};

    private YutaIntroCinematic() {}

    public static boolean active() { return active; }
    public static int tick() { return tick; }

    public static void start(double x, double y, double z, float yawDeg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        stand = new Vec3(x, y, z); yaw = yawDeg; tick = 0; rikaId = -1;
        camera = EntityType.MARKER.create(mc.level);
        if (camera == null) return;
        active = true;
        ClientFx.stopLoading();
        place(stand.add(9, 5, 9), stand.add(0, 1, 0), true);
        mc.setCameraEntity(camera);
    }

    public static void rika(int id) { rikaId = id; }
    public static void sync(int t) { if (active && Math.abs(t - tick) > 8) tick = t; }

    public static void stop() {
        active = false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.setCameraEntity(mc.player);
        camera = null;
    }

    public static void reset() { if (active) stop(); }

    private static void place(Vec3 pos, Vec3 look, boolean snap) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.player != null) {
            var hit = mc.level.clip(new ClipContext(look, pos, ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, mc.player));
            if (hit.getType() == HitResult.Type.BLOCK) {
                Vec3 back = pos.subtract(look);
                double len = back.length(), keep = Math.max(0.8, look.distanceTo(hit.getLocation()) - 0.4);
                if (len > 0.001) pos = look.add(back.scale(keep / len));
            }
        }
        Vec3 d = look.subtract(pos);
        float yw = (float) (Mth.atan2(d.z, d.x) * Mth.RAD_TO_DEG) - 90f;
        float pitch = (float) -(Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * Mth.RAD_TO_DEG);
        if (snap) { camera.xo = pos.x; camera.yo = pos.y; camera.zo = pos.z; camera.yRotO = yw; camera.xRotO = pitch; }
        else { camera.xo = camera.getX(); camera.yo = camera.getY(); camera.zo = camera.getZ(); camera.yRotO = camera.getYRot(); camera.xRotO = camera.getXRot(); }
        while (yw - camera.yRotO > 180) yw -= 360;
        while (yw - camera.yRotO < -180) yw += 360;
        camera.setPos(pos); camera.setYRot(yw); camera.setXRot(pitch);
    }

    private static double k(int a, int b) { double t = Mth.clamp((tick - a) / (double) (b - a), 0, 1); return t * t * (3 - 2 * t); }

    public static void clientTick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || camera == null) { stop(); return; }
        tick++;
        double r = Math.toRadians(yaw);
        Vec3 fwd = new Vec3(-Math.sin(r), 0, Math.cos(r)), side = new Vec3(-fwd.z, 0, fwd.x), up = new Vec3(0, 1, 0);
        Vec3 P = mc.player.getPosition(mc.getFrameTime());
        Entity re = rikaId >= 0 ? mc.level.getEntity(rikaId) : null;
        Vec3 R = re != null ? re.position() : P.subtract(fwd.scale(2.6));
        boolean snap = false;
        for (int c : CUTS) if (c == tick) { snap = true; break; }
        int t = tick;
        if (t < 70) {                                                 // wide orbit at sunset
            double a = r + Math.toRadians(140 + t * 1.2);
            place(P.add(Math.cos(a) * 10, 5 - t * 0.04, Math.sin(a) * 10), P.add(0, 1.2, 0), t == 0);
        } else if (t < 150) {                                         // close on his face
            place(P.add(fwd.scale(2.6 - k(70, 150) * 0.6)).add(side.scale(0.5)).add(up.scale(1.65)), P.add(0, 1.6, 0), snap);
        } else if (t < 210) {                                         // the ring on his hand
            place(P.add(fwd.scale(1.5)).add(side.scale(-1.0)).add(up.scale(1.1)), P.add(side.scale(-0.35)).add(0, 0.8, 0), snap);
        } else if (t < 250) {                                         // the shadows behind him, Rika rising
            place(P.add(fwd.scale(6.5)).add(up.scale(0.6)), P.add(0, 1.8 + k(210, 250) * 1.5, 0), snap);
        } else if (t < 330) {                                         // low angle: Rika looms over Yuta
            place(P.add(fwd.scale(3.6)).add(side.scale(1.8)).add(up.scale(0.3)), R.add(0, 3.6, 0), snap);
        } else if (t < 430) {                                         // over Rika's shoulder onto Yuta
            place(R.subtract(fwd.scale(2.2)).add(side.scale(1.6)).add(up.scale(4.0)), P.add(0, 1.4, 0), snap);
        } else if (t < 500) {                                         // two-shot from the side
            Vec3 mid = P.lerp(R, 0.5);
            place(mid.add(side.scale(7)).add(up.scale(2.2)), mid.add(0, 2, 0), snap);
        } else {                                                      // crane up and away
            double kk = k(500, YutaIntroDirector.T_END);
            place(P.add(fwd.scale(4 + kk * 8)).add(up.scale(2 + kk * 10)), P.add(0, 1, 0), snap);
        }
        if (mc.getCameraEntity() != camera) mc.setCameraEntity(camera);
        if (tick > YutaIntroDirector.T_END + 40) stop();
    }

    public static String subtitle() {
        int t = tick;
        if (t >= 80 && t < 145) return "cinematic.kingofcurses.yuta.y1";
        if (t >= 155 && t < 205) return "cinematic.kingofcurses.yuta.y2";
        if (t >= 262 && t < 320) return "cinematic.kingofcurses.yuta.r1";
        if (t >= 340 && t < 425) return "cinematic.kingofcurses.yuta.y3";
        if (t >= 435 && t < 495) return "cinematic.kingofcurses.yuta.y4";
        return null;
    }

    public static String title() {
        int t = tick;
        if (t >= 14 && t < 66) return "cinematic.kingofcurses.yuta.title";
        if (t >= 270 && t < 326) return "cinematic.kingofcurses.yuta.t_rika";
        return null;
    }

    public static float titleAlpha() {
        int t = tick;
        int[][] r = {{14, 66}, {270, 326}};
        for (int[] p : r) if (t >= p[0] && t < p[1]) return Mth.clamp(Math.min((t - p[0]) / 8f, (p[1] - t) / 8f), 0, 1);
        return 0;
    }

    public static float black() {
        int t = tick;
        if (t < 14) return 1f - t / 14f;
        if (t >= YutaIntroDirector.T_END - 20) return Mth.clamp((t - (YutaIntroDirector.T_END - 20)) / 16f, 0, 1);
        return 0f;
    }
}
