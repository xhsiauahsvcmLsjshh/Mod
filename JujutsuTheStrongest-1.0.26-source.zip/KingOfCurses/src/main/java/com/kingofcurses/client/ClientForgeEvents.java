package com.kingofcurses.client;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.client.screen.AbilityWheelScreen;
import com.kingofcurses.network.AbilityPacket;
import com.kingofcurses.network.CodexActionPacket;
import com.kingofcurses.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-only Forge-bus hooks: input, camera, fog and HUD suppression. */
@Mod.EventBusSubscriber(modid = KingOfCurses.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientFx.tick();
        ClientCinematic.clientTick();
        BodyAnims.tick();
        HeianCinematic.clientTick();
        GojoIntroCinematic.clientTick();
        FullFightCinematic.clientTick();
        YutaIntroCinematic.clientTick();
        if (mc.player == null) return;
        if (YutaIntroCinematic.active()) {   // v1.0.25
            while (KeyBindings.SKIP.consumeClick()) { ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.SKIP_CINEMATIC)); YutaIntroCinematic.stop(); }
            return;
        }
        if (FullFightCinematic.active()) {
            while (KeyBindings.SKIP.consumeClick()) { ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.SKIP_CINEMATIC)); FullFightCinematic.stop(); }
            return;
        }
        if (HeianCinematic.active()) {
            while (KeyBindings.SKIP.consumeClick()) HeianCinematic.stop();
            return;
        }
        if (GojoIntroCinematic.active()) {
            while (KeyBindings.SKIP.consumeClick()) { ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.SKIP_CINEMATIC)); GojoIntroCinematic.stop(); }
            return;
        }
        if (ClientCinematic.active()) {
            while (KeyBindings.SKIP.consumeClick()) {
                ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.SKIP_CINEMATIC));
                ClientCinematic.stop();
            }
            return;
        }
        while (KeyBindings.SKIP.consumeClick()) { /* nothing to skip */ }
        if (mc.screen != null) { while (mc.options.keyShift.consumeClick()) { } return; }
        while (KeyBindings.USE_ABILITY.consumeClick()) ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.USE_SELECTED, 0));
        while (KeyBindings.NEXT_ABILITY.consumeClick()) ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.CYCLE, 0));
        while (KeyBindings.DOMAIN.consumeClick()) ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.DOMAIN, 0));
        while (KeyBindings.CODEX.consumeClick()) ClientHooks.openCodex();
        while (KeyBindings.TOGGLE_CONTROLS.consumeClick()) KeyBindings.showControls = !KeyBindings.showControls;
        while (KeyBindings.RIP_FINGER.consumeClick()) {
            long now = mc.player.tickCount;
            if (now <= KeyBindings.ripConfirmUntil) {
                KeyBindings.ripConfirmUntil = 0;
                ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.RIP_FINGER));
            } else {
                KeyBindings.ripConfirmUntil = now + 60;
                mc.player.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.kingofcurses.rip_confirm", KeyBindings.RIP_FINGER.getTranslatedKeyMessage())
                        .withStyle(net.minecraft.ChatFormatting.RED), true);
            }
        }
        if (KeyBindings.ABILITY_WHEEL.consumeClick()) mc.setScreen(new AbilityWheelScreen());
        while (KeyBindings.TOUCH_PAD.consumeClick()) ClientHooks.openTouchPad();
        while (KeyBindings.BATTLE_HUD.consumeClick()) ClientHooks.openBattleHud();
        while (KeyBindings.FINISHER.consumeClick()) ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.FINISHER, 0));
        // v1.0.12 mobile gesture: double tap SNEAK opens the Technique Pad
        boolean mobile = ClientData.DATA.controlMode() == com.kingofcurses.capability.CursedData.CONTROL_MOBILE;
        while (mc.options.keyShift.consumeClick()) {
            if (!mobile) continue;
            long now = mc.player.tickCount;
            if (now - KeyBindings.lastSneakTap <= 10) { KeyBindings.lastSneakTap = -100; ClientHooks.openTouchPad(); }
            else KeyBindings.lastSneakTap = now;
        }
    }

    /** v1.0.9: KING OF CURSES difficulty switch right on the Create New World screen. */
    @SubscribeEvent
    public static void screenInit(ScreenEvent.Init.Post event) {
        // v1.0.26: TRAILER button on the main menu (top left): a pre-made GeckoLib scene, no world is created
        if (event.getScreen() instanceof net.minecraft.client.gui.screens.TitleScreen title) {
            event.addListener(net.minecraft.client.gui.components.Button.builder(net.minecraft.network.chat.Component.translatable("gui.kingofcurses.trailer"),
                    b -> Minecraft.getInstance().setScreen(new com.kingofcurses.client.trailer.TrailerScreen(title)))
                    .bounds(4, 4, 72, 20).tooltip(net.minecraft.client.gui.components.Tooltip.create(net.minecraft.network.chat.Component.translatable("gui.kingofcurses.trailer_tip"))).build());
            return;
        }
        // v1.0.18: PICK YOUR SIDE on the Create New World screen (the old KING OF CURSES switch is gone: sorcerers follow Hard difficulty)
        if (!(event.getScreen() instanceof net.minecraft.client.gui.screens.worldselection.CreateWorldScreen cws) || com.kingofcurses.ability.KocMode.SIDE == null) return;
        event.addListener(net.minecraft.client.gui.components.Button.builder(sideLabel(cws), b -> {
            net.minecraft.world.level.GameRules rules = cws.getUiState().getGameRules();
            int v = (Math.max(0, Math.min(3, rules.getInt(com.kingofcurses.ability.KocMode.SIDE))) + 1) % 4;   // v1.0.25: History -> Today -> Full Fight Video -> Yuta Okkotsu
            rules.getRule(com.kingofcurses.ability.KocMode.SIDE).set(v, null);
            b.setMessage(sideLabel(cws));
        }).bounds(4, 4, 168, 20).tooltip(net.minecraft.client.gui.components.Tooltip.create(net.minecraft.network.chat.Component.translatable("gui.kingofcurses.create.side_tip"))).build());
    }

    private static net.minecraft.network.chat.Component sideLabel(net.minecraft.client.gui.screens.worldselection.CreateWorldScreen cws) {
        int mode = cws.getUiState().getGameRules().getInt(com.kingofcurses.ability.KocMode.SIDE);
        String key = mode == 3 ? "gui.kingofcurses.create.side_yuta" : mode == 2 ? "gui.kingofcurses.create.side_fullfight" : mode == 1 ? "gui.kingofcurses.create.side_today" : "gui.kingofcurses.create.side_history";
        return net.minecraft.network.chat.Component.translatable("gui.kingofcurses.create.side",
                net.minecraft.network.chat.Component.translatable(key)
                        .withStyle(mode == 3 ? net.minecraft.ChatFormatting.WHITE : mode == 2 ? net.minecraft.ChatFormatting.LIGHT_PURPLE : mode == 1 ? net.minecraft.ChatFormatting.AQUA : net.minecraft.ChatFormatting.RED));
    }

    @SubscribeEvent
    public static void hideHud(RenderGuiOverlayEvent.Pre event) {
        if ((ClientCinematic.active() || HeianCinematic.active() || GojoIntroCinematic.active() || FullFightCinematic.active() || YutaIntroCinematic.active() || ClientFx.loading() >= 0) && !event.getOverlay().id().getNamespace().equals(KingOfCurses.MODID)) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void hand(RenderHandEvent event) {
        if (ClientCinematic.active() || HeianCinematic.active() || GojoIntroCinematic.active() || FullFightCinematic.active() || YutaIntroCinematic.active()) { event.setCanceled(true); return; }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        float t = RipAnim.progress(mc.player.getId(), event.getPartialTick());
        if (t < 0) {
            // v1.0.7: no hand to draw when the arm is gone, still regrowing, or during the awakening
            if (BodyAnims.roar(mc.player.getId(), event.getPartialTick()) > 0) { event.setCanceled(true); return; }
            if (BodyAnims.finisher(mc.player.getId(), event.getPartialTick()) >= 0 && BodyAnims.finisherKind(mc.player.getId()) != 7) { event.setCanceled(true); return; }
            boolean mainRight = mc.player.getMainArm() == net.minecraft.world.entity.HumanoidArm.RIGHT;
            boolean rightHand = (event.getHand() == net.minecraft.world.InteractionHand.MAIN_HAND) == mainRight;
            int bit = rightHand ? com.kingofcurses.capability.CursedData.ARM_RIGHT : com.kingofcurses.capability.CursedData.ARM_LEFT;
            float rg = BodyAnims.regrow(mc.player.getId(), bit, event.getPartialTick());
            if ((ClientData.DATA.lostArms() & bit) != 0 || (rg >= 0 && rg < 0.6f)) event.setCanceled(true);
            return;
        }
        event.setCanceled(true);
        if (event.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        if (!(mc.getEntityRenderDispatcher().getRenderer(mc.player) instanceof net.minecraft.client.renderer.entity.player.PlayerRenderer pr)) return;
        float up = RipAnim.raise(t), tug = RipAnim.tug(t), sh = RipAnim.shake(t, mc.player.tickCount + event.getPartialTick());
        firstPersonArm(event, pr, mc.player, true, up, tug, sh);
        firstPersonArm(event, pr, mc.player, false, up, tug, sh);
    }

    /** First-person version of the ripping pose, built on the vanilla empty-hand transform. */
    private static void firstPersonArm(RenderHandEvent event, net.minecraft.client.renderer.entity.player.PlayerRenderer pr, net.minecraft.client.player.AbstractClientPlayer player,
                                       boolean right, float up, float tug, float sh) {
        com.mojang.blaze3d.vertex.PoseStack pose = event.getPoseStack();
        float f = right ? 1.0f : -1.0f;
        float lift = up * (right ? 0.9f : 1.0f) - (right ? tug * 0.55f : 0f);
        pose.pushPose();
        pose.translate(f * (0.64f - up * 0.42f + (right ? tug * 0.25f : 0f)) + sh, -0.6f - 0.6f * (1f - lift) + 0.35f * lift, -0.72f);
        pose.mulPose(com.mojang.math.Axis.YP.rotationDegrees(f * (45.0f - up * 25f)));
        pose.mulPose(com.mojang.math.Axis.XP.rotationDegrees(-up * 25f + (right ? tug * 30f : 0f)));
        pose.translate(f * -1.0f, 3.6f, 3.5f);
        pose.mulPose(com.mojang.math.Axis.ZP.rotationDegrees(f * 120.0f));
        pose.mulPose(com.mojang.math.Axis.XP.rotationDegrees(200.0f));
        pose.mulPose(com.mojang.math.Axis.YP.rotationDegrees(f * -135.0f));
        pose.translate(f * 5.6f, 0.0f, 0.0f);
        if (right) pr.renderRightHand(pose, event.getMultiBufferSource(), event.getPackedLight(), player);
        else pr.renderLeftHand(pose, event.getMultiBufferSource(), event.getPackedLight(), player);
        pose.popPose();
    }

    private static final java.util.Set<Object> DUSTED = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<>());
    private static final java.util.Map<net.minecraft.client.model.geom.ModelPart, Boolean> SLEEVES = new java.util.IdentityHashMap<>();
    public static boolean sleeveWasVisible(net.minecraft.client.model.geom.ModelPart sleeve) { return SLEEVES.getOrDefault(sleeve, false); }

    /** Third person: hide the vanilla arms while ripping; RipArmsLayer draws them in the ripping pose. */
    @SubscribeEvent
    public static void playerPre(RenderPlayerEvent.Pre event) {
        if (!(event.getEntity() instanceof net.minecraft.client.player.AbstractClientPlayer acp)) return;
        float dust = BodyAnims.dust(acp.getId(), event.getPartialTick());
        if (dust >= 0) {
            if (dust >= 0.95f) { event.setCanceled(true); return; }
            net.minecraft.client.model.PlayerModel<?> m = event.getRenderer().getModel();
            DUSTED.add(m);
            if (dust > 0.15f) { m.rightLeg.visible = false; m.leftLeg.visible = false; m.rightPants.visible = false; m.leftPants.visible = false; }
            if (dust > 0.40f) { m.rightArm.visible = false; m.leftArm.visible = false; m.rightSleeve.visible = false; m.leftSleeve.visible = false; }
            if (dust > 0.62f) { m.body.visible = false; m.jacket.visible = false; }
            if (dust > 0.80f) { m.head.visible = false; m.hat.visible = false; }
            return;
        }
        int hide = com.kingofcurses.client.renderer.ArmStateLayer.hiddenArms(acp, event.getPartialTick());
        if (hide == 0) return;
        net.minecraft.client.model.PlayerModel<?> m = event.getRenderer().getModel();
        SLEEVES.put(m.rightSleeve, m.rightSleeve.visible);
        SLEEVES.put(m.leftSleeve, m.leftSleeve.visible);
        if ((hide & 1) != 0) { m.rightArm.visible = false; m.rightSleeve.visible = false; }
        if ((hide & 2) != 0) { m.leftArm.visible = false; m.leftSleeve.visible = false; }
    }

    @SubscribeEvent
    public static void playerPost(RenderPlayerEvent.Post event) {
        net.minecraft.client.model.PlayerModel<?> m = event.getRenderer().getModel();
        if (DUSTED.remove(m)) {   // the next player drawn with this model must look normal again (layers keep their own state)
            m.setAllVisible(true);
            if (event.getEntity() instanceof net.minecraft.client.player.AbstractClientPlayer acp) {
                m.hat.visible = acp.isModelPartShown(net.minecraft.world.entity.player.PlayerModelPart.HAT);
                m.jacket.visible = acp.isModelPartShown(net.minecraft.world.entity.player.PlayerModelPart.JACKET);
                m.leftPants.visible = acp.isModelPartShown(net.minecraft.world.entity.player.PlayerModelPart.LEFT_PANTS_LEG);
                m.rightPants.visible = acp.isModelPartShown(net.minecraft.world.entity.player.PlayerModelPart.RIGHT_PANTS_LEG);
                m.leftSleeve.visible = acp.isModelPartShown(net.minecraft.world.entity.player.PlayerModelPart.LEFT_SLEEVE);
                m.rightSleeve.visible = acp.isModelPartShown(net.minecraft.world.entity.player.PlayerModelPart.RIGHT_SLEEVE);
            }
            return;
        }
        if (SLEEVES.containsKey(m.rightSleeve)) {
            m.rightArm.visible = true; m.leftArm.visible = true;
            m.rightSleeve.visible = SLEEVES.remove(m.rightSleeve);
            m.leftSleeve.visible = SLEEVES.remove(m.leftSleeve);
        }
    }

    @SubscribeEvent
    public static void camera(ViewportEvent.ComputeCameraAngles event) {
        Minecraft mc = Minecraft.getInstance();
        float shake = ClientFx.shakeAmount();
        if (ClientFx.takeoverActive()) shake = Math.max(shake, 0.25f);
        if (shake > 0 && mc.level != null) {
            float t = (float) (mc.level.getGameTime() + event.getPartialTick());
            event.setYaw(event.getYaw() + Mth.sin(t * 2.1f) * 2.0f * shake);
            event.setPitch(event.getPitch() + Mth.cos(t * 2.7f) * 1.6f * shake);
            event.setRoll(event.getRoll() + Mth.sin(t * 1.3f) * 2.5f * shake);
        }
        float kick = ClientFx.castKick();
        if (kick > 0) event.setPitch(event.getPitch() - kick);
    }

    @SubscribeEvent
    public static void fogColor(ViewportEvent.ComputeFogColor event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && ClientData.insideDomain(mc.player.position())) {
            event.setRed(0.22f); event.setGreen(0.0f); event.setBlue(0.02f);
        } else if (ClientFx.takeoverActive()) {
            event.setRed(Math.max(event.getRed(), 0.3f)); event.setGreen(event.getGreen() * 0.3f); event.setBlue(event.getBlue() * 0.3f);
        }
    }

    @SubscribeEvent
    public static void fog(ViewportEvent.RenderFog event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && ClientData.insideDomain(mc.player.position())) {
            event.setNearPlaneDistance(2.0f);
            event.setFarPlaneDistance(Math.min(event.getFarPlaneDistance(), 34.0f));
            event.setCanceled(true);
        }
    }

    /** v1.0.22: the viewer is not part of the Full Fight Video. */
    @SubscribeEvent(priority = net.minecraftforge.eventbus.api.EventPriority.HIGHEST)
    public static void hideViewer(RenderPlayerEvent.Pre event) {
        if (FullFightCinematic.active() && event.getEntity() == Minecraft.getInstance().player) event.setCanceled(true);
    }

    /** v1.0.19: during the Strongest of Today opening the player's own body falls to the ground and gets back up. */
    private static boolean liePushed = false;

    @SubscribeEvent(priority = net.minecraftforge.eventbus.api.EventPriority.LOWEST)
    public static void lieDown(RenderPlayerEvent.Pre event) {
        if (event.isCanceled()) return;
        float lie = BodyAnims.introLie(event.getEntity().getId(), event.getPartialTick());
        if (lie <= 0f) return;
        float yaw = Mth.rotLerp(event.getPartialTick(), event.getEntity().yBodyRotO, event.getEntity().yBodyRot);
        com.mojang.blaze3d.vertex.PoseStack ps = event.getPoseStack();
        ps.pushPose();
        liePushed = true;
        // v1.0.21: same frame as the vanilla death fall (Y(180-yaw) then Z), so he falls cleanly on his side
        ps.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180f - yaw));
        ps.mulPose(com.mojang.math.Axis.ZP.rotationDegrees(90f * lie));
        ps.mulPose(com.mojang.math.Axis.YP.rotationDegrees(yaw - 180f));
    }

    @SubscribeEvent
    public static void lieDownEnd(RenderPlayerEvent.Post event) {
        if (liePushed) { event.getPoseStack().popPose(); liePushed = false; }
    }

    @SubscribeEvent
    public static void bossBar(CustomizeGuiOverlayEvent.BossEventProgress event) {
        com.kingofcurses.client.overlay.KocOverlays.bossBottom = Math.max(com.kingofcurses.client.overlay.KocOverlays.bossBottom, event.getY() + 10);
    }

    @SubscribeEvent
    public static void movement(MovementInputUpdateEvent event) {
        Input in = event.getInput();
        if (ClientCinematic.active() || HeianCinematic.active() || GojoIntroCinematic.active() || FullFightCinematic.active() || YutaIntroCinematic.active()) {
            in.forwardImpulse = 0; in.leftImpulse = 0; in.up = in.down = in.left = in.right = false; in.jumping = false; in.shiftKeyDown = false;
        } else if (ClientFx.takeoverActive()) {
            in.forwardImpulse *= 0.25f; in.leftImpulse *= -0.25f; in.jumping = false; // limited, inverted control
        }
    }

    @SubscribeEvent
    public static void interaction(InputEvent.InteractionKeyMappingTriggered event) {
        if (ClientCinematic.active() || HeianCinematic.active() || GojoIntroCinematic.active() || FullFightCinematic.active() || YutaIntroCinematic.active() || ClientFx.takeoverActive()) { event.setSwingHand(false); event.setCanceled(true); return; }
        // v1.0.12 mobile gesture: SNEAK + ATTACK (tap) casts the selected technique, whatever you hold
        Minecraft mc = Minecraft.getInstance();
        if (event.isAttack() && mc.player != null && mc.player.isShiftKeyDown()
                && ClientData.DATA.controlMode() == com.kingofcurses.capability.CursedData.CONTROL_MOBILE) {
            event.setSwingHand(false);
            event.setCanceled(true);
            // v1.0.14: with the Vigor bar full, Sneak + Attack performs the finisher
            ModNetwork.sendToServer(new AbilityPacket(ClientData.DATA.finisherReady() ? AbilityPacket.FINISHER : AbilityPacket.USE_SELECTED, 0));
        }
    }

    @SubscribeEvent
    public static void loggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientCinematic.reset();
        HeianCinematic.reset();
        GojoIntroCinematic.reset();
        FullFightCinematic.reset();
        YutaIntroCinematic.reset();
        ClientFx.reset();
        ClientData.reset();
    }
}
