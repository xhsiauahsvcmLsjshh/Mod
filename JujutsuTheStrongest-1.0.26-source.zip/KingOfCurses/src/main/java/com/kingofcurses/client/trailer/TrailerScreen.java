package com.kingofcurses.client.trailer;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.registry.ModSounds;
import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.shaders.FogShape;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexSorting;
import com.mojang.math.Axis;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.Musics;
import net.minecraft.sounds.SoundEvent;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;
import software.bernie.geckolib.core.animation.RawAnimation;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * v1.0.26 main-menu TRAILER. A pre-made scene: no world is created or loaded.
 * GeckoLib puppets (Sukuna, Jogo, fire, meteor, Fuga arrow) on a small painted set (ruined street at night), a scripted camera,
 * subtitles and the title. Timeline in ticks (20 per second), clock = real time since the screen opened.
 *   0  wide shot            70  Sukuna lights the flame     130 close-up: "Fuga." (voice + English subtitle)
 *   185 over the shoulder: the bow     245 Jogo: Maximum: Meteor     320 wide: arrow vs meteor, explosion
 *   372 Jogo in flames collapses       440 "Be proud. You are strong."   480 title at the top     END
 */
public class TrailerScreen extends Screen {
    public static final float END = 580f;

    private static final String M = KingOfCurses.MODID;
    private static ResourceLocation rl(String p) { return new ResourceLocation(M, p); }
    private static final ResourceLocation T_GROUND = rl("textures/trailer/ground.png");
    private static final ResourceLocation T_WALL = rl("textures/trailer/wall.png");
    private static final ResourceLocation T_WALL_BURNT = rl("textures/trailer/wall_burnt.png");
    private static final ResourceLocation T_RUBBLE = rl("textures/trailer/rubble.png");
    private static final ResourceLocation T_GLOW = rl("textures/trailer/glow.png");
    private static final ResourceLocation T_RING = rl("textures/trailer/ring.png");
    private static final ResourceLocation T_JOGO = rl("textures/trailer/trailer_jogo.png");
    private static final ResourceLocation T_JOGO_BURNT = rl("textures/trailer/trailer_jogo_burnt.png");
    private static final ResourceLocation[] BOX_TEX = {T_WALL, T_WALL_BURNT, T_RUBBLE};

    private static final RawAnimation SUK_STAND = RawAnimation.begin().thenPlay("animation.trailer_sukuna.stand");
    private static final RawAnimation SUK_IGNITE = RawAnimation.begin().thenPlay("animation.trailer_sukuna.ignite");
    private static final RawAnimation SUK_DRAW = RawAnimation.begin().thenPlay("animation.trailer_sukuna.draw");
    private static final RawAnimation SUK_RELEASE = RawAnimation.begin().thenPlay("animation.trailer_sukuna.release");
    private static final RawAnimation JOGO_IDLE = RawAnimation.begin().thenPlay("animation.trailer_jogo.idle");
    private static final RawAnimation JOGO_METEOR = RawAnimation.begin().thenPlay("animation.trailer_jogo.meteor");
    private static final RawAnimation JOGO_THROW = RawAnimation.begin().thenPlay("animation.trailer_jogo.throw");
    private static final RawAnimation JOGO_BURN = RawAnimation.begin().thenPlay("animation.trailer_jogo.burn");
    private static final RawAnimation FIRE = RawAnimation.begin().thenPlay("animation.trailer_fire.burn");
    private static final RawAnimation METEOR_SPIN = RawAnimation.begin().thenPlay("animation.trailer_meteor.spin");
    private static final RawAnimation ARROW_SPIN = RawAnimation.begin().thenPlay("animation.fuga_arrow.idle");

    // stage marks (blocks)
    private static final float SX = -5f, JX = 5f;
    private static final float SUK_YAW = -90f, JOGO_YAW = 90f;      // Sukuna looks +X, Jogo looks -X
    private static final float[][] GROUND_FIRES = {{-12, -6, 2.2f}, {-2, 7, 1.6f}, {9, -7, 2.6f}, {16, 5, 2.0f}, {-20, 4, 2.4f}, {3, -8.5f, 1.4f}, {24, -6, 3f}};

    private final Screen parent;
    private long startMs = -1L;
    private float lastCue = -1f;
    private final List<SoundInstance> playing = new ArrayList<>();
    private final List<float[]> boxes = new ArrayList<>();   // x0 y0 z0 x1 y1 z1 tex tile

    private TrailerActor sukuna, jogo, fire, meteor, arrow;
    private TrailerActorRenderer rSukuna, rJogo, rFire, rMeteor, rArrow;

    // per-frame fx state (computed once per frame, read by light() for every vertex: no allocations there)
    private float[] fHand = new float[3], fArrow, fMeteor;
    private final float[] lc = new float[3];
    // per-frame camera
    private float camX, camY, camZ, camYaw, camPitch, camFov;
    private float fwX, fwY, fwZ, rtX, rtY, rtZ, upX, upY, upZ;

    public TrailerScreen(Screen parent) {
        super(Component.translatable("gui.kingofcurses.trailer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        if (sukuna == null) {
            sukuna = new TrailerActor(rl("geo/entity/ryomen_sukuna.geo.json"), rl("textures/entity/ryomen_sukuna.png"), rl("animations/trailer/trailer_sukuna.animation.json"), false, SUK_STAND);
            jogo = new TrailerActor(rl("geo/trailer/trailer_jogo.geo.json"), rl("textures/trailer/trailer_jogo.png"), rl("animations/trailer/trailer_jogo.animation.json"), false, JOGO_IDLE);
            fire = new TrailerActor(rl("geo/trailer/trailer_fire.geo.json"), rl("textures/trailer/trailer_fire.png"), rl("animations/trailer/trailer_fire.animation.json"), true, FIRE);
            meteor = new TrailerActor(rl("geo/trailer/trailer_meteor.geo.json"), rl("textures/trailer/trailer_meteor.png"), rl("animations/trailer/trailer_meteor.animation.json"), false, METEOR_SPIN);
            arrow = new TrailerActor(rl("geo/entity/fuga_arrow.geo.json"), rl("textures/entity/fuga_arrow.png"), rl("animations/entity/fuga_arrow.animation.json"), true, ARROW_SPIN);
            rSukuna = new TrailerActorRenderer(true);
            rJogo = new TrailerActorRenderer(true);
            rFire = new TrailerActorRenderer(false);
            rMeteor = new TrailerActorRenderer(true);
            rArrow = new TrailerActorRenderer(false);
            buildSet();
        }
        if (minecraft != null) minecraft.getMusicManager().stopPlaying();
    }

    @Override
    public boolean isPauseScreen() { return false; }

    private float clock() { return startMs < 0 ? 0f : (Util.getMillis() - startMs) / 50f; }

    @Override
    public void tick() {
        if (minecraft == null) return;
        if (minecraft.getMusicManager().isPlayingMusic(Musics.MENU)) minecraft.getMusicManager().stopPlaying();
        if (clock() >= END) onClose();
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.setScreen(parent);
    }

    @Override
    public void removed() {
        if (minecraft != null) for (SoundInstance s : playing) minecraft.getSoundManager().stop(s);
        playing.clear();
    }

    // ------------------------------------------------------------------ sounds
    private void cues(float t) {
        cue(t, 0, ModSounds.TRAILER_THEME.get(), 0.9f, 1f);
        cue(t, 85, ModSounds.FUGA_IGNITE.get(), 0.8f, 0.8f);
        cue(t, 140, ModSounds.TRAILER_FUGA.get(), 1.0f, 1f);
        cue(t, 190, ModSounds.FUGA_IGNITE.get(), 0.9f, 1.1f);
        cue(t, 255, ModSounds.TRAILER_METEOR.get(), 1.0f, 1f);
        cue(t, 320, ModSounds.CURSED_ENERGY_BURST.get(), 0.9f, 1.3f);
        cue(t, 336, ModSounds.FUGA_EXPLODE.get(), 1.0f, 1.0f);
        cue(t, 350, ModSounds.FUGA_EXPLODE.get(), 1.0f, 0.7f);
        cue(t, 372, ModSounds.TRAILER_BURN.get(), 0.9f, 1f);
        cue(t, 440, ModSounds.SUKUNA_VOICE.get(), 0.6f, 0.85f);
        lastCue = t;
    }

    private void cue(float t, float at, SoundEvent ev, float vol, float pitch) {
        if (minecraft == null || ev == null || !(lastCue < at && t >= at)) return;
        SoundInstance s = SimpleSoundInstance.forUI(ev, pitch, vol);
        minecraft.getSoundManager().play(s);
        playing.add(s);
    }

    // ------------------------------------------------------------------ set (built once)
    private void buildSet() {
        Random r = new Random(1026L);
        for (int side = -1; side <= 1; side += 2) {
            float x = -46f;
            while (x < 46f) {
                float w = 5 + r.nextInt(5), d = 6 + r.nextInt(6), h = 8 + r.nextInt(22);
                float zn = side * (11f + r.nextInt(2)), zf = zn + side * d;
                int tex = r.nextInt(3) == 0 ? 1 : 0;
                boolean broken = r.nextInt(100) < 35;
                float hh = broken ? Math.max(5f, h * 0.6f) : h;
                box(x, 0, Math.min(zn, zf), x + w, hh, Math.max(zn, zf), tex, 4f);
                if (broken) box(x + 1, hh, Math.min(zn, zf) + 1, x + w * 0.5f, hh + 2 + r.nextInt(4), Math.max(zn, zf) - 1, 1, 4f);
                x += w + 1 + r.nextInt(2);
            }
            float sx = -64f;                                                 // skyline far behind
            while (sx < 64f) {
                float w = 8 + r.nextInt(7), h = 18 + r.nextInt(28);
                float z0 = side * 30f, z1 = side * (36f + r.nextInt(4));
                box(sx, 0, Math.min(z0, z1), sx + w, h, Math.max(z0, z1), r.nextInt(2), 8f);
                sx += w + 2 + r.nextInt(3);
            }
        }
        box(50, 0, -12, 58, 26, 12, 0, 8f);     // street ends
        box(-58, 0, -12, -50, 24, 12, 1, 8f);
        float[][] rubble = {{-10, -7, 3, 1.2f, 2}, {8, 6.5f, 2.5f, 1f, 2}, {-1, -7.5f, 2, 0.8f, 1.5f}, {13, -3, 1.5f, 0.6f, 1.5f}, {-16, 6, 3, 1.4f, 2.5f}, {20, 7, 2, 1f, 2}};
        for (float[] b : rubble) box(b[0] - b[2], 0, b[1] - b[4] / 2, b[0] + b[2], b[3], b[1] + b[4] / 2, 2, 2f);
    }

    private void box(float x0, float y0, float z0, float x1, float y1, float z1, int tex, float tile) {
        boxes.add(new float[]{x0, y0, z0, x1, y1, z1, tex, tile});
    }

    // ------------------------------------------------------------------ helpers
    private static float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
    private static float smooth(float v) { v = clamp01(v); return v * v * (3 - 2 * v); }
    private static float lerp(float a, float b, float f) { return a + (b - a) * f; }
    private static float seg(float t, float a, float b) { return clamp01((t - a) / (b - a)); }

    /** model-space offset (blocks, front = -Z) of an actor placed at (bx,by,bz) with yaw (deg) -> world */
    private static float[] local(float bx, float by, float bz, float yawDeg, float lx, float ly, float lz) {
        double a = Math.toRadians(yawDeg); float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{bx + lx * c + lz * s, by + ly, bz - lx * s + lz * c};
    }

    private static float[] handFlame() { return local(SX, 0, 0, SUK_YAW, -0.375f, 1.51f, -0.61f); }
    private static float[] bowPoint() { return local(SX, 0, 0, SUK_YAW, 0.05f, 1.40f, -0.62f); }

    /** meteor center and scale (0 = not there) */
    private static float[] meteorState(float t) {
        if (t < 255 || t >= 340) return null;
        float grow = smooth(seg(t, 255, 300));
        float s = lerp(0.2f, 4f, grow);
        if (t < 322) return new float[]{JX, 6.2f + 0.15f * (float) Math.sin(t * 0.2f), 0, s};
        float f = seg(t, 322, 336);
        float[] p = {lerp(JX, 0.8f, f), lerp(6.2f, 2.4f, f), 0, s};
        if (t >= 336) p[3] = s * (1f - seg(t, 336, 340));
        return p;
    }

    /** arrow position + direction + scale */
    private static float[] arrowState(float t) {
        if (t < 185 || t >= 350) return null;
        float[] b = bowPoint();
        if (t < 320) return new float[]{b[0], b[1], b[2], 1, 0, 0, lerp(0.25f, 1.1f, smooth(seg(t, 185, 215)))};
        float f = seg(t, 320, 350);
        return new float[]{lerp(b[0], JX, f), lerp(b[1], 1.3f, f), lerp(b[2], 0f, f), 1, 0, 0, 1.3f};
    }

    private static float burnFall(float t) { return smooth(seg(t, 418, 432)); }

    // ------------------------------------------------------------------ light (cheap, per vertex)
    private float[] light(float x, float y, float z, float t) {
        float r = 0.26f, g = 0.25f, b = 0.38f;               // moonlit night
        for (float[] f : GROUND_FIRES) {
            float dx = x - f[0], dy = y - 1f, dz = z - f[1];
            float k = f[2] * 0.55f * (0.85f + 0.15f * (float) Math.sin(t * 0.9f + f[0])) / (1f + (dx * dx + dy * dy + dz * dz) / 14f);
            r += k; g += k * 0.5f; b += k * 0.18f;
        }
        if (t >= 85 && t < 320) {
            float[] h = fHand; float k = 1.5f * smooth(seg(t, 85, 115));
            float dx = x - h[0], dy = y - h[1], dz = z - h[2];
            k /= 1f + (dx * dx + dy * dy + dz * dz) / 3f;
            r += k; g += k * 0.5f; b += k * 0.2f;
        }
        float[] a = fArrow;
        if (a != null) {
            float dx = x - a[0], dy = y - a[1], dz = z - a[2]; float k = 1.6f / (1f + (dx * dx + dy * dy + dz * dz) / 5f);
            r += k; g += k * 0.55f; b += k * 0.2f;
        }
        float[] m = fMeteor;
        if (m != null) {
            float dx = x - m[0], dy = y - m[1], dz = z - m[2]; float rr = m[3] * m[3] * 4f + 1f; float k = 1.4f * m[3] / 4f / (1f + (dx * dx + dy * dy + dz * dz) / rr);
            r += k; g += k * 0.45f; b += k * 0.12f;
        }
        if (t >= 336 && t < 400) {                         // explosions
            float k = 3f * (1f - seg(t, 336, 360)) + 4f * (t >= 350 ? 1f - seg(t, 350, 400) : 0f);
            float cx = t >= 350 ? JX : 0.8f, cy = t >= 350 ? 1.2f : 2.4f;
            float dx = x - cx, dy = y - cy, dz = z; k /= 1f + (dx * dx + dy * dy + dz * dz) / 60f;
            r += k; g += k * 0.62f; b += k * 0.3f;
        }
        if (t >= 350) {                                    // Jogo burning
            float fall = burnFall(t);
            float cx = JX - 1.0f * fall, cy = lerp(1.0f, 0.3f, fall);
            float dx = x - cx, dy = y - cy, dz = z; float k = 1.4f * (1f - 0.4f * seg(t, 460, 580)) / (1f + (dx * dx + dy * dy + dz * dz) / 8f);
            r += k; g += k * 0.5f; b += k * 0.15f;
        }
        lc[0] = Math.min(r, 1.6f); lc[1] = Math.min(g, 1.5f); lc[2] = Math.min(b, 1.4f);
        return lc;
    }

    // ------------------------------------------------------------------ camera
    private void camera(float t) {
        float[] p0, p1, l0, l1; float a, b, fov;
        if (t < 70)       { a = 0;   b = 70;  p0 = v(-14, 2.6f, 8.5f); p1 = v(-11, 2.2f, 7.2f); l0 = v(0, 1.6f, 0); l1 = v(0, 1.6f, 0); fov = 55; }
        else if (t < 130) { a = 70;  b = 130; p0 = v(-2.4f, 1.75f, 1.9f); p1 = v(-2.9f, 1.7f, 1.5f); l0 = v(-5, 1.55f, 0); l1 = v(-4.6f, 1.5f, -0.2f); fov = 50; }
        else if (t < 185) { a = 130; b = 185; p0 = v(-3.55f, 1.55f, 0.75f); p1 = v(-3.75f, 1.6f, 0.6f); l0 = v(-5, 1.82f, 0); l1 = v(-4.9f, 1.8f, -0.05f); fov = 45; }
        else if (t < 245) { a = 185; b = 245; p0 = v(-7.6f, 2.2f, 1.3f); p1 = v(-7.2f, 2.0f, 1.0f); l0 = v(2, 1.6f, 0); l1 = v(3, 1.8f, 0); fov = 50; }
        else if (t < 320) { a = 245; b = 320; p0 = v(1.6f, 1.0f, 2.6f); p1 = v(1.9f, 0.9f, 2.2f); l0 = v(5, 2.4f, 0); l1 = v(5, 4.6f, 0); fov = 62; }
        else if (t < 372) { a = 320; b = 372; p0 = v(0, 2.8f, 9.5f); p1 = v(0, 3.0f, 10.0f); l0 = v(0, 2.8f, 0); l1 = v(0, 2.6f, 0); fov = 68; }
        else              { a = 372; b = 452; p0 = v(2.5f, 1.5f, 2.4f); p1 = v(3.3f, 1.0f, 1.5f); l0 = v(5, 0.9f, 0); l1 = v(4.4f, 0.4f, 0); fov = 50; }
        float f = smooth(seg(t, a, b));
        camX = lerp(p0[0], p1[0], f); camY = lerp(p0[1], p1[1], f); camZ = lerp(p0[2], p1[2], f);
        float lx = lerp(l0[0], l1[0], f), ly = lerp(l0[1], l1[1], f), lz = lerp(l0[2], l1[2], f);
        float shake = 0f;
        if (t >= 336 && t < 372) shake = 0.12f * (1f - seg(t, 336, 372));
        if (t >= 350 && t < 360) shake += 0.1f;
        camX += shake * (float) Math.sin(t * 2.7f); camY += shake * (float) Math.sin(t * 3.9f + 1f);
        float dx = lx - camX, dy = ly - camY, dz = lz - camZ;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz); if (len < 1e-4f) len = 1e-4f;
        fwX = dx / len; fwY = dy / len; fwZ = dz / len;
        camYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        camPitch = (float) Math.toDegrees(Math.atan2(-dy, Math.sqrt(dx * dx + dz * dz)));
        camFov = fov;
        // billboard axes: right = fw x up, up' = right x fw
        float rx = -fwZ, rz = fwX; float rl = (float) Math.sqrt(rx * rx + rz * rz); if (rl < 1e-4f) { rx = 1; rz = 0; rl = 1; }
        rtX = rx / rl; rtY = 0; rtZ = rz / rl;
        upX = rtY * fwZ - rtZ * fwY; upY = rtZ * fwX - rtX * fwZ; upZ = rtX * fwY - rtY * fwX;
    }

    private static float[] v(float x, float y, float z) { return new float[]{x, y, z}; }

    // ------------------------------------------------------------------ render
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        if (minecraft == null) return;
        if (startMs < 0) startMs = Util.getMillis();
        float t = Math.min(clock(), END);
        cues(t);
        g.fillGradient(0, 0, width, height, 0xFF05040B, 0xFF2A1210);
        g.flush();
        try {
            render3D(t, partialTick);
        } catch (RuntimeException e) {
            // never crash the main menu because of the trailer
            KingOfCurses.LOGGER.error("Trailer render failed, closing it", e);
            minecraft.setScreen(parent);
            return;
        }
        overlay(g, t);
    }

    private void render3D(float t, float pt) {
        Minecraft mc = minecraft;
        camera(t);
        fHand = handFlame(); fArrow = arrowState(t); fMeteor = meteorState(t);
        float aspect = (float) mc.getWindow().getWidth() / (float) Math.max(1, mc.getWindow().getHeight());
        Matrix4f proj = new Matrix4f().setPerspective((float) Math.toRadians(camFov), aspect, 0.05f, 300f);
        float fogStart = RenderSystem.getShaderFogStart(), fogEnd = RenderSystem.getShaderFogEnd();
        float[] fogCol = RenderSystem.getShaderFogColor().clone();
        FogShape fogShape = RenderSystem.getShaderFogShape();
        PoseStack mv = RenderSystem.getModelViewStack();
        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
        RenderSystem.backupProjectionMatrix();
        RenderSystem.setProjectionMatrix(proj, VertexSorting.DISTANCE_TO_ORIGIN);
        mv.pushPose();
        mv.setIdentity();
        RenderSystem.applyModelViewMatrix();
        RenderSystem.setShaderFogStart(16f);
        RenderSystem.setShaderFogEnd(80f);
        RenderSystem.setShaderFogColor(0.11f, 0.05f, 0.06f);
        RenderSystem.setShaderFogShape(FogShape.SPHERE);
        Lighting.setupForEntityInInventory();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        try {
            PoseStack ps = new PoseStack();
            ps.mulPose(Axis.XP.rotationDegrees(camPitch));
            ps.mulPose(Axis.YP.rotationDegrees(camYaw + 180f));
            ps.translate(-camX, -camY, -camZ);
            drawSet(ps, buf, t);
            drawActors(ps, buf, t);
            drawFx(ps, buf, t);
            buf.endBatch();
        } finally {
            RenderSystem.setShaderFogStart(fogStart);
            RenderSystem.setShaderFogEnd(fogEnd);
            RenderSystem.setShaderFogColor(fogCol[0], fogCol[1], fogCol[2], fogCol.length > 3 ? fogCol[3] : 1f);
            RenderSystem.setShaderFogShape(fogShape);
            Lighting.setupFor3DItems();
            mv.popPose();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.restoreProjectionMatrix();
            RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
        }
    }

    // ---- painted set
    private void drawSet(PoseStack ps, MultiBufferSource buf, float t) {
        Matrix4f m = ps.last().pose(); Matrix3f n = ps.last().normal();
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(T_GROUND));
        face(vc, m, n, t, -60, 0, 24, 1, 0, 0, 0, 0, -1, 120, 48, 4f, 0, 1, 0);
        for (int tex = 0; tex < BOX_TEX.length; tex++) {
            vc = buf.getBuffer(RenderType.entityCutoutNoCull(BOX_TEX[tex]));
            for (float[] b : boxes) {
                if ((int) b[6] != tex) continue;
                float x0 = b[0], y0 = b[1], z0 = b[2], x1 = b[3], y1 = b[4], z1 = b[5], tile = b[7];
                float w = x1 - x0, h = y1 - y0, d = z1 - z0;
                face(vc, m, n, t, x0, y0, z1, 1, 0, 0, 0, 1, 0, w, h, tile, 0, 0, 1);
                face(vc, m, n, t, x1, y0, z0, -1, 0, 0, 0, 1, 0, w, h, tile, 0, 0, -1);
                face(vc, m, n, t, x1, y0, z1, 0, 0, -1, 0, 1, 0, d, h, tile, 1, 0, 0);
                face(vc, m, n, t, x0, y0, z0, 0, 0, 1, 0, 1, 0, d, h, tile, -1, 0, 0);
                face(vc, m, n, t, x0, y1, z1, 1, 0, 0, 0, 0, -1, w, d, tile * 2f, 0, 1, 0);
            }
        }
    }

    /** a tiled rectangle: origin o, width along u, height along v, one texture copy per tile */
    private void face(VertexConsumer vc, Matrix4f m, Matrix3f n, float t, float ox, float oy, float oz,
                      float ux, float uy, float uz, float vx, float vy, float vz, float W, float H, float tile, float nx, float ny, float nz) {
        int cu = (int) Math.ceil(W / tile - 1e-3f), cv = (int) Math.ceil(H / tile - 1e-3f);
        for (int i = 0; i < cu; i++) {
            float a0 = i * tile, a1 = Math.min(W, a0 + tile);
            for (int j = 0; j < cv; j++) {
                float b0 = j * tile, b1 = Math.min(H, b0 + tile);
                float u1 = (a1 - a0) / tile, vTop = 1f - (b1 - b0) / tile;
                vert(vc, m, n, t, ox + ux * a0 + vx * b0, oy + uy * a0 + vy * b0, oz + uz * a0 + vz * b0, 0, 1, nx, ny, nz);
                vert(vc, m, n, t, ox + ux * a1 + vx * b0, oy + uy * a1 + vy * b0, oz + uz * a1 + vz * b0, u1, 1, nx, ny, nz);
                vert(vc, m, n, t, ox + ux * a1 + vx * b1, oy + uy * a1 + vy * b1, oz + uz * a1 + vz * b1, u1, vTop, nx, ny, nz);
                vert(vc, m, n, t, ox + ux * a0 + vx * b1, oy + uy * a0 + vy * b1, oz + uz * a0 + vz * b1, 0, vTop, nx, ny, nz);
            }
        }
    }

    private void vert(VertexConsumer vc, Matrix4f m, Matrix3f n, float t, float x, float y, float z, float u, float vv, float nx, float ny, float nz) {
        float[] c = light(x, y, z, t);
        vc.vertex(m, x, y, z).color(Math.min(1f, c[0]), Math.min(1f, c[1]), Math.min(1f, c[2]), 1f).uv(u, vv)
          .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, nx, ny, nz).endVertex();
    }

    // ---- GeckoLib actors
    private void drawActor(PoseStack ps, MultiBufferSource buf, TrailerActorRenderer r, TrailerActor a, float t,
                           float x, float y, float z, float yawDeg, float pitchDeg, float scale, float offY) {
        if (scale <= 0.001f) return;
        a.clock = t;
        ps.pushPose();
        ps.translate(x, y + offY * scale, z);
        ps.mulPose(Axis.YP.rotationDegrees(yawDeg));
        if (pitchDeg != 0f) ps.mulPose(Axis.XP.rotationDegrees(pitchDeg));
        ps.scale(scale, scale, scale);
        ps.translate(-0.5f, -0.51f, -0.5f);      // GeoObjectRenderer centers objects on a block: undo it
        r.render(ps, a, buf, null, null, LightTexture.FULL_BRIGHT);
        ps.popPose();
    }

    private void tintFrom(TrailerActor a, float x, float y, float z, float t, float boost) {
        float[] c = light(x, y, z, t);
        a.tint(0.25f + c[0] * 0.75f * boost, 0.25f + c[1] * 0.75f * boost, 0.28f + c[2] * 0.72f * boost);
    }

    private void drawActors(PoseStack ps, MultiBufferSource buf, float t) {
        // Sukuna
        sukuna.anim = t < 70 ? SUK_STAND : (t < 185 ? SUK_IGNITE : (t < 320 ? SUK_DRAW : SUK_RELEASE));
        if (t < 372) {
            tintFrom(sukuna, SX, 1.5f, 0, t, 1f);
            drawActor(ps, buf, rSukuna, sukuna, t, SX, 0, 0, SUK_YAW, 0, 1f, 0);
        }
        // Jogo
        jogo.anim = t < 245 ? JOGO_IDLE : (t < 322 ? JOGO_METEOR : (t < 372 ? JOGO_THROW : JOGO_BURN));
        jogo.texture = t < 372 ? T_JOGO : T_JOGO_BURNT;
        tintFrom(jogo, JX, 1.2f, 0, t, 1f);
        drawActor(ps, buf, rJogo, jogo, t, JX, 0, 0, JOGO_YAW, 0, 1f, 0);
        // meteor (+ shattered chunks)
        float[] me = meteorState(t);
        if (me != null) { meteor.tint(1f, 0.85f, 0.75f); drawActor(ps, buf, rMeteor, meteor, t, me[0], me[1], me[2], 0, 0, me[3], -0.5f); }
        if (t >= 336 && t < 372) {
            float dt = (t - 336) / 20f;
            for (int k = 0; k < 8; k++) {
                double ang = k * Math.PI / 4.0 + 0.3;
                float vx = (float) Math.cos(ang) * 4f, vz = (float) Math.sin(ang) * 3f, vy = 3f + (k % 3) * 1.5f;
                float y = 2.4f + vy * dt - 9f * dt * dt;
                if (y < 0.2f) y = 0.2f;
                drawActor(ps, buf, rMeteor, meteor, t, 0.8f + vx * dt, y, vz * dt, k * 40f, k * 25f, 0.45f, -0.5f);
            }
        }
        // ground fires (GeckoLib flames, additive)
        for (float[] f : GROUND_FIRES) drawActor(ps, buf, rFire, fire, t, f[0], 0, f[1], f[0] * 20f, 0, f[2], 0);
        // flame in Sukuna's hand
        if (t >= 85 && t < 185) {
            float[] h = handFlame();
            drawActor(ps, buf, rFire, fire, t, h[0], h[1], h[2], 0, 0, 0.35f * smooth(seg(t, 85, 115)), 0);
        }
        // Fuga arrow
        float[] ar = arrowState(t);
        if (ar != null) drawActor(ps, buf, rArrow, arrow, t, ar[0], ar[1], ar[2], (float) Math.toDegrees(Math.atan2(-ar[3], -ar[5])), 0, ar[6], -0.25f);
        // Jogo engulfed
        if (t >= 350) {
            float fall = burnFall(t);
            float size = t < 372 ? lerp(0.5f, 2.6f, seg(t, 350, 362)) : lerp(1.3f, 0.8f, seg(t, 440, 580));
            float[][] stand = {{0, 0.1f, 0}, {0.2f, 0.7f, 0.1f}, {-0.2f, 1.2f, 0}, {0, 1.8f, 0.05f}, {0.25f, 0.4f, -0.25f}};
            float[][] prone = {{0, 0.05f, -0.2f}, {0.15f, 0.1f, -0.7f}, {-0.15f, 0.1f, -1.2f}, {0, 0.15f, -1.7f}, {0.2f, 0.05f, -0.4f}};
            for (int k = 0; k < stand.length; k++) {
                float lx = lerp(stand[k][0], prone[k][0], fall), ly = lerp(stand[k][1], prone[k][1], fall), lz = lerp(stand[k][2], prone[k][2], fall);
                float[] p = local(JX, 0, 0, JOGO_YAW, lx, ly, lz);
                drawActor(ps, buf, rFire, fire, t, p[0], p[1], p[2], k * 70f, 0, size * (0.75f + 0.1f * k), 0);
            }
        }
    }

    // ---- light-weight additive fx (a handful of quads)
    private void drawFx(PoseStack ps, MultiBufferSource buf, float t) {
        Matrix4f m = ps.last().pose(); Matrix3f n = ps.last().normal();
        VertexConsumer vc = buf.getBuffer(RenderType.eyes(T_GLOW));
        for (float[] f : GROUND_FIRES) billboard(vc, m, n, f[0], 0.8f * f[2], f[1], 1.6f * f[2], 0.45f, 0.2f, 0.06f);
        if (t >= 85 && t < 185) { float[] h = handFlame(); float k = smooth(seg(t, 85, 115)); billboard(vc, m, n, h[0], h[1] + 0.15f, h[2], 0.5f * k, 1f, 0.55f, 0.2f); }
        float[] ar = arrowState(t);
        if (ar != null) billboard(vc, m, n, ar[0], ar[1], ar[2], 0.7f * ar[6], 1f, 0.6f, 0.25f);
        if (ar != null && t >= 320) for (int k = 1; k <= 5; k++) billboard(vc, m, n, ar[0] - k * 0.45f, ar[1] + 0.02f * k, ar[2], 0.5f - k * 0.07f, 0.9f - k * 0.12f, 0.4f - k * 0.06f, 0.1f);
        float[] me = meteorState(t);
        if (me != null) billboard(vc, m, n, me[0], me[1], me[2], me[3] * 0.9f, 0.9f, 0.4f, 0.1f);
        if (t >= 336 && t < 360) { float f = seg(t, 336, 360); billboard(vc, m, n, 0.8f, 2.4f, 0, 1.5f + 6f * f, 1.4f * (1 - f), 0.9f * (1 - f), 0.4f * (1 - f)); }
        if (t >= 350 && t < 380) {
            float f = seg(t, 350, 380);
            billboard(vc, m, n, JX, 1.3f, 0, 1.5f + 7f * f, 1.6f * (1 - f), 1.0f * (1 - f), 0.4f * (1 - f));
            billboard(vc, m, n, JX, 1.0f, 0, 1f + 3f * f, 1f * (1 - f), 1f * (1 - f), 0.8f * (1 - f));
        }
        if (t >= 350) { float fall = burnFall(t); billboard(vc, m, n, JX - fall, lerp(1f, 0.3f, fall), 0, 1.6f, 0.5f, 0.22f, 0.05f); }
        // embers drifting up (analytic, no state)
        for (int k = 0; k < 36; k++) {
            float ex = ((k * 37) % 60) - 30f + (float) Math.sin(t * 0.03f + k) * 1.5f, ez = ((k * 53) % 18) - 9f;
            float ey = ((t * (0.02f + (k % 5) * 0.006f) + k * 0.7f) % 7f);
            billboard(vc, m, n, ex, ey, ez, 0.06f, 1f, 0.5f, 0.15f);
        }
        // shockwave ring on the ground
        if (t >= 350 && t < 375) {
            VertexConsumer rc = buf.getBuffer(RenderType.eyes(T_RING));
            float f = seg(t, 350, 375), R = 1f + 13f * f, c = 1f - f;
            float y = 0.05f;
            rc.vertex(m, JX - R, y, -R).color(c, c * 0.6f, c * 0.3f, 1f).uv(0, 0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, 0, 1, 0).endVertex();
            rc.vertex(m, JX - R, y, R).color(c, c * 0.6f, c * 0.3f, 1f).uv(0, 1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, 0, 1, 0).endVertex();
            rc.vertex(m, JX + R, y, R).color(c, c * 0.6f, c * 0.3f, 1f).uv(1, 1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, 0, 1, 0).endVertex();
            rc.vertex(m, JX + R, y, -R).color(c, c * 0.6f, c * 0.3f, 1f).uv(1, 0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, 0, 1, 0).endVertex();
        }
    }

    private void billboard(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z, float s, float r, float g, float b) {
        if (s <= 0f) return;
        r = clamp01(r); g = clamp01(g); b = clamp01(b);
        float rx = rtX * s, ry = rtY * s, rz = rtZ * s, ux = upX * s, uy = upY * s, uz = upZ * s;
        vc.vertex(m, x - rx - ux, y - ry - uy, z - rz - uz).color(r, g, b, 1f).uv(0, 1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, -fwX, -fwY, -fwZ).endVertex();
        vc.vertex(m, x + rx - ux, y + ry - uy, z + rz - uz).color(r, g, b, 1f).uv(1, 1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, -fwX, -fwY, -fwZ).endVertex();
        vc.vertex(m, x + rx + ux, y + ry + uy, z + rz + uz).color(r, g, b, 1f).uv(1, 0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, -fwX, -fwY, -fwZ).endVertex();
        vc.vertex(m, x - rx + ux, y - ry + uy, z - rz + uz).color(r, g, b, 1f).uv(0, 0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(n, -fwX, -fwY, -fwZ).endVertex();
    }

    // ------------------------------------------------------------------ 2D: bars, subtitles, title, fades
    private void overlay(GuiGraphics g, float t) {
        int w = width, h = height, bar = Math.max(12, h / 9);
        // flashes
        float flash = 0f;
        if (t >= 336 && t < 342) flash = 0.6f * (1f - seg(t, 336, 342));
        if (t >= 350 && t < 358) flash = Math.max(flash, 1f - seg(t, 350, 358));
        if (flash > 0.01f) g.fill(0, 0, w, h, ((int) (flash * 230) << 24) | 0xFFF0D8);
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);
        // subtitles (English)
        sub(g, t, 140, 185, "trailer.kingofcurses.fuga", "trailer.kingofcurses.fuga_sub", h - bar - 30);
        sub(g, t, 262, 312, "trailer.kingofcurses.meteor", null, h - bar - 24);
        sub(g, t, 440, 478, "trailer.kingofcurses.proud", null, h - bar - 24);
        // title at the top
        if (t >= 480) {
            float a = smooth(seg(t, 480, 500)) * (1f - seg(t, 560, END));
            int al = Math.max(8, (int) (a * 255));
            g.pose().pushPose();
            g.pose().translate(w / 2f, bar + 10, 0);
            float sc = Math.min(3.2f, (w - 20) / (float) Math.max(1, font.width(Component.translatable("trailer.kingofcurses.title"))));
            g.pose().scale(sc, sc, 1f);
            g.drawCenteredString(font, Component.translatable("trailer.kingofcurses.title"), 0, 0, (al << 24) | 0xE84A3C);
            g.pose().popPose();
            int ly = bar + 12 + (int) (9 * sc);
            int lw = (int) (w * 0.3f * a);
            if (lw > 0) g.fill(w / 2 - lw, ly, w / 2 + lw, ly + 1, (al << 24) | 0x9A1420);
            g.drawCenteredString(font, Component.translatable("trailer.kingofcurses.title_sub"), w / 2, ly + 5, (al << 24) | 0xD8CCB8);
        }
        g.drawString(font, Component.translatable("trailer.kingofcurses.skip"), w - 4 - font.width(Component.translatable("trailer.kingofcurses.skip")), h - bar / 2 - 4, 0xFF8A8A8A);
        // fade from / to black
        float black = 0f;
        if (t < 20) black = 1f - seg(t, 0, 20);
        if (t >= 560) black = seg(t, 560, END);
        if (black > 0.01f) g.fill(0, 0, w, h, ((int) (Math.min(1f, black) * 255) << 24));
    }

    private void sub(GuiGraphics g, float t, float a, float b, String key, String key2, int y) {
        if (t < a || t >= b) return;
        float al = Math.min(seg(t, a, a + 4), 1f - seg(t, b - 4, b));
        int alpha = Math.max(8, (int) (al * 255));
        g.pose().pushPose();
        g.pose().translate(width / 2f, y, 0);
        g.pose().scale(1.5f, 1.5f, 1f);
        g.drawCenteredString(font, Component.translatable(key), 0, 0, (alpha << 24) | 0xFFFFFF);
        g.pose().popPose();
        if (key2 != null) g.drawCenteredString(font, Component.translatable(key2), width / 2, y + 16, (alpha << 24) | 0xBDBDBD);
    }
}
