package com.kingofcurses.client.trailer;

import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** v1.0.26: a pre-made GeckoLib puppet for the main-menu trailer. Not an entity: it needs no world. */
public final class TrailerActor implements GeoAnimatable {
    final ResourceLocation model;
    final ResourceLocation animation;
    ResourceLocation texture;
    final boolean emissive;
    /** animation the screen wants right now (switching it restarts the controller) */
    RawAnimation anim;
    /** trailer clock in ticks, fed by TrailerScreen every frame */
    double clock;
    float red = 1f, green = 1f, blue = 1f;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    TrailerActor(ResourceLocation model, ResourceLocation texture, ResourceLocation animation, boolean emissive, RawAnimation anim) {
        this.model = model; this.texture = texture; this.animation = animation; this.emissive = emissive; this.anim = anim;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 0, state -> {
            RawAnimation a = this.anim;
            if (a == null) return PlayState.STOP;
            return state.setAndContinue(a);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    // GeckoLib reads the animation time from here for non-entity animatables
    public double getTick(Object object) { return clock; }

    void tint(float r, float g, float b) {
        red = Math.max(0f, Math.min(1f, r)); green = Math.max(0f, Math.min(1f, g)); blue = Math.max(0f, Math.min(1f, b));
    }
}
