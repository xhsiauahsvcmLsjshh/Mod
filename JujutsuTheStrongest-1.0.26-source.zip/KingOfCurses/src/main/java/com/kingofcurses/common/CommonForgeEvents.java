package com.kingofcurses.common;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.KocConfig;
import com.kingofcurses.ability.*;
import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.capability.CursedData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import com.kingofcurses.entity.SpecialGradeCurseEntity;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Server/common gameplay hooks on the Forge event bus. Contains no client classes. */
@Mod.EventBusSubscriber(modid = KingOfCurses.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommonForgeEvents {
    private CommonForgeEvents() {}

    @SubscribeEvent
    public static void attachCaps(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            CursedCapability.Provider provider = new CursedCapability.Provider();
            event.addCapability(CursedCapability.ID, provider);
            event.addListener(provider::invalidate);
        }
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone event) {
        Player original = event.getOriginal();
        original.reviveCaps();
        CursedCapability.get(original).ifPresent(old -> CursedCapability.get(event.getEntity()).ifPresent(neu -> {
            neu.copyFrom(old);
            neu.setTakeoverTicks(0);
            if (event.isWasDeath()) { neu.setEnergy(neu.maxEnergy() * 0.5f); neu.setLostArms(0); }
        }));
        original.invalidateCaps();
    }

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;
        CursedData d = KocSync.data(sp);
        PowerScaling.apply(sp, d);
        KocSync.sync(sp);
        if (d.introSeen() && d.controlMode() == CursedData.CONTROL_NONE)
            com.kingofcurses.network.ModNetwork.sendTo(sp, new com.kingofcurses.network.OpenScreenPacket(com.kingofcurses.network.OpenScreenPacket.CONTROL_MODE));
        if (!d.sideChosen()) { d.setSide(com.kingofcurses.ability.KocMode.worldSide(sp.level())); PowerScaling.apply(sp, d); KocSync.sync(sp); }   // v1.0.18 Pick Your Side
        if (!d.introSeen() && com.kingofcurses.ability.KocMode.isYuta(sp.level())) com.kingofcurses.ability.YutaIntroDirector.schedule(sp, 60);   // v1.0.25
        else if (!d.introSeen() && com.kingofcurses.ability.KocMode.isFullFight(sp.level())) com.kingofcurses.ability.FullFightDirector.schedule(sp);   // v1.0.22
        else if (!d.introSeen()) {
            if (d.isGojo()) {
                if (KocConfig.bool(KocConfig.INTRO_CINEMATIC, true)) com.kingofcurses.ability.GojoIntroDirector.schedule(sp, 80);
                else { d.setIntroSeen(true); d.setEnergy(d.maxEnergy()); KocSync.sync(sp); }
            } else if (KocConfig.bool(KocConfig.INTRO_CINEMATIC, true)) CinematicDirector.schedule(sp, 80, true);
            else CinematicDirector.buryWithoutCinematic(sp);
        }
    }

    @SubscribeEvent
    public static void logout(PlayerEvent.PlayerLoggedOutEvent event) {
        com.kingofcurses.ability.FinisherLogic.onLogout(event.getEntity().getUUID());
        com.kingofcurses.ability.HeianLogic.onLogout(event.getEntity().getUUID());
        if (event.getEntity() instanceof ServerPlayer sp) CinematicDirector.skip(sp);
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            PowerScaling.apply(sp, KocSync.data(sp)); MobileControls.giveUnlocked(sp, KocSync.data(sp));
            CursedData d = KocSync.data(sp);
            if (d.deathPending() && !event.isEndConquered()) giveRemainsCompass(sp, d);   // v1.0.15: Compass of Remains
            KocSync.sync(sp);
        }
    }

    @SubscribeEvent
    public static void changeDim(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) KocSync.sync(sp);
    }

    @SubscribeEvent
    public static void startTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer target && event.getEntity() instanceof ServerPlayer viewer) KocSync.syncOtherTo(target, viewer);
    }

    @SubscribeEvent
    public static void playerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer sp)) return;
        CursedData d = KocSync.data(sp);
        d.tickCooldowns();
        if (d.hasPowers() || d.ending() != CursedData.ENDING_NONE) {
            float regen = 0.05f + d.effectiveFingers() * 0.012f;
            if (wearingFull(sp, ModItems.SUKUNA_ROBES_HELMET.get(), ModItems.SUKUNA_ROBES_CHESTPLATE.get(), ModItems.SUKUNA_ROBES_LEGGINGS.get(), ModItems.SUKUNA_ROBES_BOOTS.get())) regen *= 1.75f;
            if (sp.hasEffect(ModEffects.CURSED_VIGOR.get())) regen *= 2.0f;
            if (!DomainManager.isActive(sp.getUUID())) d.addEnergy(regen);
        }
        com.kingofcurses.ability.VesselLogic.tickRip(sp);
        com.kingofcurses.ability.ArmLogic.tick(sp, d);
        com.kingofcurses.ability.FinisherLogic.tick(sp, d);
        com.kingofcurses.ability.HeianLogic.tick(sp);
        if (d.deathPending() && sp.isAlive() && sp.tickCount > 20) giveRemainsCompass(sp, d);   // safety net
        com.kingofcurses.ability.FirstTakeover.tick(sp);
        TakeoverLogic.tick(sp, d);
        SorcererHunts.tick(sp, d);
        EndingLogic.tickBossCountdown(sp, d);
        if (sp.tickCount % 40 == 0 && wearingFull(sp, ModItems.CURSED_ARMOR_HELMET.get(), ModItems.CURSED_ARMOR_CHESTPLATE.get(), ModItems.CURSED_ARMOR_LEGGINGS.get(), ModItems.CURSED_ARMOR_BOOTS.get())) {
            sp.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, 60, 0, true, false));
        }
        if (d.isDirty() && sp.tickCount % 10 == 0) KocSync.sync(sp);
    }

    private static void giveRemainsCompass(ServerPlayer sp, CursedData d) {
        d.clearDeathPending();
        net.minecraft.world.item.ItemStack c = com.kingofcurses.item.RemainsCompassItem.create(d.deathPos(), d.deathDim(), d.deathFingers());
        if (!sp.getInventory().add(c)) sp.drop(c, false);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.remains_compass").withStyle(ChatFormatting.DARK_RED), false);
    }

    private static boolean wearingFull(Player p, Item h, Item c, Item l, Item b) {
        return p.getItemBySlot(EquipmentSlot.HEAD).is(h) && p.getItemBySlot(EquipmentSlot.CHEST).is(c)
                && p.getItemBySlot(EquipmentSlot.LEGS).is(l) && p.getItemBySlot(EquipmentSlot.FEET).is(b);
    }

    @SubscribeEvent
    public static void hurt(LivingHurtEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            if (CinematicDirector.isInScene(sp.getUUID()) || com.kingofcurses.ability.GojoIntroDirector.isInScene(sp.getUUID()) || com.kingofcurses.ability.FullFightDirector.isInScene(sp.getUUID()) || com.kingofcurses.ability.YutaIntroDirector.isInScene(sp.getUUID()) || com.kingofcurses.ability.FinisherLogic.running(sp.getUUID())) { event.setCanceled(true); return; }
            CursedData d = KocSync.data(sp);
            float amount = event.getAmount() * (1.0f - PowerScaling.damageReduction(d));
            if (sp.hasEffect(ModEffects.WARDED.get())) amount *= 0.7f;
            Player p = sp;
            if (wearingFull(p, ModItems.JUJUTSU_UNIFORM_HELMET.get(), ModItems.JUJUTSU_UNIFORM_CHESTPLATE.get(), ModItems.JUJUTSU_UNIFORM_LEGGINGS.get(), ModItems.JUJUTSU_UNIFORM_BOOTS.get())
                    && event.getSource().getEntity() instanceof com.kingofcurses.entity.CursedSpiritEntity) amount *= 0.75f;
            event.setAmount(amount);
            com.kingofcurses.ability.ArmLogic.onHurt(sp, d, event.getSource(), amount);
        }
        com.kingofcurses.ability.ArmLogic.blackFlash(event);
    }

    /** v1.0.14: final damage dealt by a Sukuna host fills the Vigor bar. */
    @SubscribeEvent
    public static void damageDealt(net.minecraftforge.event.entity.living.LivingDamageEvent event) {
        if (event.getSource().getEntity() instanceof ServerPlayer sp && event.getEntity() != sp) {
            com.kingofcurses.ability.FinisherLogic.onDamageDealt(sp, KocSync.data(sp), event.getEntity(), event.getAmount());
        }
    }

    @SubscribeEvent
    public static void jump(LivingEvent.LivingJumpEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            float boost = PowerScaling.jumpBoost(KocSync.data(sp));
            if (boost > 0) { Vec3 v = sp.getDeltaMovement(); sp.setDeltaMovement(v.x, v.y + boost, v.z); sp.hurtMarked = true; }
        }
    }

    @SubscribeEvent
    public static void fall(LivingFallEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            int f = KocSync.data(sp).effectiveFingers();
            if (f > 0) event.setDistance(Math.max(0, event.getDistance() - f * 0.6f));
        }
    }

    @SubscribeEvent
    public static void death(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer dying) {
            CursedData dd = KocSync.data(dying);
            boolean host = dd.fingers() > 0 || dd.ending() == CursedData.ENDING_EMBRACE;
            boolean dusted = com.kingofcurses.ability.DustDeath.onDeath(dying);
            if (host && !dusted) dd.setDeathMark(dying.blockPosition(), dying.serverLevel().dimension().location().toString(), 0);
        }
        com.kingofcurses.ability.VesselLogic.onDeath(event.getEntity());
        SliceLogic.onDeath(event.getEntity());
        if (event.getEntity() instanceof SpecialGradeCurseEntity && event.getSource().getEntity() instanceof ServerPlayer sp) {
            KocAdvancements.award(sp, "special_grade");
        }
    }

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        net.minecraft.server.MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        DomainManager.tick(server);
        com.kingofcurses.ability.GojoLogic.tick(server);
        com.kingofcurses.ability.GojoIntroDirector.tick(server);
        com.kingofcurses.ability.SukunaBossFight.tick(server);
        CinematicDirector.tick(server);
        com.kingofcurses.ability.BossRitual.tick(server);
        com.kingofcurses.ability.DustDeath.tick(server);
        com.kingofcurses.ability.FullFightDirector.tick(server);   // v1.0.22 (also runs the Shinjuku builder)
        com.kingofcurses.ability.YutaIntroDirector.tick(server);   // v1.0.25
    }

    @SubscribeEvent
    public static void commands(RegisterCommandsEvent event) {
        KocCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public static void stopped(ServerStoppedEvent event) {
        DomainManager.clear();
        CinematicDirector.clear();
        com.kingofcurses.ability.VesselLogic.clearRips();
        com.kingofcurses.ability.ArmLogic.clear();
        com.kingofcurses.ability.FinisherLogic.clear();
        com.kingofcurses.ability.GojoLogic.clear();
        com.kingofcurses.ability.GojoIntroDirector.clear();
        com.kingofcurses.ability.SukunaBossFight.clear();
        com.kingofcurses.ability.BossRitual.clear();
        com.kingofcurses.ability.FirstTakeover.clear();
        com.kingofcurses.ability.DustDeath.clear();
        com.kingofcurses.ability.FullFightDirector.clear();
        com.kingofcurses.ability.YutaIntroDirector.clear();
        com.kingofcurses.ability.ShinjukuCity.clear();
    }
}
