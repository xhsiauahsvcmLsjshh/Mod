package com.kingofcurses.common;

import com.kingofcurses.ability.CinematicDirector;
import com.kingofcurses.ability.KocSync;
import com.kingofcurses.ability.PowerScaling;
import com.kingofcurses.capability.CursedData;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** /kingofcurses ... : operator tools to test progression quickly. */
public final class KocCommands {
    private KocCommands() {}

    private static int setSide(ServerPlayer p, int side) {
        CursedData data = KocSync.data(p);
        data.setSide(side);
        if (side == 1) data.setFingerMask(0);
        data.setEnergy(data.maxEnergy());
        PowerScaling.apply(p, data);
        KocSync.sync(p);
        if (side == 1) com.kingofcurses.ability.GojoIntroDirector.schedule(p, 10);
        p.displayClientMessage(Component.translatable(side == 1 ? "gui.kingofcurses.create.side_today" : "gui.kingofcurses.create.side_history"), false);
        return 1;
    }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("kingofcurses").requires(s -> s.hasPermission(2))
                .then(Commands.literal("setfingers").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("count", IntegerArgumentType.integer(0, 20)).executes(ctx -> {
                            ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                            int n = IntegerArgumentType.getInteger(ctx, "count");
                            CursedData data = KocSync.data(p);
                            data.setFingerMask(n == 0 ? 0 : (1 << n) - 1);
                            data.setEnergy(data.maxEnergy());
                            if (n >= 20 && !data.bossDefeated() && data.ending() == CursedData.ENDING_NONE) data.setBossCountdown(100);
                            PowerScaling.apply(p, data);
                            com.kingofcurses.ability.MobileControls.refresh(p, data);
                            KocSync.sync(p);
                            ctx.getSource().sendSuccess(() -> Component.translatable("commands.kingofcurses.setfingers", p.getDisplayName(), n), true);
                            return n;
                        }))))
                .then(Commands.literal("resetending").then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                    ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                    CursedData data = KocSync.data(p);
                    data.setEnding(CursedData.ENDING_NONE);
                    data.setBossDefeated(false);
                    data.setBossSpawned(false);
                    PowerScaling.apply(p, data);
                    com.kingofcurses.ability.MobileControls.refresh(p, data);
                    KocSync.sync(p);
                    ctx.getSource().sendSuccess(() -> Component.translatable("commands.kingofcurses.resetending", p.getDisplayName()), true);
                    return 1;
                })))
                .then(Commands.literal("side")   // v1.0.18: switch side (and replay its opening)
                        .then(Commands.literal("history").executes(ctx -> setSide(ctx.getSource().getPlayerOrException(), 0)))
                        .then(Commands.literal("today").executes(ctx -> setSide(ctx.getSource().getPlayerOrException(), 1))))
                .then(Commands.literal("fullfight").executes(ctx -> {   // v1.0.22: build Shinjuku (if needed) and replay the Full Fight Video
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    com.kingofcurses.ability.FullFightDirector.schedule(p);
                    return 1;
                }))
                .then(Commands.literal("yuta").executes(ctx -> {   // v1.0.25: replay the Yuta Okkotsu opening
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    com.kingofcurses.ability.YutaIntroDirector.schedule(p, 10);
                    return 1;
                }))
                .then(Commands.literal("heian").executes(ctx -> {   // v1.0.17: teleport to the throne / replay the arrival video
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    net.minecraft.server.level.ServerLevel h = p.getServer().getLevel(com.kingofcurses.ability.HeianLogic.HEIAN);
                    if (h == null) return 0;
                    int y = com.kingofcurses.ability.HeianLogic.ensureArena(h);
                    p.teleportTo(h, 0.5, y + 1, 7.5, 180f, 0f);
                    com.kingofcurses.network.ModNetwork.sendTo(p, new com.kingofcurses.network.ScreenFxPacket(com.kingofcurses.network.ScreenFxPacket.HEIAN_INTRO, com.kingofcurses.ability.HeianLogic.INTRO_LENGTH, 0f));
                    return 1;
                }))
                .then(Commands.literal("replayintro").then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                    ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                    CinematicDirector.schedule(p, 5, !KocSync.data(p).introSeen());
                    ctx.getSource().sendSuccess(() -> Component.translatable("commands.kingofcurses.replayintro", p.getDisplayName()), true);
                    return 1;
                })))
                .then(Commands.literal("energy").then(Commands.argument("player", EntityArgument.player()).executes(ctx -> {
                    ServerPlayer p = EntityArgument.getPlayer(ctx, "player");
                    CursedData data = KocSync.data(p);
                    data.setEnergy(data.maxEnergy());
                    for (com.kingofcurses.ability.Ability a : com.kingofcurses.ability.Ability.values()) data.setCooldown(a, 0);
                    KocSync.sync(p);
                    ctx.getSource().sendSuccess(() -> Component.translatable("commands.kingofcurses.energy", p.getDisplayName()), true);
                    return 1;
                })))
                .then(Commands.literal("mode")
                        .then(Commands.literal("on").executes(ctx -> { com.kingofcurses.ability.KocMode.set(ctx.getSource().getServer(), true); return 1; }))
                        .then(Commands.literal("off").executes(ctx -> { com.kingofcurses.ability.KocMode.set(ctx.getSource().getServer(), false); return 1; }))));
    }
}
