package com.kingofcurses.item;

import com.kingofcurses.ability.YutaPowers;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** v1.0.25 Rika's Ring: right click summons Rika (5 min) or, with Rika out, fires the Pure Love beam. Sneak + right click: Cursed Speech. */
public class RikaRingItem extends Item {
    public RikaRingItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) YutaPowers.ring(sp);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.rika_ring").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.translatable("tooltip.kingofcurses.rika_ring2").withStyle(ChatFormatting.GRAY));
    }
}
