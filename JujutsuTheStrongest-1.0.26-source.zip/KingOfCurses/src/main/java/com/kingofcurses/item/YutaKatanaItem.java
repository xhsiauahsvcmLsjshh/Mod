package com.kingofcurses.item;

import com.kingofcurses.ability.YutaPowers;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** v1.0.25 Yuta's Katana: a strong sword. Right click: cursed-energy slash. Sneak + right click: Reverse Cursed Technique. */
public class YutaKatanaItem extends SwordItem {
    public YutaKatanaItem(Properties p) { super(KocTiers.SPECIAL, 5, -2.4f, p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            YutaPowers.katana(sp);
            player.swing(hand, true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.yuta_katana").withStyle(ChatFormatting.WHITE));
        tooltip.add(Component.translatable("tooltip.kingofcurses.yuta_katana2").withStyle(ChatFormatting.GRAY));
    }
}
