package com.kingofcurses.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.UUID;

/**
 * v1.0.25 Rika Orimoto, Yuta's Special Grade curse. Summoned with Rika's Ring for five minutes: she follows her owner,
 * fights every hostile creature and whatever hurts him, and never attacks players. In the opening video she is a no-AI actor.
 */
public class RikaEntity extends PathfinderMob implements GeoEntity {
    private static final String M = "rika_orimoto";
    private static final EntityDataAccessor<Boolean> CINEMATIC = SynchedEntityData.defineId(RikaEntity.class, EntityDataSerializers.BOOLEAN);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle = KocAnims.loop(M, "idle"), walk = KocAnims.loop(M, "walk"), run = KocAnims.loop(M, "run");
    @Nullable private UUID owner;
    private int life = -1;

    public RikaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 32.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(CINEMATIC, false);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3D, true));
        goalSelector.addGoal(4, new FollowOwnerGoal(this));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false, e -> e instanceof Enemy));
    }

    /** The opening video: no AI, untouchable, removed by the director. */
    public void setupCinematic() {
        entityData.set(CINEMATIC, true);
        setNoAi(true); setInvulnerable(true); setNoGravity(true); setPersistenceRequired();
    }

    public boolean isCinematic() { return entityData.get(CINEMATIC); }

    public void bind(Player p, int ticks) { owner = p.getUUID(); life = ticks; }

    @Nullable
    public Player owner() { return owner == null ? null : level().getPlayerByUUID(owner); }

    public boolean isOwnedBy(Player p) { return owner != null && owner.equals(p.getUUID()); }

    /** Seconds left before she goes back into the ring. */
    public int secondsLeft() { return Math.max(0, life / 20); }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (target instanceof Player || target instanceof RikaEntity) return;   // she never turns on people
        super.setTarget(target);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || isCinematic()) return;
        Player o = owner();
        if (o == null || !o.isAlive() || o.level() != level()) { vanish(); return; }
        if (life > 0 && --life == 0) { vanish(); return; }
        if (tickCount % 10 == 0) {
            LivingEntity a = o.getLastHurtByMob();
            if (a != null && a != this && a.isAlive() && !(a instanceof Player)) setTarget(a);
            LivingEntity b = o.getLastHurtMob();
            if (getTarget() == null && b != null && b != this && b.isAlive() && !(b instanceof Player)) setTarget(b);
        }
    }

    /** Back into the ring, in a puff of dark energy. */
    public void vanish() {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.SQUID_INK, getX(), getY() + 1.6, getZ(), 30, 0.8, 1.0, 0.8, 0.03);
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.REVERSE_PORTAL, getX(), getY() + 1.6, getZ(), 30, 0.8, 1.0, 0.8, 0.05);
        }
        discard();
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        triggerAnim("main", random.nextBoolean() ? "attack" : "slash");
        return super.doHurtTarget(target);
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (isCinematic()) return true;
        if (source.getEntity() instanceof Player p && isOwnedBy(p)) return true;
        return super.isInvulnerableTo(source);
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean shouldBeSaved() { return false; }
    @Override public boolean isPushable() { return !isCinematic(); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::predicate)
                .triggerableAnim("attack", KocAnims.once(M, "attack"))
                .triggerableAnim("slash", KocAnims.once(M, "slash"))
                .triggerableAnim("cast", KocAnims.once(M, "cast"))
                .triggerableAnim("rise", KocAnims.once(M, "rise")));
    }

    private PlayState predicate(AnimationState<RikaEntity> state) {
        if (state.isMoving()) return state.setAndContinue(getTarget() != null ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    /** Keeps Rika near Yuta; teleports behind him if she falls too far back. */
    static final class FollowOwnerGoal extends Goal {
        private final RikaEntity r;
        FollowOwnerGoal(RikaEntity r) { this.r = r; setFlags(EnumSet.of(Goal.Flag.MOVE)); }

        @Override public boolean canUse() { Player o = r.owner(); return o != null && r.getTarget() == null && r.distanceToSqr(o) > 25; }
        @Override public boolean canContinueToUse() { Player o = r.owner(); return o != null && r.getTarget() == null && r.distanceToSqr(o) > 9; }
        @Override public void stop() { r.getNavigation().stop(); }

        @Override
        public void tick() {
            Player o = r.owner();
            if (o == null) return;
            r.getLookControl().setLookAt(o, 10f, r.getMaxHeadXRot());
            if (r.distanceToSqr(o) > 24 * 24) {
                net.minecraft.world.phys.Vec3 back = o.getLookAngle().multiply(1, 0, 1);
                if (back.lengthSqr() < 1.0E-4) back = new net.minecraft.world.phys.Vec3(0, 0, 1);
                back = back.normalize().scale(-2.5);
                r.teleportTo(o.getX() + back.x, o.getY(), o.getZ() + back.z);
                r.getNavigation().stop();
            } else if (r.tickCount % 10 == 0) r.getNavigation().moveTo(o, 1.25D);
        }
    }
}
