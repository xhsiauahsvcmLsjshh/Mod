import json, os
from models import *
SUKUNA_HAIR=(236,150,162); SUKUNA_SKIN=(226,190,166); KIMONO=(238,232,218); BLOODC=(120,6,18)

def build_all():
    M={}
    # ---------------- Ryomen Sukuna (vessel) ----------------
    m=humanoid("ryomen_sukuna",skin=SUKUNA_SKIN,top=KIMONO,bottom=(30,22,26),arms_col=SUKUNA_SKIN,
        face=face_human(eye=CE,iris=CE,hair=SUKUNA_HAIR,marks=BLACK,glow_eyes=True,extra_eyes=True,skin=SUKUNA_SKIN),
        body_painter=multi(trim((30,20,24),top=True,bottom=False),emblem(CRIMSON,0,False)),arm_painter=tattoo(BLACK))
    ty=m.top_y
    add(m,"head",[-4,ty+8,-4],[8,2,8],SUKUNA_HAIR,mat="hair")
    add(m,"head",[-4.5,ty+6,-4.5],[1,3,9],SUKUNA_HAIR,mat="hair"); add(m,"head",[3.5,ty+6,-4.5],[1,3,9],SUKUNA_HAIR,mat="hair")
    add(m,"body",[-4.5,12,-2.5],[9,3,5],(150,14,32),trim(GOLD,True,True))                               # obi
    add(m,"body",[-5,5,-3],[10,7,6],KIMONO,stripes((40,30,34),5,True,faces_only=("front","back")))       # hakama skirt
    add(m,"body",[-4,22,-2.6],[3,2,1],(30,20,24)); add(m,"body",[1,22,-2.6],[3,2,1],(30,20,24))           # kimono collar V
    M[m.name]=m
    # ---------------- Sukuna True Form ----------------
    m=humanoid("sukuna_true_form",s=1.3,skin=(214,170,150),top=(20,14,16),bottom=(26,16,18),arms_col=(214,170,150),extra_arms=True,
        face=face_human(eye=CE,iris=CE,hair=(240,236,230),marks=BLACK,glow_eyes=True,extra_eyes=True,skin=(214,170,150)),
        body_painter=multi(tattoo(BLACK),emblem(CE,2,True)),arm_painter=tattoo(BLACK),hands=(200,150,130))
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y
    add(m,"head",[-hs/2,ty+hs,-hs/2],[hs,3,hs],(240,236,230),mat="hair")
    add(m,"head",[hs/2,ty+2,-3],[2,5,6],(214,170,150),face_curse(1,CE,True),mat="skin")      # side face
    add(m,"body",[-bw/2-1,lh-6,-4],[bw+2,8,8],(160,16,30),multi(stripes(BLACK,4,True),trim(GOLD)))
    M[m.name]=m
    # ---------------- Gojo (split for the cut) ----------------
    GJ=(18,18,30)
    m=humanoid("gojo_satoru",skin=(238,216,202),top=GJ,bottom=GJ,split=True,hands=(238,216,202),
        face=face_human(hair=(250,250,255),blindfold=(12,12,16),skin=(238,216,202)),body_painter=multi(buttons((60,60,90)),emblem(GOLD,3,False)))
    ty=m.top_y; lh=m.dims[0]
    add(m,"head",[-4,ty+8,-4],[8,3,8],(250,250,255),mat="hair")
    add(m,"head",[-5,ty+5,-3],[1,5,7],(250,250,255),mat="hair"); add(m,"head",[4,ty+5,-3],[1,5,7],(250,250,255),mat="hair")
    add(m,"head",[-2,ty+10,-2],[4,2,4],(250,250,255),mat="hair")
    add(m,"body",[-4.5,ty-3,-2.5],[9,3,5],(28,28,44),trim((60,60,90)))   # high collar
    lo=m.dims[1]//3
    m.bone("blood_pool","root",[0,0,0],[Cube([-10,-0.9,-7],[20,1,14],BLOODC,mat="flesh"),Cube([-6,-0.85,-10],[12,1,20],shade(BLOODC,0.85),mat="flesh"),
                                       Cube([-13,-0.88,-3],[26,1,6],shade(BLOODC,1.1),mat="flesh")])
    m.bone("blood_upper","body",[0,lh+lo,0],[Cube([x,lh+lo-3,-1],[1,3,1],(150,10,24),mat="flesh") for x in (-3,-1,2)]+[Cube([-4,lh+lo-1,-2],[8,1,4],(130,8,20),mat="flesh")])
    m.bone("blood_lower","hips",[0,lh+lo,0],[Cube([x,lh+lo,z],[1,2+(abs(x)%2),1],(170,14,28),mat="flesh") for x,z in ((-2,-1),(1,0),(3,-1),(-3,1))]+[Cube([-4,lh+lo,-2],[8,1,4],(130,8,20),mat="flesh")])
    M[m.name]=m
    # ---------------- Fly Head ----------------
    m=Model("fly_head"); m.bone("root",None,[0,0,0])
    m.bone("body","root",[0,7,0],[Cube([-5,3,-5],[10,10,10],(96,74,60),face_curse(5,(255,220,40),True),mat="curse"),Cube([-2,13,-2],[4,2,4],(70,52,44),mat="curse")])
    m.bone("left_wing","body",[5,11,0],[Cube([5,10,-4],[1,6,8],(170,150,140),mat="plain")]); m.bone("right_wing","body",[-5,11,0],[Cube([-6,10,-4],[1,6,8],(170,150,140),mat="plain")])
    m.bone("jaw","body",[0,4,-4],[Cube([-3,1,-7],[6,3,4],(80,30,30),face_curse(0,BONE,True),mat="curse")])
    for k,(x,z) in enumerate(((-3,-2),(3,-2),(-3,3),(3,3))): m.bone(f"leg_{k}","body",[x,3,z],[Cube([x-0.5,0,z-0.5],[1,3,1],(50,36,30),mat="curse")])
    m.parts=(("left_wing",2,35,0),("right_wing",2,35,0),("jaw",0,14,0))+tuple((f"leg_{k}",0,18,0) for k in range(4)); M[m.name]=m
    # ---------------- Crawling Eye ----------------
    m=Model("crawling_eye"); m.bone("root",None,[0,0,0]); m.bone("body","root",[0,7,0],[Cube([-6,4,-6],[12,8,12],(60,40,70),giant_eye(),mat="curse")])
    for k in range(6):
        side=-1 if k<3 else 1; z=-4+(k%3)*4
        m.bone(f"leg_{k}","body",[side*6,6,z],[Cube([6 if side>0 else -12,5,z-1],[6,1,2],(40,24,44),mat="curse")])
        m.bone(f"foot_{k}",f"leg_{k}",[side*12,6,z],[Cube([12 if side>0 else -13,0,z-1],[1,6,2],(30,18,34),mat="curse")])
    m.parts=tuple((f"leg_{k}",2,22,0) for k in range(6)); M[m.name]=m
    # ---------------- Roppongi Curse ----------------
    m=humanoid("roppongi_curse",s=1.1,skin=(80,70,80),top=(50,40,52),bottom=(40,32,42),arms_col=(80,70,80),face=face_curse(7,(255,230,60)),head_size=10,
               body_painter=face_curse(4,(255,230,60),False),arm_w=3,skin_mat="curse",cloth_mat="curse",shoes=(40,30,40))
    add(m,"body",[-3,24,2],[6,5,4],(70,60,72),face_curse(2,(255,230,60),False),mat="curse"); M[m.name]=m
    # ---------------- Lantern Hag ----------------
    m=humanoid("lantern_hag",s=1.25,skin=(170,160,150),top=(36,30,26),bottom=(36,30,26),arm_w=2,face=face_curse(2,(255,140,30)),head_size=8,skin_mat="curse")
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y
    add(m,"right_forearm",[-bw/2-aw-1,ty-m.ah-6,-2],[4,5,4],(255,150,40),glow="full",mat="plain"); add(m,"right_forearm",[-bw/2-aw/2-0.5,ty-m.ah-1,-0.5],[1,1,1],(60,40,20))
    add(m,"head",[-5,ty+hs-1,-5],[10,2,10],(30,24,20),mat="wood"); add(m,"head",[-2,ty+hs+1,-2],[4,3,4],(30,24,20),mat="wood")
    add(m,"body",[-5,4,-3],[10,lh-4,6],(36,30,26),stripes((24,20,16),3,True)); M[m.name]=m
    # ---------------- Hanged Bride ----------------
    m=humanoid("hanged_bride",s=1.1,skin=(220,215,210),top=(236,232,226),bottom=(236,232,226),face=face_curse(2,(200,0,20),False),skin_mat="skin")
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y
    add(m,"body",[-6,2,-4],[12,lh+2,8],(236,232,226),multi(stripes((200,196,190),4,True),trim((180,170,160),False,True)))
    add(m,"head",[-5,ty+hs-3,-5],[10,4,10],(250,250,250),mat="plain"); add(m,"head",[-5,ty+1,3],[10,7,2],(250,250,250),mat="plain")
    add(m,"head",[-1,ty+hs,-1],[2,10,2],(110,90,70),mat="wood"); add(m,"body",[-2,ty-6,-4.2],[4,4,1],(150,10,26),mat="flesh")
    M[m.name]=m
    # ---------------- Bone Centipede ----------------
    m=Model("bone_centipede"); m.bone("root",None,[0,0,0]); z=-14
    m.bone("seg_0","root",[0,6,z],[Cube([-4,2,z-6],[8,7,7],BONE,face_curse(4,CE,True),mat="bone"),Cube([-5,2,z-7],[2,2,3],BONE2,mat="bone"),Cube([3,2,z-7],[2,2,3],BONE2,mat="bone")])
    prev="seg_0"
    for k in range(1,7):
        zz=z+(k-1)*6+1
        m.bone(f"seg_{k}",prev,[0,6,zz],[Cube([-3.5,2,zz],[7,6,6],shade(BONE,1-0.05*k),mat="bone"),Cube([-1,8,zz+1],[2,2,3],BONE2,mat="bone")])
        m.bone(f"legs_{k}",f"seg_{k}",[0,3,zz+2],[Cube([-7,0,zz+2],[3,4,1],BONE2,mat="bone"),Cube([4,0,zz+2],[3,4,1],BONE2,mat="bone")])
        prev=f"seg_{k}"
    m.body="seg_0"; m.parts=tuple((f"seg_{k}",1,10,0) for k in range(1,7))+tuple((f"legs_{k}",0,25,0) for k in range(1,7)); M[m.name]=m
    # ---------------- Finger Bearer ----------------
    m=Model("finger_bearer"); m.bone("root",None,[0,0,0])
    m.bone("body","root",[0,16,0],[Cube([-10,12,-10],[20,14,20],(70,16,24),face_curse(6,(255,230,90),True),mat="curse"),Cube([-3,26,-3],[6,6,6],BONE2,mat="bone"),
                                   Cube([-6,26,4],[3,4,3],BONE2,mat="bone"),Cube([3,26,4],[3,4,3],BONE2,mat="bone")])
    for k in range(4):
        side=-1 if k<2 else 1; z=-6+(k%2)*12
        m.bone(f"leg_{k}","body",[side*10,16,z],[Cube([10 if side>0 else -14,4,z-2],[4,12,4],(60,12,20),mat="curse")])
        m.bone(f"claw_{k}",f"leg_{k}",[side*12,4,z],[Cube([10 if side>0 else -14,0,z-3],[4,4,6],BONE,mat="bone")])
    m.bone("tail","body",[0,18,10],[Cube([-2,16,10],[4,4,10],BONE,mat="bone")]); m.bone("tail_tip","tail",[0,18,20],[Cube([-1,17,20],[2,2,6],BONE2,mat="bone")])
    m.parts=tuple((f"leg_{k}",0,25,0) for k in range(4))+(("tail",1,20,0),("tail_tip",1,25,0)); M[m.name]=m
    # ---------------- Smallpox Deity ----------------
    m=humanoid("smallpox_deity",s=1.55,skin=(110,92,70),top=(90,74,56),bottom=(70,58,44),arms_col=(110,92,70),head_col=(74,60,44),face=face_curse(9,(240,240,200)),
               body_painter=face_curse(6,(240,240,200),False),skin_mat="curse",cloth_mat="curse")
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y
    add(m,"body",[-6,ty-6,4],[12,16,4],(60,40,28),multi(emblem(BONE,2,False),trim((40,26,18))),mat="wood"); M[m.name]=m
    # ---------------- Cursed Womb ----------------
    m=Model("cursed_womb"); m.bone("root",None,[0,0,0])
    m.bone("body","root",[0,18,0],[Cube([-8,12,-8],[16,14,16],(120,24,50),giant_eye((255,210,220),CE),mat="curse"),Cube([-3,26,-3],[6,4,6],(160,40,70),mat="curse")])
    for k in range(4):
        x=-6+k*4
        m.bone(f"tendril_{k}","body",[x,12,0],[Cube([x-1,6,-1],[2,6,2],(150,30,60),mat="curse")])
        m.bone(f"tendril_tip_{k}",f"tendril_{k}",[x,6,0],[Cube([x-0.5,0,-0.5],[1,6,1],(180,40,70),mat="curse")])
    m.parts=tuple((f"tendril_{k}",0,18,0) for k in range(4))+tuple((f"tendril_tip_{k}",0,26,0) for k in range(4)); M[m.name]=m
    # ---------------- Shrine Warden ----------------
    m=humanoid("shrine_warden",s=1.6,skin=(30,20,22),top=(26,12,16),bottom=(22,10,14),face=face_curse(2,CE,False),
               body_painter=multi(stripes(GOLD,5,False),emblem(CE,3,True)),arm_painter=stripes(GOLD,4,False),cloth_mat="metal",leg_painter=stripes(GOLD,5,False))
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y
    add(m,"head",[-hs/2-1,ty+hs-2,-hs/2-1],[hs+2,3,hs+2],GOLD,mat="metal"); add(m,"head",[-1,ty+hs+1,-hs/2-1],[2,6,1],GOLD,mat="metal")
    add(m,"right_arm",[-bw/2-aw-1,ty-5,-aw/2-1],[aw+2,4,aw+2],GOLD,mat="metal"); add(m,"left_arm",[bw/2-1,ty-5,-aw/2-1],[aw+2,4,aw+2],GOLD,mat="metal")
    add(m,"right_forearm",[-bw/2-aw/2-1,ty-m.ah,-12],[2,2,26],(90,60,40),mat="wood"); add(m,"right_forearm",[-bw/2-aw/2-1,ty-m.ah-1,-18],[2,4,6],(210,210,220),mat="metal")
    add(m,"body",[-bw/2-1,lh-8,-bw/4-1],[bw+2,8,bw/2+2],(40,14,18),stripes(GOLD,3,True),mat="metal")
    M[m.name]=m
    # ---------------- Sorcerers ----------------
    U=(20,20,34)
    m=humanoid("jujutsu_sorcerer",skin=SKIN,top=U,bottom=U,face=face_human(hair=(30,24,22)),body_painter=multi(buttons(GOLD),emblem(GOLD,1,False)),shoes=(14,14,18))
    add(m,"head",[-4,32,-4],[8,2,8],(30,24,22),mat="hair"); add(m,"body",[-4.5,21,-2.5],[9,3,5],(28,28,44),trim((60,60,90))); M[m.name]=m
    m=humanoid("sorcerer_elite",skin=SKIN,top=(14,14,22),bottom=(14,14,22),face=face_human(hair=(20,20,20),eye=(60,120,255),iris=(60,120,255),glow_eyes=True),
               body_painter=multi(buttons(GOLD),stripes(GOLD,6,True,faces_only=("front",))),shoes=(10,10,14))
    add(m,"head",[-4,32,-4],[8,2,8],(20,20,20),mat="hair"); add(m,"body",[-5,4,-3],[10,8,6],(14,14,22),trim(GOLD,False,True))
    add(m,"left_forearm",[4,12,-8],[1,1,16],(200,200,215),mat="metal"); add(m,"left_forearm",[3.5,11.5,6],[2,2,1],GOLD,mat="metal"); M[m.name]=m
    m=humanoid("jujutsu_student",s=0.95,skin=SKIN,top=(26,26,44),bottom=(26,26,44),face=face_human(hair=(90,50,30)),body_painter=multi(buttons(GOLD),emblem(GOLD,0,False)),shoes=(200,60,40))
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y
    add(m,"head",[-hs/2,ty+hs,-hs/2],[hs,2,hs],(90,50,30),mat="hair"); add(m,"body",[-bw/2-0.5,ty-3,-2.5],[bw+1,3,5],(36,36,58),trim((70,70,100))); M[m.name]=m
    m=humanoid("sealing_master",s=1.05,skin=(200,190,180),top=(240,234,216),bottom=(240,234,216),face=face_human(eye=(90,90,255),iris=(90,90,255),glow_eyes=True,hair=(230,230,230)),
               body_painter=multi(stripes((44,44,110),4,True,faces_only=("front","back")),emblem((90,90,255),1,True)),arms_col=(240,234,216),arm_painter=trim((44,44,110),False,True))
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y
    add(m,"head",[-hs/2-1,ty+hs,-hs/2-1],[hs+2,2,hs+2],(44,44,110)); add(m,"head",[-1,ty+hs+2,-1],[2,4,2],GOLD,mat="metal")
    add(m,"body",[-6,0,-4],[12,lh,8],(240,234,216),multi(stripes((44,44,110),5,True),trim(GOLD,False,True)))
    m.bone("talismans","body",[0,ty+6,6],[Cube([-8+k*5,ty+4,5],[3,7,1],PAPER,emblem(CRIMSON,k,True),mat="plain") for k in range(4)])
    M[m.name]=m
    # ---------------- v1.0.8 named sorcerers (KING OF CURSES difficulty) ----------------
    W_=(236,236,240); DK=(24,24,34)
    yuta_model(M); ryu_model(M); rika_model(M)
    # ---------------- Toji Fushiguro (v1.0.18): black shirt, white baggy pants, lip scar, Inventory Curse worm, Inverted Spear ----------------
    TS=(222,190,166)
    m=humanoid("toji_fushiguro",s=1.05,skin=TS,top=(16,16,20),bottom=(214,212,204),arms_col=(16,16,20),hands=TS,
        face=face_human(hair=(18,16,20),eye=(30,60,40),iris=(60,120,80),brow=(16,14,18),skin=TS,mouth=(150,90,90)),shoes=(18,18,20))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    add(m,"head",[-hs/2,ty+hs-1,-hs/2],[hs,2,hs],(18,16,20),mat="hair"); add(m,"head",[-hs/2-0.5,ty+hs-4,-hs/2],[1,3,hs],(18,16,20),mat="hair")
    add(m,"head",[hs/2-0.5,ty+hs-4,-hs/2],[1,3,hs],(18,16,20),mat="hair"); add(m,"head",[-hs/2,ty+hs-3,-hs/2-0.6],[hs,2,1],(18,16,20),mat="hair")
    add(m,"head",[-1.5,ty+1.4,-hs/2-0.15],[1,1.4,0.2],(235,205,200))                                     # lip scar
    add(m,"body",[-bw/2-0.5,lh,-2.5],[bw+1,2,5],(30,26,26))                                              # belt
    WORM=(118,58,150); WORM2=(80,34,104)
    m.bone("worm","body",[0,ty,0],[
        Cube([-bw/2-1,ty-1,-3],[bw+2,2,6],WORM,stripes(WORM2,2,True),mat="curse"),                     # coiled round the neck
        Cube([bw/2-1,ty-6,-3.2],[2,6,2],WORM,stripes(WORM2,2,False),mat="curse"),                        # down the chest
        Cube([-bw/2-0.5,ty-9,-3.4],[bw-1,2,2],WORM,stripes(WORM2,2,True),mat="curse"),                    # across the belly
        Cube([-bw/2-2.5,ty-2,-2],[3,3,4],WORM2,face_curse(2,(250,240,120),True),mat="curse")])           # the worm's head on the shoulder
    add(m,"right_forearm",[-bw/2-aw/2-0.5,ty-m.ah+1,-16],[1,1,17],(196,200,214),mat="metal")             # Inverted Spear of Heaven
    add(m,"right_forearm",[-bw/2-aw/2-1.5,ty-m.ah+0.5,-17],[3,2,1],(170,176,192),mat="metal")
    add(m,"right_forearm",[-bw/2-aw/2-1,ty-m.ah,0.5],[2,2,3],(60,50,60),mat="wood")
    M[m.name]=m
    # ---------------- Suguru Geto (v1.0.20): monk kesa, long black hair with a bun, ear gauges ----------------
    GS=(232,206,186); KESA=(24,24,30); SASH=(176,130,70)
    m=humanoid("suguru_geto",skin=GS,top=KESA,bottom=KESA,arms_col=KESA,hands=GS,
        face=face_human(hair=(14,12,16),eye=(30,24,22),iris=(50,40,36),brow=(14,12,16),skin=GS,mouth=(130,80,80)),
        body_painter=multi(trim(SASH,True,False)),arm_painter=trim(SASH,False,True),shoes=(30,26,24))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    add(m,"head",[-4,ty+8,-4],[8,2,8],(14,12,16),mat="hair"); add(m,"head",[-1.5,ty+9,1.5],[3,3,3],(14,12,16),mat="hair")   # bun
    add(m,"head",[-4.5,ty+2,-4],[1,6,8],(14,12,16),mat="hair"); add(m,"head",[3.5,ty+2,-4],[1,6,8],(14,12,16),mat="hair")
    add(m,"head",[-1,ty+3,-4.6],[1,5,1],(14,12,16),mat="hair")                                                       # the famous bang
    add(m,"head",[-4.6,ty+2,0],[0.4,1.2,1.2],GOLD,mat="metal"); add(m,"head",[4.2,ty+2,0],[0.4,1.2,1.2],GOLD,mat="metal")
    add(m,"body",[-bw/2-0.4,lh-5,-2.4],[bw+0.8,6,4.8],KESA,stripes((40,40,48),3,True))                               # hakama
    add(m,"body",[-bw/2,ty-9,-2.6],[bw,9,0.4],SASH,stripes((150,100,50),2,False),mat="cloth")                          # kesa drape
    M[m.name]=m
    # ---------------- Curse User (v1.0.20): hooded black robe, pale skin, red glowing eyes ----------------
    m=humanoid("curse_user",skin=(196,186,180),top=(14,10,14),bottom=(14,10,14),arms_col=(14,10,14),hands=(196,186,180),
        face=face_human(hair=(10,8,10),eye=CE,iris=CE,glow_eyes=True,skin=(196,186,180),marks=(90,10,20)),body_painter=emblem(CE,1,True),shoes=(10,8,10))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    add(m,"head",[-hs/2-0.5,ty+hs-1,-hs/2-0.5],[hs+1,1.5,hs+1],(20,14,20)); add(m,"head",[-hs/2-0.5,ty+1,hs/2-0.5],[hs+1,hs-1,1],(20,14,20))   # hood
    add(m,"head",[-hs/2-0.5,ty+1,-hs/2-0.5],[1,hs-1,hs],(20,14,20)); add(m,"head",[hs/2-0.5,ty+1,-hs/2-0.5],[1,hs-1,hs],(20,14,20))
    add(m,"body",[-bw/2-0.5,1,-2.5],[bw+1,lh-1,5],(14,10,14),trim(CRIMSON,False,True))                                  # long robe
    M[m.name]=m
    # Kinji Hakari: slicked teal hair, black long coat over a white shirt, gold chain
    m=humanoid("kinji_hakari",skin=(226,196,176),top=(22,22,26),bottom=(22,22,26),
        face=face_human(hair=(60,150,140),eye=(30,30,30),iris=(200,170,60),brow=(40,90,84),skin=(226,196,176),mouth=(130,60,60)),
        body_painter=multi(stripes((236,236,236),8,True,faces_only=("front",)),trim((60,150,140),True,False)),shoes=(14,14,16))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    add(m,"head",[-4,ty+8,-4.5],[8,2,9],(60,150,140),mat="hair"); add(m,"head",[-4,ty+5,3.5],[8,4,1],(40,110,104),mat="hair")
    add(m,"head",[-4.6,ty+3,-1],[1,2,1],GOLD,mat="metal"); add(m,"head",[3.6,ty+3,-1],[1,2,1],GOLD,mat="metal")             # earrings
    add(m,"body",[-2,ty-5,-2.6],[4,4,1],(240,240,240)); add(m,"body",[-3,ty-6,-2.7],[6,1,1],GOLD,glow="full",mat="metal")  # shirt + chain
    add(m,"body",[-5,2,-3],[10,10,6],(22,22,26),trim((60,150,140),False,True))                                         # coat tails
    M[m.name]=m
    # Maki Zen'in: dark green ponytail, glasses, dark uniform, red three-section staff
    m=humanoid("maki_zenin",s=0.97,skin=(230,200,180),top=(20,26,24),bottom=(20,26,24),
        face=face_human(hair=(24,52,36),eye=(20,20,20),iris=(80,60,40),brow=(20,40,28),skin=(230,200,180),mouth=(140,70,70)),
        body_painter=multi(buttons(GOLD),emblem(GOLD,2,False)),shoes=(30,24,20))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    add(m,"head",[-hs/2,ty+hs,-hs/2],[hs,2,hs],(24,52,36),mat="hair"); add(m,"head",[-1,ty+hs-3,hs/2],[2,2,2],(24,52,36),mat="hair"); add(m,"head",[-0.5,ty+hs-9,hs/2+1],[1,7,1],(24,52,36),mat="hair")
    add(m,"head",[-hs/2,ty+hs/2,-hs/2-0.5],[hs,1,0.5],(10,10,12),mat="metal")                                           # glasses
    for k in range(3): add(m,"right_forearm",[-bw/2-aw/2-0.5,ty-m.ah+1,-6-k*7],[1,1,6],(170,20,30) if k!=1 else (130,14,24),mat="wood")
    M[m.name]=m
    # Megumi Fushiguro: spiky black hair, dark uniform, shadow pooling at his feet
    m=humanoid("megumi_fushiguro",s=0.97,skin=(228,204,186),top=(18,18,30),bottom=(18,18,30),
        face=face_human(hair=(14,14,22),eye=(20,40,60),iris=(40,80,120),brow=(14,14,22),skin=(228,204,186)),
        body_painter=multi(buttons(GOLD),emblem(GOLD,1,False)),shoes=(10,10,14))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    for k,(x,z,hgt) in enumerate(((-3,-3,3),(0,-2,4),(2,-3,3),(-2,1,4),(1,1,5),(-3,2,3),(2,2,3))):
        add(m,"head",[x,ty+hs,z],[2,hgt,2],(14,14,22),mat="hair")
    add(m,"body",[-bw/2-0.5,ty-3,-2.5],[bw+1,3,5],(26,26,40),trim((60,60,90)))
    m.bone("shadow","root",[0,0,0],[Cube([-6,0.05,-6],[12,0.1,12],(6,6,12),glow=None,mat="plain"),Cube([-1,0.1,-1],[2,0.1,2],(40,30,90),glow="full",mat="plain")])
    M[m.name]=m
    # Aoi Todo: huge, topknot, scar, open jacket over a bare chest
    m=humanoid("aoi_todo",s=1.2,skin=(196,150,118),top=(196,150,118),bottom=(30,30,44),arms_col=(196,150,118),
        face=face_human(hair=(18,14,12),eye=(20,20,20),iris=(60,40,30),brow=(18,14,12),skin=(196,150,118),mouth=(110,50,40)),
        body_painter=multi(trim((150,100,80),False,False,True)),shoes=(20,16,14))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    add(m,"head",[-hs/2,ty+hs,-hs/2],[hs,1,hs],(18,14,12),mat="hair"); add(m,"head",[-1.5,ty+hs+1,-1.5],[3,3,3],(18,14,12),mat="hair")
    add(m,"head",[1,ty+hs/2,-hs/2-0.3],[1,3,0.3],(140,70,60),mat="skin")                                               # scar
    add(m,"body",[-bw/2-0.6,lh,-bw/4-0.6],[2.6,bh,bw/2+1.2],(30,30,44)); add(m,"body",[bw/2-2,lh,-bw/4-0.6],[2.6,bh,bw/2+1.2],(30,30,44))  # open jacket
    M[m.name]=m
    # Kento Nanami: blond side part, tinted goggles, beige suit, leopard tie, wrapped blunt blade
    m=humanoid("kento_nanami",s=1.03,skin=(228,200,178),top=(200,184,150),bottom=(190,174,140),
        face=face_human(hair=(232,206,120),eye=(20,20,20),iris=(60,60,40),brow=(200,170,90),skin=(228,200,178),mouth=(130,80,70)),
        body_painter=multi(buttons((120,100,70)),trim((160,144,110),True,False)),shoes=(60,40,30))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    add(m,"head",[-hs/2,ty+hs,-hs/2],[hs,2,hs],(232,206,120),mat="hair"); add(m,"head",[-hs/2-0.5,ty+hs-3,-hs/2],[1,4,hs],(232,206,120),mat="hair")
    add(m,"head",[-hs/2,ty+hs/2,-hs/2-0.6],[hs,2,0.6],(70,130,120),glow=None,mat="metal")                                # goggles
    add(m,"body",[-1,ty-9,-2.6],[2,8,0.6],(170,120,50),stripes((40,26,14),2,False))                                     # leopard tie
    add(m,"right_forearm",[-bw/2-aw/2-1,ty-m.ah,-12],[2,3,12],(230,226,214),stripes((60,50,40),2,False),mat="cloth")    # wrapped blade
    M[m.name]=m
    # ---------------- Malevolent Shrine ----------------
    m=Model("malevolent_shrine"); m.bone("root",None,[0,0,0])
    m.bone("base","root",[0,0,0],[Cube([-40,0,-40],[80,6,80],(40,10,14),stripes(BONE,8,False),mat="wood"),Cube([-30,6,-30],[60,4,60],(26,8,10),mat="wood")])
    m.bone("pillars","base",[0,10,0],[Cube([x,10,z],[8,40,8],(120,14,26),stripes(BLACK,6,False),mat="wood") for (x,z) in ((-24,-24),(16,-24),(-24,16),(16,16))])
    m.bone("roof","pillars",[0,50,0],[Cube([-44,50,-44],[88,6,88],(18,10,12),stripes((60,16,20),4,False)),Cube([-30,56,-30],[60,8,60],(24,12,14)),
                                      Cube([-14,64,-14],[28,10,28],(140,16,30),emblem(CE,0,True))])
    m.bone("jaw","base",[0,10,-28],[Cube([-18,10,-34],[36,8,8],(150,20,34),face_curse(0,BONE,True),mat="flesh")])
    m.bone("maw","roof",[0,44,-28],[Cube([-18,40,-34],[36,10,8],(150,20,34),face_curse(6,CE,True),mat="flesh")])
    m.bone("skulls","base",[0,6,0],[Cube([-36+k*12,6,-38],[6,6,6],BONE,face_curse(2,CE,False),mat="bone") for k in range(7)])
    m.bone("horn_l","roof",[-30,64,0],[Cube([-34,64,-3],[4,14,6],BONE,mat="bone")]); m.bone("horn_r","roof",[30,64,0],[Cube([30,64,-3],[4,14,6],BONE,mat="bone")])
    m.plan="shrine"; M[m.name]=m
    # ---------------- Projectiles ----------------
    m=Model("dismantle_slash"); m.bone("root",None,[0,0,0])
    m.bone("blade","root",[0,4,0],[Cube([-1+(k-3)*2,4-abs(k-3),-1],[2,1,2],(255,240,245),glow="full",mat="plain") for k in range(7)]+[Cube([-7,2,-0.5],[14,1,1],CE,glow="full",mat="plain")])
    m.plan="proj"; M[m.name]=m
    m=Model("fuga_arrow"); m.bone("root",None,[0,0,0])
    m.bone("arrow","root",[0,4,0],[Cube([-0.5,3.5,-8],[1,1,16],(255,180,60),glow="full",mat="plain"),Cube([-1.5,2.5,-10],[3,3,3],(255,240,160),glow="full",mat="plain"),
                                   Cube([-2,2,6],[4,4,2],(255,90,20),glow="full",mat="plain")])
    m.plan="proj"; M[m.name]=m
    mahoraga_model(M)
    return M

def yuta_extra():
    return {
     "stitch":A(1.6,True,{"root":{"position":cyc(1.6,[(0,R(0,-5,0)),(0.5,R(0,-5.1,0))])},"body":{"rotation":cyc(1.6,[(0,R(38)),(0.5,R(42))])},
         "head":{"rotation":cyc(1.6,[(0,R(-26)),(0.5,R(-30))])},
         "right_leg":{"rotation":cyc(1.6,[(0,R(-85)),(0.5,R(-85))])},"right_shin":{"rotation":cyc(1.6,[(0,R(95)),(0.5,R(95))])},
         "left_leg":{"rotation":cyc(1.6,[(0,R(-30)),(0.5,R(-30))])},"left_shin":{"rotation":cyc(1.6,[(0,R(80)),(0.5,R(80))])},
         "right_arm":{"rotation":cyc(1.6,[(0,R(-70,-10,0)),(0.25,R(-80,-25,0)),(0.5,R(-70,-10,0)),(0.75,R(-85,5,0))])},
         "right_forearm":{"rotation":cyc(1.6,[(0,R(-40)),(0.25,R(-20)),(0.5,R(-40)),(0.75,R(-30))])},
         "left_arm":{"rotation":cyc(1.6,[(0,R(-75,15,0)),(0.5,R(-78,15,0))])},"left_forearm":{"rotation":cyc(1.6,[(0,R(-45)),(0.5,R(-48))])}}),
     "collapse":A(1.5,"hold",{"root":{"position":[(0,R(0,-5,0)),(0.6,R(0,-6,0)),(1.5,R(0,-10.5,0))],"rotation":[(0,R()),(0.6,R(0,0,6)),(1.5,R(0,0,82))]},
         "head":{"rotation":[(0,R(-26)),(0.4,R(20)),(1.5,R(10,0,-15))]},"right_arm":{"rotation":[(0,R(-70)),(0.4,R(-10,0,10)),(1.5,R(0,0,20))]},
         "left_arm":{"rotation":[(0,R(-75)),(0.4,R(-5,0,-10)),(1.5,R(10,0,-30))]},"right_leg":{"rotation":[(0,R(-85)),(1.5,R(-10))]},
         "right_shin":{"rotation":[(0,R(95)),(1.5,R(10))]},"left_leg":{"rotation":[(0,R(-30)),(1.5,R(-20))]},"left_shin":{"rotation":[(0,R(80)),(1.5,R(20))]}}),
    }

def yuta_model(M):
    """v1.0.25 (rebuilt) Yuta Okkotsu: all-white Jujutsu uniform, messy black hair, tired dark eyes with bags, katana, Rika's ring."""
    W_=(238,238,242); W2=(204,204,214); HAIR=(14,13,18); SKN=(234,210,192)
    def face(img,glow,x,y,w,h,faces):
        cx=x+w//2; ey=y+4
        for ex in (cx-3,cx+1):
            rect(img,ex,ey,ex+1,ey,(236,232,228)); P(img,ex+(1 if ex<cx else 0),ey,(26,22,30))
            rect(img,ex,ey-1,ex+1,ey-1,(28,24,32))
            rect(img,ex,ey+1,ex+1,ey+1,(168,136,148))
        P(img,cx-1,ey+2,shade(SKN,0.86))
        rect(img,cx-1,ey+3,cx,ey+3,(150,96,96))
    m=humanoid("yuta_okkotsu",skin=SKN,top=W_,bottom=W_,arms_col=W_,shoes=(18,18,22),face=face,
        body_painter=multi(trim(W2,False,True),buttons((150,150,165))),arm_painter=trim(W2,False,True),leg_painter=trim(W2,False,True))
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    H=lambda o,sz: add(m,"head",o,sz,HAIR,mat="hair")
    H([-4.5,ty+7,-4.5],[9,2,9]); H([-4.6,ty+3,-4],[1,5,8]); H([3.6,ty+3,-4],[1,5,8]); H([-4,ty+2,3.6],[8,7,1])
    for x,hgt in ((-4,3),(-2,2),(-1,3),(1,2),(2,3)): H([x,ty+8-hgt,-4.7],[1 if x!=-1 else 2,hgt,1])
    for o,sz in (([-3,ty+9,-3],[3,2,3]),([0,ty+9,-1],[3,2,4]),([-5,ty+7,-2],[1,2,3]),([4,ty+6,0],[2,2,2]),([-2,ty+9,1],[2,2,3]),([2,ty+8,2.6],[2,2,2])): H(o,sz)
    add(m,"body",[-4.5,ty-3,-2.6],[9,3,5.2],W_,trim(W2))
    add(m,"body",[-4.4,lh-4,-2.3],[8.8,5,4.6],W_,trim(W2,False,True))
    add(m,"body",[-0.4,ty-12,2.2],[1.4,13,1.2],(26,20,28),mat="wood")
    add(m,"right_forearm",[-bw/2-aw/2-0.5,ty-m.ah+1,-16],[1,1,15],(222,224,232),mat="metal")
    add(m,"right_forearm",[-bw/2-aw/2-1.5,ty-m.ah+0.5,-1.4],[3,2,1],(40,34,30),mat="metal")
    add(m,"right_forearm",[-bw/2-aw/2-1,ty-m.ah,-0.4],[2,2,4],(32,18,26),mat="wood")
    add(m,"left_forearm",[bw/2+aw-0.5,ty-m.ah+1,-1],[1,1,1],(235,235,245),glow="full",mat="metal")
    M[m.name]=m

def ryu_model(M):
    """v1.0.25 Ryu Ishigori: black coat with white fur, open on a bare chest with a necklace, maroon belt with a gold star,
    black trousers, and the cannon pompadour pointing forward with the barrel open at the front."""
    SK=(228,192,166); COAT=(18,16,22); FUR=(238,234,228); PANT=(20,18,24); BELT=(112,22,32); HAIR=(30,22,30); GLD=(222,182,64)
    def chest(img,glow,x,y,w,h,faces):
        cx=x+w//2; d=shade(SK,0.82)
        rect(img,cx,y+4,cx,y+h-2,d)
        rect(img,cx-3,y+4,cx-1,y+4,d); rect(img,cx+1,y+4,cx+3,y+4,d)
        for yy in (y+7,y+9): P(img,cx-1,yy,d); P(img,cx+1,yy,d)
        for xx in range(cx-2,cx+3): P(img,xx,y+1+abs(xx-cx)//2,(196,198,206))
        P(img,cx,y+3,(150,154,166))
    def face(img,glow,x,y,w,h,faces):
        cx=x+w//2; ey=y+5
        for ex in (cx-3,cx+1):
            rect(img,ex,ey,ex+1,ey,(240,238,236)); P(img,ex+(1 if ex<cx else 0),ey,(70,110,180))
            rect(img,ex,ey-2,ex+1,ey-2,HAIR)
        P(img,cx-1,ey+2,shade(SK,0.84))
        rect(img,cx-1,ey+4,cx+1,ey+4,(130,74,70)); P(img,cx+2,ey+3,(130,74,70))
    m=humanoid("ryu_ishigori",s=1.1,skin=SK,top=SK,bottom=PANT,arms_col=COAT,hands=SK,shoes=(12,12,14),face=face,body_painter=chest)
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y; bd=4
    add(m,"body",[-bw/2-0.6,lh-3,bd/2-0.1],[bw+1.2,bh+3,1],COAT)
    add(m,"body",[-bw/2-0.7,lh-3,-bd/2-0.7],[2.6,bh+3,bd+1.4],COAT)
    add(m,"body",[bw/2-1.9,lh-3,-bd/2-0.7],[2.6,bh+3,bd+1.4],COAT)
    add(m,"body",[-bw/2-1,lh-4,-bd/2-1],[bw+2,1.5,bd+2],FUR)
    add(m,"body",[-bw/2-1.4,ty-2,-bd/2-1.2],[bw+2.8,3,bd+2.4],FUR)
    add(m,"body",[-bw/2+1.6,lh,-bd/2-0.4],[bw-3.2,1.6,1],BELT)
    add(m,"body",[-1,lh-0.2,-bd/2-0.9],[2,2,1],GLD,mat="metal")
    for side,bn in ((-1,"right_forearm"),(1,"left_forearm")):
        x0=-(bw/2+aw) if side<0 else bw/2
        add(m,bn,[x0-0.5,ty-m.ah+1.5,-aw/2-0.5],[aw+1,2,aw+1],FUR)
    add(m,"head",[-hs/2-0.3,ty+hs-2,-hs/2+2],[hs+0.6,2.4,hs-1.5],HAIR,mat="hair")
    add(m,"head",[-hs/2-0.3,ty+3,hs/2-0.6],[hs+0.6,hs-3,1],HAIR,mat="hair")
    add(m,"head",[-hs/2-0.4,ty+4,-hs/2+2],[1,hs-4,hs-2],HAIR,mat="hair"); add(m,"head",[hs/2-0.6,ty+4,-hs/2+2],[1,hs-4,hs-2],HAIR,mat="hair")
    def muzzle(img,glow,x,y,w,h,faces):
        cx,cy=x+w//2,y+h//2
        rect(img,cx-1,cy-1,cx+1,cy+1,(10,8,12)); P(img,cx,cy,(230,240,255)); P(glow,cx,cy,(230,240,255))
    add(m,"head",[-3.5,ty+hs-2,-hs/2-6],[7,6,9],HAIR,mat="hair")
    add(m,"head",[-3,ty+hs-1.5,-hs/2-9],[6,5,3],HAIR,muzzle,mat="hair")
    add(m,"head",[-2.5,ty+hs+3.5,-hs/2-4],[5,1.4,6],shade(HAIR,1.3),mat="hair")
    M[m.name]=m

def rika_model(M):
    """v1.0.25 (rebuilt) Rika: hunched pale giant, enormous head split by a grin full of teeth, tiny red eyes,
    long black hair growing from the head and falling down the back, very long arms with huge clawed hands."""
    SK=(224,220,214); SK2=(178,174,172); SK3=(150,146,146); HAIR=(10,9,12); NAIL=(36,26,30); O=8
    def wrinkles(img,glow,x,y,w,h,faces):
        for fn,(fx,fy,fw,fh,_) in faces.items():
            if fn in("top","bottom"): continue
            for yy in range(fy+1,fy+fh,3):
                for xx in range(fx,fx+fw):
                    if (xx*3+yy)%5!=0: P(img,xx,yy,SK2)
    def ribs(img,glow,x,y,w,h,faces):
        wrinkles(img,glow,x,y,w,h,faces)
        cx=x+w//2
        for yy in range(y+2,y+h-1,2):
            for xx in range(x+2,x+w-2):
                if abs(xx-cx)>1: P(img,xx,yy,SK3)
        rect(img,cx,y+1,cx,y+h-2,SK3)
    def face(img,glow,x,y,w,h,faces):
        cx=x+w//2
        rect(img,x+2,y+2,x+w-3,y+2,SK3)                        # heavy brow
        for ex in (cx-5,cx+3):
            rect(img,ex,y+3,ex+1,y+4,(16,10,14)); P(img,ex+1 if ex<cx else ex,y+3,(255,40,60)); P(glow,ex+1 if ex<cx else ex,y+3,(255,40,60))
        my=y+6
        rect(img,x+1,my,x+w-2,y+h-2,(56,6,14))                # mouth from ear to ear
        P(img,x,my-1,(56,6,14)); P(img,x+w-1,my-1,(56,6,14)); P(img,x,my-2,SK3); P(img,x+w-1,my-2,SK3)
        for xx in range(x+1,x+w-1):                           # two rows of big teeth, a smaller row behind
            if xx%2==0:
                P(img,xx,my,(242,238,226)); P(img,xx,my+1,(242,238,226))
                P(img,xx,y+h-2,(242,238,226)); P(img,xx,y+h-3,(228,222,206))
            else:
                P(img,xx,my,(212,206,190)); P(img,xx,my+2,(200,194,178))
        P(glow,cx,my+3,(120,10,24))
    m=Model("rika_orimoto"); m.bone("root",None,[0,0,0])
    m.bone("body","root",[0,O+10,0],[Cube([-5,O+4,-4],[10,8,8],SK,wrinkles,mat="skin"),Cube([-7,O+11,-5],[14,7,10],SK,wrinkles,mat="skin"),
        Cube([-9,O+18,-6],[18,9,12],SK,ribs,mat="skin"),Cube([-10,O+25,-4],[20,4,9],SK,wrinkles,mat="skin"),
        Cube([-8,O+21,6],[16,9,1],HAIR,mat="hair")],rot=[22,0,0])
    # the head: skull, crown of hair, side locks framing the face, a thick curtain growing from the back of the head
    m.bone("head","body",[0,O+28,-3],[Cube([-8,O+27,-14],[16,13,13],SK,face,mat="skin"),
        Cube([-8.5,O+39,-14.5],[17,2,14],HAIR,mat="hair"),
        Cube([-9,O+25,-13],[1,15,12],HAIR,mat="hair"),Cube([8,O+25,-13],[1,15,12],HAIR,mat="hair"),
        Cube([-8.5,O+26,-2],[17,15,2],HAIR,mat="hair")],rot=[-18,0,0])
    m.bone("hair","head",[0,O+27,-1],[Cube([-8,O+9,-2],[16,18,2],HAIR,mat="hair"),Cube([-6,O+5,-1.5],[12,4,1.5],HAIR,mat="hair")])
    for side,sx in (("right",-1),("left",1)):
        x0=-15 if sx<0 else 10
        m.bone(f"{side}_arm","body",[sx*11.5,O+27,0],[Cube([x0,O+14,-2.5],[5,14,5],SK,wrinkles,mat="skin")],rot=[-30,0,-12*sx])
        cl=[Cube([x0,O,-2.5],[5,14,5],SK,wrinkles,mat="skin"),Cube([x0-1,O-4,-3.5],[7,4,7],SK,mat="skin")]
        cl+=[Cube([x0-1+k*1.8,O-9,-3.5],[1,5,1],NAIL,mat="bone") for k in range(4)]
        m.bone(f"{side}_forearm",f"{side}_arm",[sx*12.5,O+14,0],cl,rot=[-25,0,0])
        m.bone(f"{side}_leg","root",[sx*2.5,O+5,0],[Cube([-2 if sx>0 else -4.5,O-1,-2],[4,6,4],SK,mat="skin")],rot=[-35,0,0])
        m.bone(f"{side}_shin",f"{side}_leg",[sx*2.5,O-1,0],[Cube([-1.5 if sx>0 else -3.5,O-5,-1.5],[3,4,3],SK2,mat="skin")])
    m.plan="humanoid"; m.top_y=O+28; m.hs=13; m.ah=28; m.dims=(10,20,13,18,5)
    M[m.name]=m

def rika_extra():
    return {
     "idle":A(4.0,True,{"root":{"position":cyc(4,[(0,R()),(0.5,R(0,0.9,0))])},
         "right_arm":{"rotation":cyc(4,[(0,R(-6,0,4)),(0.5,R(-12,0,6))])},"left_arm":{"rotation":cyc(4,[(0,R(-6,0,-4)),(0.5,R(-12,0,-6))])},
         "right_forearm":{"rotation":cyc(4,[(0,R(-4)),(0.5,R(-12))])},"left_forearm":{"rotation":cyc(4,[(0,R(-4)),(0.5,R(-12))])},
         "head":{"rotation":cyc(4,[(0,R(-4,8)),(0.5,R(-2,-8))])},"hair":{"rotation":cyc(4,[(0,R(4)),(0.5,R(-2))])}}),
     "slash":A(0.9,False,{"right_arm":{"rotation":[(0,R()),(0.3,R(-110,0,40)),(0.6,R(-40,0,-30)),(0.9,R())]},
         "right_forearm":{"rotation":[(0,R()),(0.3,R(-40)),(0.6,R(15)),(0.9,R())]},
         "body":{"rotation":[(0,R()),(0.3,R(-6,30,0)),(0.6,R(8,-30,0)),(0.9,R())]}}),
     "attack":A(0.6,False,{"left_arm":{"rotation":[(0,R()),(0.2,R(-100,0,10)),(0.4,R(-70,0,6)),(0.6,R())]},
         "left_forearm":{"rotation":[(0,R()),(0.2,R(15)),(0.6,R())]},"head":{"rotation":[(0,R()),(0.2,R(-10)),(0.6,R())]}}),
     "cast":A(1.4,False,{"right_arm":{"rotation":[(0,R()),(0.4,R(-130,0,45)),(1.0,R(-125,0,45)),(1.4,R())]},"left_arm":{"rotation":[(0,R()),(0.4,R(-130,0,-45)),(1.0,R(-125,0,-45)),(1.4,R())]},
         "head":{"rotation":[(0,R()),(0.4,R(-25)),(1.0,R(-22)),(1.4,R())]},"body":{"rotation":[(0,R()),(0.4,R(-12)),(1.4,R())]}}),
     "rise":A(1.6,"hold",{"root":{"position":[(0,R(0,-40,0)),(1.2,R(0,1,0)),(1.6,R())]},"head":{"rotation":[(0,R(25)),(1.2,R(-10)),(1.6,R())]},
         "right_arm":{"rotation":[(0,R(-150,0,30)),(1.2,R(-60,0,20)),(1.6,R())]},"left_arm":{"rotation":[(0,R(-150,0,-30)),(1.2,R(-60,0,-20)),(1.6,R())]}}),
    }

def mahoraga_model(M):
    """v1.0.22 Eight-Handled Sword Divergent Sila Divine General Mahoraga: pale giant, Dharma Wheel over the head, Sword of Extermination."""
    MS=(214,210,200); CL=(236,232,222); GOLDW=(201,162,39)
    m=humanoid("mahoraga",s=1.7,skin=MS,top=MS,bottom=CL,arms_col=MS,hands=MS,
        face=face_human(hair=MS,eye=(40,36,34),iris=(70,64,60),brow=MS,skin=MS,mouth=(120,96,90)),shoes=MS)
    ty=m.top_y; lh,bh,hs,bw,aw=m.dims
    add(m,"body",[-bw/2-0.5,lh-2,-2.6*1.7],[bw+1,4,5.2*1.7],CL,trim(GOLDW))                                   # loincloth
    add(m,"head",[-hs/2-1,ty+2,-1],[2,6,2],(190,186,176)); add(m,"head",[hs/2-1,ty+2,-1],[2,6,2],(190,186,176))  # wing-like ears
    add(m,"head",[-hs/2,ty+hs/2,-hs/2-0.3],[hs,2,0.4],(150,146,140))                                         # the closed eye band
    wy=ty+hs+5; R0=7
    cubes=[Cube([-1,wy-1,-1],[2,2,2],GOLDW,mat="metal",glow="full")]
    cubes.append(Cube([-R0,wy-0.5,-0.5],[2*R0,1,1],GOLDW,mat="metal")); cubes.append(Cube([-0.5,wy-0.5,-R0],[1,1,2*R0],GOLDW,mat="metal"))
    for sx,sz in ((-R0,-R0),(R0-1.5,-R0),(-R0,R0-1.5),(R0-1.5,R0-1.5)): cubes.append(Cube([sx,wy-0.75,sz],[1.5,1.5,1.5],GOLDW,mat="metal"))
    cubes.append(Cube([-R0,wy-0.75,-R0],[2*R0,1.5,1],GOLDW,mat="metal")); cubes.append(Cube([-R0,wy-0.75,R0-1],[2*R0,1.5,1],GOLDW,mat="metal"))
    cubes.append(Cube([-R0,wy-0.75,-R0],[1,1.5,2*R0],GOLDW,mat="metal")); cubes.append(Cube([R0-1,wy-0.75,-R0],[1,1.5,2*R0],GOLDW,mat="metal"))
    m.bone("wheel","head",[0,wy,0],cubes)
    add(m,"right_forearm",[-bw/2-aw/2-0.75,ty-m.ah-2,-1],[1.5,1.5,30],(226,228,236),mat="metal",glow="full")   # Sword of Extermination
    add(m,"right_forearm",[-bw/2-aw/2-2,ty-m.ah-3,-2],[4,3.5,3],GOLDW,mat="metal")
    M[m.name]=m

def mahoraga_extra():
    return {
     "adapt":A(1.0,False,{"wheel":{"rotation":[(0,R()),(0.6,R(0,45,0)),(1.0,R(0,45,0))]},"head":{"rotation":[(0,R()),(0.3,R(-8)),(1.0,R())]}}),
     "rise":A(1.6,"hold",{"root":{"position":[(0,R(0,-60,0)),(1.2,R(0,0,0)),(1.6,R())]},"head":{"rotation":[(0,R(30)),(1.2,R(10)),(1.6,R())]},
         "right_arm":{"rotation":[(0,R(-170)),(1.2,R(-40)),(1.6,R())]},"left_arm":{"rotation":[(0,R(-170)),(1.2,R(-40)),(1.6,R())]}}),
     "punch":A(0.6,False,{"left_arm":{"rotation":[(0,R()),(0.18,R(-30,0,-30)),(0.3,R(-100,0,0)),(0.6,R())]},"left_forearm":{"rotation":[(0,R(-8)),(0.18,R(-90)),(0.3,R(0)),(0.6,R(-8))]},
         "body":{"rotation":[(0,R()),(0.18,R(0,25,0)),(0.3,R(8,-30,0)),(0.6,R())]},"right_leg":{"rotation":[(0,R()),(0.3,R(18)),(0.6,R())]},"left_leg":{"rotation":[(0,R()),(0.3,R(-25)),(0.6,R())]}}),
     "dead":A(1.4,"hold",{"root":{"rotation":[(0,R()),(0.8,R(-40,0,10)),(1.4,R(-88,0,10))],"position":[(0,R()),(1.4,R(0,3,0))]},
         "wheel":{"rotation":[(0,R()),(1.4,R(40,90,20))],"position":[(0,R()),(1.4,R(0,-6,6))]},"right_arm":{"rotation":[(0,R()),(1.4,R(-20,0,60))]},"left_arm":{"rotation":[(0,R()),(1.4,R(-20,0,-60))]}}),
    }

BLOOD_BONES=("blood_pool","blood_upper","blood_lower")
def gojo_extra():
    Z=[(0,R(0,0,0))]
    return {
     "infinity":A(2.0,True,{"right_arm":{"rotation":cyc(2,[(0,R(-80,-15,-10)),(0.5,R(-84,-15,-12))])},"right_forearm":{"rotation":cyc(2,[(0,R(-55)),(0.5,R(-60))])},
         "left_arm":{"rotation":cyc(2,[(0,R(5,0,-6)),(0.5,R(5,0,-8))])},"left_forearm":{"rotation":cyc(2,[(0,R(-40)),(0.5,R(-42))])},
         "head":{"rotation":cyc(2,[(0,R(-4,10)),(0.5,R(-6,6))])}}),
     "blue":A(1.2,False,{"right_arm":{"rotation":[(0,R()),(0.25,R(-95,10,0)),(0.9,R(-95,10,0)),(1.2,R(-60))]},"right_forearm":{"rotation":[(0,R(-8)),(0.25,R(0)),(1.2,R(-20))]},
         "left_arm":{"rotation":[(0,R()),(0.25,R(8,0,-8)),(1.2,R(5))]},"left_forearm":{"rotation":[(0,R(-8)),(0.25,R(-45)),(1.2,R(-40))]},
         "body":{"rotation":[(0,R()),(0.25,R(0,-20,0)),(0.9,R(0,-18,0)),(1.2,R())]},"head":{"rotation":[(0,R()),(0.25,R(0,15,0)),(1.2,R())]}}),
     "red":A(1.2,False,{"right_arm":{"rotation":[(0,R()),(0.3,R(-30,0,40)),(0.55,R(-95,0,-5)),(1.2,R(-60))]},"left_arm":{"rotation":[(0,R()),(0.3,R(-30,0,-40)),(0.55,R(-95,0,5)),(1.2,R(-60))]},
         "right_forearm":{"rotation":[(0,R(-8)),(0.3,R(-80)),(0.55,R(0)),(1.2,R(-20))]},"left_forearm":{"rotation":[(0,R(-8)),(0.3,R(-80)),(0.55,R(0)),(1.2,R(-20))]},
         "body":{"rotation":[(0,R()),(0.3,R(-10)),(0.55,R(12)),(1.2,R())]},"right_leg":{"rotation":[(0,R()),(0.55,R(-20)),(1.2,R())]},"left_leg":{"rotation":[(0,R()),(0.55,R(18)),(1.2,R())]}}),
     # v1.0.18 Strongest of Today intro: stabbed by Toji, dies, comes back with RCT, Hollow Purple
     "stabbed":A(0.5,False,{"body":{"rotation":[(0,R()),(0.1,R(18,0,-6)),(0.5,R(10))]},"head":{"rotation":[(0,R()),(0.1,R(25)),(0.5,R(12))]},
         "right_arm":{"rotation":[(0,R()),(0.1,R(-30,0,30)),(0.5,R(-10,0,15))]},"left_arm":{"rotation":[(0,R()),(0.1,R(-30,0,-30)),(0.5,R(-10,0,-15))]},
         "right_leg":{"rotation":[(0,R()),(0.1,R(-15)),(0.5,R(-5))]}}),
     "fall_dead":A(1.4,"hold",{"root":{"rotation":[(0,R()),(0.5,R(-20,0,0)),(1.1,R(-90,0,0)),(1.4,R(-90,0,0))],"position":[(0,R()),(1.1,R(0,2,0)),(1.4,R(0,2,0))]},
         "head":{"rotation":[(0,R()),(1.1,R(0,30,0)),(1.4,R(0,30,0))]},"right_arm":{"rotation":[(0,R()),(1.1,R(-10,0,50)),(1.4,R(-10,0,50))]},
         "left_arm":{"rotation":[(0,R()),(1.1,R(-20,0,-35)),(1.4,R(-20,0,-35))]},"left_leg":{"rotation":[(0,R()),(1.1,R(0,0,-12)),(1.4,R(0,0,-12))]}}),
     "rise":A(2.0,"hold",{"root":{"rotation":[(0,R(-90,0,0)),(0.6,R(-90,0,0)),(1.4,R(-15,0,0)),(2.0,R())],"position":[(0,R(0,2,0)),(1.4,R(0,0.5,0)),(2.0,R())]},
         "head":{"rotation":[(0,R(0,30,0)),(0.6,R(-35,0,0)),(1.4,R(-25,0,0)),(2.0,R(-10,0,0))]},
         "right_arm":{"rotation":[(0,R(-10,0,50)),(1.0,R(-20,0,70)),(2.0,R(-15,0,40))]},"left_arm":{"rotation":[(0,R(-20,0,-35)),(1.0,R(-20,0,-70)),(2.0,R(-15,0,-40))]}}),
     "purple":A(1.6,"hold",{"right_arm":{"rotation":[(0,R()),(0.5,R(-90,-10,-25)),(1.0,R(-90,-5,-5)),(1.6,R(-92,0,0))]},
         "left_arm":{"rotation":[(0,R()),(0.5,R(-90,10,25)),(1.0,R(-80,25,10)),(1.6,R(-10,0,-10))]},
         "right_forearm":{"rotation":[(0,R(-8)),(0.5,R(-20)),(1.6,R(0))]},"left_forearm":{"rotation":[(0,R(-8)),(0.5,R(-20)),(1.6,R(-30))]},
         "body":{"rotation":[(0,R()),(0.5,R(0,10,0)),(1.6,R(0,-15,0))]},"head":{"rotation":[(0,R()),(0.5,R(-8)),(1.6,R(-4))]}}),
     "cut_in_half":A(3.0,"hold",{
         "body":{"position":[(0,R()),(0.25,R(0,0.5,0)),(0.6,R(3,-2,-1)),(1.1,R(8,-9,-2)),(1.4,R(10,-12,-2)),(3.0,R(10,-12,-2))],
                 "rotation":[(0,R()),(0.25,R(0,0,5)),(0.6,R(10,6,30)),(1.1,R(20,10,78)),(1.4,R(18,12,90)),(1.6,R(18,12,86)),(3.0,R(18,12,88))]},
         "head":{"rotation":[(0,R()),(0.6,R(-20)),(1.4,R(10,0,-10)),(3.0,R(10,0,-10))]},
         "right_arm":{"rotation":[(0,R()),(0.6,R(-60,0,30)),(1.4,R(-150,0,10)),(3.0,R(-150,0,10))]},"left_arm":{"rotation":[(0,R()),(0.6,R(-30,0,-60)),(1.4,R(-10,0,-30)),(3.0,R(-10,0,-30))]},
         "right_forearm":{"rotation":[(0,R(-8)),(1.4,R(-30)),(3,R(-30))]},"left_forearm":{"rotation":[(0,R(-8)),(1.4,R(-60)),(3,R(-60))]},
         "hips":{"rotation":[(0,R()),(0.8,R()),(1.3,R(25)),(1.8,R(82)),(2.0,R(78)),(3.0,R(80))],"position":[(0,R()),(1.8,R(0,0,1)),(3.0,R(0,0,1))]},
         "right_leg":{"rotation":[(0,R()),(0.8,R(-5,0,4)),(1.8,R(-20,0,6)),(3,R(-20,0,6))]},"left_leg":{"rotation":[(0,R()),(0.8,R(5,0,-4)),(1.8,R(-5,0,-8)),(3,R(-5,0,-8))]},
         "right_shin":{"rotation":[(0,R()),(1.0,R(30)),(1.8,R(10)),(3,R(10))]},
         "blood_upper":{"scale":[(0,R(0.001,0.001,0.001)),(0.2,R(0.001,0.001,0.001)),(0.3,R(1,1.6,1)),(0.6,R(1,1,1)),(3,R(1,1.2,1))]},
         "blood_lower":{"scale":[(0,R(0.001,0.001,0.001)),(0.2,R(0.001,0.001,0.001)),(0.3,R(1.2,2.2,1.2)),(0.7,R(1,1,1)),(1.0,R(1,1.6,1)),(1.4,R(1,1,1)),(3,R(1,1.1,1))]},
         "blood_pool":{"scale":[(0,R(0.001,1,0.001)),(0.8,R(0.001,1,0.001)),(1.6,R(0.45,1,0.45)),(3.0,R(1,1,1))]}},0.05),
    }

def gojo_eyes_model():
    GJ=(18,18,30)
    m=humanoid("gojo_satoru",skin=(238,216,202),top=GJ,bottom=GJ,split=True,hands=(238,216,202),
        face=face_human(hair=(250,250,255),eye=(80,180,255),iris=(110,200,255),glow_eyes=True,brow=(235,235,245),skin=(238,216,202)),body_painter=multi(buttons((60,60,90)),emblem(GOLD,3,False)))
    return m
def gojo_kenjaku_model():
    GJ=(14,14,22)
    m=humanoid("gojo_satoru",skin=(236,212,198),top=GJ,bottom=GJ,split=True,hands=(236,212,198),
        face=face_human(hair=(250,250,255),eye=(150,90,255),iris=(120,190,255),glow_eyes=True,brow=(235,235,245),skin=(236,212,198),stitches=(60,24,30)),
        body_painter=multi(buttons((60,60,90)),emblem((120,60,200),3,False)))
    return m
def geto_extra():
    return {"talk":A(3.0,True,{"right_arm":{"rotation":cyc(3,[(0,R(-25,0,8)),(0.3,R(-45,-15,10)),(0.6,R(-20,0,8))])},
        "right_forearm":{"rotation":cyc(3,[(0,R(-40)),(0.3,R(-60)),(0.6,R(-35))])},"left_arm":{"rotation":cyc(3,[(0,R(-5,0,-4)),(0.5,R(-8,0,-6))])},
        "head":{"rotation":cyc(3,[(0,R(2,0,0)),(0.25,R(-4,8,0)),(0.5,R(3,0,0)),(0.75,R(-3,-8,0))])},"body":{"rotation":cyc(3,[(0,R()),(0.5,R(2,0,0))])}})}

def toji_extra():
    S=lambda v:R(v,v,v)
    lie={"root":{"rotation":[(0,R(-90,0,0)),(1,R(-90,0,0))],"position":[(0,R(0,2,0)),(1,R(0,2,0))]},
         "head":{"rotation":[(0,R(0,25,0)),(1,R(0,25,0))]},"right_arm":{"rotation":[(0,R(-10,0,40)),(1,R(-10,0,40))]},
         "left_arm":{"scale":[(0,S(0.001)),(1,S(0.001))]},"right_leg":{"rotation":[(0,R(0,0,8)),(1,R(0,0,8))]},"left_leg":{"rotation":[(0,R(5,0,-14)),(1,R(5,0,-14))]}}
    lie2={k:dict(v) for k,v in lie.items()}; lie2["worm"]={"scale":[(0,S(0.001)),(1,S(0.001))]}
    return {
     "stab":A(0.6,False,{"right_arm":{"rotation":[(0,R(-20)),(0.15,R(-40,0,25)),(0.3,R(-95,0,-5)),(0.6,R(-20))]},
         "right_forearm":{"rotation":[(0,R(-8)),(0.15,R(-80)),(0.3,R(0)),(0.6,R(-8))]},"left_arm":{"rotation":[(0,R()),(0.3,R(-60,0,-20)),(0.6,R())]},
         "body":{"rotation":[(0,R()),(0.15,R(0,-25,0)),(0.3,R(10,20,0)),(0.6,R())]},"right_leg":{"rotation":[(0,R()),(0.3,R(-30)),(0.6,R())]},"left_leg":{"rotation":[(0,R()),(0.3,R(20)),(0.6,R())]}}),
     "corpse":A(1.0,True,lie),"corpse_noworm":A(1.0,True,lie2),
     "smirk":A(2.0,True,{"head":{"rotation":cyc(2,[(0,R(-6,0,4)),(0.5,R(-8,0,6))])},"right_arm":{"rotation":cyc(2,[(0,R(-10,0,8)),(0.5,R(-12,0,10))])},
         "left_arm":{"rotation":cyc(2,[(0,R(0,0,-6)),(0.5,R(0,0,-8))])}})}

def heian_extra(m):
    """v1.0.17 Heian Sukuna on his throne (true form rig, 4 arms)."""
    lh=m.dims[0]
    sitroot={"position":cyc(4,[(0,R(0,-lh*0.5,0)),(0.5,R(0,-lh*0.5+0.2,0))])}
    legs={"right_leg":{"rotation":cyc(4,[(0,R(-88,8,0)),(0.5,R(-88,8,0))])},"left_leg":{"rotation":cyc(4,[(0,R(-88,-8,0)),(0.5,R(-88,-8,0))])},
          "right_shin":{"rotation":cyc(4,[(0,R(88)),(0.5,R(88))])},"left_shin":{"rotation":cyc(4,[(0,R(88)),(0.5,R(88))])}}
    def sit(onearm):
        b={"root":sitroot,**legs,
           "body":{"rotation":cyc(4,[(0,R(-6)),(0.5,R(-4))])},
           "head":{"rotation":cyc(8,[(0,R(4)),(0.25,R(2,12,0)),(0.5,R(5)),(0.75,R(2,-12,0))])},
           "right_arm":{"rotation":cyc(4,[(0,R(-35,0,12)),(0.5,R(-37,0,12))])},"left_arm":{"rotation":cyc(4,[(0,R(-35,0,-12)),(0.5,R(-37,0,-12))])},
           "right_forearm":{"rotation":cyc(4,[(0,R(-40)),(0.5,R(-42))])},"left_forearm":{"rotation":cyc(4,[(0,R(-40)),(0.5,R(-42))])},
           "right_arm2":{"rotation":cyc(4,[(0,R(-55,0,6)),(0.5,R(-57,0,6))])},"left_arm2":{"rotation":cyc(4,[(0,R(-55,0,-6)),(0.5,R(-57,0,-6))])},
           "right_forearm2":{"rotation":cyc(4,[(0,R(-25)),(0.5,R(-27))])},"left_forearm2":{"rotation":cyc(4,[(0,R(-25)),(0.5,R(-27))])}}
        if onearm: b["right_arm2"]["scale"]=cyc(4,[(0,R(0.001,0.001,0.001)),(0.5,R(0.001,0.001,0.001))])
        return A(4.0,True,b,0.1)
    ex={"throne_sit":sit(False),"throne_sit_onearm":sit(True)}
    # jumpscare: lunges forward off the throne, four arms flung open, roaring
    ex["throne_roar"]=A(1.6,"hold",{"root":{"position":[(0,R(0,-lh*0.5,0)),(0.25,R(0,2,10)),(1.6,R(0,2,10))]},
        "body":{"rotation":[(0,R()),(0.2,R(25)),(1.6,R(22))]},"head":{"rotation":[(0,R()),(0.2,R(-30)),(0.5,R(-26,0,6)),(0.8,R(-30,0,-6)),(1.6,R(-28))]},
        "right_arm":{"rotation":[(0,R()),(0.2,R(-150,0,40)),(1.6,R(-150,0,40))]},"left_arm":{"rotation":[(0,R()),(0.2,R(-150,0,-40)),(1.6,R(-150,0,-40))]},
        "right_arm2":{"rotation":[(0,R()),(0.25,R(-80,0,70)),(1.6,R(-80,0,70))]},"left_arm2":{"rotation":[(0,R()),(0.25,R(-80,0,-70)),(1.6,R(-80,0,-70))]},
        "right_forearm":{"rotation":[(0,R()),(0.2,R(-20)),(1.6,R(-20))]},"left_forearm":{"rotation":[(0,R()),(0.2,R(-20)),(1.6,R(-20))]},
        "right_leg":{"rotation":[(0,R(-88)),(0.25,R(-30)),(1.6,R(-30))]},"left_leg":{"rotation":[(0,R(-88)),(0.25,R(-10)),(1.6,R(-10))]},
        "right_shin":{"rotation":[(0,R(88)),(0.25,R(30)),(1.6,R(30))]},"left_shin":{"rotation":[(0,R(88)),(0.25,R(15)),(1.6,R(15))]}})
    # tears off his lower right arm with the upper left hand and hurls it
    S=lambda v:R(v,v,v)
    ex["rip_arm"]=A(2.4,"hold",{"root":{"position":[(0,R(0,-lh*0.5,0)),(2.4,R(0,-lh*0.5,0))]},**legs,
        "body":{"rotation":[(0,R(-6)),(0.4,R(5,-20,0)),(1.2,R(8,-28,0)),(1.5,R(-4,15,0)),(1.8,R(10,-10,0)),(2.4,R(-6))]},
        "head":{"rotation":[(0,R()),(0.4,R(10,-25,0)),(1.2,R(-25,0,0)),(1.4,R(-30,0,5)),(1.8,R(0,0,0)),(2.4,R())]},
        "left_arm":{"rotation":[(0,R(-35,0,-12)),(0.4,R(-60,-40,30)),(1.2,R(-50,-45,35)),(1.5,R(-170,0,-20)),(1.8,R(-70,0,-5)),(2.4,R(-35,0,-12))]},
        "left_forearm":{"rotation":[(0,R(-40)),(0.4,R(-60)),(1.2,R(-50)),(1.5,R(-30)),(1.8,R(0)),(2.4,R(-40))]},
        "right_arm2":{"rotation":[(0,R(-55,0,6)),(0.4,R(-40,0,20)),(0.8,R(-35,0,35)),(1.0,R(-30,0,28)),(1.19,R(-25,0,45))],
                      "scale":[(0,S(1)),(1.19,S(1)),(1.2,S(0.001)),(2.4,S(0.001))]},
        "right_arm":{"rotation":[(0,R(-35,0,12)),(1.2,R(-35,0,20)),(2.4,R(-35,0,12))]},"right_forearm":{"rotation":[(0,R(-40)),(2.4,R(-40))]},
        "left_arm2":{"rotation":[(0,R(-55,0,-6)),(2.4,R(-55,0,-6))]},"left_forearm2":{"rotation":[(0,R(-25)),(2.4,R(-25))]},
        "right_forearm2":{"rotation":[(0,R(-25)),(1.2,R(-10)),(2.4,R(-10))]}})
    return ex

def write_all(root):
    M=build_all()
    for name,m in M.items():
        m.pack(); img,glow=m.paint()
        for d in ("geo/entity","animations/entity","textures/entity"): os.makedirs(f"{root}/{d}",exist_ok=True)
        json.dump(m.geo(),open(f"{root}/geo/entity/{name}.geo.json","w"),indent=1)
        img.save(f"{root}/textures/entity/{name}.png"); glow.save(f"{root}/textures/entity/{name}_glowmask.png")
        if name=="sukuna_true_form":   # v1.0.17 Heian Sukuna: same rig and skin
            h=img
            h.save(f"{root}/textures/entity/heian_sukuna.png"); glow.save(f"{root}/textures/entity/heian_sukuna_glowmask.png")
        if name=="gojo_satoru":
            eyes=gojo_eyes_model()
            head_painter=eyes.get("head").cubes[0].painter
            orig=m.get("head").cubes[0].painter
            m.get("head").cubes[0].painter=head_painter
            img2,glow2=m.paint()
            m.get("head").cubes[0].painter=orig
            img2.save(f"{root}/textures/entity/gojo_satoru_eyes.png"); glow2.save(f"{root}/textures/entity/gojo_satoru_eyes_glowmask.png")
            # v1.0.4 final boss: Gojo's body, possessed by Yuta through Kenjaku's technique (stitched forehead, violet-tinted eyes)
            km=gojo_kenjaku_model()
            m.get("head").cubes[0].painter=km.get("head").cubes[0].painter
            img3,glow3=m.paint()
            m.get("head").cubes[0].painter=orig
            img3.save(f"{root}/textures/entity/gojo_kenjaku.png"); glow3.save(f"{root}/textures/entity/gojo_kenjaku_glowmask.png")
        if m.plan=="humanoid":
            extra=gojo_extra() if name=="gojo_satoru" else (yuta_extra() if name=="yuta_okkotsu" else (heian_extra(m) if name=="sukuna_true_form" else (toji_extra() if name=="toji_fushiguro" else (geto_extra() if name=="suguru_geto" else (mahoraga_extra() if name=="mahoraga" else (rika_extra() if name=="rika_orimoto" else None))))))
            an=humanoid_anims(m,extra)
            if name=="gojo_satoru":
                cut=an["animations"]["animation.gojo_satoru.cut_in_half"]
                dead={"animation_length":1.0,"loop":True,"bones":{}}
                for bn,chans in cut["bones"].items():
                    dead["bones"][bn]={}
                    for ch,keys in chans.items():
                        last=keys[sorted(keys,key=float)[-1]]
                        dead["bones"][bn][ch]={"0.0":last}
                an["animations"]["animation.gojo_satoru.dead"]=dead
                hide={b:{"scale":{"0.0":[0.001,0.001,0.001]}} for b in BLOOD_BONES}
                for k,v in an["animations"].items():
                    if not (k.endswith("cut_in_half") or k.endswith("dead")):
                        for b,ch in hide.items(): v["bones"].setdefault(b,{}).update(ch)
        elif m.plan=="generic":
            an=generic_anims(m,m.body,m.parts)
        elif m.plan=="shrine":
            an={"format_version":"1.8.0","animations":{
              "animation.malevolent_shrine.rise":A(2.0,"hold",{"root":{"position":[(0,R(0,-80,0)),(1.6,R(0,2,0)),(2.0,R())]},"jaw":{"rotation":[(0,R()),(1.6,R(30)),(2,R())]}}),
              "animation.malevolent_shrine.idle":A(3.0,True,{"jaw":{"rotation":cyc(3,[(0,R()),(0.5,R(25))])},"maw":{"rotation":cyc(3,[(0,R()),(0.5,R(-12))])},
                     "roof":{"position":cyc(3,[(0,R()),(0.5,R(0,1,0))])},"horn_l":{"rotation":cyc(3,[(0,R(0,0,-4)),(0.5,R(0,0,4))])},"horn_r":{"rotation":cyc(3,[(0,R(0,0,4)),(0.5,R(0,0,-4))])}},0.1)}}
        else:
            bn="blade" if name=="dismantle_slash" else "arrow"
            an={"format_version":"1.8.0","animations":{f"animation.{name}.idle":A(0.5,True,{bn:{"rotation":[(0,R()),(0.5,R(0,0,360 if bn=="arrow" else 0))],
                 "scale":cyc(0.5,[(0,R(1,1,1)),(0.5,R(1.15,1.15,1.15))])}})}}
        json.dump(an,open(f"{root}/animations/entity/{name}.animation.json","w"),separators=(",",":"))
    return M
