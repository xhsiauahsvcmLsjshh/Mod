import numpy as np, os, subprocess
from scipy.io import wavfile
from scipy.signal import butter, lfilter
SR=22050
rng=np.random.default_rng(7)
def t(d): return np.arange(int(SR*d))/SR
def env(n,a=0.01,r=0.3):
    e=np.ones(n); A=int(SR*a); R=int(SR*r)
    if A>0: e[:A]=np.linspace(0,1,A)
    if R>0 and R<n: e[-R:]*=np.linspace(1,0,R)**2
    return e
def bp(x,lo,hi): b,a=butter(2,[lo/(SR/2),min(hi/(SR/2),0.99)],btype='band'); return lfilter(b,a,x)
def lp(x,f): b,a=butter(2,f/(SR/2),btype='low'); return lfilter(b,a,x)
def hp(x,f): b,a=butter(2,f/(SR/2),btype='high'); return lfilter(b,a,x)
def noise(d): return rng.standard_normal(int(SR*d))
def reverb(x,decay=0.4,delays=(0.031,0.047,0.071,0.093)):
    y=np.concatenate([x,np.zeros(int(SR*0.8))])
    for dl in delays:
        for rep in range(1,6):
            D=int(SR*dl*rep)
            seg=x[:max(0,len(y)-D)]
            y[D:D+len(seg)]+=seg*(decay**rep)*0.5
    return y
def fit(x,n): return np.pad(x,(0,max(0,n-len(x))))[:n]
def slash(d=0.35,lo=2500,hi=9000):
    n=noise(d); tt=t(d); sweep=bp(n,lo,hi)*np.exp(-tt*9)
    return sweep*env(len(sweep),0.002,0.15)
def voice(f0,d,formants=((600,1000),(800,1400)),vib=4,grit=0.2):
    tt=t(d); f=f0*(1+0.03*np.sin(2*np.pi*vib*tt)); ph=np.cumsum(2*np.pi*f/SR)
    saw=2*((ph/(2*np.pi))%1)-1; x=saw+grit*noise(d)
    out=sum(bp(x,lo,hi) for lo,hi in formants); return out*env(len(out),0.05,0.3)
def norm(x,g=0.9): return x/(np.max(np.abs(x))+1e-9)*g
def S():
    s={}
    s["dismantle"]=slash(0.4)
    s["cleave"]=np.concatenate([slash(0.25,1800,7000),slash(0.35,1500,8000)])
    s["domain_slash"]=slash(0.18,3000,10000)
    s["cinematic_slash"]=reverb(np.concatenate([slash(0.9,800,9000)*1.0+0.6*lp(noise(0.9),200)*np.exp(-t(0.9)*4)]),0.55)
    s["world_slash"]=reverb(slash(1.8,600,10000)+0.5*np.sin(2*np.pi*55*t(1.8))*np.exp(-t(1.8)*2),0.5)
    s["sukuna_roar"]=reverb(voice(70,2.2,((200,500),(500,900)),6,0.6)+0.4*lp(noise(2.2),300)*env(int(SR*2.2),0.2,0.8))
    ha=[]
    for k,f in enumerate((140,135,130,128,120,112)):
        ha.append(voice(f,0.18,((500,900),(1000,1600)),0,0.15)); ha.append(np.zeros(int(SR*0.07)))
    s["sukuna_laugh"]=reverb(np.concatenate(ha),0.35)
    s["sukuna_voice"]=reverb(np.concatenate([voice(85,0.5,((300,700),(900,1300))),voice(78,0.4,((400,800),(1000,1500))),voice(70,0.7,((250,600),(700,1100)))]),0.4)
    tt=t(1.2); s["fuga_ignite"]=bp(noise(1.2),300,4000)*np.linspace(0,1,len(tt))**1.5*env(len(tt),0.01,0.2)+0.3*np.sign(noise(1.2))*(rng.random(len(tt))>0.995)
    tt=t(1.6); s["fuga_explode"]=reverb(lp(noise(1.6),400)*np.exp(-tt*3)+np.sin(2*np.pi*45*tt)*np.exp(-tt*2.5),0.5)
    tt=t(4.0); drone=sum(np.sin(2*np.pi*f*tt)*a for f,a in ((55,1),(82.4,0.6),(110,0.4),(116.5,0.3),(164.8,0.25)))
    bell=np.sin(2*np.pi*440*tt)*np.exp(-tt*1.2)*0.5+np.sin(2*np.pi*660*tt)*np.exp(-tt*1.5)*0.3
    s["domain_expansion"]=reverb(drone*env(len(tt),1.0,1.2)+bell,0.6)
    crunch=np.concatenate([bp(noise(0.08),800,5000)*np.exp(-t(0.08)*30) if k%2==0 else np.zeros(int(SR*0.06)) for k in range(12)])
    s["finger_eat"]=crunch+0.3*lp(noise(len(crunch)/SR),150)
    def thump(): tt=t(0.18); return np.sin(2*np.pi*(60-80*tt)*tt)*np.exp(-tt*25)
    s["heartbeat"]=np.concatenate([thump(),np.zeros(int(SR*0.12)),thump()*0.7,np.zeros(int(SR*0.35))])
    tt=t(2.5); s["cinematic_sting"]=reverb(sum(np.sin(2*np.pi*f*tt) for f in (98,103.8,146.8,207.6))*env(len(tt),0.02,1.5)*np.exp(-tt*0.6),0.6)
    tt=t(2.0); s["gojo_infinity"]=reverb(sum(np.sin(2*np.pi*f*tt+np.sin(2*np.pi*0.5*tt)*k) for k,f in enumerate((880,1318,1760,2637)))*env(len(tt),0.4,0.8)*0.4,0.5)
    tt=t(0.5); s["blood_splatter"]=lp(noise(0.5),1200)*np.exp(-tt*10)*(1+0.5*np.sin(2*np.pi*30*tt))
    tt=t(2.0); s["curse_ambient"]=bp(noise(2.0),300,2500)*(0.5+0.5*np.sin(2*np.pi*3*tt))**2*env(len(tt),0.3,0.6)
    tt=t(0.45); s["curse_hurt"]=voice(380,0.45,((1200,2400),(2500,3500)),18,0.5)
    tt=t(1.1); f=np.linspace(420,90,len(tt)); ph=np.cumsum(2*np.pi*f/SR); s["curse_death"]=reverb(bp(np.sign(np.sin(ph))+0.4*noise(1.1),300,3000)*env(len(tt),0.01,0.5),0.4)
    s["sorcerer_hurt"]=voice(150,0.3,((500,900),(1100,1700)),0,0.2)
    s["sorcerer_death"]=voice(130,0.9,((400,800),(900,1400)),3,0.25)*np.linspace(1,0.2,int(SR*0.9))
    tt=t(1.3); s["rct_heal"]=reverb(sum(np.sin(2*np.pi*f*(1+tt*0.5)*tt) for f in (523,659,784))*env(len(tt),0.1,0.6)*0.35,0.5)
    s["takeover"]=reverb(fit(np.concatenate([s["heartbeat"],s["heartbeat"]*1.3]),int(SR*2))+0.6*fit(voice(60,2.0,((150,400),(400,800)),8,0.8),int(SR*2)),0.5)
    tt=t(0.7); s["resonance_pulse"]=np.sin(2*np.pi*110*tt)*np.exp(-tt*5)+0.3*np.sin(2*np.pi*220*tt)*np.exp(-tt*7)
    tt=t(3.0); s["seal_ritual"]=reverb(np.sin(2*np.pi*392*tt)*np.exp(-tt*1)+0.4*voice(110,3.0,((400,800),(800,1200)),2,0.05),0.6)
    tt=t(1.0); s["cursed_energy_burst"]=bp(noise(1.0),200,3000)*np.exp(-tt*4)+np.sin(2*np.pi*(80+200*tt)*tt)*np.exp(-tt*3)*0.6
    # boss theme ~24s taiko + drone
    L=24; tt=t(L); drone=0.3*np.sin(2*np.pi*55*tt)+0.2*np.sin(2*np.pi*82.4*tt)+0.12*np.sin(2*np.pi*116.5*tt)
    beat=np.zeros(len(tt)); pat=[0,0.5,0.75,1.5,2.0,2.5,2.75,3.5]
    for bar in range(L//4):
        for p in pat:
            st=int((bar*4+p)*SR*0.5); d=thump(); d=d*(1.4 if p in(0,2.0) else 0.8)
            if st+len(d)<len(beat): beat[st:st+len(d)]+=d
    s["boss_theme"]=drone*env(len(tt),2,2)+beat
    trailer_sounds(s,thump)
    return s

# ---------------- v1.0.26 trailer ----------------
def _reson(x,F,BW):
    """time-varying 2-pole resonator; F and BW are arrays (Hz) the same length as x"""
    y=np.zeros(len(x)); y1=y2=0.0
    for n in range(len(x)):
        r=np.exp(-np.pi*BW[n]/SR); c=-r*r; b=2*r*np.cos(2*np.pi*F[n]/SR); a=1-b-c
        v=a*x[n]+b*y1+c*y2; y[n]=v; y2=y1; y1=v
    return y
def _ramp(pts,n):
    """pts [(time_s,value)] -> per-sample linear ramp"""
    ts=np.arange(n)/SR; return np.interp(ts,[p[0] for p in pts],[p[1] for p in pts])
def fuga_voice():
    """Sukuna (deep, calm, low male voice) saying 'Fuga' [ɸɯːɡa]: formant synthesis, placeholder for a real recording."""
    D=1.05; n=int(SR*D); ts=np.arange(n)/SR
    f0=_ramp([(0,100),(0.14,98),(0.42,93),(0.5,94),(0.7,84),(1.05,68)],n)*(1+0.004*np.sin(2*np.pi*5.5*ts))
    ph=np.cumsum(f0/SR)%1.0
    glott=np.where(ph<0.6,0.5*(1-np.cos(np.pi*ph/0.6)),np.cos(np.pi*(ph-0.6)/0.8))   # Rosenberg pulse
    glott=np.diff(glott,prepend=0)*40+0.06*rng.standard_normal(n)
    voiced=_ramp([(0,0),(0.12,0),(0.17,1),(0.40,1),(0.43,0.25),(0.485,0.2),(0.50,1),(0.75,0.9),(1.05,0)],n)
    src=glott*voiced
    F1=_ramp([(0,330),(0.40,340),(0.44,260),(0.50,300),(0.58,690),(1.05,640)],n)
    F2=_ramp([(0,1150),(0.40,1250),(0.46,1650),(0.50,1600),(0.60,1180),(1.05,1120)],n)
    F3=_ramp([(0,2300),(0.40,2300),(0.46,1950),(0.50,2000),(0.60,2450),(1.05,2400)],n)
    out=_reson(src,F1,np.full(n,70))*1.0+_reson(src,F2,np.full(n,95))*0.55+_reson(src,F3,np.full(n,140))*0.25
    fr=bp(rng.standard_normal(n),700,4500)*_ramp([(0,0),(0.03,0.5),(0.12,0.7),(0.17,0),(1.05,0)],n)    # bilabial [ɸ]
    burst=bp(rng.standard_normal(n),1300,2800)*_ramp([(0,0),(0.478,0),(0.485,1.2),(0.505,0),(1.05,0)],n)  # [ɡ] release
    breath=bp(rng.standard_normal(n),400,2500)*_ramp([(0,0),(0.8,0),(1.0,0.12),(1.05,0)],n)
    v=out/(np.max(np.abs(out))+1e-9)+fr*0.35+burst*0.4+breath
    sub=lp(v,300)*0.35                       # chest weight
    v=np.tanh(1.6*(v+sub))
    return reverb(np.concatenate([np.zeros(int(SR*0.05)),v]),0.3)
def trailer_sounds(s,thump):
    s["trailer_fuga"]=fuga_voice()
    tt=t(3.5); s["trailer_meteor"]=reverb(lp(noise(3.5),220)*np.linspace(0.2,1,len(tt))**2+0.6*np.sin(2*np.pi*(38+12*tt)*tt)*np.linspace(0,1,len(tt))
        +0.25*bp(noise(3.5),300,1800)*np.linspace(0,1,len(tt)),0.5)*env(len(tt)+int(SR*0.8),0.3,0.6)[:len(tt)+int(SR*0.8)]
    tt=t(4.0); crack=np.zeros(len(tt))
    for k in range(260):
        st=rng.integers(0,len(tt)-300); crack[st:st+300]+=bp(noise(300/SR),1500,7000)*np.exp(-np.arange(300)/40)*rng.random()
    s["trailer_burn"]=crack*env(len(tt),0.05,1.0)+0.5*lp(noise(4.0),500)*env(len(tt),0.3,1.5)+0.5*voice(90,4.0,((250,600),(700,1100)),5,0.7)*np.linspace(1,0,len(tt))**2
    # 29 s theme: drone, taiko that speeds up toward the meteor, silence, two hits (explosion), chord for the title
    L=29; tt=t(L); y=0.22*np.sin(2*np.pi*55*tt)+0.14*np.sin(2*np.pi*82.4*tt)+0.08*np.sin(2*np.pi*110*tt+np.sin(2*np.pi*0.2*tt))
    y*=np.interp(tt,[0,3,16.2,16.4,16.8,19,29],[0,1,1,0.0,0.0,0.6,0.0])
    beats=list(np.arange(1.0,9.0,1.5))+list(np.arange(9.0,13.0,0.75))+list(np.arange(13.0,15.5,0.375))+list(np.arange(15.5,16.2,0.1875))
    for b in beats:
        d=thump(); st=int(b*SR); y[st:st+len(d)]+=d*(0.9 if b<13 else 1.1)
    for hit,g in ((16.8,2.0),(17.5,2.6),(24.0,1.8)):
        tt2=t(3.0); h=(np.sin(2*np.pi*(50-20*tt2)*tt2)*np.exp(-tt2*2.0)+0.5*lp(noise(3.0),300)*np.exp(-tt2*3))*g; st=int(hit*SR); y[st:st+len(h)]+=h[:len(y)-st]
    tc=t(6.5); chord=sum(np.sin(2*np.pi*f*tc)*a for f,a in ((110,0.3),(130.8,0.22),(164.8,0.2),(220,0.12)))*env(len(tc),1.0,3.0)
    bell=np.sin(2*np.pi*880*tc)*np.exp(-tc*1.5)*0.25+np.sin(2*np.pi*1320*tc)*np.exp(-tc*2)*0.12
    st=int(24.0*SR); y[st:st+len(tc)]+=(chord+bell)[:len(y)-st]
    s["trailer_theme"]=reverb(y,0.45)[:int(SR*L)]
def write(root):
    os.makedirs(f"{root}/sounds",exist_ok=True)
    custom=os.path.join(os.path.dirname(os.path.abspath(__file__)),"custom_sounds")
    for k,v in S().items():
        mine=os.path.join(custom,f"{k}.ogg")
        if os.path.exists(mine):                      # v1.0.26: a real recording (e.g. trailer_fuga.ogg) wins over the synthesized one
            import shutil; shutil.copyfile(mine,f"{root}/sounds/{k}.ogg"); continue
        v=norm(np.nan_to_num(v),0.85); w=f"/tmp/{k}.wav"; wavfile.write(w,SR,(v*32767).astype(np.int16))
        subprocess.run(["ffmpeg","-y","-loglevel","error","-i",w,"-ac","1","-c:a","libvorbis","-q:a","3",f"{root}/sounds/{k}.ogg"],check=True)
if __name__=="__main__":
    write("/tmp/snd"); print(sorted(os.listdir("/tmp/snd/sounds")))
