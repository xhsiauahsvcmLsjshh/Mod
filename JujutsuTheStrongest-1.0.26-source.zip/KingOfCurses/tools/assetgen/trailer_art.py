"""v1.0.26 TRAILER: pre-made GeckoLib actors (Jogo, fire, meteor), Sukuna trailer animations and the scenery textures.
Everything is written to geo/trailer, animations/trailer and textures/trailer. Nothing here is a world entity."""
import json, os, math, random
from models import *
from models import _vn
from PIL import Image

JS=(206,196,178); ROBE=(228,220,200); SASH=(44,34,32); HAKAMA=(58,48,44); LAVA=(255,150,40); ROCK=(70,62,60)

def jogo_face(img,glow,x,y,w,h,faces):
    cx=x+w//2
    # one big eye (Jogo is a cyclops-like curse), dark rim
    ey=y+2
    rect(img,cx-2,ey-1,cx+2,ey-1,(60,52,48))
    rect(img,cx-2,ey,cx+2,ey+2,(240,236,226)); rect(img,cx-1,ey,cx+1,ey+2,(250,248,240))
    P(img,cx,ey+1,(20,14,12)); P(img,cx-1,ey+1,(70,40,30))
    rect(img,cx-3,ey+3,cx+3,ey+3,shade(JS,0.8))
    # wide mouth full of teeth, black lips
    my=y+h-3
    rect(img,x+1,my-1,x+w-2,my-1,(30,22,22)); rect(img,x+1,my+1,x+w-2,my+1,(30,22,22))
    for xx in range(x+1,x+w-1): P(img,xx,my,(236,226,200) if (xx-x)%2 else (196,184,160))
    # black volcanic stones where the ears are
    for fn in ("east","west"):
        fx,fy,fw,fh,_=faces[fn]; rect(img,fx+fw//2-1,fy+3,fx+fw//2,fy+4,(24,20,20))

def cone_painter(img,glow,x,y,w,h,faces):
    for fn,(fx,fy,fw,fh,_) in faces.items():
        if fn in("top","bottom"): continue
        for xx in range(fx,fx+fw):
            for yy in range(fy,fy+fh):
                c=img.getpixel((xx,yy))
                if c[3]: P(img,xx,yy,mix(c[:3],(86,74,70),0.35*(1-(yy-fy)/max(1,fh))))

def lava_painter(img,glow,x,y,w,h,faces):
    for fn,(fx,fy,fw,fh,_) in faces.items():
        for xx in range(fx,fx+fw):
            for yy in range(fy,fy+fh):
                c=(255,200,80) if (xx+yy)%3 else (255,120,30); P(img,xx,yy,c); P(glow,xx,yy,c)

def jogo_model():
    m=humanoid("trailer_jogo",s=0.9,skin=JS,top=ROBE,bottom=HAKAMA,arms_col=ROBE,hands=JS,head_size=9,face=jogo_face,shoes=(36,28,24),
               body_painter=multi(trim((60,50,46),top=True,bottom=False),stripes(shade(ROBE,0.9),4,True,faces_only=("front","back"))),skin_mat="skin")
    lh,bh,hs,bw,aw=m.dims; ty=m.top_y
    # volcano head: stacked cone, crater rim, glowing lava
    add(m,"head",[-4,ty+hs,-4],[8,2,8],JS,cone_painter,mat="skin")
    add(m,"head",[-3,ty+hs+2,-3],[6,2,6],shade(JS,0.9),cone_painter,mat="skin")
    add(m,"head",[-2.5,ty+hs+4,-2.5],[5,1,5],(64,56,54),mat="plain")
    add(m,"head",[-1.5,ty+hs+4.3,-1.5],[3,1,3],LAVA,lava_painter,glow="full",mat="plain")
    m.bone("smoke","head",[0,ty+hs+5,0],[Cube([-2,ty+hs+6,-2],[4,3,4],(120,112,112),mat="plain"),Cube([-1.5,ty+hs+9,-1],[3,2,3],(150,144,144),mat="plain"),
                                           Cube([-1,ty+hs+11.5,-1.5],[2,2,2],(170,166,166),mat="plain")])
    # robe: sash, skirt, wide sleeves
    add(m,"body",[-bw/2-0.5,lh+3,-2.5],[bw+1,2,5],SASH,trim((150,40,30),True,True))
    add(m,"body",[-bw/2-1,lh-5,-3],[bw+2,7,6],ROBE,stripes(shade(ROBE,0.86),3,True,faces_only=("front","back","east","west")))
    for side,sx in (("right",-1),("left",1)):
        x0=-(bw/2+aw)-0.5 if sx<0 else bw/2-0.5
        add(m,f"{side}_forearm",[x0,ty-m.ah+3,-2.5],[aw+1,4,5],ROBE,trim((60,50,46),False,True))
    return m

def R3(x=0,y=0,z=0): return [x,y,z]

def jogo_anims():
    n="trailer_jogo"; an={}
    an[f"animation.{n}.idle"]=A(3.0,True,{"root":{"position":cyc(3,[(0,R3(0,5,0)),(0.5,R3(0,6.5,0))])},
        "body":{"rotation":cyc(3,[(0,R3(2)),(0.5,R3(-2))])},"head":{"rotation":cyc(3,[(0,R3(-4)),(0.5,R3(2))])},
        "right_arm":{"rotation":cyc(3,[(0,R3(-10,0,18)),(0.5,R3(-14,0,24))])},"left_arm":{"rotation":cyc(3,[(0,R3(-10,0,-18)),(0.5,R3(-14,0,-24))])},
        "right_leg":{"rotation":cyc(3,[(0,R3(-8)),(0.5,R3(-14))])},"left_leg":{"rotation":cyc(3,[(0,R3(4)),(0.5,R3(-2))])},
        "right_shin":{"rotation":cyc(3,[(0,R3(14)),(0.5,R3(20))])},"left_shin":{"rotation":cyc(3,[(0,R3(10)),(0.5,R3(14))])},
        "smoke":{"position":cyc(3,[(0,R3()),(0.5,R3(0,1.5,0))]),"scale":cyc(3,[(0,R3(1,1,1)),(0.5,R3(1.25,1.3,1.25))])}})
    # Maximum: Meteor - both arms up, the meteor grows above him
    an[f"animation.{n}.meteor"]=A(3.8,"hold",{"root":{"position":[(0,R3(0,5,0)),(0.8,R3(0,9,0)),(3.8,R3(0,10,0))]},
        "body":{"rotation":[(0,R3(2)),(0.8,R3(-12)),(2.0,R3(-14)),(3.8,R3(-15))]},
        "head":{"rotation":[(0,R3(-4)),(0.8,R3(-28)),(3.8,R3(-30))]},
        "right_arm":{"rotation":[(0,R3(-10,0,18)),(0.8,R3(-172,0,-12)),(1.6,R3(-176,0,-8)),(2.4,R3(-170,0,-14)),(3.8,R3(-175,0,-10))]},
        "left_arm":{"rotation":[(0,R3(-10,0,-18)),(0.8,R3(-172,0,12)),(1.6,R3(-176,0,8)),(2.4,R3(-170,0,14)),(3.8,R3(-175,0,10))]},
        "right_forearm":{"rotation":[(0,R3()),(0.8,R3(-14)),(3.8,R3(-18))]},"left_forearm":{"rotation":[(0,R3()),(0.8,R3(-14)),(3.8,R3(-18))]},
        "right_leg":{"rotation":[(0,R3(-8)),(0.8,R3(-4)),(3.8,R3(-6))]},"left_leg":{"rotation":[(0,R3(4)),(3.8,R3(6))]},
        "smoke":{"scale":[(0,R3(1,1,1)),(0.8,R3(1.6,2.2,1.6)),(3.8,R3(1.8,2.6,1.8))]}})
    # hurls it forward
    an[f"animation.{n}.throw"]=A(1.4,"hold",{"root":{"position":[(0,R3(0,10,0)),(0.3,R3(0,9,0)),(1.4,R3(0,6,0))]},
        "body":{"rotation":[(0,R3(-15)),(0.3,R3(18)),(1.4,R3(10))]},"head":{"rotation":[(0,R3(-30)),(0.3,R3(-6)),(1.4,R3(-10))]},
        "right_arm":{"rotation":[(0,R3(-175,0,-10)),(0.3,R3(-70,0,-6)),(1.4,R3(-80,0,-10))]},"left_arm":{"rotation":[(0,R3(-175,0,10)),(0.3,R3(-70,0,6)),(1.4,R3(-80,0,10))]},
        "right_forearm":{"rotation":[(0,R3(-18)),(0.3,R3(0)),(1.4,R3(-10))]},"left_forearm":{"rotation":[(0,R3(-18)),(0.3,R3(0)),(1.4,R3(-10))]}})
    # engulfed by Fuga: writhes, drops to his knees, collapses face down
    an[f"animation.{n}.burn"]=A(3.6,"hold",{
        "root":{"position":[(0,R3(0,0,0)),(1.1,R3(0,0,0)),(1.6,R3(0,-4.5,0)),(2.3,R3(0,-4.5,0)),(3.0,R3(0,2,0)),(3.6,R3(0,2,0))],
                "rotation":[(0,R3()),(1.6,R3()),(2.3,R3(8)),(3.0,R3(86)),(3.6,R3(88))]},
        "body":{"rotation":[(0,R3(-10)),(0.3,R3(-18,10,6)),(0.6,R3(-12,-12,-6)),(0.9,R3(-20,8,4)),(1.2,R3(-8,-4,0)),(1.6,R3(14)),(2.3,R3(22)),(3.0,R3(4)),(3.6,R3(0))]},
        "head":{"rotation":[(0,R3(-30)),(0.4,R3(-40,15,0)),(0.8,R3(-35,-15,0)),(1.2,R3(-20)),(1.6,R3(15)),(2.3,R3(25)),(3.0,R3(-10,0,20)),(3.6,R3(-12,0,24))]},
        "right_arm":{"rotation":[(0,R3(-120,0,-20)),(0.3,R3(-150,20,10)),(0.6,R3(-100,-10,-30)),(0.9,R3(-140,10,0)),(1.2,R3(-60,0,10)),(1.6,R3(-30,0,14)),(2.3,R3(-20,0,10)),(3.0,R3(-170,0,-10)),(3.6,R3(-176,0,-14))]},
        "left_arm":{"rotation":[(0,R3(-120,0,20)),(0.3,R3(-100,10,30)),(0.6,R3(-150,-20,-10)),(0.9,R3(-110,-10,10)),(1.2,R3(-60,0,-10)),(1.6,R3(-30,0,-14)),(2.3,R3(-24,0,-10)),(3.0,R3(-40,0,-20)),(3.6,R3(-30,0,-24))]},
        "right_forearm":{"rotation":[(0,R3(-60)),(0.6,R3(-90)),(1.2,R3(-30)),(2.3,R3(-10)),(3.6,R3(-6))]},
        "left_forearm":{"rotation":[(0,R3(-60)),(0.6,R3(-40)),(1.2,R3(-30)),(2.3,R3(-10)),(3.6,R3(-20))]},
        "right_leg":{"rotation":[(0,R3(-6)),(1.1,R3(-10)),(1.6,R3(0)),(2.3,R3(0)),(3.0,R3(4)),(3.6,R3(6))]},
        "left_leg":{"rotation":[(0,R3(6)),(1.1,R3(4)),(1.6,R3(0)),(2.3,R3(0)),(3.0,R3(-2)),(3.6,R3(-4))]},
        "right_shin":{"rotation":[(0,R3()),(1.1,R3(10)),(1.6,R3(90)),(2.3,R3(90)),(3.0,R3(20)),(3.6,R3(14))]},
        "left_shin":{"rotation":[(0,R3()),(1.1,R3(10)),(1.6,R3(90)),(2.3,R3(90)),(3.0,R3(30)),(3.6,R3(24))]},
        "smoke":{"scale":[(0,R3(2,3,2)),(1.6,R3(2.4,3.4,2.4)),(3.6,R3(0.6,0.6,0.6))]}})
    return {"format_version":"1.8.0","animations":an}

def sukuna_anims():
    """Trailer-only animations on Ryomen Sukuna's rig (bones: root body head right_arm right_forearm left_arm left_forearm legs/shins)."""
    n="trailer_sukuna"; an={}
    an[f"animation.{n}.stand"]=A(4.0,True,{"body":{"rotation":cyc(4,[(0,R3(1)),(0.5,R3(3))])},"head":{"rotation":cyc(4,[(0,R3(4,6,0)),(0.5,R3(6,4,0))])},
        "right_arm":{"rotation":cyc(4,[(0,R3(0,0,4)),(0.5,R3(2,0,6))])},"left_arm":{"rotation":cyc(4,[(0,R3(0,0,-4)),(0.5,R3(2,0,-6))])},
        "right_forearm":{"rotation":cyc(4,[(0,R3(-6)),(0.5,R3(-10))])},"left_forearm":{"rotation":cyc(4,[(0,R3(-6)),(0.5,R3(-10))])},
        "right_leg":{"rotation":[(0,R3(0,0,4))]},"left_leg":{"rotation":[(0,R3(0,0,-4))]}})
    # raises the right hand, palm up: the flame is born in it (hand ends near local (-6, 24.8, -10.5) px)
    an[f"animation.{n}.ignite"]=A(3.0,"hold",{"body":{"rotation":[(0,R3(1)),(0.6,R3(4,-8,0)),(3.0,R3(5,-9,0))]},
        "head":{"rotation":[(0,R3(4)),(0.8,R3(16,-10,0)),(2.2,R3(14,-12,0)),(3.0,R3(6,-4,0))]},
        "right_arm":{"rotation":[(0,R3(0,0,4)),(0.7,R3(-80,0,0)),(3.0,R3(-82,0,0))]},
        "right_forearm":{"rotation":[(0,R3(-6)),(0.7,R3(-50)),(3.0,R3(-52))]},
        "left_arm":{"rotation":[(0,R3(0,0,-4)),(1.0,R3(4,0,-8)),(3.0,R3(4,0,-8))]},"left_forearm":{"rotation":[(0,R3(-6)),(3.0,R3(-12))]},
        "right_leg":{"rotation":[(0,R3(0,0,4)),(0.6,R3(-6,0,6))]},"left_leg":{"rotation":[(0,R3(0,0,-4)),(0.6,R3(6,0,-6))]}})
    # bow stance: left arm aims at Jogo, right hand pulls the flame arrow back to the cheek
    an[f"animation.{n}.draw"]=A(2.5,"hold",{"body":{"rotation":[(0,R3(4,-9,0)),(0.6,R3(0,30,0)),(2.5,R3(0,32,0))]},
        "head":{"rotation":[(0,R3(6,-4,0)),(0.6,R3(2,-30,0)),(2.5,R3(4,-32,0))]},
        "left_arm":{"rotation":[(0,R3(4,0,-8)),(0.6,R3(-90,-30,0)),(2.5,R3(-90,-32,0))]},"left_forearm":{"rotation":[(0,R3(-12)),(0.6,R3(-2)),(2.5,R3(0))]},
        "right_arm":{"rotation":[(0,R3(-82,0,0)),(0.6,R3(-88,-34,0)),(1.6,R3(-90,-44,0)),(2.5,R3(-90,-48,0))]},
        "right_forearm":{"rotation":[(0,R3(-52)),(0.6,R3(-95)),(1.6,R3(-112)),(2.5,R3(-118))]},
        "right_leg":{"rotation":[(0,R3(-6,0,6)),(0.6,R3(10,0,8))]},"left_leg":{"rotation":[(0,R3(6,0,-6)),(0.6,R3(-16,0,-8))]},
        "left_shin":{"rotation":[(0,R3()),(0.6,R3(12))]}})
    an[f"animation.{n}.release"]=A(1.5,"hold",{"body":{"rotation":[(0,R3(0,32,0)),(0.15,R3(-6,36,0)),(1.5,R3(0,30,0))]},
        "head":{"rotation":[(0,R3(4,-32,0)),(1.5,R3(6,-30,0))]},
        "left_arm":{"rotation":[(0,R3(-90,-32,0)),(0.15,R3(-96,-30,0)),(1.5,R3(-80,-26,0))]},"left_forearm":{"rotation":[(0,R3(0)),(1.5,R3(-4))]},
        "right_arm":{"rotation":[(0,R3(-90,-48,0)),(0.12,R3(-70,-70,-40)),(1.5,R3(-40,-40,-30))]},
        "right_forearm":{"rotation":[(0,R3(-118)),(0.12,R3(-20)),(1.5,R3(-14))]},
        "right_leg":{"rotation":[(0,R3(10,0,8))]},"left_leg":{"rotation":[(0,R3(-16,0,-8))]},"left_shin":{"rotation":[(0,R3(12))]}})
    return {"format_version":"1.8.0","animations":an}

def fire_model():
    m=Model("trailer_fire"); m.bone("root",None,[0,0,0])
    m.bone("core","root",[0,0,0],[Cube([-3,0,-3],[6,5,6],(255,226,140),glow="full",mat="plain")])
    cols=[(255,150,40),(255,110,30),(255,180,60),(240,80,20),(255,130,36)]
    for k,(x,z,h) in enumerate(((-3,-1,9),(1,-3,11),(2,1,8),(-2,2,10),(0,0,14))):
        m.bone(f"f{k}","root",[x,0,z],[Cube([x-1.5,1,z-1.5],[3,h,3],cols[k],glow="full",mat="plain"),Cube([x-0.5,1+h,z-0.5],[1,3,1],(255,220,120),glow="full",mat="plain")])
    return m

def fire_anims():
    b={}
    for k in range(5):
        b[f"f{k}"]={"scale":cyc(1.2,[(0,R3(1,1,1)),(0.3,R3(1.15,1.35,1.15)),(0.7,R3(0.85,0.75,0.85))]),
                    "position":cyc(1.2,[(0,R3()),(0.4,R3(0.4*(1 if k%2 else -1),0.5,0)),(0.8,R3(-0.3*(1 if k%2 else -1),0,0.3))]),
                    "rotation":cyc(1.2,[(0,R3(0,k*40,0)),(0.5,R3(4,k*40+20,-4))])}
    b["core"]={"scale":cyc(0.6,[(0,R3(1,1,1)),(0.5,R3(1.1,0.9,1.1))])}
    return {"format_version":"1.8.0","animations":{"animation.trailer_fire.burn":A(1.2,True,b)}}

def meteor_model():
    m=Model("trailer_meteor"); m.bone("root",None,[0,0,0])
    def crack(img,glow,x,y,w,h,faces):
        r=random.Random(5)
        for fn,(fx,fy,fw,fh,_) in faces.items():
            for k in range(fw*fh//7):
                xx=fx+r.randrange(fw); yy=fy+r.randrange(fh); c=(255,140+r.randrange(80),40)
                P(img,xx,yy,c); P(glow,xx,yy,c)
                if r.random()<0.6 and xx+1<fx+fw: P(img,xx+1,yy,c); P(glow,xx+1,yy,c)
    m.bone("rock","root",[0,8,0],[Cube([-8,0,-8],[16,16,16],ROCK,crack,mat="curse"),Cube([-6,-2,-6],[12,2,12],shade(ROCK,0.9),crack,mat="curse"),
        Cube([-6,16,-6],[12,2,12],shade(ROCK,1.1),crack,mat="curse"),Cube([-10,3,-5],[2,10,10],shade(ROCK,0.95),crack,mat="curse"),
        Cube([8,3,-5],[2,10,10],shade(ROCK,0.95),crack,mat="curse"),Cube([-5,3,-10],[10,10,2],ROCK,crack,mat="curse"),Cube([-5,3,8],[10,10,2],ROCK,crack,mat="curse")])
    return m

def meteor_anims():
    return {"format_version":"1.8.0","animations":{"animation.trailer_meteor.spin":A(4.0,True,{"rock":{"rotation":[(0,R3(0,0,0)),(2.0,R3(180,90,40)),(4.0,R3(360,180,80))]}},step=0.1)}}

# ---------------- scenery textures (drawn as plain quads by TrailerScreen) ----------------
def scene_textures(root):
    d=f"{root}/textures/trailer"; os.makedirs(d,exist_ok=True); r=random.Random(26)
    g=new(32,32)
    for x in range(32):
        for y in range(32):
            v=_vn(x/4,y/4,3); P(g,x,y,shade((58,58,64),0.8+0.35*v+r.uniform(-0.05,0.05)))
    for k in range(5):
        x,y=r.randrange(32),r.randrange(32)
        for s in range(12): x=(x+r.choice((-1,0,1)))%32; y=(y+r.choice((0,1)))%32; P(g,x,y,(26,24,28))
    g.save(f"{d}/ground.png")
    w=new(32,32)
    for x in range(32):
        for y in range(32): P(w,x,y,shade((84,80,86),0.85+0.2*_vn(x/5,y/5,7)+r.uniform(-0.04,0.04)))
    for wx in (3,19):
        for wy in (4,20):
            lit=r.random()
            c=(255,170,70) if lit<0.18 else ((120,150,190) if lit<0.3 else (22,24,32))
            rect(w,wx,wy,wx+9,wy+8,c); rect(w,wx,wy+4,wx+9,wy+4,(40,40,46)); rect(w,wx+5,wy,wx+5,wy+8,(40,40,46))
            rect(w,wx-1,wy+9,wx+10,wy+9,(110,106,112))
    w.save(f"{d}/wall.png")
    w2=w.copy()                      # burnt facade: soot + broken windows
    for x in range(32):
        for y in range(32):
            c=w2.getpixel((x,y))
            if _vn(x/6,y/6,11)>0.5: P(w2,x,y,shade(c[:3],0.45))
    w2.save(f"{d}/wall_burnt.png")
    rb=new(32,32)
    for x in range(32):
        for y in range(32):
            v=_vn(x/3,y/3,13); P(rb,x,y,shade((96,90,90),0.6+0.6*v))
    rb.save(f"{d}/rubble.png")
    gl=new(32,32)
    for x in range(32):
        for y in range(32):
            dd=math.hypot(x-15.5,y-15.5)/15.5; a=max(0,1-dd)**2
            P(gl,x,y,(clamp(255*a),clamp(255*a),clamp(255*a),255))
    gl.save(f"{d}/glow.png")
    rg=new(64,64)
    for x in range(64):
        for y in range(64):
            dd=math.hypot(x-31.5,y-31.5)/31.5; a=max(0,1-abs(dd-0.85)/0.15) if dd<1 else 0
            P(rg,x,y,(clamp(255*a),clamp(255*a),clamp(255*a),255))
    rg.save(f"{d}/ring.png")

def burnt(img):
    out=img.copy(); r=random.Random(9)
    for x in range(img.width):
        for y in range(img.height):
            c=img.getpixel((x,y))
            if c[3]==0: continue
            k=_vn(x/3,y/3,21)
            P(out,x,y,mix(c[:3],(38,22,18),0.55+0.3*k)+(255,))
    return out

def write_all(root):
    for dd in ("geo/trailer","animations/trailer","textures/trailer"): os.makedirs(f"{root}/{dd}",exist_ok=True)
    for m,an in ((jogo_model(),jogo_anims()),(fire_model(),fire_anims()),(meteor_model(),meteor_anims())):
        m.pack(); img,glow=m.paint()
        json.dump(m.geo(),open(f"{root}/geo/trailer/{m.name}.geo.json","w"),indent=1)
        img.save(f"{root}/textures/trailer/{m.name}.png"); glow.save(f"{root}/textures/trailer/{m.name}_glowmask.png")
        json.dump(an,open(f"{root}/animations/trailer/{m.name}.animation.json","w"),separators=(",",":"))
        if m.name=="trailer_jogo":
            b=burnt(img); gb=glow.copy(); rr=random.Random(4)
            for k in range(70):
                x,y=rr.randrange(img.width),rr.randrange(img.height)
                if img.getpixel((x,y))[3]: c=(255,110+rr.randrange(90),30); P(b,x,y,c); P(gb,x,y,c)
            b.save(f"{root}/textures/trailer/trailer_jogo_burnt.png"); gb.save(f"{root}/textures/trailer/trailer_jogo_burnt_glowmask.png")
    json.dump(sukuna_anims(),open(f"{root}/animations/trailer/trailer_sukuna.animation.json","w"),separators=(",",":"))
    scene_textures(root)

if __name__=="__main__":
    write_all("/tmp/trailer_out"); print(sorted(os.listdir("/tmp/trailer_out/textures/trailer")))
