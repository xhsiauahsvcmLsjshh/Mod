Put real recordings here as OGG Vorbis, mono, same name as the sound (example: trailer_fuga.ogg).
gen_all.py copies them instead of the synthesized placeholder. Then rebuild.
