import json, os, re, glob, gzip, struct, sys
sys.path.insert(0,'.')
from spec import *
import os as _o; ROOT=_o.path.abspath(_o.path.join(_o.path.dirname(_o.path.abspath(__file__)),'..','..')); RES=ROOT+'/src/main/resources'; A=RES+'/assets/kingofcurses'; D=RES+'/data'
errs=[]; warn=[]
def E(m): errs.append(m)
# 1. all json parse
js={}
for p in glob.glob(RES+'/**/*.json',recursive=True)+[RES+'/pack.mcmeta']:
    try: js[p]=json.load(open(p,encoding='utf-8'))
    except Exception as e: E(f"JSON parse {p}: {e}")
print("json files:",len(js))
# registry ids from Java
J=open(ROOT+'/src/main/java/com/kingofcurses/registry/ModBlocks.java').read()
blocks=re.findall(r'register\("([a-z0-9_]+)"',J)
I=open(ROOT+'/src/main/java/com/kingofcurses/registry/ModItems.java').read()
items=[x for x in re.findall(r'ITEMS\.register\("([a-z0-9_]+)"',I) if not x.endswith('_')]+LEGACY_FINGERS+blocks
ents=re.findall(r'ENTITIES\.register\("([a-z0-9_]+)"',open(ROOT+'/src/main/java/com/kingofcurses/registry/ModEntities.java').read())
sounds=re.findall(r'register\("([a-z0-9_]+)"\)',open(ROOT+'/src/main/java/com/kingofcurses/registry/ModSounds.java').read())
effects=re.findall(r'EFFECTS\.register\("([a-z0-9_]+)"',open(ROOT+'/src/main/java/com/kingofcurses/registry/ModEffects.java').read())
parts=re.findall(r'PARTICLES\.register\("([a-z0-9_]+)"',open(ROOT+'/src/main/java/com/kingofcurses/registry/ModParticles.java').read())
print("blocks",len(blocks),"items(total incl. blockitems)",len(items),"entities",len(ents),"sounds",len(sounds),"effects",len(effects),"particles",len(parts))
def tex_exists(ref):
    ns,path=ref.split(":") if ":" in ref else ("minecraft",ref)
    if ns!="kingofcurses": return True
    return os.path.exists(f"{RES}/assets/{ns}/textures/{path}.png")
def model_exists(ref):
    ns,path=ref.split(":") if ":" in ref else ("minecraft",ref)
    if ns!="kingofcurses": return True
    return os.path.exists(f"{RES}/assets/{ns}/models/{path}.json")
# 2. blockstates -> models -> textures
for b in blocks:
    p=f"{A}/blockstates/{b}.json"
    if p not in js: E(f"missing blockstate {b}"); continue
    bs=js[p]; refs=[]
    if "variants" in bs:
        for v in bs["variants"].values(): refs+= [x["model"] for x in (v if isinstance(v,list) else [v])]
    for part in bs.get("multipart",[]): refs.append(part["apply"]["model"])
    for r in refs:
        if not model_exists(r): E(f"blockstate {b} -> missing model {r}")
for p,m in js.items():
    if "/models/" in p:
        for k,t in m.get("textures",{}).items():
            if not t.startswith("#") and not tex_exists(t): E(f"{p}: missing texture {t}")
        par=m.get("parent")
        if par and not model_exists(par): E(f"{p}: missing parent {par}")
        for o in m.get("overrides",[]):
            if not model_exists(o["model"]): E(f"{p}: override missing {o['model']}")
# 3. item models
for it in items:
    if not os.path.exists(f"{A}/models/item/{it}.json"): E(f"missing item model {it}")
# 4. lang
en=js[f"{A}/lang/en_us.json"]; itl=js[f"{A}/lang/it_it.json"]
if set(en)!=set(itl): E(f"lang key mismatch: {set(en)^set(itl)}")
for b in blocks:
    if f"block.kingofcurses.{b}" not in en: E(f"lang missing block {b}")
for it in items:
    if it in blocks: continue
    if f"item.kingofcurses.{it}" not in en: E(f"lang missing item {it}")
for e in ents:
    if f"entity.kingofcurses.{e}" not in en: E(f"lang missing entity {e}")
for e in effects:
    if f"effect.kingofcurses.{e}" not in en: E(f"lang missing effect {e}")
# translation keys used in java
used=set()
for jf in glob.glob(ROOT+'/src/main/java/**/*.java',recursive=True):
    s=open(jf).read()
    used|=set(re.findall(r'"((?:message|gui|hud|tooltip|cinematic|commands|ability|key|container|itemGroup|subtitles)\.kingofcurses[a-z0-9_.]*|key\.categories\.kingofcurses)"',s))
dyn_prefix=("tooltip.kingofcurses.talisman.","tooltip.kingofcurses.perk.","ability.kingofcurses.","gui.kingofcurses.codex.lore_","gui.kingofcurses.codex.site_","cinematic.kingofcurses.line_","key.kingofcurses.")
for k in used:
    if k.endswith(".") or k.endswith("_"): continue
    if k not in en: E(f"java uses missing lang key {k}")
for t in ("sealing","warding","binding","flame"):
    if f"tooltip.kingofcurses.talisman.{t}" not in en: E("talisman tooltip "+t)
for pk in ("none","bleed","nullify","knockback","pull","soul","curse_slayer","cleaver"):
    if f"tooltip.kingofcurses.perk.{pk}" not in en: E("perk "+pk)
for a in ABILITIES:
    for suf in ("",".desc"):
        if f"ability.kingofcurses.{a[0].lower()}{suf}" not in en: E("ability "+a[0])
for i in range(11):
    if f"cinematic.kingofcurses.line_{i}" not in en: E(f"line {i}")
for k in ("use_ability","next_ability","ability_wheel","domain_expansion","cursed_codex","skip_cinematic"):
    if f"key.kingofcurses.{k}" not in en: E("key "+k)
# advancements lang
for p,a in js.items():
    if "/advancements/" in p:
        for f in ("title","description"):
            k=a["display"][f]["translate"]
            if k not in en: E(f"adv lang {k}")
        icon=a["display"]["icon"]["item"].split(":")[1]
        if icon not in items: E(f"adv icon {icon}")
# 5. sounds
sj=js[f"{A}/sounds.json"]
for s in sounds:
    if s not in sj: E(f"sounds.json missing {s}")
    elif not os.path.exists(f"{A}/sounds/{s}.ogg"): E(f"missing ogg {s}")
    if f"subtitles.kingofcurses.{s}" not in en: E(f"subtitle {s}")
# 6. particles
for pt in parts:
    pj=js.get(f"{A}/particles/{pt}.json")
    if not pj: E(f"particle json {pt}"); continue
    for t in pj["textures"]:
        if not os.path.exists(f"{A}/textures/particle/{t.split(':')[1]}.png"): E(f"particle tex {t}")
for e in effects:
    if not os.path.exists(f"{A}/textures/mob_effect/{e}.png"): E(f"effect icon {e}")
# 7. entities geo/anim/tex/glow + anim names referenced in Java
for e in ents:
    if e in NON_GEO_ENTITIES: continue
    if e in SHARED_GEO:
        src=SHARED_GEO[e]
        for f in (f"textures/entity/{e}.png",f"textures/entity/{e}_glowmask.png"):
            if not os.path.exists(f"{A}/{f}"): E(f"entity asset missing {f}")
        from PIL import Image
        if Image.open(f"{A}/textures/entity/{e}.png").size!=Image.open(f"{A}/textures/entity/{src}.png").size: E("shared tex size "+e)
        if Image.open(f"{A}/textures/entity/{e}_glowmask.png").convert("RGBA").getbbox() is None: E("empty glowmask (GeckoLib crash) "+e)
        continue
    for f in (f"geo/entity/{e}.geo.json",f"animations/entity/{e}.animation.json",f"textures/entity/{e}.png",f"textures/entity/{e}_glowmask.png"):
        if not os.path.exists(f"{A}/{f}"): E(f"entity asset missing {f}")
    g=js.get(f"{A}/geo/entity/{e}.geo.json")
    if g:
        from PIL import Image
        im=Image.open(f"{A}/textures/entity/{e}.png"); d=g["minecraft:geometry"][0]["description"]
        if im.size!=(d["texture_width"],d["texture_height"]): E(f"tex size mismatch {e} {im.size} vs {d['texture_width']}x{d['texture_height']}")
        gm=Image.open(f"{A}/textures/entity/{e}_glowmask.png")
        if gm.size!=im.size: E("glow size "+e)
        if gm.convert("RGBA").getbbox() is None: E("empty glowmask (GeckoLib crash) "+e)
        names=[b["name"] for b in g["minecraft:geometry"][0]["bones"]]
        if len(names)!=len(set(names)): E("dup bones "+e)
        for b in g["minecraft:geometry"][0]["bones"]:
            if "parent" in b and b["parent"] not in names: E(f"{e}: bone parent missing {b['parent']}")
        an=js[f"{A}/animations/entity/{e}.animation.json"]["animations"]
        for aname,adef in an.items():
            for bn in adef["bones"]:
                if bn not in names: E(f"{e}: anim {aname} references missing bone {bn}")
need={"humanoid":["idle","walk","run","attack","slash","cast","domain"],}
anim_refs=set()
for jf in glob.glob(ROOT+'/src/main/java/com/kingofcurses/entity/*.java'):
    s=open(jf).read()
    for m in re.finditer(r'KocAnims\.(?:loop|once|onceThenIdle|hold|key)\((\w+|"[a-z_]+"), "([a-z_]+)"\)',s): anim_refs.add((m.group(1),m.group(2)))
# map model variables
models_by_class={"CursedSpiritEntity":[x[0] for x in ENTITIES if x[1] in("CURSE","SPECIAL")],"SorcererEntity":["jujutsu_sorcerer","sorcerer_elite","jujutsu_student","sealing_master"],"SukunaEntity":["ryomen_sukuna","sukuna_true_form"]}
for e in models_by_class["CursedSpiritEntity"]+models_by_class["SorcererEntity"]:
    an=js[f"{A}/animations/entity/{e}.animation.json"]["animations"]
    for a in ("idle","walk","run","attack","slash","cast") + (("domain",) if e in models_by_class["SorcererEntity"] else ()):
        if f"animation.{e}.{a}" not in an: E(f"anim missing {e}.{a}")
for e in models_by_class["SukunaEntity"]:
    an=js[f"{A}/animations/entity/{e}.animation.json"]["animations"]
    for a in ("idle","walk","run","taunt","slash","dig","vanish","domain","eat_finger","attack","dash","combo","recoil","charge"):
        if f"animation.{e}.{a}" not in an: E(f"anim missing {e}.{a}")
an=js[f"{A}/animations/entity/gojo_satoru.animation.json"]["animations"]
for a in ("idle","walk","run","infinity","cut_in_half","blue","red","dash","combo","charge","domain","taunt"):
    if f"animation.gojo_satoru.{a}" not in an: E("gojo "+a)
for e,a in (("malevolent_shrine","rise"),("malevolent_shrine","idle"),("dismantle_slash","idle"),("fuga_arrow","idle")):
    if f"animation.{e}.{a}" not in js[f"{A}/animations/entity/{e}.animation.json"]["animations"]: E(f"{e}.{a}")
# 8. loot/recipes item refs
def item_ok(ref):
    ns,p=ref.split(":") if ":" in ref else ("minecraft",ref)
    return ns!="kingofcurses" or p in items
def walk(o,path):
    if isinstance(o,dict):
        for k,v in o.items():
            if k in("item","name","result") and isinstance(v,str) and ":" in v and not v.startswith("minecraft:") and "loot" not in v:
                if v.startswith("kingofcurses:") and not item_ok(v) and v.split(":")[1] not in blocks: E(f"{path}: unknown item {v}")
            walk(v,path)
    elif isinstance(o,list):
        for v in o: walk(v,path)
for p,o in js.items():
    if "/loot_tables/" in p or "/recipes/" in p: walk(o,p)
for b in blocks:
    if not os.path.exists(f"{D}/kingofcurses/loot_tables/blocks/{b}.json"): E("block loot "+b)
for e in ents:
    if e in("malevolent_shrine","dismantle_slash","fuga_arrow","sliced_corpse","sukuna_arm_thrown"): continue
    if not os.path.exists(f"{D}/kingofcurses/loot_tables/entities/{e}.json"): E("entity loot "+e)
for n in range(1,21):
    if not os.path.exists(f"{D}/kingofcurses/loot_tables/chests/finger_%02d.json"%n): E("finger chest %d"%n)
# 9. worldgen refs
for p,o in js.items():
    if "/worldgen/structure/" in p and "/tags/" not in p:
        name=os.path.basename(p)[:-5]
        pool=o["start_pool"].split(":")[1]
        if not os.path.exists(f"{D}/kingofcurses/worldgen/template_pool/{pool}.json"): E("pool "+pool)
        if not os.path.exists(f"{D}/kingofcurses/structures/{name}.nbt"): E("nbt "+name)
        bt=o["biomes"][1:].split(":")[1]
        if not os.path.exists(f"{D}/kingofcurses/tags/worldgen/biome/{bt}.json"): E("biome tag "+bt)
        if not os.path.exists(f"{D}/kingofcurses/worldgen/structure_set/{name}.json"): E("set "+name)
# 10. nbt palette check
def readnbt(path):
    b=gzip.open(path).read(); i=[0]
    def rd(n): v=b[i[0]:i[0]+n]; i[0]+=n; return v
    def payload(t):
        if t==1: return struct.unpack(">b",rd(1))[0]
        if t==2: return struct.unpack(">h",rd(2))[0]
        if t==3: return struct.unpack(">i",rd(4))[0]
        if t==4: return struct.unpack(">q",rd(8))[0]
        if t==5: return struct.unpack(">f",rd(4))[0]
        if t==6: return struct.unpack(">d",rd(8))[0]
        if t==8: n=struct.unpack(">H",rd(2))[0]; return rd(n).decode()
        if t==9:
            et,n=struct.unpack(">bi",rd(5)); return [payload(et) for _ in range(n)]
        if t==10:
            d={}
            while True:
                tt=struct.unpack(">b",rd(1))[0]
                if tt==0: return d
                n=struct.unpack(">H",rd(2))[0]; k=rd(n).decode(); d[k]=payload(tt)
        if t==11: n=struct.unpack(">i",rd(4))[0]; return [struct.unpack(">i",rd(4))[0] for _ in range(n)]
        raise Exception(t)
    t=struct.unpack(">b",rd(1))[0]; n=struct.unpack(">H",rd(2))[0]; rd(n); return payload(t)
VALIDPROPS={"stairs":{"facing","half","shape","waterlogged"},"slab":{"type","waterlogged"},"pillar":{"axis"},"reliquary":{"facing"},"leaves":{"distance","persistent","waterlogged"},"wall":{"up","north","east","south","west","waterlogged"}}
kinds={b[0]:b[1] for b in BLOCKS}
fingers_in_structs={}
for p in glob.glob(D+'/kingofcurses/structures/*.nbt'):
    t=readnbt(p)
    for pal in t["palette"]:
        n=pal["Name"]
        if n.startswith("kingofcurses:"):
            bid=n.split(":")[1]
            if bid not in blocks: E(f"{p}: unknown block {n}")
            k=kinds.get(bid)
            for prop in pal.get("Properties",{}):
                if k in VALIDPROPS and prop not in VALIDPROPS[k]: E(f"{p}: bad prop {n}[{prop}]")
                if k not in VALIDPROPS: E(f"{p}: {n} has props but none expected")
    for bl in t["blocks"]:
        if "nbt" in bl and "LootTable" in bl["nbt"]:
            lt=bl["nbt"]["LootTable"].split(":")[1]
            if not os.path.exists(f"{D}/kingofcurses/loot_tables/{lt}.json"): E(f"{p}: loot table {lt}")
            m=re.search(r"finger_(\d+)",lt)
            if m: fingers_in_structs.setdefault(int(m.group(1)),[]).append(os.path.basename(p))
    for en_ in t["entities"]:
        eid=en_["nbt"]["id"].split(":")[1]
        if eid not in ents: E(f"{p}: unknown entity {eid}")
        if "FingerIndex" in en_["nbt"]: fingers_in_structs.setdefault(en_["nbt"]["FingerIndex"],[]).append(os.path.basename(p)+"(mob)")
# default special-grade fingers covered
print("fingers placed:",sorted(fingers_in_structs))
missing=[n for n in range(2,21) if n not in fingers_in_structs]
if missing: E(f"fingers without a location: {missing}")
# GUI textures
for g_ in ("gui/codex","gui/reliquary")+tuple(f"gui/ability/{a[0].lower()}" for a in ABILITIES)+tuple(f"entity/markings/markings_{i}" for i in range(1,6)):
    if not os.path.exists(f"{A}/textures/{g_}.png"): E("gui tex "+g_)
for s,_,_,_ in ARMOR_SETS+[("gojo_blindfold",0,0,0)]:
    for L in (1,2):
        if not os.path.exists(f"{A}/textures/models/armor/{s}_layer_{L}.png"): E("armor tex")
if not os.path.exists(RES+"/kingofcurses_logo.png"): E("logo")
for f in ("textures/entity/gojo_satoru_eyes.png","textures/entity/gojo_satoru_eyes_glowmask.png","textures/entity/gore.png"):
    if not os.path.exists(f"{A}/{f}"): E("missing "+f)
an=js[f"{A}/animations/entity/gojo_satoru.animation.json"]["animations"]
if "animation.gojo_satoru.dead" not in an: E("gojo dead anim")
print("ERRORS:",len(errs))
for e in errs[:60]: print(" -",e)

# v1.0.4 checks
for t in range(1,6):
    for suf in ("","_glow"):
        f=f"{A}/textures/entity/markings/markings_{t}{suf}.png"
        if not os.path.exists(f): E("markings missing "+f)
        else:
            from PIL import Image
            if Image.open(f).convert("RGBA").getbbox() is None: E("empty markings "+f)
for oid,_,_ in CURSED_OBJECTS:
    if not os.path.exists(f"{A}/textures/item/{oid}.png"): E("cursed object tex "+oid)
print("v1.0.4 checks done, errors so far:",len(errs))

for t in (1,2,3):
    for suf in ("","_glow"):
        if not os.path.exists(f"{A}/textures/entity/markings/vessel_{t}{suf}.png"): E(f"vessel tex {t}{suf}")
if not os.path.exists(f"{A}/textures/item/ripped_finger.png"): E("ripped finger tex")
print("v1.0.5 checks done, errors:",len(errs))

for f in ("sukuna_eyes","sukuna_eyes_glow"):
    if not os.path.exists(f"{A}/textures/entity/markings/{f}.png"): E("missing "+f)
print("v1.0.7 checks done, errors:",len(errs))
# v1.0.25: every translation key written in Java (also cinematic.kingofcurses.yuta.* built at runtime with _sub) exists in both languages
for jf in glob.glob(ROOT+'/src/main/java/**/*.java',recursive=True):
    for k in re.findall(r'"((?:cinematic|message|tooltip|gui)\.kingofcurses\.[a-z0-9_.]+)"',open(jf).read()):
        if k.endswith(".") or k.endswith("_"): continue
        if k not in en or k not in itl: E(f"lang key missing {k} ({os.path.basename(jf)})")
for k in ("cinematic.kingofcurses.yuta.title_sub","cinematic.kingofcurses.yuta.t_rika_sub"):
    if k not in en: E("missing "+k)
an=js[f"{A}/animations/entity/rika_orimoto.animation.json"]["animations"]
for a in ("idle","walk","run","attack","slash","cast","rise"):
    if f"animation.rika_orimoto.{a}" not in an: E("rika anim "+a)
for e in ("rika_ring","yuta_katana"):
    if not os.path.exists(f"{A}/textures/item/{e}.png"): E("item tex "+e)
print("v1.0.25 checks done, errors:",len(errs))

# v1.0.26: main-menu trailer (pre-made GeckoLib scene)
import re as _re, json as _json, os as _os
_ts=open(os.path.join(PROJECT if 'PROJECT' in dir() else os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..')),"src/main/java/com/kingofcurses/client/trailer/TrailerScreen.java"),encoding="utf-8").read()
for _f in _re.findall(r'rl\("([a-z_/]+\.(?:json|png))"\)',_ts):
    if not _os.path.exists(f"{A}/{_f}"): E("trailer file missing "+_f)
    if _f.startswith("textures/") and ("trailer_jogo" in _f or "ryomen_sukuna" in _f or "trailer_meteor" in _f):
        if not _os.path.exists(f"{A}/{_f[:-4]}_glowmask.png"): E("trailer glowmask missing "+_f)
_anims={}
for _d in ("animations/trailer","animations/entity"):
    for _fn in _os.listdir(f"{A}/{_d}"): _anims.update(_json.load(open(f"{A}/{_d}/{_fn}"))["animations"])
for _a in _re.findall(r'thenPlay\("([a-z_.]+)"\)',_ts):
    if _a not in _anims: E("trailer anim missing "+_a)
_sk=[b["name"] for b in _json.load(open(f"{A}/geo/entity/ryomen_sukuna.geo.json"))["minecraft:geometry"][0]["bones"]]
for _n,_v in _json.load(open(f"{A}/animations/trailer/trailer_sukuna.animation.json"))["animations"].items():
    for _b in _v["bones"]:
        if _b not in _sk: E(f"trailer sukuna bone {_b} not in rig")
_jg=[b["name"] for b in _json.load(open(f"{A}/geo/trailer/trailer_jogo.geo.json"))["minecraft:geometry"][0]["bones"]]
for _n,_v in _json.load(open(f"{A}/animations/trailer/trailer_jogo.animation.json"))["animations"].items():
    for _b in _v["bones"]:
        if _b not in _jg: E(f"trailer jogo bone {_b} missing")
for _lang in ("en_us","it_it"):
    _L=_json.load(open(f"{A}/lang/{_lang}.json"))
    for _k in set(_re.findall(r'"((?:trailer|gui)\.kingofcurses\.[a-z_.]+)"',_ts+open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..',"src/main/java/com/kingofcurses/client/ClientForgeEvents.java"),encoding="utf-8").read())):
        if _k.startswith("gui.kingofcurses.create.side") and _k not in _L: E(f"{_lang} missing {_k}")
        elif _k not in _L and not _k.startswith("gui.kingofcurses.create.side"): E(f"{_lang} missing {_k}")
for _s in ("trailer_fuga","trailer_meteor","trailer_burn","trailer_theme"):
    if not _os.path.exists(f"{A}/sounds/{_s}.ogg"): E("trailer sound missing "+_s)
    if "TRAILER_"+_s[8:].upper() not in _ts: E("trailer sound unused "+_s)
print("v1.0.26 checks done, errors:",len(errs))
