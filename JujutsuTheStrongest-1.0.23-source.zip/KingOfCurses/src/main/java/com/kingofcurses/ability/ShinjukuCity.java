package com.kingofcurses.ability;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * v1.0.22 Full Fight Video: flattens the land around spawn and raises a small Shinjuku (roads, crossings,
 * sidewalks, lamp posts, glass towers). Everything is done in small time-boxed slices every tick, so the
 * server never freezes: a few milliseconds of work per tick while the loading screen is up. The same
 * queue later carves the damage of the fight (Red, Hollow Purple, the World-Cutting Slash).
 */
public final class ShinjukuCity {
    public static final int R = 80, GRID = 32, ROAD = 4, WALK = 6;
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    private static ServerLevel level;
    private static BlockPos center;
    private static int groundY;
    private static List<long[]> chunks;           // {chunkX, chunkZ}
    private static int chunkIdx, colIdx;
    private static boolean building;
    private static long seed;
    private static final ArrayDeque<BlockPos> CARVE = new ArrayDeque<>();

    private ShinjukuCity() {}

    public static boolean building() { return building; }
    public static float progress() { return chunks == null || chunks.isEmpty() ? (building ? 0f : 1f) : Mth.clamp((chunkIdx + colIdx / 256f) / chunks.size(), 0f, 1f); }
    public static BlockPos center() { return center; }
    public static int groundY() { return groundY; }

    /** Picks the city centre and ground level at the spawn point and starts building. */
    public static void begin(ServerLevel sl, BlockPos at) {
        level = sl;
        sl.getChunk(at.getX() >> 4, at.getZ() >> 4);
        int y = sl.getHeight(Heightmap.Types.OCEAN_FLOOR, at.getX(), at.getZ()) - 1;
        groundY = Mth.clamp(y, sl.getSeaLevel(), sl.getSeaLevel() + 40);
        center = new BlockPos(at.getX(), groundY, at.getZ());
        seed = sl.getSeed() ^ center.asLong();
        chunks = new ArrayList<>();
        int c0x = (center.getX() - R) >> 4, c1x = (center.getX() + R) >> 4, c0z = (center.getZ() - R) >> 4, c1z = (center.getZ() + R) >> 4;
        for (int cx = c0x; cx <= c1x; cx++) for (int cz = c0z; cz <= c1z; cz++) chunks.add(new long[]{cx, cz});
        chunks.sort((a, b) -> Double.compare(dist2(a), dist2(b)));   // the plaza first
        chunkIdx = 0; colIdx = 0; building = true;
    }

    private static double dist2(long[] c) {
        double dx = c[0] * 16 + 8 - center.getX(), dz = c[1] * 16 + 8 - center.getZ();
        return dx * dx + dz * dz;
    }

    /** Restores the city layout (for carving) on a world that already has it. */
    public static void restore(ServerLevel sl, BlockPos c) {
        level = sl; center = c; groundY = c.getY(); seed = sl.getSeed() ^ c.asLong(); building = false; chunks = null;
    }

    /** Runs some building / carving for at most {@code budgetMs}. */
    public static void tick(long budgetMs) {
        if (level == null) return;
        long end = System.nanoTime() + budgetMs * 1_000_000L;
        while (building && System.nanoTime() < end) {
            if (chunkIdx >= chunks.size()) { building = false; break; }
            long[] c = chunks.get(chunkIdx);
            if (colIdx == 0) level.getChunk((int) c[0], (int) c[1]);
            int x = (int) c[0] * 16 + (colIdx & 15), z = (int) c[1] * 16 + (colIdx >> 4);
            column(x, z);
            if (++colIdx >= 256) { colIdx = 0; chunkIdx++; }
        }
        while (!CARVE.isEmpty() && System.nanoTime() < end) {
            for (int i = 0; i < 64 && !CARVE.isEmpty(); i++) {
                BlockPos p = CARVE.poll();
                if (p.getY() > groundY - 12 && level.isLoaded(p) && !level.getBlockState(p).isAir()) level.setBlock(p, Blocks.AIR.defaultBlockState(), FLAGS);
            }
        }
    }

    public static void clear() { level = null; building = false; CARVE.clear(); chunks = null; center = null; }

    // ------------------------------------------------------------------ the layout
    private static int fold(int d) { int m = Math.floorMod(d, GRID); return Math.min(m, GRID - m); }

    /** A tower in the lot (lu, lv), or null. {minX, minZ, sizeX, sizeZ, height, palette} in city coordinates. */
    private static int[] tower(int lu, int lv) {
        int cu = lu * GRID + GRID / 2, cv = lv * GRID + GRID / 2;
        java.util.Random r = new java.util.Random(seed ^ (lu * 341873128712L) ^ (lv * 132897987541L));
        int sx = 12 + r.nextInt(6), sz = 12 + r.nextInt(6);
        boolean inner = Math.abs(cu) < GRID && Math.abs(cv) < GRID;
        int h = inner ? 14 + r.nextInt(10) : 26 + r.nextInt(34);
        int mu = cu - sx / 2 + r.nextInt(3) - 1, mv = cv - sz / 2 + r.nextInt(3) - 1;
        if (Math.abs(mu) > R - 2 || Math.abs(mu + sx) > R - 2 || Math.abs(mv) > R - 2 || Math.abs(mv + sz) > R - 2) return null;
        return new int[]{mu, mv, sx, sz, h, r.nextInt(4)};
    }

    private static final BlockState[] WALL = {Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), Blocks.WHITE_CONCRETE.defaultBlockState(),
            Blocks.GRAY_CONCRETE.defaultBlockState(), Blocks.CYAN_TERRACOTTA.defaultBlockState()};
    private static final BlockState[] GLASS = {Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), Blocks.GRAY_STAINED_GLASS.defaultBlockState(),
            Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), Blocks.CYAN_STAINED_GLASS.defaultBlockState()};

    private static BlockState ground(int u, int v) {
        int fu = fold(u), fv = fold(v);
        boolean roadU = fu <= ROAD, roadV = fv <= ROAD;   // roadU: the road running along Z (|u| small)
        if (roadU || roadV) {
            if (roadU && roadV) return Blocks.GRAY_CONCRETE.defaultBlockState();                                   // crossing
            if (roadU && fv <= ROAD + 4 && fu < ROAD && Math.floorMod(u, 2) == 0) return Blocks.WHITE_CONCRETE.defaultBlockState();   // zebra
            if (roadV && fu <= ROAD + 4 && fv < ROAD && Math.floorMod(v, 2) == 0) return Blocks.WHITE_CONCRETE.defaultBlockState();
            if (roadU && fu == 0 && Math.floorMod(v, 6) < 3) return Blocks.WHITE_CONCRETE.defaultBlockState();       // lane dashes
            if (roadV && fv == 0 && Math.floorMod(u, 6) < 3) return Blocks.WHITE_CONCRETE.defaultBlockState();
            return Blocks.GRAY_CONCRETE.defaultBlockState();
        }
        if (fu <= WALK || fv <= WALK) return Blocks.SMOOTH_STONE.defaultBlockState();
        return Blocks.POLISHED_ANDESITE.defaultBlockState();
    }

    private static void column(int x, int z) {
        int u = x - center.getX(), v = z - center.getZ();
        if (Math.abs(u) > R || Math.abs(v) > R) return;
        int g = groundY;
        int top = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);   // first free block above the terrain
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(x, g, z);
        // fill down (water, holes) and lay the ground
        set(p.setY(g), ground(u, v));
        for (int y = g - 1; y >= g - 24; y--) {
            BlockState s = level.getBlockState(p.setY(y));
            if (y < g - 3 && !s.isAir() && s.getFluidState().isEmpty()) break;
            set(p, y >= g - 2 ? Blocks.STONE_BRICKS.defaultBlockState() : Blocks.STONE.defaultBlockState());
        }
        // what stands on this column
        int lu = Math.floorDiv(u, GRID), lv = Math.floorDiv(v, GRID);
        int[] t = (fold(u) > WALK && fold(v) > WALK) ? tower(lu, lv) : null;
        int built = g;
        if (t != null && u >= t[0] && u < t[0] + t[2] && v >= t[1] && v < t[1] + t[3]) {
            int bu = u - t[0], bv = v - t[1], h = t[4];
            boolean edge = bu == 0 || bv == 0 || bu == t[2] - 1 || bv == t[3] - 1;
            boolean corner = (bu == 0 || bu == t[2] - 1) && (bv == 0 || bv == t[3] - 1);
            int along = (bu == 0 || bu == t[2] - 1) ? bv : bu;
            for (int k = 1; k <= h; k++) {
                BlockState s;
                if (k == h) s = edge ? Blocks.SMOOTH_STONE.defaultBlockState() : WALL[2];                                // roof
                else if (edge) {
                    if (corner || k % 4 == 0) s = WALL[t[5]];
                    else if (k <= 3 && along >= t[2] / 2 - 1 && along <= t[2] / 2 && (bu == 0 || bv == 0)) s = Blocks.AIR.defaultBlockState();   // the door
                    else s = along % 3 == 0 ? WALL[t[5]] : GLASS[t[5]];
                } else s = k % 8 == 0 ? WALL[2] : Blocks.AIR.defaultBlockState();                                          // floors
                set(p.setY(g + k), s);
            }
            built = g + h;
            if (edge && !corner && (along % 4 == 1)) { set(p.setY(g + h + 1), Blocks.SMOOTH_STONE_SLAB.defaultBlockState()); built = g + h + 1; }   // parapet
        } else {
            int fu = fold(u), fv = fold(v);
            boolean lamp = (fu == WALK || fv == WALK) && fu > ROAD && fv > ROAD && Math.floorMod(u + v, 14) == 0 && !(fu <= WALK && fv <= WALK);
            if (lamp) {
                for (int k = 1; k <= 4; k++) set(p.setY(g + k), Blocks.IRON_BARS.defaultBlockState());
                set(p.setY(g + 5), Blocks.SEA_LANTERN.defaultBlockState());
                built = g + 5;
            }
        }
        // clear the rest (hills, trees, old buildings)
        for (int y = built + 1; y < top; y++) {
            if (!level.getBlockState(p.setY(y)).isAir()) level.setBlock(p, Blocks.AIR.defaultBlockState(), FLAGS);
        }
    }

    private static void set(BlockPos p, BlockState s) {
        if (level.getBlockState(p) != s) level.setBlock(p, s, FLAGS);
    }

    /** Centre of the tower in lot (lu, lv), at about a third of its height (or null). */
    public static Vec3 towerCenter(int lu, int lv) {
        int[] t = tower(lu, lv);
        if (t == null) return null;
        return new Vec3(center.getX() + t[0] + t[2] / 2.0, groundY + 1 + Math.min(6, t[4] / 3.0), center.getZ() + t[1] + t[3] / 2.0);
    }

    // ------------------------------------------------------------------ damage of the fight
    /** Erases a tube of radius r from a to b (through buildings, roads, anything). */
    public static void carveTube(Vec3 a, Vec3 b, double r) {
        if (level == null) return;
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 n = d.scale(1 / len);
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        for (double s = 0; s <= len; s += 0.8) {
            Vec3 c = a.add(n.scale(s));
            int ri = (int) Math.ceil(r);
            for (int dx = -ri; dx <= ri; dx++) for (int dy = -ri; dy <= ri; dy++) for (int dz = -ri; dz <= ri; dz++) {
                if (dx * dx + dy * dy + dz * dz > r * r) continue;
                BlockPos p = BlockPos.containing(c.x + dx, c.y + dy, c.z + dz);
                if (seen.add(p.asLong())) CARVE.add(p);
            }
        }
    }

    /** A thin vertical cut (one block wide) from a to b, from y0 up to y1: Dismantle and the World-Cutting Slash. */
    public static void carveCut(Vec3 a, Vec3 b, int y0, int y1) {
        if (level == null) return;
        Vec3 d = b.subtract(a);
        double len = Math.sqrt(d.x * d.x + d.z * d.z);
        if (len < 0.01) return;
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        for (int y = y0; y <= y1; y++) for (double s = 0; s <= len; s += 0.7) {
            BlockPos p = BlockPos.containing(a.x + d.x * s / len, y, a.z + d.z * s / len);
            if (seen.add(p.asLong())) CARVE.add(p);
        }
    }
}
