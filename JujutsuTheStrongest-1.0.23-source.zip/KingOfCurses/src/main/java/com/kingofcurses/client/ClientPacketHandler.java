package com.kingofcurses.client;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.network.*;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/** Runs client logic for server packets. Only ever class-loaded on the physical client. */
public final class ClientPacketHandler {
    private ClientPacketHandler() {}

    public static void handleSync(SyncDataPacket p) {
        ClientData.DATA.loadSync(p.tag);
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) CursedCapability.get(mc.player).ifPresent(d -> d.loadSync(p.tag));
    }

    public static void handleRip(com.kingofcurses.network.RipAnimPacket p) {
        if (p.kind == com.kingofcurses.network.RipAnimPacket.RIP) RipAnim.start(p.entityId);
        else if (p.kind == com.kingofcurses.network.RipAnimPacket.TRANSFORM) BodyAnims.startTransform(p.entityId);
        else if (p.kind == com.kingofcurses.network.RipAnimPacket.POSSESS) BodyAnims.startPossess(p.entityId);
        else if (p.kind == com.kingofcurses.network.RipAnimPacket.DUST) BodyAnims.startDust(p.entityId);
        else if (p.kind == com.kingofcurses.network.RipAnimPacket.FINISHER) BodyAnims.startFinisher(p.entityId, p.arg);
        else BodyAnims.startRegrow(p.entityId, p.arg);
    }

    public static void handleFullFight(com.kingofcurses.network.FullFightPacket p) {
        if (p.action == com.kingofcurses.network.FullFightPacket.START) FullFightCinematic.start(p.a, p.b, new net.minecraft.core.BlockPos(p.x, p.y, p.z));
        else if (p.action == com.kingofcurses.network.FullFightPacket.SYNC) FullFightCinematic.sync(p.tick);
        else if (p.action == com.kingofcurses.network.FullFightPacket.MAHORAGA) FullFightCinematic.mahoraga(p.a);
        else FullFightCinematic.stop();
    }

    public static void handleGojoIntro(com.kingofcurses.network.GojoIntroPacket p) {
        if (p.action == com.kingofcurses.network.GojoIntroPacket.START) GojoIntroCinematic.start(p.gojoId, p.tojiId, p.tick / 100f);
        else if (p.action == com.kingofcurses.network.GojoIntroPacket.SYNC) GojoIntroCinematic.sync(p.tick);
        else if (p.action == com.kingofcurses.network.GojoIntroPacket.GETO) GojoIntroCinematic.geto(p.gojoId);
        else GojoIntroCinematic.stop();
    }

    public static void handleOther(SyncOtherPacket p) { ClientData.setOther(p.entityId, p.fingers, p.ending); }

    public static void handleCinematic(CinematicPacket p) {
        if (p.action == CinematicPacket.START) ClientCinematic.start(p);
        else if (p.action == CinematicPacket.SYNC) ClientCinematic.sync(p.sukunaId);
        else ClientCinematic.stop();
    }

    public static void handleFx(ScreenFxPacket p) { ClientFx.trigger(p.type, p.duration, p.intensity); }

    public static void handleDomain(DomainStatePacket p) {
        ClientData.domainActive = p.active;
        ClientData.domainCenter = new Vec3(p.x, p.y, p.z);
        ClientData.domainRadius = p.radius;
        ClientData.domainTicks = p.ticksLeft;
    }

    public static void handleOpenScreen(OpenScreenPacket p) {
        if (p.screen == OpenScreenPacket.ENDING) ClientHooks.openEnding();
        if (p.screen == OpenScreenPacket.CONTROL_MODE) ClientHooks.openControlMode();
    }
}
