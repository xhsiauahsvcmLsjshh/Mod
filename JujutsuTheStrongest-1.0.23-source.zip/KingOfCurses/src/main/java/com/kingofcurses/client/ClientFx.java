package com.kingofcurses.client;

import com.kingofcurses.ability.Ability;
import com.kingofcurses.network.ScreenFxPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;

/** Screen shake, flashes, aura and takeover state. */
public final class ClientFx {
    private static int shake, shakeMax, redFlash, redMax, whiteFlash, whiteMax, aura, auraMax, markings, takeover, cast, blackFlash, loading, loadingMax, subtitle, subtitleMax, subtitleLine = -1;
    private static float shakeIntensity;
    private static int castAbility = -1;

    private ClientFx() {}

    public static void trigger(int type, int duration, float intensity) {
        switch (type) {
            case ScreenFxPacket.SHAKE -> { shake = shakeMax = duration; shakeIntensity = intensity; }
            case ScreenFxPacket.RED_FLASH -> redFlash = redMax = duration;
            case ScreenFxPacket.WHITE_FLASH -> whiteFlash = whiteMax = duration;
            case ScreenFxPacket.AURA -> aura = auraMax = duration;
            case ScreenFxPacket.MARKINGS -> markings = duration;
            case ScreenFxPacket.BLACK_FLASH -> blackFlash = duration;
            case ScreenFxPacket.LOADING -> { loading = loadingMax = duration; loadingKind = 0; }
            case ScreenFxPacket.LOADING_PROGRESS -> {   // v1.0.23: never moves backwards
                int next = Math.max(1, Math.round((1f - intensity) * 1000f));
                if (loadingKind != duration || loading <= 0) loading = next; else loading = Math.min(loading, next);
                loadingMax = 1000; loadingKind = duration; loadingHold = 30;
            }
            case ScreenFxPacket.HEIAN_INTRO -> HeianCinematic.start();
            case ScreenFxPacket.SUBTITLE -> { subtitle = subtitleMax = duration; subtitleLine = (int) intensity; }
            case ScreenFxPacket.TAKEOVER -> takeover = duration;
            case ScreenFxPacket.TAKEOVER_END -> takeover = 0;
            case ScreenFxPacket.ARM_CAST -> {
                cast = duration; castAbility = (int) intensity;
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null) mc.player.swing(InteractionHand.MAIN_HAND);
            }
            default -> { }
        }
    }

    public static void tick() {
        if (shake > 0) shake--;
        if (redFlash > 0) redFlash--;
        if (whiteFlash > 0) whiteFlash--;
        if (aura > 0) aura--;
        if (markings > 0) markings--;
        if (takeover > 0) takeover--;
        if (cast > 0) cast--;
        if (blackFlash > 0) blackFlash--;
        if (loading > 0) { if (loadingKind == 0) loading--; else if (--loadingHold <= 0) loading = 0; }
        if (subtitle > 0) subtitle--;
    }

    public static float shakeAmount() { return shake <= 0 ? 0 : shakeIntensity * (shake / (float) Math.max(1, shakeMax)); }
    public static float redAlpha() { return redFlash <= 0 ? 0 : redFlash / (float) Math.max(1, redMax); }
    public static float whiteAlpha() { return whiteFlash <= 0 ? 0 : whiteFlash / (float) Math.max(1, whiteMax); }
    public static float auraAlpha() { return aura <= 0 ? 0 : aura / (float) Math.max(1, auraMax); }
    public static float markingsBoost() { return markings > 0 ? 0.5f : 0f; }
    public static boolean takeoverActive() { return takeover > 0 || ClientData.DATA.takeoverTicks() > 0; }
    /** Camera kick for cast animations (degrees of pitch). */
    public static float castKick() {
        if (cast <= 0) return 0;
        float strength = castAbility == Ability.FUGA.ordinal() || castAbility == Ability.WORLD_SLASH.ordinal() ? 2.5f : 1.2f;
        return strength * (cast / 12f);
    }
    /** v1.0.8 loading screen before the intro: progress 0..1, or -1 when hidden. */
    public static float loading() { return loading <= 0 ? -1f : 1f - loading / (float) Math.max(1, loadingMax); }
    public static void stopLoading() { loading = 0; }
    /** v1.0.22: 0 = intro loading, 1 = building Shinjuku. */
    public static int loadingKind() { return loadingKind; }
    private static int loadingKind, loadingHold;
    /** v1.0.9 big possession subtitles: the line index, or -1. */
    public static int subtitleLine() { return subtitle > 0 ? subtitleLine : -1; }
    public static float subtitleAlpha() { return subtitle <= 0 ? 0 : Math.min(1f, Math.min(subtitle, subtitleMax - subtitle) / 6f); }

    /** Remaining ticks of the BLACK FLASH title. */
    public static int blackFlash() { return blackFlash; }
    public static void reset() { shake = redFlash = whiteFlash = aura = markings = takeover = cast = blackFlash = loading = subtitle = 0; }
}
