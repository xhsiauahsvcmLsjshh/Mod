package com.kingofcurses.client;

import com.kingofcurses.ability.ArmLogic;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;

import java.util.HashMap;
import java.util.Map;

/** v1.0.7 client timelines: the four-arm awakening and arm regrowth. */
public final class BodyAnims {
    private static final Map<Integer, Long> TRANSFORM = new HashMap<>();
    private static final Map<Integer, Long> POSSESS = new HashMap<>();
    private static final Map<Integer, Long> DUST = new HashMap<>();
    private static final Map<Integer, long[]> FINISH = new HashMap<>(); // start, kind
    private static final Map<Integer, long[]> REGROW = new HashMap<>(); // start, arm mask
    private static CameraType savedCamera;
    private static long cameraUntil;
    private BodyAnims() {}

    private static long now() { Minecraft mc = Minecraft.getInstance(); return mc.level == null ? 0 : mc.level.getGameTime(); }

    public static void startTransform(int id) {
        TRANSFORM.put(id, now());
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.getId() == id) {   // show the player their new body from the front
            if (savedCamera == null) savedCamera = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);
            cameraUntil = now() + ArmLogic.TRANSFORM_LENGTH + 10;
        }
    }

    /** v1.0.9 first-finger possession: Sukuna takes the body for a few seconds. */
    public static void startPossess(int id) {
        POSSESS.put(id, now());
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.getId() == id) {
            if (savedCamera == null) savedCamera = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);
            cameraUntil = now() + com.kingofcurses.ability.FirstTakeover.LENGTH;
        }
    }

    /** 0..1 progress of the possession, or -1. */
    public static float possess(int id, float pt) {
        Long s = POSSESS.get(id);
        if (s == null) return -1f;
        float t = (now() - s + pt) / com.kingofcurses.ability.FirstTakeover.LENGTH;
        if (t >= 1f) { POSSESS.remove(id); return -1f; }
        return Math.max(0f, t);
    }

    /** v1.0.10 crumbling to dust on death, seen from behind in third person. */
    public static void startDust(int id) {
        DUST.put(id, now());
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.getId() == id) {
            if (savedCamera == null) savedCamera = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            cameraUntil = now() + com.kingofcurses.ability.DustDeath.LENGTH + 30;
        }
    }

    /** 0..1 progress of the crumbling, or -1. */
    public static float dust(int id, float pt) {
        Long s = DUST.get(id);
        if (s == null) return -1f;
        float t = (now() - s + pt) / com.kingofcurses.ability.DustDeath.LENGTH;
        if (t >= 1.5f) { DUST.remove(id); return -1f; }
        return Math.max(0f, Math.min(1f, t));
    }

    /** v1.0.14 finisher: seen from behind in third person. */
    public static void startFinisher(int id, int kind) {
        FINISH.put(id, new long[]{now(), kind});
        Minecraft mc = Minecraft.getInstance();
        if (kind != 7 && mc.player != null && mc.player.getId() == id) {
            if (savedCamera == null) savedCamera = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            cameraUntil = now() + com.kingofcurses.ability.FinisherLogic.LENGTHS[Mth.clamp(kind, 0, 13)] + 12;
        }
    }

    /** 0..1 progress of the finisher, or -1. */
    public static float finisher(int id, float pt) {
        long[] f = FINISH.get(id);
        if (f == null) return -1f;
        float t = (now() - f[0] + pt) / com.kingofcurses.ability.FinisherLogic.LENGTHS[(int) Mth.clamp(f[1], 0, 13)];
        if (t >= 1f) { FINISH.remove(id); return -1f; }
        return Math.max(0f, t);
    }

    public static int finisherKind(int id) { long[] f = FINISH.get(id); return f == null ? -1 : (int) f[1]; }

    private static float lerp(float a, float b, float t) { return a + (b - a) * smooth(t); }

    /** Arm angles {xRot, yRot, zRot} for the finisher pose, or null when no finisher is running. */
    public static float[] finisherArm(int id, boolean right, float pt, float age) {
        float t = finisher(id, pt);
        if (t < 0) return null;
        int kind = finisherKind(id);
        float side = right ? -1f : 1f, sh = Mth.sin(age * 2.6f) * 0.06f;
        final float UP = -2.9f, FWD = -1.57f;
        switch (kind) {
            case 0 -> { // TEAR: lift overhead, pull apart
                float x = lerp(FWD, UP, t / 0.25f);
                float z = t < 0.25f ? side * 0.2f : t < 0.72f ? lerp(side * 0.2f, side * 0.75f, (t - 0.25f) / 0.47f) + sh : lerp(side * 0.75f, side * 1.6f, (t - 0.72f) / 0.08f);
                return new float[]{x + (t > 0.25f && t < 0.72f ? sh : 0), 0f, z};
            }
            case 1 -> { // HEART: wind up, thrust, pull out and raise
                if (!right) return new float[]{-1.1f, 0.3f, 0f};
                if (t < 0.25f) return new float[]{lerp(0f, 0.7f, t / 0.25f), 0f, 0f};
                if (t < 0.32f) return new float[]{lerp(0.7f, FWD, (t - 0.25f) / 0.07f), 0f, 0f};
                if (t < 0.72f) return new float[]{FWD + sh, 0f, 0f};
                return new float[]{lerp(FWD, -2.4f, (t - 0.72f) / 0.15f), 0f, -0.2f};
            }
            case 2 -> { // SLAM: hold up high, smash down
                float x = t < 0.4f ? lerp(FWD, UP, t / 0.2f) : t < 0.55f ? lerp(UP, -0.4f, (t - 0.4f) / 0.12f) : -0.4f;
                return new float[]{x, 0f, side * 0.15f};
            }
            case 3 -> { // DISMANTLE STORM: alternating slashes
                float ph = Mth.sin(age * 1.4f + (right ? 0f : 3.14f));
                return new float[]{FWD + ph * 0.7f, side * -0.3f * ph, side * (0.25f + 0.35f * ph)};
            }
            case 4 -> { // FUGA: right hand points, left draws the arrow back
                if (right) return new float[]{FWD, -0.1f, 0f};
                return new float[]{FWD, lerp(0f, 0.9f, t / 0.5f), 0f};
            }
            case 5 -> { // SKY CLEAVE: uppercut, then a huge downward slash
                if (t < 0.18f) return new float[]{lerp(0.3f, UP, t / 0.18f), 0f, side * 0.1f};
                if (t < 0.6f) return new float[]{UP, 0f, side * 0.25f};
                if (t < 0.7f) return new float[]{lerp(UP, -0.2f, (t - 0.6f) / 0.1f), 0f, side * 0.3f};
                return new float[]{-0.2f, 0f, side * 0.3f};
            }
            case 6 -> { // BARRAGE: piston punches
                float ph = Mth.sin(age * 2.2f + (right ? 0f : 3.14f));
                if (t > 0.82f && right) return new float[]{FWD, 0f, 0f};
                return new float[]{ph > 0 ? FWD : -0.5f, 0f, side * 0.05f};
            }
            case 8 -> { // RED POINT BLANK: right index finger pointed, then the recoil
                if (!right) return new float[]{-0.3f, 0f, 0.1f};
                return new float[]{t < 0.65f ? FWD + sh * 0.3f : lerp(FWD, -2.2f, (t - 0.65f) / 0.1f), 0f, 0f};
            }
            case 9 -> { // BLUE CRUSH: both hands closing around the singularity
                float c = lerp(0.6f, 0.05f, t / 0.75f);
                return new float[]{-1.9f + sh, 0f, side * -c};
            }
            case 10 -> { // PURPLE ERASE: hands apart, then together, then the release
                if (t < 0.6f) return new float[]{FWD, 0f, side * lerp(0.9f, 0.05f, t / 0.6f)};
                return new float[]{right ? FWD : -0.4f, 0f, 0f};
            }
            case 11 -> { // INFINITY WALL: casual palm up, then the flick
                if (!right) return new float[]{-0.2f, 0f, 0.15f};
                return new float[]{t < 0.68f ? -1.3f : lerp(-1.3f, -1.75f, (t - 0.68f) / 0.06f), 0f, -0.15f};
            }
            case 12 -> { // GOJO BLACK FLASH
                float ph = Mth.sin(age * 2.2f + (right ? 0f : 3.14f));
                if (t > 0.68f && right) return new float[]{FWD, 0f, 0f};
                return new float[]{ph > 0 ? FWD : -0.6f, 0f, side * 0.05f};
            }
            case 13 -> { // VOID PUNCH: hand sign, then the fist
                if (t < 0.65f) return new float[]{-1.2f, side * -0.5f, side * -0.6f};
                return new float[]{right ? FWD : -0.5f, 0f, 0f};
            }
            case 7 -> { // CATCH: both hands snap up and grab the flying arm
                float x = t < 0.25f ? lerp(-0.6f, -2.0f, t / 0.25f) : lerp(-2.0f, -1.2f, (t - 0.25f) / 0.75f);
                return new float[]{x + sh, 0f, side * -0.25f};
            }
            default -> { return null; }
        }
    }

    // ------------------------------------------------------------------ v1.0.19 Strongest of Today opening, played on the player's own body
    private static boolean introOn(int id) {
        Minecraft mc = Minecraft.getInstance();
        return GojoIntroCinematic.active() && mc.player != null && mc.player.getId() == id;
    }

    /** 0..1 how far the player's body is lying on the ground during the opening. */
    public static float introLie(int id, float pt) {
        if (!introOn(id)) return 0f;
        float t = GojoIntroCinematic.tick() + pt;
        float fall = com.kingofcurses.ability.GojoIntroDirector.T_FALL, rise = com.kingofcurses.ability.GojoIntroDirector.T_RISE;
        if (t < fall) return 0f;
        if (t < fall + 14) return smooth((t - fall) / 14f);
        if (t < rise) return 1f;
        if (t < rise + 30) return 1f - smooth((t - rise) / 30f);
        return 0f;
    }

    /** Arm angles for the player during the opening, or null. */
    public static float[] introArm(int id, boolean right, float pt, float age) {
        if (!introOn(id)) return null;
        float t = GojoIntroCinematic.tick() + pt;
        float side = right ? -1f : 1f;
        int s1 = com.kingofcurses.ability.GojoIntroDirector.T_STAB1, fall = com.kingofcurses.ability.GojoIntroDirector.T_FALL;
        int rise = com.kingofcurses.ability.GojoIntroDirector.T_RISE, charge = com.kingofcurses.ability.GojoIntroDirector.T_CHARGE, fire = com.kingofcurses.ability.GojoIntroDirector.T_FIRE;
        if (t >= s1 && t < fall) {                       // every stab jerks the arms a little (v1.0.21: softer)
            float ph = ((t - s1) % 10f) / 10f;
            float jolt = ph < 0.3f ? smooth(ph / 0.3f) : 1f - smooth((ph - 0.3f) / 0.7f);
            return new float[]{-0.15f - 0.35f * jolt, 0f, side * (0.1f + 0.25f * jolt)};
        }
        if (t >= fall && t < rise + 30) return null;     // v1.0.21: on the ground the vanilla arms follow the body
        if (t >= charge && t < fire) {                   // Red in one hand, Blue in the other, closing together
            float k = smooth((t - charge) / (float) (fire - charge));
            return new float[]{-1.55f, side * -(0.7f - 0.6f * k), 0f};
        }
        if (t >= fire && t < fire + 30) return new float[]{right ? -1.6f : -0.3f, 0f, right ? 0f : 0.2f};   // Hollow Purple, fired
        return null;
    }

    public static void startRegrow(int id, int arms) { REGROW.put(id, new long[]{now(), arms}); }

    /** Called every client tick. */
    public static void tick() {
        if (savedCamera != null && now() >= cameraUntil) {
            Minecraft.getInstance().options.setCameraType(savedCamera);
            savedCamera = null;
        }
    }

    /** 0..1 progress of the transformation, or -1. */
    public static float transform(int id, float pt) {
        Long s = TRANSFORM.get(id);
        if (s == null) return -1f;
        float t = (now() - s + pt) / ArmLogic.TRANSFORM_LENGTH;
        if (t >= 1f) { TRANSFORM.remove(id); return -1f; }
        return Math.max(0f, t);
    }

    /** 0..1 progress of an arm regrowing (bit mask arm), or -1. */
    public static float regrow(int id, int arm, float pt) {
        long[] r = REGROW.get(id);
        if (r == null || (r[1] & arm) == 0) return -1f;
        float t = (now() - r[0] + pt) / ArmLogic.REGROW_LENGTH;
        if (t >= 1f) { REGROW.remove(id); return -1f; }
        return Math.max(0f, t);
    }

    static float smooth(float x) { x = Mth.clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
    /** How far the extra arms have grown out (1 when no animation is running). */
    public static float armsGrowth(int id, float pt) { float t = transform(id, pt); return t < 0 ? 1f : smooth((t - 0.22f) / 0.45f); }
    /** How open the second pair of eyes is (1 when no animation is running). */
    public static float eyesOpen(int id, float pt) { float t = transform(id, pt); return t < 0 ? 1f : smooth((t - 0.55f) / 0.2f); }
    /** Roar pose amount for the main arms during the transformation. */
    public static float roar(int id, float pt) {
        float ps = possess(id, pt);
        if (ps >= 0) {   // arms flung open while Sukuna rules the body, then they drop as the player wins it back
            if (ps < 0.12f) return smooth(ps / 0.12f);
            if (ps < 0.72f) return 1f;
            if (ps < 0.84f) return 1f - smooth((ps - 0.72f) / 0.12f) * 0.7f;   // the struggle
            return 0.3f * (1f - smooth((ps - 0.84f) / 0.1f));
        }
        float t = transform(id, pt);
        if (t < 0) return 0f;
        if (t < 0.2f) return smooth(t / 0.2f);
        if (t < 0.8f) return 1f;
        return 1f - smooth((t - 0.8f) / 0.2f);
    }

    public static void clear() { FINISH.clear(); TRANSFORM.clear(); REGROW.clear(); POSSESS.clear(); DUST.clear(); }
}
