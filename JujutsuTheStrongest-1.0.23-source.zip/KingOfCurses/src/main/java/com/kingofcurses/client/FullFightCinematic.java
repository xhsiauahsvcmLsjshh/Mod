package com.kingofcurses.client;

import com.kingofcurses.entity.GojoEntity;
import com.kingofcurses.entity.MahoragaEntity;
import com.kingofcurses.entity.SukunaEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

import static com.kingofcurses.ability.FullFightDirector.*;

/** v1.0.22 client camera for the Full Fight Video: dozens of cuts, all framed on the real actors. */
public final class FullFightCinematic {
    private static boolean active;
    private static int tick, gojoId, sukunaId, mahoId = -1;
    private static Entity camera;
    private static Vec3 C = Vec3.ZERO, lastG = Vec3.ZERO, lastS = Vec3.ZERO, lastM = null;

    private FullFightCinematic() {}

    public static boolean active() { return active; }
    public static int tick() { return tick; }

    public static void start(int g, int s, BlockPos center) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        gojoId = g; sukunaId = s; mahoId = -1; tick = 0; lastM = null;
        C = new Vec3(center.getX() + 0.5, center.getY() + 1, center.getZ() + 0.5);
        lastG = C.add(-26, 0, 0); lastS = C.add(9, 0, 0);
        camera = EntityType.MARKER.create(mc.level);
        if (camera == null) return;
        active = true;
        ClientFx.stopLoading();
        place(C.add(40, 45, 40), C, true);
        mc.setCameraEntity(camera);
    }

    public static void mahoraga(int id) { mahoId = id; }
    public static void sync(int t) { if (active && Math.abs(t - tick) > 8) tick = t; }

    public static void stop() {
        active = false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.setCameraEntity(mc.player);
        camera = null;
    }

    public static void reset() { if (active) stop(); }

    private static void place(Vec3 pos, Vec3 look, boolean snap) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.player != null) {   // never inside a tower
            var hit = mc.level.clip(new net.minecraft.world.level.ClipContext(look, pos, net.minecraft.world.level.ClipContext.Block.VISUAL,
                    net.minecraft.world.level.ClipContext.Fluid.NONE, mc.player));
            if (hit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
                Vec3 back = pos.subtract(look);
                double len = back.length(), keep = Math.max(0.8, look.distanceTo(hit.getLocation()) - 0.4);
                if (len > 0.001) pos = look.add(back.scale(keep / len));
            }
        }
        Vec3 d = look.subtract(pos);
        float yaw = (float) (Mth.atan2(d.z, d.x) * Mth.RAD_TO_DEG) - 90f;
        float pitch = (float) -(Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * Mth.RAD_TO_DEG);
        if (snap) { camera.xo = pos.x; camera.yo = pos.y; camera.zo = pos.z; camera.yRotO = yaw; camera.xRotO = pitch; }
        else { camera.xo = camera.getX(); camera.yo = camera.getY(); camera.zo = camera.getZ(); camera.yRotO = camera.getYRot(); camera.xRotO = camera.getXRot(); }
        while (yaw - camera.yRotO > 180) yaw -= 360;
        while (yaw - camera.yRotO < -180) yaw += 360;
        camera.setPos(pos); camera.setYRot(yaw); camera.setXRot(pitch);
    }

    private static double ease(double t) { t = Mth.clamp(t, 0, 1); return t * t * (3 - 2 * t); }
    private static double k(int a, int b) { return ease((tick - a) / (double) (b - a)); }

    private static Entity find(int id, Class<? extends Entity> cls) {
        Minecraft mc = Minecraft.getInstance();
        Entity e = mc.level.getEntity(id);
        if (cls.isInstance(e)) return e;
        for (Entity c : mc.level.getEntitiesOfClass(cls, new net.minecraft.world.phys.AABB(C, C).inflate(90))) return c;
        return null;
    }

    /** The cut points: the camera snaps instead of gliding. */
    private static final int[] CUTS = {60, 130, 165, 215, 250, 270, 405, 460, 480, 520, 590, 610, 650, 680, 700, 780, 800, 870, 1000, 1030, 1065, 1140, 1160,
            1180, 1200, 1240, 1320, 1360, 1460, 1500, 1515, 1560, 1640, 1720, 1745, 1770, 1800, 1810, 1840, 1900, 2170, 2260, 2380};

    public static void clientTick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || camera == null) { stop(); return; }
        tick++;
        float pt = mc.getFrameTime();
        Entity ge = find(gojoId, GojoEntity.class), se = find(sukunaId, SukunaEntity.class);
        Entity me = mahoId >= 0 || tick >= T_MAHO ? find(mahoId, MahoragaEntity.class) : null;
        if (ge != null) lastG = ge.getPosition(pt);
        if (se != null) lastS = se.getPosition(pt);
        if (me != null) lastM = me.getPosition(pt);
        Vec3 G = lastG, S = lastS, M = lastM != null ? lastM : C.add(11, 0, 3), up = new Vec3(0, 1, 0);
        Vec3 gs = new Vec3(S.x - G.x, 0, S.z - G.z);
        Vec3 dGS = gs.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : gs.normalize(), dSG = dGS.reverse();
        Vec3 side = new Vec3(-dGS.z, 0, dGS.x);
        Vec3 mid = G.lerp(S, 0.5);
        boolean snap = false;
        for (int c : CUTS) if (c == tick) { snap = true; break; }
        int t = tick;
        if (t < 60) {                                                    // aerial: Shinjuku, empty, waiting
            double a = Math.toRadians(45 + t * 0.6);
            place(C.add(Math.cos(a) * 55, 42 - t * 0.15, Math.sin(a) * 55), C.add(0, 4, 0), t == 0);
        } else if (t < 130) {                                            // Gojo walks in
            place(G.add(dGS.scale(3.2)).add(side.scale(1.6)).add(up.scale(1.3)), G.add(0, 1.6, 0), snap);
        } else if (t < 165) {                                            // Sukuna
            place(S.add(dSG.scale(2.6)).add(side.scale(0.8)).add(up.scale(1.7)), S.add(0, 1.6, 0), snap);
        } else if (t < 215) {                                            // "Nah, I'd win."
            place(G.add(dGS.scale(2.2 - k(165, 215) * 0.6)).add(side.scale(-0.7)).add(up.scale(1.75)), G.add(0, 1.7, 0), snap);
        } else if (t < 250) {                                            // low wide two-shot
            place(mid.add(side.scale(10)).add(up.scale(0.4)), mid.add(0, 2, 0), snap);
        } else if (t < 270) {                                            // the dash
            place(mid.add(side.scale(12 - k(250, 266) * 6)).add(up.scale(1.8)), mid.add(0, 1.4, 0), snap);
        } else if (t < 405) {                                            // the exchange: orbit
            double a = (t - 270) * 0.055;
            place(mid.add(Math.cos(a) * 6.5, 2.2 + Math.sin(t * 0.07), Math.sin(a) * 6.5), mid.add(0, 1.3, 0), snap);
        } else if (t < 460) {                                            // Blue, over Gojo's shoulder
            place(G.subtract(dGS.scale(2.8)).add(side.scale(1.0)).add(up.scale(2.1)), S.add(0, 1.1, 0), snap);
        } else if (t < 480) {                                            // Red: he flies into the tower
            place(C.add(0, 4, -11), S.add(0, 1, 0), snap);
        } else if (t < 520) {                                            // the hole in the tower
            place(C.add(-2, 5, -9), S.add(0, 1, 0), snap);
        } else if (t < 590) {                                            // he walks out, laughing
            place(S.add(dSG.scale(3.6)).add(side.scale(0.6)).add(up.scale(1.4)), S.add(0, 1.6, 0), snap);
        } else if (t < 610) {                                            // Dismantle
            place(S.subtract(dSG.scale(3.2)).add(side.scale(1.2)).add(up.scale(2.4)), G.add(0, 1.4, 0), snap);
        } else if (t < 650) {                                            // ...stopped by Infinity, the towers behind are cut
            place(G.add(dGS.scale(2.0)).add(side.scale(-1.6)).add(up.scale(1.6)), G.add(dSG.scale(10)).add(0, 6, 0), snap);
        } else if (t < 680) {                                            // Domain Expansion: hand signs
            place(G.add(dGS.scale(1.8)).add(up.scale(1.75)), G.add(0, 1.7, 0), snap);
        } else if (t < 700) {
            place(S.add(dSG.scale(1.8)).add(up.scale(1.75)), S.add(0, 1.7, 0), snap);
        } else if (t < 780) {                                            // the domain clash, wide
            double a = (t - 700) * 0.02;
            place(mid.add(side.scale(Math.cos(a) * 18)).add(dGS.scale(Math.sin(a) * 18)).add(up.scale(10)), mid.add(0, 2, 0), snap);
        } else if (t < 800) {                                            // the Void shatters
            place(G.add(dGS.scale(1.6)).add(side.scale(0.6)).add(up.scale(1.7)), G.add(0, 1.7, 0), snap);
        } else if (t < 870) {
            double a = (t - 800) * 0.025 + 1.6;
            place(mid.add(side.scale(Math.cos(a) * 16)).add(dGS.scale(Math.sin(a) * 16)).add(up.scale(8)), mid.add(0, 2, 0), snap);
        } else if (t < 1000) {                                           // inside the Void: the beating, Black Flash
            place(mid.add(side.scale(3.4)).add(up.scale(1.6)), mid.add(0, 1.4, 0), snap);
        } else if (t < 1030) {                                           // "With this treasure, I summon..."
            place(S.add(dSG.scale(3.0)).add(up.scale(0.3)), S.add(0, 2.2, 0), snap);
        } else if (t < 1065) {                                           // Mahoraga rises
            Vec3 dm = new Vec3(G.x - M.x, 0, G.z - M.z).normalize();
            place(M.add(dm.scale(10)).add(up.scale(0.5)), M.add(0, 3.5 + k(1030, 1065) * 1.5, 0), snap);
        } else if (t < 1140) {                                           // Mahoraga against Gojo
            Vec3 mm = G.lerp(M, 0.5);
            place(mm.add(side.scale(9)).add(up.scale(3)), mm.add(0, 2.2, 0), snap);
        } else if (t < 1160) {                                           // the wheel turns
            Vec3 dm = new Vec3(G.x - M.x, 0, G.z - M.z).normalize();
            place(M.add(dm.scale(4.5)).add(up.scale(6.2)), M.add(0, 6.6, 0), snap);
        } else if (t < 1180) {
            Vec3 mm = G.lerp(M, 0.5);
            place(mm.add(side.scale(-6)).add(up.scale(2)), mm.add(0, 2, 0), snap);
        } else if (t < 1200) {                                           // through Infinity, into a tower
            place(C.add(-3, 4, 7), G.add(0, 1, 0), snap);
        } else if (t < 1240) {
            place(C.add(-1, 6, 4), G.add(0, 1, 0), snap);
        } else if (t < 1320) {                                           // Gojo walks out, smiling
            place(G.add(dGS.scale(3.0)).add(side.scale(0.5)).add(up.scale(1.7)), G.add(0, 1.7, 0), snap);
        } else if (t < 1360) {                                           // he rises over Shinjuku
            Vec3 g0 = new Vec3(G.x, C.y, G.z);
            place(g0.add(dGS.scale(6)).add(up.scale(0.5)), G.add(0, 1.6, 0), snap);
        } else if (t < 1460) {                                           // the incantation
            double a = (t - 1360) * 0.035;
            place(G.add(Math.cos(a) * 3.6, 1.7, Math.sin(a) * 3.6), G.add(0, 1.6, 0), snap);
        } else if (t < 1500) {                                           // over the shoulder, Purple ready
            place(G.subtract(dGS.scale(3.0)).add(side.scale(0.9)).add(up.scale(1.0)), S.add(0, 1, 0), snap);
        } else if (t < 1515) {                                           // follow the Purple
            Vec3 b = C.add(11, 1, 2), a = G.add(0, 1.5, 0);
            Vec3 p = a.lerp(b, Mth.clamp((t - 1500) / 12.0, 0, 1));
            Vec3 dir = b.subtract(a).normalize();
            place(p.subtract(dir.scale(5)).add(up.scale(2)), b, snap);
        } else if (t < 1560) {                                           // the crater, from far away
            place(C.add(-18, 16, -22), C.add(11, 0, 3), snap);
        } else if (t < 1640) {                                           // Gojo comes down
            place(G.add(dGS.scale(3.5)).add(up.scale(1.2)), G.add(0, 1.6, 0), snap);
        } else if (t < 1720) {                                           // Sukuna gets up
            place(S.add(dSG.scale(3.0)).add(side.scale(-0.6)).add(up.scale(1.6)), S.add(0, 1.6, 0), snap);
        } else if (t < 1745) {                                           // "Dragon scale."
            place(S.add(dSG.scale(1.5)).add(up.scale(1.55)), S.add(0, 1.5, 0), snap);
        } else if (t < 1770) {                                           // Gojo, smiling
            place(G.add(dGS.scale(1.6)).add(up.scale(1.75)), G.add(0, 1.72, 0), snap);
        } else if (t < 1800) {                                           // "Twin meteors."
            place(S.add(dSG.scale(1.3)).add(side.scale(0.3)).add(up.scale(1.65)), S.add(0, 1.6, 0), snap);
        } else if (t < 1810) {                                           // silence
            place(mid.add(side.scale(11)).add(up.scale(2)), mid.add(0, 1.6, 0), snap);
        } else if (t < 1840) {                                           // the World-Cutting Slash
            place(mid.add(side.scale(11)).add(up.scale(2)), mid.add(0, 1.6, 0), snap);
        } else if (t < 1900) {                                           // he falls
            place(G.add(side.scale(3.2 - k(1840, 1900))).add(dGS.scale(1.2)).add(up.scale(1.0)), G.add(0, 0.6, 0), snap);
        } else if (t < 2170) {                                           // the airport (white)
            place(C.add(0, 60, 0), C.add(30, 90, 10), snap);
        } else if (t < 2260) {                                           // Sukuna over the body
            place(G.add(side.scale(5.5)).add(up.scale(1.0)), mid.add(0, 1.0, 0), snap);
        } else if (t < 2380) {
            place(S.add(dSG.scale(2.6)).add(up.scale(0.6)), S.add(0, 1.8, 0), snap);
        } else {                                                         // pull back over the ruins
            double kk = k(2380, 2500);
            place(C.add(-8, 6 + kk * 40, 18 + kk * 30), C.add(-6, 0, 0), snap);
        }
        if (mc.getCameraEntity() != camera) mc.setCameraEntity(camera);
        if (tick > T_END + 40) stop();
    }

    public static String subtitle() {
        int t = tick;
        if (t >= 120 && t < 165) return "fullfight.kingofcurses.s1";
        if (t >= 168 && t < 214) return "fullfight.kingofcurses.g1";
        if (t >= 540 && t < 588) return "fullfight.kingofcurses.s2";
        if (t >= 655 && t < 689) return "fullfight.kingofcurses.g2";
        if (t >= 690 && t < 722) return "fullfight.kingofcurses.s3";
        if (t >= 785 && t < 832) return "fullfight.kingofcurses.g3";
        if (t >= 1000 && t < 1030) return "fullfight.kingofcurses.s4";
        if (t >= 1030 && t < 1066) return "fullfight.kingofcurses.s5";
        if (t >= 1250 && t < 1310) return "fullfight.kingofcurses.g4";
        if (t >= 1360 && t < 1400) return "fullfight.kingofcurses.g5";
        if (t >= 1400 && t < 1440) return "fullfight.kingofcurses.g6";
        if (t >= 1440 && t < 1492) return "fullfight.kingofcurses.g7";
        if (t >= 1595 && t < 1640) return "fullfight.kingofcurses.g8";
        if (t >= 1650 && t < 1716) return "fullfight.kingofcurses.s6";
        if (t >= 1722 && t < 1745) return "fullfight.kingofcurses.s7";
        if (t >= 1747 && t < 1770) return "fullfight.kingofcurses.s8";
        if (t >= 1772 && t < 1800) return "fullfight.kingofcurses.s9";
        if (t >= 1920 && t < 1992) return "fullfight.kingofcurses.a1";
        if (t >= 1995 && t < 2072) return "fullfight.kingofcurses.a2";
        if (t >= 2075 && t < 2152) return "fullfight.kingofcurses.a3";
        if (t >= 2215 && t < 2292) return "fullfight.kingofcurses.s10";
        if (t >= 2295 && t < 2378) return "fullfight.kingofcurses.s11";
        return null;
    }

    /** Big centre titles: {key, colour} or null. */
    public static String[] title() {
        int t = tick;
        if (t >= 14 && t < 112) return new String[]{"fullfight.kingofcurses.title", "F2E6FF"};
        if (t >= 660 && t < 690) return new String[]{"fullfight.kingofcurses.t_void", "7FD4FF"};
        if (t >= 692 && t < 724) return new String[]{"fullfight.kingofcurses.t_shrine", "E0102A"};
        if (t >= 958 && t < 990) return new String[]{"fullfight.kingofcurses.t_blackflash", "FF2A40"};
        if (t >= 1034 && t < 1068) return new String[]{"fullfight.kingofcurses.t_mahoraga", "E8D8B0"};
        if (t >= 1478 && t < 1512) return new String[]{"fullfight.kingofcurses.t_purple", "B57CFF"};
        if (t >= 1812 && t < 1845) return new String[]{"fullfight.kingofcurses.t_wcs", "FFFFFF"};
        if (t >= 2392 && t < 2490) return new String[]{"fullfight.kingofcurses.t_end", "E0102A"};
        return null;
    }

    public static float titleAlpha() {
        int t = tick;
        int[][] r = {{14, 112}, {660, 690}, {692, 724}, {958, 990}, {1034, 1068}, {1478, 1512}, {1812, 1845}, {2392, 2490}};
        for (int[] p : r) if (t >= p[0] && t < p[1]) return Mth.clamp(Math.min((t - p[0]) / 8f, (p[1] - t) / 8f), 0, 1);
        return 0;
    }

    /** Black over everything (fades). */
    public static float black() {
        int t = tick;
        if (t < 12) return 1f - t / 12f;
        if (t >= T_END - 20) return Mth.clamp((t - (T_END - 20)) / 16f, 0, 1);
        return 0f;
    }

    /** White over everything: the afterlife (airport). */
    public static float white() {
        int t = tick;
        if (t >= 1880 && t < T_AIRPORT) return (t - 1880) / 20f;
        if (t >= T_AIRPORT && t < 2150) return 1f;
        if (t >= 2150 && t < T_BACK) return 1f - (t - 2150) / 20f;
        return 0f;
    }

    /** -1 none, else 0..1 colour mix between the Void (blue) and the Shrine (red). */
    public static float domainTint() {
        int t = tick;
        if (t < T_CLASH || t >= T_CAUGHT + 20) return -1f;
        return 0.5f + 0.5f * Mth.sin(t * 0.25f);
    }

    /** 0..1 the World-Cutting Slash line across the screen. */
    public static float worldSlash() {
        int t = tick;
        return t >= T_CUT && t < T_CUT + 12 ? (t - T_CUT) / 12f : -1f;
    }
}
