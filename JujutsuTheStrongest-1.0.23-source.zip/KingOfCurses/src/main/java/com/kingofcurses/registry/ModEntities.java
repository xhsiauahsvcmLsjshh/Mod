package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.entity.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, KingOfCurses.MODID);

    public static final RegistryObject<EntityType<SukunaEntity>> RYOMEN_SUKUNA = ENTITIES.register("ryomen_sukuna",
            () -> EntityType.Builder.<SukunaEntity>of((t, l) -> new SukunaEntity(t, l, false), MobCategory.MONSTER).sized(0.6f, 1.95f).fireImmune().clientTrackingRange(10).build(id("ryomen_sukuna")));
    public static final RegistryObject<EntityType<SukunaEntity>> SUKUNA_TRUE_FORM = ENTITIES.register("sukuna_true_form",
            () -> EntityType.Builder.<SukunaEntity>of((t, l) -> new SukunaEntity(t, l, true), MobCategory.MONSTER).sized(0.9f, 2.6f).fireImmune().clientTrackingRange(10).build(id("sukuna_true_form")));
    public static final RegistryObject<EntityType<GojoEntity>> GOJO_SATORU = ENTITIES.register("gojo_satoru",
            () -> EntityType.Builder.<GojoEntity>of(GojoEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(10).build(id("gojo_satoru")));
    public static final RegistryObject<EntityType<CursedSpiritEntity>> FLY_HEAD = ENTITIES.register("fly_head",
            () -> EntityType.Builder.<CursedSpiritEntity>of((t, l) -> new CursedSpiritEntity(t, l, CurseKind.FLY_HEAD), MobCategory.MONSTER).sized(0.7f, 0.7f).clientTrackingRange(10).build(id("fly_head")));
    public static final RegistryObject<EntityType<CursedSpiritEntity>> CRAWLING_EYE = ENTITIES.register("crawling_eye",
            () -> EntityType.Builder.<CursedSpiritEntity>of((t, l) -> new CursedSpiritEntity(t, l, CurseKind.CRAWLING_EYE), MobCategory.MONSTER).sized(0.9f, 0.6f).clientTrackingRange(10).build(id("crawling_eye")));
    public static final RegistryObject<EntityType<CursedSpiritEntity>> ROPPONGI_CURSE = ENTITIES.register("roppongi_curse",
            () -> EntityType.Builder.<CursedSpiritEntity>of((t, l) -> new CursedSpiritEntity(t, l, CurseKind.ROPPONGI_CURSE), MobCategory.MONSTER).sized(1.0f, 1.8f).clientTrackingRange(10).build(id("roppongi_curse")));
    public static final RegistryObject<EntityType<CursedSpiritEntity>> LANTERN_HAG = ENTITIES.register("lantern_hag",
            () -> EntityType.Builder.<CursedSpiritEntity>of((t, l) -> new CursedSpiritEntity(t, l, CurseKind.LANTERN_HAG), MobCategory.MONSTER).sized(0.7f, 2.4f).fireImmune().clientTrackingRange(10).build(id("lantern_hag")));
    public static final RegistryObject<EntityType<CursedSpiritEntity>> HANGED_BRIDE = ENTITIES.register("hanged_bride",
            () -> EntityType.Builder.<CursedSpiritEntity>of((t, l) -> new CursedSpiritEntity(t, l, CurseKind.HANGED_BRIDE), MobCategory.MONSTER).sized(0.7f, 2.2f).clientTrackingRange(10).build(id("hanged_bride")));
    public static final RegistryObject<EntityType<CursedSpiritEntity>> BONE_CENTIPEDE = ENTITIES.register("bone_centipede",
            () -> EntityType.Builder.<CursedSpiritEntity>of((t, l) -> new CursedSpiritEntity(t, l, CurseKind.BONE_CENTIPEDE), MobCategory.MONSTER).sized(1.4f, 0.9f).clientTrackingRange(10).build(id("bone_centipede")));
    public static final RegistryObject<EntityType<SpecialGradeCurseEntity>> FINGER_BEARER = ENTITIES.register("finger_bearer",
            () -> EntityType.Builder.<SpecialGradeCurseEntity>of((t, l) -> new SpecialGradeCurseEntity(t, l, CurseKind.FINGER_BEARER), MobCategory.MONSTER).sized(1.6f, 2.2f).clientTrackingRange(10).build(id("finger_bearer")));
    public static final RegistryObject<EntityType<SpecialGradeCurseEntity>> SMALLPOX_DEITY = ENTITIES.register("smallpox_deity",
            () -> EntityType.Builder.<SpecialGradeCurseEntity>of((t, l) -> new SpecialGradeCurseEntity(t, l, CurseKind.SMALLPOX_DEITY), MobCategory.MONSTER).sized(1.8f, 3.0f).clientTrackingRange(10).build(id("smallpox_deity")));
    public static final RegistryObject<EntityType<SpecialGradeCurseEntity>> CURSED_WOMB = ENTITIES.register("cursed_womb",
            () -> EntityType.Builder.<SpecialGradeCurseEntity>of((t, l) -> new SpecialGradeCurseEntity(t, l, CurseKind.CURSED_WOMB), MobCategory.MONSTER).sized(1.4f, 1.6f).clientTrackingRange(10).build(id("cursed_womb")));
    public static final RegistryObject<EntityType<SpecialGradeCurseEntity>> SHRINE_WARDEN = ENTITIES.register("shrine_warden",
            () -> EntityType.Builder.<SpecialGradeCurseEntity>of((t, l) -> new SpecialGradeCurseEntity(t, l, CurseKind.SHRINE_WARDEN), MobCategory.MONSTER).sized(1.4f, 3.2f).fireImmune().clientTrackingRange(10).build(id("shrine_warden")));
    public static final RegistryObject<EntityType<SorcererEntity>> JUJUTSU_SORCERER = ENTITIES.register("jujutsu_sorcerer",
            () -> EntityType.Builder.<SorcererEntity>of((t, l) -> new SorcererEntity(t, l, SorcererEntity.Kind.SORCERER), MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(10).build(id("jujutsu_sorcerer")));
    public static final RegistryObject<EntityType<SorcererEntity>> SORCERER_ELITE = ENTITIES.register("sorcerer_elite",
            () -> EntityType.Builder.<SorcererEntity>of((t, l) -> new SorcererEntity(t, l, SorcererEntity.Kind.ELITE), MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(10).build(id("sorcerer_elite")));
    public static final RegistryObject<EntityType<SorcererEntity>> JUJUTSU_STUDENT = ENTITIES.register("jujutsu_student",
            () -> EntityType.Builder.<SorcererEntity>of((t, l) -> new SorcererEntity(t, l, SorcererEntity.Kind.STUDENT), MobCategory.CREATURE).sized(0.6f, 1.85f).clientTrackingRange(10).build(id("jujutsu_student")));
    public static final RegistryObject<EntityType<GojoKenjakuEntity>> GOJO_KENJAKU = ENTITIES.register("gojo_kenjaku",
            () -> EntityType.Builder.<GojoKenjakuEntity>of(GojoKenjakuEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).fireImmune().clientTrackingRange(10).build(id("gojo_kenjaku")));
    public static final RegistryObject<EntityType<NamedSorcererEntity>> YUTA_OKKOTSU = ENTITIES.register("yuta_okkotsu",
            () -> EntityType.Builder.<NamedSorcererEntity>of((t, l) -> new NamedSorcererEntity(t, l, NamedSorcererEntity.Kind.YUTA_OKKOTSU), MobCategory.CREATURE).sized(0.6f, 1.9f).clientTrackingRange(10).build(id("yuta_okkotsu")));
    public static final RegistryObject<EntityType<NamedSorcererEntity>> KINJI_HAKARI = ENTITIES.register("kinji_hakari",
            () -> EntityType.Builder.<NamedSorcererEntity>of((t, l) -> new NamedSorcererEntity(t, l, NamedSorcererEntity.Kind.KINJI_HAKARI), MobCategory.CREATURE).sized(0.6f, 1.95f).clientTrackingRange(10).build(id("kinji_hakari")));
    public static final RegistryObject<EntityType<NamedSorcererEntity>> MAKI_ZENIN = ENTITIES.register("maki_zenin",
            () -> EntityType.Builder.<NamedSorcererEntity>of((t, l) -> new NamedSorcererEntity(t, l, NamedSorcererEntity.Kind.MAKI_ZENIN), MobCategory.CREATURE).sized(0.6f, 1.85f).clientTrackingRange(10).build(id("maki_zenin")));
    public static final RegistryObject<EntityType<NamedSorcererEntity>> MEGUMI_FUSHIGURO = ENTITIES.register("megumi_fushiguro",
            () -> EntityType.Builder.<NamedSorcererEntity>of((t, l) -> new NamedSorcererEntity(t, l, NamedSorcererEntity.Kind.MEGUMI_FUSHIGURO), MobCategory.CREATURE).sized(0.6f, 1.85f).clientTrackingRange(10).build(id("megumi_fushiguro")));
    public static final RegistryObject<EntityType<NamedSorcererEntity>> AOI_TODO = ENTITIES.register("aoi_todo",
            () -> EntityType.Builder.<NamedSorcererEntity>of((t, l) -> new NamedSorcererEntity(t, l, NamedSorcererEntity.Kind.AOI_TODO), MobCategory.CREATURE).sized(0.75f, 2.3f).clientTrackingRange(10).build(id("aoi_todo")));
    public static final RegistryObject<EntityType<NamedSorcererEntity>> KENTO_NANAMI = ENTITIES.register("kento_nanami",
            () -> EntityType.Builder.<NamedSorcererEntity>of((t, l) -> new NamedSorcererEntity(t, l, NamedSorcererEntity.Kind.KENTO_NANAMI), MobCategory.CREATURE).sized(0.6f, 1.95f).clientTrackingRange(10).build(id("kento_nanami")));
    public static final RegistryObject<EntityType<SealingMasterEntity>> SEALING_MASTER = ENTITIES.register("sealing_master",
            () -> EntityType.Builder.<SealingMasterEntity>of(SealingMasterEntity::new, MobCategory.MONSTER).sized(0.7f, 2.1f).clientTrackingRange(10).build(id("sealing_master")));
    public static final RegistryObject<EntityType<MalevolentShrineEntity>> MALEVOLENT_SHRINE = ENTITIES.register("malevolent_shrine",
            () -> EntityType.Builder.<MalevolentShrineEntity>of(MalevolentShrineEntity::new, MobCategory.MISC).sized(6.0f, 7.0f).fireImmune().clientTrackingRange(12).build(id("malevolent_shrine")));
    public static final RegistryObject<EntityType<DismantleSlashEntity>> DISMANTLE_SLASH = ENTITIES.register("dismantle_slash",
            () -> EntityType.Builder.<DismantleSlashEntity>of(DismantleSlashEntity::new, MobCategory.MISC).sized(0.9f, 0.5f).clientTrackingRange(4).updateInterval(2).build(id("dismantle_slash")));
    public static final RegistryObject<EntityType<FugaArrowEntity>> FUGA_ARROW = ENTITIES.register("fuga_arrow",
            () -> EntityType.Builder.<FugaArrowEntity>of(FugaArrowEntity::new, MobCategory.MISC).sized(0.5f, 0.5f).fireImmune().clientTrackingRange(4).updateInterval(2).build(id("fuga_arrow")));
    public static final RegistryObject<EntityType<SlicedCorpseEntity>> SLICED_CORPSE = ENTITIES.register("sliced_corpse",
            () -> EntityType.Builder.<SlicedCorpseEntity>of(SlicedCorpseEntity::new, MobCategory.MISC).sized(0.6f, 0.6f).clientTrackingRange(8).updateInterval(20).build(id("sliced_corpse")));
    public static final RegistryObject<EntityType<TojiEntity>> TOJI_FUSHIGURO = ENTITIES.register("toji_fushiguro",
            () -> EntityType.Builder.<TojiEntity>of(TojiEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(10).build(id("toji_fushiguro")));
    public static final RegistryObject<EntityType<GetoEntity>> SUGURU_GETO = ENTITIES.register("suguru_geto",
            () -> EntityType.Builder.<GetoEntity>of(GetoEntity::new, MobCategory.CREATURE).sized(0.6f, 1.95f).clientTrackingRange(10).build(id("suguru_geto")));
    public static final RegistryObject<EntityType<CurseUserEntity>> CURSE_USER = ENTITIES.register("curse_user",
            () -> EntityType.Builder.<CurseUserEntity>of(CurseUserEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(10).build(id("curse_user")));
    public static final RegistryObject<EntityType<HeianSukunaEntity>> HEIAN_SUKUNA = ENTITIES.register("heian_sukuna",
            () -> EntityType.Builder.<HeianSukunaEntity>of(HeianSukunaEntity::new, MobCategory.MONSTER).sized(1.6f, 4.2f).fireImmune().clientTrackingRange(10).build(id("heian_sukuna")));
    public static final RegistryObject<EntityType<MahoragaEntity>> MAHORAGA = ENTITIES.register("mahoraga",
            () -> EntityType.Builder.<MahoragaEntity>of(MahoragaEntity::new, MobCategory.MONSTER).sized(1.3f, 3.8f).fireImmune().clientTrackingRange(10).build(id("mahoraga")));
    public static final RegistryObject<EntityType<SukunaArmEntity>> SUKUNA_ARM_THROWN = ENTITIES.register("sukuna_arm_thrown",
            () -> EntityType.Builder.<SukunaArmEntity>of(SukunaArmEntity::new, MobCategory.MISC).sized(0.8f, 0.8f).fireImmune().clientTrackingRange(6).updateInterval(1).build(id("sukuna_arm_thrown")));

    private ModEntities() {}

    private static String id(String path) {
        return new ResourceLocation(KingOfCurses.MODID, path).toString();
    }

    /** Mod-bus listener. */
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(RYOMEN_SUKUNA.get(), SukunaEntity.createAttributes(500, 12, 0.32, 10, 0.9).build());
        event.put(SUKUNA_TRUE_FORM.get(), SukunaEntity.createAttributes(800, 18, 0.34, 16, 0.9).build());
        event.put(GOJO_SATORU.get(), GojoEntity.createAttributes(500, 10, 0.32, 10, 0.9).build());
        event.put(FLY_HEAD.get(), CursedSpiritEntity.createAttributes(8, 2, 0.3, 0, 0.0).build());
        event.put(CRAWLING_EYE.get(), CursedSpiritEntity.createAttributes(10, 3, 0.28, 0, 0.0).build());
        event.put(ROPPONGI_CURSE.get(), CursedSpiritEntity.createAttributes(30, 5, 0.26, 2, 0.0).build());
        event.put(LANTERN_HAG.get(), CursedSpiritEntity.createAttributes(28, 4, 0.24, 2, 0.0).build());
        event.put(HANGED_BRIDE.get(), CursedSpiritEntity.createAttributes(45, 6, 0.25, 4, 0.0).build());
        event.put(BONE_CENTIPEDE.get(), CursedSpiritEntity.createAttributes(80, 8, 0.33, 6, 0.0).build());
        event.put(FINGER_BEARER.get(), CursedSpiritEntity.createAttributes(160, 10, 0.27, 8, 0.6).build());
        event.put(SMALLPOX_DEITY.get(), CursedSpiritEntity.createAttributes(220, 12, 0.22, 10, 0.6).build());
        event.put(CURSED_WOMB.get(), CursedSpiritEntity.createAttributes(200, 9, 0.2, 6, 0.6).build());
        event.put(SHRINE_WARDEN.get(), CursedSpiritEntity.createAttributes(300, 15, 0.26, 14, 0.9).build());
        event.put(JUJUTSU_SORCERER.get(), SorcererEntity.createAttributes(40, 6, 0.3, 4, 0.0).build());
        event.put(SORCERER_ELITE.get(), SorcererEntity.createAttributes(90, 9, 0.32, 8, 0.0).build());
        event.put(JUJUTSU_STUDENT.get(), SorcererEntity.createAttributes(28, 4, 0.3, 2, 0.0).build());
        event.put(GOJO_KENJAKU.get(), GojoKenjakuEntity.createAttributes(900, 14, 0.34, 14, 0.9).build());
        event.put(YUTA_OKKOTSU.get(), NamedSorcererEntity.createAttributes(170, 9, 0.33, 8, 0.6).build());
        event.put(KINJI_HAKARI.get(), NamedSorcererEntity.createAttributes(160, 9, 0.32, 8, 0.6).build());
        event.put(MAKI_ZENIN.get(), NamedSorcererEntity.createAttributes(130, 10, 0.38, 10, 0.6).build());
        event.put(MEGUMI_FUSHIGURO.get(), NamedSorcererEntity.createAttributes(120, 7, 0.31, 6, 0.6).build());
        event.put(AOI_TODO.get(), NamedSorcererEntity.createAttributes(180, 12, 0.31, 10, 0.6).build());
        event.put(KENTO_NANAMI.get(), NamedSorcererEntity.createAttributes(150, 10, 0.3, 10, 0.6).build());
        event.put(SEALING_MASTER.get(), SorcererEntity.createAttributes(450, 14, 0.3, 12, 0.9).build());
        event.put(TOJI_FUSHIGURO.get(), TojiEntity.createAttributes(320, 14, 0.36, 8, 0.9).build());
        event.put(SUGURU_GETO.get(), GetoEntity.createAttributes(300, 10, 0.3, 10, 0.9).build());
        event.put(CURSE_USER.get(), CurseUserEntity.createAttributes(60, 7, 0.3, 4, 0.0).build());
        event.put(HEIAN_SUKUNA.get(), HeianSukunaEntity.createAttributes(2000, 30, 0.0, 30, 0.9).build());
        event.put(MAHORAGA.get(), MahoragaEntity.createAttributes(900, 22, 0.3, 16, 0.9).build());
    }

    /** Mod-bus listener. */
    public static void registerSpawnPlacements(SpawnPlacementRegisterEvent event) {
        event.register(FLY_HEAD.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(CRAWLING_EYE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(ROPPONGI_CURSE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(LANTERN_HAG.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(HANGED_BRIDE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(BONE_CENTIPEDE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(CURSE_USER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
    }
}
