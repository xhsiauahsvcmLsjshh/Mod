import json, os
from spec import *
from texts import T, ADV
import structures
R=None
def W(path,obj):
    p=f"{R}/{path}"; os.makedirs(os.path.dirname(p),exist_ok=True)
    json.dump(obj,open(p,"w",encoding="utf-8"),indent=2,ensure_ascii=False)
def ns(x): return x if ":" in x else f"{MODID}:{x}"
def B(x): return f"{MODID}:block/{x}"
IT_FIX=[(" è già"," è già"),("Il primo dito e sepolto","Il primo dito è sepolto"),("e venuto","è venuto"),("e caduto","è caduto"),("Sukuna e sigillato","Sukuna è sigillato"),
 ("destino è già","destino è già"),("puo","può"),("piu","più"),("Divinita","Divinità"),("E tornato","È tornato"),("e tua, ed e definitiva","è tua, ed è definitiva"),("Gia consumato","Già consumato"),("gia","già")]
def itfix(s):
    for a,b in IT_FIX: s=s.replace(a,b)
    return s

def blockstates_models():
    A=f"assets/{MODID}"
    for bid,kind,props,tool,en,it,ex in BLOCKS:
        if kind in("cube","ore"):
            W(f"{A}/blockstates/{bid}.json",{"variants":{"":{"model":B(bid)}}})
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/cube_all","textures":{"all":B(bid)}})
        elif kind=="pillar":
            W(f"{A}/blockstates/{bid}.json",{"variants":{"axis=y":{"model":B(bid)},"axis=x":{"model":B(bid),"x":90,"y":90},"axis=z":{"model":B(bid),"x":90}}})
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/cube_column","textures":{"end":B(bid+"_top"),"side":B(bid)}})
        elif kind=="stairs":
            tex=B(props); m={k:f"{MODID}:block/{bid}{s}" for k,s in (("s",""),("i","_inner"),("o","_outer"))}
            for suf,par in (("","stairs"),("_inner","inner_stairs"),("_outer","outer_stairs")):
                W(f"{A}/models/block/{bid}{suf}.json",{"parent":f"minecraft:block/{par}","textures":{"bottom":tex,"top":tex,"side":tex}})
            v={}
            yrot={"east":0,"south":90,"west":180,"north":270}
            for f in ("east","north","south","west"):
                for h in ("bottom","top"):
                    for sh in ("inner_left","inner_right","outer_left","outer_right","straight"):
                        model=m["s"] if sh=="straight" else (m["i"] if sh.startswith("inner") else m["o"])
                        y=yrot[f]
                        if h=="bottom":
                            if sh in("inner_left","outer_left"): y=(y-90)%360
                        else:
                            if sh in("inner_right","outer_right"): y=(y+90)%360
                        d={"model":model}
                        if h=="top": d["x"]=180
                        if y: d["y"]=y
                        if y or h=="top": d["uvlock"]=True
                        v[f"facing={f},half={h},shape={sh}"]=d
            W(f"{A}/blockstates/{bid}.json",{"variants":v})
        elif kind=="slab":
            tex=B(props)
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/slab","textures":{"bottom":tex,"top":tex,"side":tex}})
            W(f"{A}/models/block/{bid}_top.json",{"parent":"minecraft:block/slab_top","textures":{"bottom":tex,"top":tex,"side":tex}})
            W(f"{A}/blockstates/{bid}.json",{"variants":{"type=bottom":{"model":B(bid)},"type=top":{"model":B(bid+"_top")},"type=double":{"model":B(props)}}})
        elif kind=="wall":
            tex=B(props)
            W(f"{A}/models/block/{bid}_post.json",{"parent":"minecraft:block/template_wall_post","textures":{"wall":tex}})
            W(f"{A}/models/block/{bid}_side.json",{"parent":"minecraft:block/template_wall_side","textures":{"wall":tex}})
            W(f"{A}/models/block/{bid}_side_tall.json",{"parent":"minecraft:block/template_wall_side_tall","textures":{"wall":tex}})
            W(f"{A}/models/block/{bid}_inventory.json",{"parent":"minecraft:block/wall_inventory","textures":{"wall":tex}})
            mp=[{"when":{"up":"true"},"apply":{"model":B(bid+"_post")}}]
            for d,y in (("north",0),("east",90),("south",180),("west",270)):
                for h,suf in (("low","_side"),("tall","_side_tall")):
                    a={"model":B(bid+suf),"uvlock":True}
                    if y: a["y"]=y
                    mp.append({"when":{d:h},"apply":a})
            W(f"{A}/blockstates/{bid}.json",{"multipart":mp})
        elif kind=="fence":
            tex=B(props)
            W(f"{A}/models/block/{bid}_post.json",{"parent":"minecraft:block/fence_post","textures":{"texture":tex}})
            W(f"{A}/models/block/{bid}_side.json",{"parent":"minecraft:block/fence_side","textures":{"texture":tex}})
            W(f"{A}/models/block/{bid}_inventory.json",{"parent":"minecraft:block/fence_inventory","textures":{"texture":tex}})
            mp=[{"apply":{"model":B(bid+"_post")}}]
            for d,y in (("north",0),("east",90),("south",180),("west",270)):
                a={"model":B(bid+"_side"),"uvlock":True}
                if y: a["y"]=y
                mp.append({"when":{d:"true"},"apply":a})
            W(f"{A}/blockstates/{bid}.json",{"multipart":mp})
        elif kind=="fence_gate":
            tex=B(props)
            for suf,par in (("","template_fence_gate"),("_open","template_fence_gate_open"),("_wall","template_fence_gate_wall"),("_wall_open","template_fence_gate_wall_open")):
                W(f"{A}/models/block/{bid}{suf}.json",{"parent":f"minecraft:block/{par}","textures":{"texture":tex}})
            v={}
            for f,y in (("south",0),("west",90),("north",180),("east",270)):
                for iw in ("false","true"):
                    for op in ("false","true"):
                        suf=("_wall" if iw=="true" else "")+("_open" if op=="true" else "")
                        d={"model":B(bid+suf),"uvlock":True}
                        if y: d["y"]=y
                        v[f"facing={f},in_wall={iw},open={op}"]=d
            W(f"{A}/blockstates/{bid}.json",{"variants":v})
        elif kind=="leaves":
            W(f"{A}/blockstates/{bid}.json",{"variants":{"":{"model":B(bid)}}})
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/leaves","textures":{"all":B(bid)},"render_type":"minecraft:cutout_mipped"})
        elif kind=="lantern":
            W(f"{A}/blockstates/{bid}.json",{"variants":{"":{"model":B(bid)}}})
            t=B(bid); dk=B("black_lacquer_planks")
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/block","render_type":"minecraft:cutout","textures":{"particle":t,"paper":t,"wood":dk},
              "elements":[
               {"from":[4,0,4],"to":[12,1,12],"faces":{d:{"texture":"#wood"} for d in("north","south","east","west","up","down")}},
               {"from":[4.5,1,4.5],"to":[11.5,11,11.5],"faces":{d:{"texture":"#paper","uv":[1,1,15,15]} for d in("north","south","east","west")}|{"up":{"texture":"#wood"},"down":{"texture":"#wood"}}},
               {"from":[3.5,11,3.5],"to":[12.5,13,12.5],"faces":{d:{"texture":"#wood"} for d in("north","south","east","west","up","down")}},
               {"from":[7,13,7],"to":[9,16,9],"faces":{d:{"texture":"#wood"} for d in("north","south","east","west","up","down")}}]})
        elif kind=="reliquary":
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/orientable","textures":{"top":B("reliquary_top"),"front":B("reliquary_front"),"side":B("reliquary_side")}})
            W(f"{A}/blockstates/{bid}.json",{"variants":{f"facing={f}":({"model":B(bid),"y":y} if y else {"model":B(bid)}) for f,y in (("north",0),("east",90),("south",180),("west",270))}})
        elif kind=="hportal":
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/block","render_type":"minecraft:translucent","ambientocclusion":False,
               "textures":{"particle":B(bid),"portal":B(bid)},
               "elements":[{"from":[0,0,6],"to":[16,16,10],"shade":False,"faces":{"north":{"uv":[0,0,16,16],"texture":"#portal"},"south":{"uv":[0,0,16,16],"texture":"#portal"}}}]})
            W(f"{A}/blockstates/{bid}.json",{"variants":{"axis=x":{"model":B(bid)},"axis=z":{"model":B(bid),"y":90}}})
        elif kind=="csand":
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/cube_all","textures":{"all":B(bid)}})
            W(f"{A}/blockstates/{bid}.json",{"variants":{f"power={n}":{"model":B(bid)} for n in range(1,21)}})
        elif kind in("burial","trap","altar"):
            W(f"{A}/blockstates/{bid}.json",{"variants":{"":{"model":B(bid)}}})
            W(f"{A}/models/block/{bid}.json",{"parent":"minecraft:block/cube_bottom_top","textures":{"top":B(bid+"_top"),"side":B(bid),"bottom":B("cursed_soil" if kind=="burial" else "temple_stone")}})
        # item model
        if kind in("wall","fence"): parent=B(bid+"_inventory")
        else: parent=B(bid)
        W(f"{A}/models/item/{bid}.json",{"parent":parent})

def item_models():
    A=f"assets/{MODID}/models/item"
    gen=lambda i,par="minecraft:item/generated": W(f"{A}/{i}.json",{"parent":par,"textures":{"layer0":f"{MODID}:item/{i}"}})
    for fid,_,_ in FINGERS: gen(fid)
    for lid in LEGACY_FINGERS: W(f"{A}/{lid}.json",{"parent":"minecraft:item/generated","textures":{"layer0":f"{MODID}:item/sukuna_finger"}})
    for oid,_,_ in CURSED_OBJECTS: gen(oid)
    gen("ripped_finger")
    for m in MATERIALS: gen(m[0])
    for t in TALISMANS: gen(t[0])
    for v in VIALS: gen(v[0])
    gen("cursed_codex")
    for w in WEAPONS: gen(w[0],"minecraft:item/handheld")
    for t in TOOLS: gen(t[0],"minecraft:item/handheld")
    for s,_,_,_ in ARMOR_SETS:
        for p,_,_,_ in ARMOR_PIECES: gen(f"{s}_{p}")
    for lv in range(1,4): W(f"{A}/cursed_compass_{lv}.json",{"parent":"minecraft:item/generated","textures":{"layer0":f"{MODID}:item/cursed_compass_{lv}"}})
    W(f"{A}/sukuna_clue.json",{"parent":"minecraft:item/generated","textures":{"layer0":f"{MODID}:item/sukuna_clue"}})
    W(f"{A}/sukuna_arm.json",{"parent":"minecraft:item/handheld","textures":{"layer0":f"{MODID}:item/sukuna_arm"}})
    W(f"{A}/heian_seal.json",{"parent":"minecraft:item/generated","textures":{"layer0":f"{MODID}:item/heian_seal"}})
    W(f"{A}/remains_compass.json",{"parent":"minecraft:item/generated","textures":{"layer0":f"{MODID}:item/remains_compass"}})
    W(f"{A}/cursed_compass.json",{"parent":"minecraft:item/generated","textures":{"layer0":f"{MODID}:item/cursed_compass_0"},
      "overrides":[{"predicate":{f"{MODID}:resonance":v},"model":f"{MODID}:item/cursed_compass_{k+1}"} for k,v in enumerate((0.33,0.66,0.95))]})
    for e in ENTITIES:
        if e[1] in NO_EGG: continue
        W(f"{A}/{e[0]}_spawn_egg.json",{"parent":"minecraft:item/template_spawn_egg"})
    for t in TECHNIQUES: gen(t[0])
    gen("gojo_blindfold")

def lang():
    en={}; it={}
    def put(k,e,i): en[k]=e; it[k]=itfix(i)
    for bid,kind,props,tool,e,i,ex in BLOCKS: put(f"block.{MODID}.{bid}",e,i)
    for fid,e,i in FINGERS: put(f"item.{MODID}.{fid}",e,i)
    for lid in LEGACY_FINGERS: put(f"item.{MODID}.{lid}","Sukuna's Finger (old)","Dito di Sukuna (vecchio)")
    for oid,e,i in CURSED_OBJECTS: put(f"item.{MODID}.{oid}",e,i)
    for m,e,i in MATERIALS: put(f"item.{MODID}.{m}",e,i)
    for tid,_,e,i in TALISMANS: put(f"item.{MODID}.{tid}",e,i)
    for v in VIALS: put(f"item.{MODID}.{v[0]}",v[3],v[4])
    put(f"item.{MODID}.cursed_codex","Cursed Codex","Codice Maledetto"); put(f"item.{MODID}.cursed_compass","Cursed Compass","Bussola Maledetta"); put(f"item.{MODID}.remains_compass","Compass of Remains","Bussola dei Resti")
    put(f"item.{MODID}.sukuna_clue","Clue of Sukuna","Indizio su Sukuna")
    put(f"item.{MODID}.sukuna_arm","Arm of Heian Sukuna","Braccio di Sukuna dell'Era Heian"); put(f"item.{MODID}.heian_seal","Heian Gate Seal","Sigillo del Portale Heian")
    for w in WEAPONS: put(f"item.{MODID}.{w[0]}",w[5],w[6])
    for t in TOOLS: put(f"item.{MODID}.{t[0]}",t[2],t[3])
    for s,_,_,_ in ARMOR_SETS:
        for p,_,_,_ in ARMOR_PIECES:
            e,i=ARMOR_PIECE_NAMES[s][p]; put(f"item.{MODID}.{s}_{p}",e,i)
    for e in ENTITIES:
        put(f"entity.{MODID}.{e[0]}",e[11],e[12])
        if e[1] not in NO_EGG: put(f"item.{MODID}.{e[0]}_spawn_egg",e[11]+" Spawn Egg","Uovo Generatore: "+e[12])
    for tid,_,e,i in TECHNIQUES: put(f"item.{MODID}.{tid}",e,i)
    put(f"item.{MODID}.gojo_blindfold","Gojo's Blindfold","Benda di Gojo")
    for eid,_,_,e,i in EFFECTS: put(f"effect.{MODID}.{eid}",e,i)
    for s in SOUNDS: put(f"subtitles.{MODID}.{s}",*SOUND_SUBS[s])
    for aid,_,_,_,e,i,desc in ABILITIES: put(f"ability.{MODID}.{aid.lower()}",e,i); put(f"ability.{MODID}.{aid.lower()}.desc",desc,ABIL_IT[aid])
    for k,(e,i) in T.items(): put(k,e,i)
    for k,(te,ti,de,di,icon,frame) in ADV.items():
        put(f"advancements.{MODID}.{k}.title",te,ti); put(f"advancements.{MODID}.{k}.description",de,di)
    W(f"assets/{MODID}/lang/en_us.json",dict(sorted(en.items()))); W(f"assets/{MODID}/lang/it_it.json",dict(sorted(it.items())))
    return en,it
ABIL_IT={"DISMANTLE":"Un taglio rapido e invisibile che vola in avanti e taglia tutto sul suo cammino.","CLEAVE":"Un taglio adattivo che si adegua alla resistenza e alle dimensioni del bersaglio.",
 "REVERSE_CURSED_TECHNIQUE":"Trasforma l'energia negativa in positiva per curare le ferite e purificare i malanni.","SPIDERWEB":"I tagli si propagano nel terreno intorno a te.",
 "FUGA":"Tende un arco di fiamma e scocca una freccia infuocata.","WORLD_SLASH":"Un taglio che recide lo spazio stesso davanti a te.","DOMAIN_EXPANSION":"Manifesta il tuo santuario. Ogni essere vivente al suo interno viene tagliato senza fine.",
 "BLUE":"Attrazione: trascina tutto nel punto che guardi dentro una singolarita schiacciante.","RED":"Repulsione: un'esplosione che scaglia via i nemici.",
 "HOLLOW_PURPLE":"Rosso e Blu si scontrano in una massa immaginaria che cancella tutto sul suo cammino.","INFINITY":"Attiva/disattiva. Finche hai energia maledetta, gli attacchi non ti raggiungono.",
 "BLINK":"Ti teletrasporti a breve distanza dove guardi.","INFINITE_VOID":"Chiunque sia dentro riceve informazioni infinite e non puo muoversi."}

def sounds_particles():
    W(f"assets/{MODID}/sounds.json",{s:{"sounds":[{"name":f"{MODID}:{s}","stream":s=="boss_theme"}],"subtitle":f"subtitles.{MODID}.{s}"} for s in SOUNDS})
    for p in PARTICLES: W(f"assets/{MODID}/particles/{p}.json",{"textures":[f"{MODID}:{p}_{k}" for k in range(4)]})

def loot():
    D=f"data/{MODID}/loot_tables"
    def self_drop(bid): return {"type":"minecraft:block","pools":[{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns(bid)}],"conditions":[{"condition":"minecraft:survives_explosion"}]}]}
    for bid,kind,props,tool,e,i,ex in BLOCKS:
        if kind=="slab":
            t={"type":"minecraft:block","pools":[{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns(bid),"functions":[{"function":"minecraft:set_count","count":2,"add":False,"conditions":[{"condition":"minecraft:block_state_property","block":ns(bid),"properties":{"type":"double"}}]},{"function":"minecraft:explosion_decay"}]}]}]}
        elif kind=="ore":
            t={"type":"minecraft:block","pools":[{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:alternatives","children":[
               {"type":"minecraft:item","name":ns(bid),"conditions":[{"condition":"minecraft:match_tool","predicate":{"enchantments":[{"enchantment":"minecraft:silk_touch","levels":{"min":1}}]}}]},
               {"type":"minecraft:item","name":ns("cursed_energy_shard"),"functions":[{"function":"minecraft:set_count","count":{"type":"minecraft:uniform","min":1,"max":2}},{"function":"minecraft:apply_bonus","enchantment":"minecraft:fortune","formula":"minecraft:ore_drops"},{"function":"minecraft:explosion_decay"}]}]}]}]}
        elif kind=="leaves":
            t={"type":"minecraft:block","pools":[{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:alternatives","children":[
               {"type":"minecraft:item","name":ns(bid),"conditions":[{"condition":"minecraft:any_of","terms":[{"condition":"minecraft:match_tool","predicate":{"items":["minecraft:shears"]}},{"condition":"minecraft:match_tool","predicate":{"enchantments":[{"enchantment":"minecraft:silk_touch","levels":{"min":1}}]}}]}]},
               {"type":"minecraft:item","name":"minecraft:stick","conditions":[{"condition":"minecraft:random_chance","chance":0.06}]}]}]}]}
        elif kind in("csand","hportal"):
            t={"type":"minecraft:block","pools":[]}   # the finger is dropped by CursedSandBlock itself
        elif kind=="burial":
            t={"type":"minecraft:block","pools":[{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns("sukuna_finger")}]},{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns("cursed_soil")}]}]}
        else: t=self_drop(bid)
        W(f"{D}/blocks/{bid}.json",t)
    common=[("cursed_energy_shard",6,1,4),("curse_residue",6,1,5),("blank_talisman",4,1,3),("cursed_energy_vial",3,1,2),("cursed_ink",3,1,2),("bone_white_fragment",4,1,3),("minecraft:gold_ingot",2,1,3),("minecraft:bone",4,2,6),("sealing_talisman",2,1,1),("crimson_thread",3,1,3)]
    def cpool(rolls=(3,6)):
        return {"rolls":{"type":"minecraft:uniform","min":rolls[0],"max":rolls[1]},"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns(n),"weight":w,"functions":[{"function":"minecraft:set_count","count":{"type":"minecraft:uniform","min":a,"max":b}}]} for n,w,a,b in common]}
    for n in range(1,21):
        W(f"{D}/chests/finger_%02d.json"%n,{"type":"minecraft:chest","pools":[{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns("sukuna_finger")}]},cpool()]})
    W(f"{D}/chests/dark_institute.json",{"type":"minecraft:chest","pools":[{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns("sukuna_clue")}]},cpool()]})
    W(f"{D}/chests/jujutsu_high_supplies.json",{"type":"minecraft:chest","pools":[cpool((4,8)),{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns(x)} for x in ("jujutsu_uniform_helmet","jujutsu_uniform_chestplate","jujutsu_uniform_leggings","jujutsu_uniform_boots","cursed_katana")]}]})
    ent_drops={"fly_head":[("curse_residue",0,2)],"crawling_eye":[("curse_residue",0,2),("minecraft:spider_eye",0,1)],"roppongi_curse":[("curse_residue",1,3),("cursed_energy_shard",0,1)],
      "lantern_hag":[("curse_residue",1,3),("minecraft:blaze_powder",0,1)],"hanged_bride":[("curse_residue",1,3),("crimson_thread",0,2)],"bone_centipede":[("bone_white_fragment",2,4),("cursed_energy_shard",1,2)],
      "finger_bearer":[("special_grade_core",1,1),("cursed_energy_shard",2,5)],"smallpox_deity":[("special_grade_core",1,1),("bone_white_fragment",2,5)],"cursed_womb":[("special_grade_core",1,1),("curse_residue",3,6)],
      "shrine_warden":[("special_grade_core",1,2),("cursed_energy_shard",3,6)],"jujutsu_sorcerer":[("blank_talisman",1,3),("jujutsu_cloth",0,2)],"sorcerer_elite":[("sealing_talisman",0,2),("jujutsu_cloth",1,2),("cursed_energy_vial",0,1)],
      "jujutsu_student":[("jujutsu_cloth",0,1)],"yuta_okkotsu":[("special_grade_core",1,1),("cursed_energy_vial",1,2)],"kinji_hakari":[("cursed_energy_vial",1,3),("minecraft:gold_ingot",1,3)],
      "maki_zenin":[("jujutsu_cloth",1,2),("cursed_katana",0,1)],"megumi_fushiguro":[("jujutsu_cloth",1,2),("cursed_ink",1,2)],"aoi_todo":[("jujutsu_cloth",1,2),("cursed_energy_shard",2,4)],
      "kento_nanami":[("jujutsu_cloth",1,2),("cursed_energy_vial",0,2)],"gojo_kenjaku":[("special_grade_core",2,4),("prison_realm",1,1),("promise_ring",1,1),("greater_cursed_energy_vial",1,3)],"sealing_master":[("special_grade_core",2,3),("sealing_talisman",3,6),("greater_cursed_energy_vial",1,2)],"ryomen_sukuna":[],"sukuna_true_form":[],"gojo_satoru":[],"heian_sukuna":[],"mahoraga":[],"toji_fushiguro":[],"suguru_geto":[],"curse_user":[("cursed_energy_shard",0,2),("curse_residue",1,2),("blank_talisman",0,1)]}
    for e,drops in ent_drops.items():
        W(f"{D}/entities/{e}.json",{"type":"minecraft:entity","pools":[{"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":ns(n),"functions":[{"function":"minecraft:set_count","count":{"type":"minecraft:uniform","min":a,"max":b}},{"function":"minecraft:looting_enchant","count":{"type":"minecraft:uniform","min":0,"max":1}}]}]} for n,a,b in drops]})

def recipes():
    D=f"data/{MODID}/recipes"; c=[0]
    def shaped(name,pattern,key,result,count=1,cat="misc"):
        W(f"{D}/{name}.json",{"type":"minecraft:crafting_shaped","category":cat,"pattern":pattern,"key":{k:({"tag":v[1:]} if v.startswith("#") else {"item":ns(v)}) for k,v in key.items()},"result":{"item":ns(result),"count":count}})
    def shapeless(name,ings,result,count=1,cat="misc"):
        W(f"{D}/{name}.json",{"type":"minecraft:crafting_shapeless","category":cat,"ingredients":[({"tag":v[1:]} if v.startswith("#") else {"item":ns(v)}) for v in ings],"result":{"item":ns(result),"count":count}})
    def smelt(name,ing,result,xp=0.5,t=200):
        W(f"{D}/{name}.json",{"type":"minecraft:smelting","category":"misc","ingredient":{"item":ns(ing)},"result":ns(result),"experience":xp,"cookingtime":t})
    def cut(name,ing,result,count=1):
        W(f"{D}/{name}.json",{"type":"minecraft:stonecutting","ingredient":{"item":ns(ing)},"result":ns(result),"count":count})
    shapeless("temple_stone",["minecraft:cobblestone"]*8+["curse_residue"],"temple_stone",8,"building")
    shaped("temple_stone_bricks",["SS","SS"],{"S":"temple_stone"},"temple_stone_bricks",4,"building")
    smelt("cracked_temple_stone_bricks","temple_stone_bricks","cracked_temple_stone_bricks",0.1)
    for r_,res in (("polished_temple_stone","polished_temple_stone"),("chiseled_temple_stone","chiseled_temple_stone"),("temple_stone_pillar","temple_stone_pillar"),("temple_stone_bricks_cut","temple_stone_bricks")):
        cut(r_+"_stonecutting","temple_stone",res)
    shapeless("cursed_wood_planks_from_log",["cursed_wood_log"],"cursed_wood_planks",4,"building")
    shapeless("cursed_wood_planks_from_stripped",["stripped_cursed_wood_log"],"cursed_wood_planks",4,"building")
    shapeless("cursed_wood_planks",["minecraft:dark_oak_planks"]*8+["curse_residue"],"cursed_wood_planks",8,"building")
    shapeless("cursed_wood_log",["minecraft:dark_oak_log"]*4+["curse_residue"],"cursed_wood_log",4,"building")
    shapeless("black_lacquer_planks",["cursed_wood_planks"]*8+["minecraft:black_dye"],"black_lacquer_planks",8,"building")
    shapeless("torii_beam",["cursed_wood_planks"]*8+["minecraft:red_dye"],"torii_beam",8,"building")
    shapeless("torii_pillar",["cursed_wood_log"]*4+["minecraft:red_dye"],"torii_pillar",4,"building")
    shapeless("shrine_roof_tiles",["minecraft:deepslate_tiles"]*8+["minecraft:black_dye"],"shrine_roof_tiles",8,"building")
    shaped("cursed_seal_block",["BBB","BIB","BBB"],{"B":"temple_stone_bricks","I":"cursed_ink"},"cursed_seal_block",8,"building")
    shapeless("bone_white_plaster",["minecraft:calcite","minecraft:calcite","minecraft:bone_meal"],"bone_white_plaster",2,"building")
    shapeless("crimson_tatami",["minecraft:wheat","minecraft:wheat","minecraft:wheat","minecraft:red_dye"],"crimson_tatami",1,"building")
    shaped("talisman_wall",["TTT","PPP"],{"T":"blank_talisman","P":"cursed_wood_planks"},"talisman_wall",3,"building")
    shapeless("blood_soaked_soil",["minecraft:dirt","minecraft:dirt","minecraft:dirt","minecraft:dirt","crimson_thread"],"blood_soaked_soil",4,"building")
    shapeless("cursed_soil",["minecraft:coarse_dirt","minecraft:coarse_dirt","minecraft:coarse_dirt","minecraft:coarse_dirt","curse_residue"],"cursed_soil",4,"building")
    shapeless("cursed_bone_pile",["minecraft:bone_block","curse_residue"],"cursed_bone_pile",2,"building")
    shaped("sealing_stone",["OOO","OSO","OOO"],{"O":"minecraft:obsidian","S":"sealing_talisman"},"sealing_stone",8,"building")
    shaped("cursed_energy_crystal_block",["SSS","SSS","SSS"],{"S":"cursed_energy_shard"},"cursed_energy_crystal_block",1,"building")
    shapeless("cursed_energy_shard_from_block",["cursed_energy_crystal_block"],"cursed_energy_shard",9)
    smelt("cursed_energy_shard_from_ore","cursed_crystal_ore","cursed_energy_shard",0.8); smelt("cursed_energy_shard_from_deepslate_ore","deepslate_cursed_crystal_ore","cursed_energy_shard",0.8)
    for bid,kind,props,tool,e,i,ex in BLOCKS:
        if kind=="stairs": shaped(bid,["X  ","XX ","XXX"],{"X":props},bid,4,"building"); 
        if kind=="slab": shaped(bid,["XXX"],{"X":props},bid,6,"building")
        if kind=="wall": shaped(bid,["XXX","XXX"],{"X":props},bid,6,"building")
        if kind=="fence": shaped(bid,["XSX","XSX"],{"X":props,"S":"minecraft:stick"},bid,3,"building")
        if kind=="fence_gate": shaped(bid,["SXS","SXS"],{"X":props,"S":"minecraft:stick"},bid,1,"redstone")
    shaped("shrine_lantern",[" T ","TLT"," T "],{"T":"blank_talisman","L":"minecraft:lantern"},"shrine_lantern",2,"decorations")
    shaped("reliquary",["GPG","PCP","GPG"],{"G":"minecraft:gold_nugget","P":"black_lacquer_planks","C":"minecraft:chest"},"reliquary",1,"decorations")
    shaped("cursed_spike_trap",["BBB","SIS"],{"B":"bone_white_fragment","S":"temple_stone","I":"minecraft:iron_ingot"},"cursed_spike_trap",2,"redstone")
    shaped("malevolent_altar",["TCT","XAX","XXX"],{"T":"crimson_thread","C":"cursed_energy_crystal_block","X":"temple_stone_bricks","A":"chiseled_temple_stone"},"malevolent_altar",1,"decorations")
    shapeless("blank_talisman",["minecraft:paper","minecraft:paper","minecraft:string"],"blank_talisman",3)
    shapeless("cursed_ink",["minecraft:ink_sac","cursed_energy_shard"],"cursed_ink",2)
    shapeless("crimson_thread",["minecraft:string","minecraft:red_dye","curse_residue"],"crimson_thread",3)
    shapeless("jujutsu_cloth",["minecraft:black_wool","minecraft:gold_nugget","minecraft:string"],"jujutsu_cloth",2)
    shapeless("bone_white_fragment",["minecraft:bone","minecraft:bone","curse_residue"],"bone_white_fragment",2)
    for tid,ty,e,i in TALISMANS:
        extra={"SEALING":"minecraft:chain","WARDING":"minecraft:iron_ingot","BINDING":"crimson_thread","FLAME":"minecraft:blaze_powder"}[ty]
        shapeless(tid,["blank_talisman","cursed_ink",extra],tid,2)
    shaped("cursed_energy_vial",[" S ","SBS"," S "],{"S":"cursed_energy_shard","B":"minecraft:glass_bottle"},"cursed_energy_vial",1,"misc")
    shaped("greater_cursed_energy_vial",["CCC","CVC","CCC"],{"C":"cursed_energy_shard","V":"cursed_energy_vial"},"greater_cursed_energy_vial")
    shapeless("reverse_curse_tonic",["cursed_energy_vial","minecraft:golden_apple","bone_white_fragment"],"reverse_curse_tonic")
    shapeless("cursed_codex",["minecraft:book","cursed_ink","cursed_energy_shard","crimson_thread"],"cursed_codex")
    shaped("remains_compass",["S","S"],{"S":"minecraft:stick"},"remains_compass")
    shapeless("fingers_from_arm",["sukuna_arm"],"sukuna_finger",5)
    W(f"{D}/clue_combine.json",{"type":ns("clue_combine"),"category":"misc"})
    shaped("heian_seal",["GTG","TET","GTG"],{"G":"minecraft:gold_ingot","T":"torii_beam","E":"minecraft:ender_eye"},"heian_seal")
    shaped("cursed_compass",["SBS","BCB","SBS"],{"S":"cursed_energy_shard","B":"bone_white_fragment","C":"minecraft:compass"},"cursed_compass")
    # v1.0.4 cursed objects (Prison Realm and the Promise Ring are boss drops only)
    shaped("black_rope",["TCT","CSC","TCT"],{"T":"crimson_thread","C":"cursed_ink","S":"special_grade_core"},"black_rope")
    shaped("death_painting",["IRI","RPR","IRI"],{"I":"cursed_ink","R":"curse_residue","P":"minecraft:painting"},"death_painting")
    shaped("cursed_spirit_orb",[" R ","RSR"," R "],{"R":"curse_residue","S":"cursed_energy_shard"},"cursed_spirit_orb",2)
    shaped("inventory_curse",["RRR","RER","RRR"],{"R":"curse_residue","E":"minecraft:ender_chest"},"inventory_curse")
    W_=lambda n,p,k: shaped(n,p,k,n,1,"equipment")
    W_("cursed_katana",["  S"," S ","H  "],{"S":"cursed_energy_shard","H":"crimson_thread"})
    W_("slaughter_demon",[" S","H "],{"S":"cursed_energy_shard","H":"minecraft:stick"})
    W_("inverted_spear_of_heaven",["  C"," S ","S  "],{"C":"special_grade_core","S":"minecraft:iron_ingot"})
    W_("playful_cloud",["SCS","SBS","SBS"],{"C":"special_grade_core","S":"cursed_energy_shard","B":"minecraft:blaze_rod"})
    W_("chain_of_a_thousand_miles",["CCC","CSC","CCC"],{"C":"minecraft:chain","S":"cursed_energy_shard"})
    W_("split_soul_katana",["  C"," K ","T  "],{"C":"special_grade_core","K":"cursed_katana","T":"crimson_thread"})
    W_("dragon_bone",[" B ","BCB"," H "],{"B":"bone_white_fragment","C":"special_grade_core","H":"minecraft:stick"})
    W_("kings_cleaver",["CC ","CS "," H "],{"C":"special_grade_core","S":"cursed_energy_crystal_block","H":"crimson_thread"})
    for tid,kind,_,_ in TOOLS:
        p={"pickaxe":["SSS"," H "," H "],"axe":["SS ","SH "," H "],"shovel":[" S "," H "," H "],"hoe":["SS "," H "," H "]}[kind]
        shaped(tid,p,{"S":"cursed_energy_shard","H":"minecraft:stick"},tid,1,"equipment")
    pats={"helmet":["XXX","X X"],"chestplate":["X X","XXX","XXX"],"leggings":["XXX","X X","X X"],"boots":["X X","X X"]}
    mats={"jujutsu_uniform":"jujutsu_cloth","cursed_armor":"cursed_energy_shard","sukuna_robes":"crimson_thread"}
    for s,_,_,_ in ARMOR_SETS:
        for p,_,_,_ in ARMOR_PIECES:
            key={"X":mats[s]}
            pat=pats[p]
            if s=="sukuna_robes" and p=="chestplate": pat=["X X","XCX","XXX"]; key["C"]="special_grade_core"
            shaped(f"{s}_{p}",pat,key,f"{s}_{p}",1,"equipment")

def tags():
    D="data/minecraft/tags/blocks"; mine={"pickaxe":[],"axe":[],"shovel":[],"hoe":[]}
    for bid,kind,props,tool,e,i,ex in BLOCKS: mine[tool].append(ns(bid))
    for t,v in mine.items(): W(f"{D}/mineable/{t}.json",{"replace":False,"values":v})
    W(f"{D}/needs_iron_tool.json",{"replace":False,"values":[ns("cursed_crystal_ore"),ns("deepslate_cursed_crystal_ore"),ns("cursed_energy_crystal_block")]})
    W(f"{D}/needs_diamond_tool.json",{"replace":False,"values":[ns("sealing_stone")]})
    sel=lambda k:[ns(b[0]) for b in BLOCKS if b[1]==k]
    W(f"{D}/stairs.json",{"replace":False,"values":sel("stairs")}); W(f"{D}/slabs.json",{"replace":False,"values":sel("slab")})
    W(f"{D}/walls.json",{"replace":False,"values":sel("wall")}); W(f"{D}/wooden_fences.json",{"replace":False,"values":sel("fence")}); W(f"{D}/fence_gates.json",{"replace":False,"values":sel("fence_gate")})
    W(f"{D}/leaves.json",{"replace":False,"values":sel("leaves")}); W(f"{D}/logs.json",{"replace":False,"values":[ns("cursed_wood_log"),ns("stripped_cursed_wood_log")]})
    W(f"{D}/planks.json",{"replace":False,"values":[ns("cursed_wood_planks"),ns("black_lacquer_planks")]})
    I="data/minecraft/tags/items"
    W(f"{I}/stairs.json",{"replace":False,"values":sel("stairs")}); W(f"{I}/slabs.json",{"replace":False,"values":sel("slab")}); W(f"{I}/walls.json",{"replace":False,"values":sel("wall")})
    W(f"{I}/wooden_fences.json",{"replace":False,"values":sel("fence")}); W(f"{I}/fence_gates.json",{"replace":False,"values":sel("fence_gate")}); W(f"{I}/leaves.json",{"replace":False,"values":sel("leaves")})
    W(f"{I}/logs.json",{"replace":False,"values":[ns("cursed_wood_log"),ns("stripped_cursed_wood_log")]}); W(f"{I}/planks.json",{"replace":False,"values":[ns("cursed_wood_planks"),ns("black_lacquer_planks")]})
    W(f"data/{MODID}/tags/items/sukuna_fingers.json",{"replace":False,"values":[ns(f[0]) for f in FINGERS]+[ns(x) for x in LEGACY_FINGERS]})
    W(f"data/{MODID}/tags/entity_types/curses.json",{"replace":False,"values":[ns(e[0]) for e in ENTITIES if e[1] in("CURSE","SPECIAL")]})
    W(f"data/{MODID}/tags/entity_types/sorcerers.json",{"replace":False,"values":[ns(e[0]) for e in ENTITIES if e[1] in("SORCERER","BOSS","GOJOBOSS","NAMED")]})

def worldgen():
    D=f"data/{MODID}"
    for name,(fn,biomes,sp,sep,salt,kind) in structures.STRUCTS.items():
        W(f"{D}/tags/worldgen/biome/has_structure/{name}.json",{"replace":False,"values":biomes})
        s={"type":"minecraft:jigsaw","biomes":f"#{MODID}:has_structure/{name}","spawn_overrides":{},"start_pool":f"{MODID}:{name}/start","size":1,"max_distance_from_center":80,"use_expansion_hack":False}
        if kind=="surface": s.update(step="surface_structures",terrain_adaptation="beard_thin",start_height={"absolute":0},project_start_to_heightmap="WORLD_SURFACE_WG")
        if kind=="den": s.update(step="surface_structures",terrain_adaptation="beard_box",start_height={"absolute":-6},project_start_to_heightmap="WORLD_SURFACE_WG")
        if kind=="underground": s.update(step="underground_structures",terrain_adaptation="none",start_height={"absolute":10})
        if kind=="deep": s.update(step="underground_structures",terrain_adaptation="none",start_height={"absolute":-42})
        if kind=="nether": s.update(step="underground_decoration",terrain_adaptation="none",start_height={"absolute":40})
        if name=="end_reliquary": s.update(step="surface_structures",terrain_adaptation="none",start_height={"absolute":62}); s.pop("project_start_to_heightmap",None)
        W(f"{D}/worldgen/structure/{name}.json",s)
        W(f"{D}/worldgen/template_pool/{name}/start.json",{"fallback":"minecraft:empty","elements":[{"weight":1,"element":{"element_type":"minecraft:single_pool_element","location":f"{MODID}:{name}","projection":"rigid","processors":"minecraft:empty"}}]})
        W(f"{D}/worldgen/structure_set/{name}.json",{"structures":[{"structure":f"{MODID}:{name}","weight":1}],"placement":{"type":"minecraft:random_spread","spacing":sp,"separation":sep,"salt":salt}})
    W(f"{D}/tags/worldgen/structure/finger_sites.json",{"replace":False,"values":[f"{MODID}:{n}" for n in structures.STRUCTS if n!="dark_institute"]})
    W(f"{D}/tags/worldgen/structure/dark_institutes.json",{"replace":False,"values":[f"{MODID}:dark_institute"]})
    W(f"{D}/tags/worldgen/structure/jujutsu_institutes.json",{"replace":False,"values":[f"{MODID}:jujutsu_high"]})
    # ore + tree
    W(f"{D}/worldgen/configured_feature/cursed_crystal_ore.json",{"type":"minecraft:ore","config":{"size":6,"discard_chance_on_air_exposure":0.0,"targets":[
        {"target":{"predicate_type":"minecraft:tag_match","tag":"minecraft:stone_ore_replaceables"},"state":{"Name":ns("cursed_crystal_ore")}},
        {"target":{"predicate_type":"minecraft:tag_match","tag":"minecraft:deepslate_ore_replaceables"},"state":{"Name":ns("deepslate_cursed_crystal_ore")}}]}})
    W(f"{D}/worldgen/placed_feature/cursed_crystal_ore.json",{"feature":ns("cursed_crystal_ore"),"placement":[{"type":"minecraft:count","count":7},{"type":"minecraft:in_square"},
        {"type":"minecraft:height_range","height":{"type":"minecraft:trapezoid","min_inclusive":{"above_bottom":0},"max_inclusive":{"absolute":48}}},{"type":"minecraft:biome"}]})
    W(f"{D}/worldgen/configured_feature/cursed_tree.json",{"type":"minecraft:tree","config":{
        "dirt_provider":{"type":"minecraft:simple_state_provider","state":{"Name":"minecraft:dirt"}},
        "trunk_provider":{"type":"minecraft:simple_state_provider","state":{"Name":ns("cursed_wood_log"),"Properties":{"axis":"y"}}},
        "trunk_placer":{"type":"minecraft:straight_trunk_placer","base_height":5,"height_rand_a":2,"height_rand_b":1},
        "foliage_provider":{"type":"minecraft:simple_state_provider","state":{"Name":ns("cursed_leaves"),"Properties":{"distance":"7","persistent":"false","waterlogged":"false"}}},
        "foliage_placer":{"type":"minecraft:blob_foliage_placer","radius":2,"offset":0,"height":3},
        "minimum_size":{"type":"minecraft:two_layers_feature_size","limit":1,"lower_size":0,"upper_size":1},
        "decorators":[],"ignore_vines":True,"force_dirt":False}})
    W(f"{D}/worldgen/placed_feature/cursed_tree.json",{"feature":ns("cursed_tree"),"placement":[{"type":"minecraft:rarity_filter","chance":3},{"type":"minecraft:in_square"},
        {"type":"minecraft:surface_water_depth_filter","max_water_depth":0},{"type":"minecraft:heightmap","heightmap":"OCEAN_FLOOR"},
        {"type":"minecraft:block_predicate_filter","predicate":{"type":"minecraft:would_survive","state":{"Name":"minecraft:dark_oak_sapling","Properties":{"stage":"0"}}}},{"type":"minecraft:biome"}]})
    F=f"{D}/forge/biome_modifier"
    W(f"{F}/add_cursed_crystal_ore.json",{"type":"forge:add_features","biomes":"#minecraft:is_overworld","features":ns("cursed_crystal_ore"),"step":"underground_ores"})
    W(f"{F}/add_cursed_trees.json",{"type":"forge:add_features","biomes":["minecraft:dark_forest","minecraft:swamp","minecraft:old_growth_spruce_taiga"],"features":ns("cursed_tree"),"step":"vegetal_decoration"})
    W(f"{F}/add_curse_spawns.json",{"type":"forge:add_spawns","biomes":"#minecraft:is_overworld","spawners":[
        {"type":ns("fly_head"),"weight":18,"minCount":1,"maxCount":3},{"type":ns("crawling_eye"),"weight":14,"minCount":1,"maxCount":2},
        {"type":ns("roppongi_curse"),"weight":8,"minCount":1,"maxCount":1},{"type":ns("lantern_hag"),"weight":6,"minCount":1,"maxCount":1},
        {"type":ns("hanged_bride"),"weight":4,"minCount":1,"maxCount":1},{"type":ns("bone_centipede"),"weight":2,"minCount":1,"maxCount":1}]})
    W(f"{F}/add_nether_curse_spawns.json",{"type":"forge:add_spawns","biomes":"#minecraft:is_nether","spawners":[{"type":ns("lantern_hag"),"weight":10,"minCount":1,"maxCount":2},{"type":ns("bone_centipede"),"weight":4,"minCount":1,"maxCount":1}]})
    W(f"{F}/add_end_curse_spawns.json",{"type":"forge:add_spawns","biomes":["minecraft:end_highlands","minecraft:end_midlands","minecraft:end_barrens"],"spawners":[{"type":ns("hanged_bride"),"weight":6,"minCount":1,"maxCount":1},{"type":ns("crawling_eye"),"weight":8,"minCount":1,"maxCount":2}]})

def advancements():
    D=f"data/{MODID}/advancements"; parents={"root":None,"first_finger":"root","five_fingers":"first_finger","ten_fingers":"five_fingers","fifteen_fingers":"ten_fingers","twenty_fingers":"fifteen_fingers",
      "domain_expansion":"twenty_fingers","special_grade":"first_finger","sealer_defeated":"twenty_fingers","embrace":"sealer_defeated","reject":"sealer_defeated"}
    for k,(te,ti,de,di,icon,frame) in ADV.items():
        disp={"icon":{"item":ns(icon)},"title":{"translate":f"advancements.{MODID}.{k}.title"},"description":{"translate":f"advancements.{MODID}.{k}.description"},"frame":frame,"show_toast":True,"announce_to_chat":k!="root","hidden":k in("embrace","reject")}
        if k=="root": disp["background"]=f"{MODID}:textures/block/temple_stone_bricks.png"
        a={"display":disp,"criteria":{"granted":{"trigger":"minecraft:impossible"}},"requirements":[["granted"]]}
        if parents[k]: a["parent"]=f"{MODID}:{parents[k]}"
        W(f"{D}/{k}.json",a)

def heian():
    """v1.0.17 the Heian Era: golden, eternal sunset, cherry groves, Sukuna's throne at the centre."""
    D=f"data/{MODID}"
    W(f"{D}/dimension_type/heian_era.json",{"ultrawarm":False,"natural":True,"piglin_safe":False,"respawn_anchor_works":False,"bed_works":True,"has_raids":False,
       "has_skylight":True,"has_ceiling":False,"coordinate_scale":1.0,"ambient_light":0.08,"fixed_time":12600,"logical_height":384,"effects":"minecraft:overworld",
       "infiniburn":"#minecraft:infiniburn_overworld","min_y":-64,"height":384,"monster_spawn_light_level":{"type":"minecraft:uniform","value":{"min_inclusive":0,"max_inclusive":7}},
       "monster_spawn_block_light_limit":0})
    W(f"{D}/worldgen/biome/heian_era.json",{"has_precipitation":False,"temperature":0.9,"downfall":0.0,
       "effects":{"sky_color":0xE8A23C,"fog_color":0xF0B45A,"water_color":0x7A1018,"water_fog_color":0x3A0608,"grass_color":0xD6A84A,"foliage_color":0xE09A3A,
                  "mood_sound":{"sound":"minecraft:ambient.cave","tick_delay":6000,"block_search_extent":8,"offset":2.0},
                  "particle":{"options":{"type":"minecraft:ash"},"probability":0.004}},
       "spawners":{"monster":[{"type":ns("roppongi_curse"),"weight":40,"minCount":1,"maxCount":2},{"type":ns("lantern_hag"),"weight":30,"minCount":1,"maxCount":1},
                              {"type":ns("hanged_bride"),"weight":20,"minCount":1,"maxCount":1},{"type":ns("fly_head"),"weight":60,"minCount":2,"maxCount":4}],
                   "creature":[],"ambient":[],"axolotls":[],"underground_water_creature":[],"water_creature":[],"water_ambient":[],"misc":[]},
       "spawn_costs":{},"carvers":{"air":["minecraft:cave","minecraft:canyon"]},
       "features":[[],["minecraft:lake_lava_surface"],[],[],[],[],["minecraft:ore_coal_upper","minecraft:ore_iron_middle","minecraft:ore_gold","minecraft:ore_gold_lower"],
                   [],["minecraft:spring_lava"],["minecraft:trees_cherry","minecraft:flower_cherry","minecraft:patch_grass_plain","minecraft:patch_dead_bush_badlands"],
                   ["minecraft:freeze_top_layer"]]})
    W(f"{D}/dimension/heian_era.json",{"type":ns("heian_era"),"generator":{"type":"minecraft:noise","settings":"minecraft:overworld",
       "biome_source":{"type":"minecraft:fixed","biome":ns("heian_era")}}})

def run(res):
    global R; R=res
    blockstates_models(); item_models(); en,it=lang(); sounds_particles(); loot(); recipes(); tags(); worldgen(); advancements(); heian()
    W("pack.mcmeta",{"pack":{"description":{"text":"King of Curses resources"},"pack_format":15}})
    return en,it
