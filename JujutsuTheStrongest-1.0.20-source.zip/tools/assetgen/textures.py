import os, random, math
from px import *
from spec import *
def save(img,path):
    os.makedirs(os.path.dirname(path),exist_ok=True); img.save(path)

# ---------- BLOCK TEXTURES ----------
def t_stone(base=STONE,seed=1,speck=PURPLE2):
    i=new(); noise_fill(i,base,0.10,seed); r=random.Random(seed)
    for _ in range(10): P(i,r.randrange(16),r.randrange(16),shade(base,0.78))
    for _ in range(4): P(i,r.randrange(16),r.randrange(16),speck)
    return i
def t_bricks(base=STONE,mortar=(54,50,56),seed=2,cracked=False):
    i=new(); noise_fill(i,base,0.09,seed)
    for y in (0,4,8,12): rect(i,0,y,15,y,mortar)
    for row,y in enumerate((0,4,8,12)):
        off=0 if row%2==0 else 4
        for x in range(off,16,8): rect(i,x,y,x,y+3,mortar)
        for x in range(16): P(i,x,y+1,shade(base,1.15))
    if cracked:
        line(i,2,1,6,7,BLACK); line(i,6,7,4,12,BLACK); line(i,11,3,14,9,BLACK); line(i,9,10,12,15,shade(BLACK,1.5))
    return i
def t_chiseled():
    i=t_stone(STONE,3); rect(i,0,0,15,0,GRAY); rect(i,0,15,15,15,GRAY); rect(i,0,0,0,15,GRAY); rect(i,15,0,15,15,GRAY)
    rect(i,2,2,13,13,shade(STONE,0.85)); glyph(i,5,4,CRIMSON,0); return i
def t_polished():
    i=new(); noise_fill(i,shade(STONE,1.1),0.04,4)
    for k in range(16): P(i,k,0,shade(STONE,1.35)); P(i,0,k,shade(STONE,1.35)); P(i,k,15,shade(STONE,0.7)); P(i,15,k,shade(STONE,0.7))
    return i
def t_planks(base=WOOD2,seed=5):
    i=new(); noise_fill(i,base,0.07,seed); r=random.Random(seed)
    for y in (3,7,11,15): rect(i,0,y,15,y,shade(base,0.55))
    for y in range(16):
        if y%4!=3 and r.random()<0.5: line(i,r.randrange(4),y,r.randrange(8,16),y,shade(base,0.85))
    for k,y in enumerate((0,4,8,12)):
        x=(k*5+3)%16; rect(i,x,y,x,y+2,shade(base,0.6))
    return i
def t_log_side(base=WOOD,seed=6,band=None):
    i=new(); noise_fill(i,base,0.08,seed); r=random.Random(seed)
    for x in range(0,16,3): rect(i,x,0,x,15,shade(base,0.7))
    for _ in range(8): P(i,r.randrange(16),r.randrange(16),shade(base,1.3))
    if band: rect(i,0,13,15,15,band)
    return i
def t_log_top(bark=WOOD,inner=WOOD2):
    i=new(); noise_fill(i,bark,0.08,7)
    for x in range(16):
        for y in range(16):
            d=math.hypot(x-7.5,y-7.5)
            if d<6.6: P(i,x,y,shade(inner,0.85+0.2*((int(d*1.2))%2)))
    return i
def t_roof():
    i=new(); noise_fill(i,(40,38,48),0.08,8)
    for row,y in enumerate(range(0,16,4)):
        for x in range(16):
            c=(x+(row%2)*2)%4
            P(i,x,y+3,BLACK)
            if c==0: rect(i,x,y,x,y+3,(26,24,32))
            if c==2: P(i,x,y+1,(70,66,84))
    return i
def t_seal():
    i=t_bricks((70,62,66),(30,24,28),9)
    for a in range(40):
        t=a/40*2*math.pi; P(i,round(7.5+6*math.cos(t)),round(7.5+6*math.sin(t)),CRIMSON)
    glyph(i,5,4,CE,1); return i
def t_plaster():
    i=new(); noise_fill(i,BONE,0.04,10); r=random.Random(10)
    for _ in range(6): P(i,r.randrange(16),r.randrange(16),BONE2)
    return i
def t_tatami():
    i=new(); noise_fill(i,(120,20,30),0.06,11)
    for y in range(16):
        for x in range(16):
            if (x+y)%3==0: P(i,x,y,shade((120,20,30),0.8))
    rect(i,0,0,15,1,BLACK); rect(i,0,14,15,15,BLACK); return i
def t_talisman_wall():
    i=new(); noise_fill(i,WOOD,0.06,12)
    for k,x in enumerate((1,6,11)):
        rect(i,x,1,x+3,14,PAPER); glyph(i,x-1,4,CRIMSON,k)
        rect(i,x,1,x+3,1,shade(PAPER,0.8))
    return i
def t_dirt(base=(74,52,40),seed=13,blood=0):
    i=new(); noise_fill(i,base,0.14,seed); r=random.Random(seed)
    for _ in range(blood): x,y=r.randrange(16),r.randrange(16); P(i,x,y,BLOOD); P(i,x+1,y,DEEPRED)
    return i
def t_cursed_soil():
    i=t_dirt((50,36,46),14,0); r=random.Random(14)
    for _ in range(9): P(i,r.randrange(16),r.randrange(16),PURPLE2)
    return i
def t_bones():
    i=new(); noise_fill(i,(48,40,40),0.1,15); r=random.Random(15)
    for _ in range(7):
        x,y=r.randrange(1,13),r.randrange(1,14); horiz=r.random()<0.5
        if horiz: rect(i,x,y,x+3,y,BONE); P(i,x,y-1,BONE2); P(i,x+3,y+1,BONE2)
        else: rect(i,x,y,x,y+3,BONE); P(i,x-1,y,BONE2); P(i,x+1,y+3,BONE2)
    P(i,7,7,BONE); P(i,8,7,BONE); P(i,7,8,BLACK); return i
def t_sealing_stone():
    i=new(); noise_fill(i,(26,20,30),0.08,16); glyph(i,5,4,BONE2,2)
    for k in range(16): P(i,k,0,PURPLE); P(i,k,15,PURPLE)
    return i
def t_crystal():
    i=new(); noise_fill(i,(90,8,20),0.1,17)
    for k in range(16):
        line(i,k,0,0,k,shade(CE,0.7) if k%4==0 else (120,10,26))
    line(i,0,15,15,0,CE); line(i,3,15,15,3,shade(CE,0.8)); return i
def t_ore(deep=False):
    i=t_stone((70,70,78) if deep else STONE,18 if deep else 19,speck=GRAY)
    for (x,y) in ((3,3),(4,3),(3,4),(10,5),(11,5),(11,6),(6,10),(7,10),(6,11),(12,12)): P(i,x,y,CE)
    for (x,y) in ((4,4),(10,6),(7,11)): P(i,x,y,(255,140,150))
    return i
def t_leaves():
    i=new(); r=random.Random(20)
    for x in range(16):
        for y in range(16):
            v=r.random()
            if v>0.18: P(i,x,y,shade((112,12,28),0.7+0.5*r.random()))
            if v>0.95: P(i,x,y,(40,4,10))
    return i
def t_lacquer():
    i=new(); noise_fill(i,LACQUER,0.05,21)
    for x in (0,15): rect(i,x,0,x,15,shade(LACQUER,0.7))
    rect(i,0,0,15,0,shade(LACQUER,1.2)); return i
def t_black_lacquer():
    i=t_planks((26,20,24),22)
    for y in (3,7,11,15): P(i,4,y,GOLD)
    return i
def t_torii_side(): return t_log_side(LACQUER,23,band=BLACK)
def t_torii_top():
    i=t_log_top(shade(LACQUER,0.8),LACQUER); return i
def t_temple_pillar_side():
    i=new(); noise_fill(i,shade(STONE,1.15),0.05,24)
    for x in (1,5,10,14): rect(i,x,0,x,15,shade(STONE,0.9))
    rect(i,0,0,15,1,shade(STONE,0.75)); rect(i,0,14,15,15,shade(STONE,0.75)); return i
def t_temple_pillar_top():
    i=t_polished(); glyph(i,5,4,shade(STONE,0.7),3); return i
def t_reliquary(face):
    i=t_planks((34,22,26),25)
    for k in range(16): P(i,k,0,GOLD); P(i,k,15,GOLD); P(i,0,k,GOLD); P(i,15,k,GOLD)
    if face=="front":
        rect(i,5,4,10,11,PAPER); glyph(i,5,4,CRIMSON,1); rect(i,7,12,8,13,GOLD)
    if face=="top":
        rect(i,3,3,12,12,(20,12,16)); glyph(i,5,4,CE,0)
    return i
def t_disturbed(top):
    i=t_dirt((66,44,34),26,6)
    if top:
        r=random.Random(27)
        for _ in range(14): P(i,r.randrange(3,13),r.randrange(3,13),shade((66,44,34),0.55))
        P(i,8,8,BONE2); P(i,7,8,shade(CE,0.6))
    return i
def t_spike_top():
    i=t_stone((60,56,62),28)
    for x in (2,7,12):
        for y in (2,7,12):
            rect(i,x,y,x+1,y+1,BONE); P(i,x,y,(255,255,255)); P(i,x+1,y+1,BLOOD)
    return i
def t_spike_side():
    i=t_bricks((60,56,62),(30,26,30),29)
    for x in range(0,16,3): P(i,x,0,BONE); P(i,x+1,0,BONE2)
    return i
def t_altar_top():
    i=t_polished()
    for a in range(48):
        t=a/48*2*math.pi; P(i,round(7.5+6.5*math.cos(t)),round(7.5+6.5*math.sin(t)),CRIMSON)
    for k in range(5):
        t=k/5*2*math.pi-math.pi/2; t2=(k+2)/5*2*math.pi-math.pi/2
        line(i,round(7.5+6*math.cos(t)),round(7.5+6*math.sin(t)),round(7.5+6*math.cos(t2)),round(7.5+6*math.sin(t2)),CE)
    return i
def t_altar_side():
    i=t_bricks((50,44,50),(22,16,20),30); rect(i,0,0,15,1,GOLD); glyph(i,5,5,CRIMSON,3); return i
def t_lantern():
    i=new(); noise_fill(i,(30,22,22),0.05,31)
    rect(i,1,1,14,14,PAPER); glyph(i,5,4,CRIMSON,0)
    for k in range(16): P(i,k,0,BLACK); P(i,k,15,BLACK)
    return i

def t_cursed_sand():
    """v1.0.10: the ashes of a vessel. Dark crimson grains with glinting cursed specks and black ash."""
    i=new(); r=random.Random(404)
    for x in range(16):
        for y in range(16):
            c=mix((96,24,30),(40,10,14),r.random()*0.6)
            if r.random()<0.12: c=(20,8,10)
            if r.random()<0.05: c=(200,40,56)
            P(i,x,y,c)
    for (x,y) in ((3,4),(11,2),(7,9),(13,12),(2,13)): P(i,x,y,(255,70,90))
    return i

def gen_block_textures(root):
    T={}
    T["temple_stone"]=t_stone(); T["temple_stone_bricks"]=t_bricks(); T["cracked_temple_stone_bricks"]=t_bricks(cracked=True)
    T["chiseled_temple_stone"]=t_chiseled(); T["polished_temple_stone"]=t_polished(); T["cursed_wood_planks"]=t_planks()
    T["black_lacquer_planks"]=t_black_lacquer(); T["torii_beam"]=t_lacquer(); T["shrine_roof_tiles"]=t_roof()
    T["cursed_seal_block"]=t_seal(); T["bone_white_plaster"]=t_plaster(); T["crimson_tatami"]=t_tatami(); T["talisman_wall"]=t_talisman_wall()
    T["blood_soaked_soil"]=t_dirt((70,40,34),32,22); T["cursed_soil"]=t_cursed_soil(); T["cursed_bone_pile"]=t_bones()
    T["sealing_stone"]=t_sealing_stone(); T["cursed_energy_crystal_block"]=t_crystal(); T["cursed_crystal_ore"]=t_ore(); T["deepslate_cursed_crystal_ore"]=t_ore(True)
    T["cursed_wood_log"]=t_log_side(); T["cursed_wood_log_top"]=t_log_top(); T["stripped_cursed_wood_log"]=t_log_side(WOOD2,33); T["stripped_cursed_wood_log_top"]=t_log_top(WOOD2,shade(WOOD2,1.2))
    T["torii_pillar"]=t_torii_side(); T["torii_pillar_top"]=t_torii_top(); T["temple_stone_pillar"]=t_temple_pillar_side(); T["temple_stone_pillar_top"]=t_temple_pillar_top()
    T["cursed_leaves"]=t_leaves(); T["shrine_lantern"]=t_lantern(); T["reliquary_side"]=t_reliquary("side"); T["reliquary_front"]=t_reliquary("front"); T["reliquary_top"]=t_reliquary("top")
    T["disturbed_soil"]=t_disturbed(False); T["disturbed_soil_top"]=t_disturbed(True); T["cursed_spike_trap"]=t_spike_side(); T["cursed_spike_trap_top"]=t_spike_top()
    T["cursed_sand"]=t_cursed_sand(); T["malevolent_altar"]=t_altar_side(); T["malevolent_altar_top"]=t_altar_top()
    for k,v in T.items(): save(v,f"{root}/textures/block/{k}.png")
    return T

# ---------- ITEM TEXTURES ----------
def i_finger(n):
    i=new(); r=random.Random(100+n)
    tone=mix(BONE,(140,110,96),0.25+0.02*(n%5))
    pts=[(3,13),(4,12),(5,11),(6,10),(7,9),(8,8),(9,7),(10,6),(11,5),(12,4)]
    for k,(x,y) in enumerate(pts):
        for dx in (-1,0,1):
            for dy in (-1,0,1): P(i,x+dx,y+dy,shade(tone,0.9+0.1*dy*-1))
    rect(i,12,2,13,3,(60,20,30)); P(i,13,2,(30,8,14)); # black nail
    for (x,y) in ((6,9),(8,7),(10,5)): P(i,x,y+1,shade(tone,0.65)) # knuckles
    marks=[(4,12),(5,13),(7,10),(9,8),(11,6),(6,11),(8,9),(10,7)]
    for k in range(min(8,1+n//3)): x,y=marks[k]; P(i,x,y,CRIMSON)
    rect(i,2,13,3,14,DEEPRED); P(i,2,14,BLOOD)
    # tally dots for number (bottom-left)
    for k in range(n//5): P(i,1+k,1,CE)
    for k in range(n%5): P(i,1+k,3,BONE)
    outline(i,BLACK); return i
def i_sword(blade,hilt=BLACK,guard=GOLD,curved=True,wrap=CRIMSON):
    i=new()
    for k in range(10):
        x=5+k; y=10-k
        if curved and k>6: y+=1
        P(i,x,y,blade); P(i,x-1,y,shade(blade,0.75)); P(i,x,y+1,shade(blade,0.6))
    rect(i,3,10,5,12,guard)
    for k in range(4): P(i,3-k//2+ (k%2),12+k//2+(k%2),wrap if k%2 else hilt)
    P(i,1,14,hilt); P(i,2,13,wrap)
    outline(i,BLACK); return i
def i_spear():
    i=new()
    for k in range(13): P(i,2+k,13-k,(150,130,90) if k<9 else (200,200,210))
    rect(i,12,1,14,3,(220,220,230)); P(i,11,4,(200,200,210)); P(i,14,4,(200,200,210)); P(i,15,0,WHITE)
    for k in range(3): P(i,5+k*2,10-k*2,CRIMSON)
    outline(i,BLACK); return i
def i_cloud():
    i=new()
    for seg,(x0,y0,x1,y1) in enumerate(((1,14,5,10),(6,9,10,5),(11,4,14,1))):
        line(i,x0,y0,x1,y1,(110,24,140)); line(i,x0+1,y0,x1+1,y1,(70,14,90))
    for (x,y) in ((5,10),(6,9),(10,5),(11,4)): P(i,x,y,GOLD)
    outline(i,BLACK); return i
def i_chain():
    i=new()
    for k in range(7):
        x=2+k*2; y=13-k*2
        rect(i,x,y,x+1,y+1,(150,150,160)); P(i,x,y,(210,210,220))
    rect(i,13,1,15,3,GOLD); P(i,14,2,CRIMSON); outline(i,BLACK); return i
def i_bone_blade():
    i=new()
    for k in range(11):
        x=3+k; y=12-k; P(i,x,y,BONE); P(i,x-1,y,BONE2); P(i,x,y+1,BONE2)
        if k%3==0: P(i,x+1,y+1,BONE)
    rect(i,1,13,3,15,(40,30,30)); P(i,2,14,CRIMSON); outline(i,BLACK); return i
def i_cleaver():
    i=new(); rect(i,6,2,13,9,(170,170,180)); rect(i,6,2,13,2,(230,230,240)); line(i,6,9,13,9,(120,120,130))
    rect(i,12,3,12,8,CRIMSON); line(i,5,9,1,14,BLACK); line(i,4,9,1,13,(60,30,30)); outline(i,BLACK); return i
def i_tool(kind,head=(150,20,36)):
    i=new()
    line(i,3,13,11,5,WOOD2); line(i,4,13,12,5,WOOD)
    if kind=="pickaxe": line(i,6,3,13,10,head); line(i,7,3,13,9,shade(head,1.3)); line(i,5,2,6,3,head); line(i,13,10,14,11,head)
    if kind=="axe": rect(i,9,2,13,7,head); rect(i,10,3,12,5,shade(head,1.3)); P(i,13,8,head)
    if kind=="shovel": rect(i,10,2,13,5,head); rect(i,11,2,12,4,shade(head,1.3))
    if kind=="hoe": rect(i,8,3,13,4,head); rect(i,8,5,9,6,head)
    outline(i,BLACK); return i
def i_armor(piece,main,trim,accent):
    i=new()
    if piece=="helmet": rect(i,3,4,12,10,main); rect(i,5,8,10,10,(0,0,0,0)); rect(i,3,4,12,4,trim); P(i,7,5,accent); P(i,8,5,accent)
    if piece=="chestplate":
        rect(i,2,3,13,13,main); rect(i,6,3,9,5,(0,0,0,0)); rect(i,2,3,4,8,main); rect(i,7,6,8,13,trim); P(i,8,8,accent); P(i,8,10,accent)
        rect(i,0,4,1,9,main); rect(i,14,4,15,9,main)
    if piece=="leggings": rect(i,3,2,12,4,trim); rect(i,3,5,7,14,main); rect(i,8,5,12,14,main); P(i,7,8,accent)
    if piece=="boots": rect(i,2,8,6,13,main); rect(i,9,8,13,13,main); rect(i,2,13,6,13,trim); rect(i,9,13,13,13,trim); P(i,4,10,accent); P(i,11,10,accent)
    outline(i,BLACK); return i
def i_talisman(k,color):
    i=new(); rect(i,4,1,11,14,PAPER); rect(i,4,1,11,2,shade(PAPER,0.8)); glyph(i,5,4,color,k); rect(i,7,12,8,13,color)
    outline(i,BLACK); return i
def i_vial(liq):
    i=new(); rect(i,6,1,9,2,WOOD2); rect(i,6,3,9,5,(200,210,230)); rect(i,4,6,11,14,(200,210,230)); rect(i,5,8,10,13,liq); P(i,6,9,shade(liq,1.6)); outline(i,BLACK); return i
def i_codex():
    i=new(); rect(i,2,2,13,14,(30,10,16)); rect(i,3,2,3,14,CRIMSON); rect(i,12,3,13,13,PAPER)
    glyph(i,6,4,CE,0); P(i,8,12,GOLD); outline(i,BLACK); return i
def i_compass(level):
    i=new()
    for x in range(16):
        for y in range(16):
            d=math.hypot(x-7.5,y-7.5)
            if d<6.8: P(i,x,y,(40,30,34) if d>5.6 else (70,52,60))
    glow=[shade(CE,0.35),shade(CE,0.6),shade(CE,0.85),CE][level]
    for x in range(16):
        for y in range(16):
            if math.hypot(x-7.5,y-7.5)<1.5+level*0.9: P(i,x,y,glow)
    rect(i,7,2,8,4,BONE); P(i,7,1,GOLD); P(i,8,1,GOLD); outline(i,BLACK); return i
def i_remains_compass():
    i=new()
    for x in range(16):
        for y in range(16):
            d=math.hypot(x-7.5,y-7.5)
            if d<6.8: P(i,x,y,(30,26,22) if d>5.6 else (196,170,120))
    # cursed sand grains + a red needle
    for (x,y) in [(5,9),(6,10),(9,10),(10,8),(4,7),(11,6)]: P(i,x,y,(150,120,80))
    line(i,8,8,11,4,CRIMSON); line(i,8,8,5,11,(60,50,46)); P(i,8,8,BLACK)
    rect(i,7,2,8,4,BONE); P(i,7,1,CRIMSON); P(i,8,1,CRIMSON); outline(i,BLACK); return i
def i_material(kind):
    i=new(); r=random.Random(hash(kind)%999)
    if kind=="cursed_energy_shard":
        for k in range(7): line(i,8-k//2,2+k,8+k//2,2+k,mix(CE,DEEPRED,k/7))
        for k in range(5): line(i,8-(4-k)//1//2,9+k,8+(4-k)//2,9+k,DEEPRED)
        P(i,8,3,(255,180,190))
    elif kind=="curse_residue":
        for _ in range(40):
            x,y=int(r.gauss(8,2.6)),int(r.gauss(9,2.2)); P(i,x,y,mix(PURPLE,(20,6,22),r.random()))
        P(i,6,8,CE); P(i,10,9,CE)
    elif kind=="bone_white_fragment":
        line(i,3,12,12,3,BONE); line(i,4,12,12,4,BONE2); rect(i,11,2,13,4,BONE); rect(i,2,11,4,13,BONE)
    elif kind=="crimson_thread":
        for k in range(30):
            t=k/30*4*math.pi; P(i,round(7.5+5*math.cos(t)*(1-k/40)),round(7.5+5*math.sin(t)*(1-k/40)),CRIMSON)
        line(i,8,8,14,14,BLOOD)
    elif kind=="jujutsu_cloth":
        rect(i,2,3,13,12,(22,22,36)); for_x=[P(i,x,3,(60,60,90)) for x in range(2,14)]; rect(i,10,5,11,6,GOLD)
    elif kind=="cursed_ink":
        rect(i,4,6,11,13,(18,10,14)); rect(i,6,3,9,5,(40,28,32)); rect(i,5,7,10,9,CRIMSON); P(i,6,7,CE)
    elif kind=="blank_talisman":
        rect(i,4,1,11,14,PAPER); rect(i,4,1,11,2,shade(PAPER,0.8))
    elif kind=="special_grade_core":
        for x in range(16):
            for y in range(16):
                d=math.hypot(x-7.5,y-7.5)
                if d<6: P(i,x,y,mix(CE,(20,0,6),d/6))
        glyph(i,6,5,BLACK,1)
    outline(i,BLACK); return i

WEAPON_ART={
 "cursed_katana":lambda: i_sword((180,180,190)),
 "slaughter_demon":lambda: i_sword((150,40,50),guard=BLACK,curved=False),
 "inverted_spear_of_heaven":i_spear,
 "playful_cloud":i_cloud,
 "chain_of_a_thousand_miles":i_chain,
 "split_soul_katana":lambda: i_sword((90,60,140),guard=BONE,wrap=PURPLE2),
 "dragon_bone":i_bone_blade,
 "kings_cleaver":i_cleaver,
}
ARMOR_COL={"jujutsu_uniform":((26,26,44),(60,60,92),GOLD),"cursed_armor":((44,10,18),(16,10,12),CE),"sukuna_robes":((236,230,214),(20,14,16),CRIMSON)}

def gen_item_textures(root):
    save(i_sukuna_finger(),f"{root}/textures/item/sukuna_finger.png")
    for k,f in WEAPON_ART.items(): save(f(),f"{root}/textures/item/{k}.png")
    for tid,kind,_,_ in TOOLS: save(i_tool(kind),f"{root}/textures/item/{tid}.png")
    for sid,_,_,_ in ARMOR_SETS:
        m,t,a=ARMOR_COL[sid]
        for p,_,_,_ in ARMOR_PIECES: save(i_armor(p,m,t,a),f"{root}/textures/item/{sid}_{p}.png")
    for k,(tid,_,_,_) in enumerate(TALISMANS): save(i_talisman(k,[CRIMSON,BLUE,PURPLE2,(255,120,20)][k]),f"{root}/textures/item/{tid}.png")
    save(i_vial(CRIMSON),f"{root}/textures/item/cursed_energy_vial.png"); save(i_vial(CE),f"{root}/textures/item/greater_cursed_energy_vial.png"); save(i_vial((240,240,255)),f"{root}/textures/item/reverse_curse_tonic.png")
    save(i_codex(),f"{root}/textures/item/cursed_codex.png")
    for lv in range(4): save(i_compass(lv),f"{root}/textures/item/cursed_compass_{lv}.png")
    save(i_remains_compass(),f"{root}/textures/item/remains_compass.png")
    for mid,_,_ in MATERIALS: save(i_material(mid),f"{root}/textures/item/{mid}.png")

# ---------- ARMOR LAYERS (64x32) ----------
def armor_layer(sid,layer):
    m,t,a=ARMOR_COL[sid]; i=new(64,32); r=random.Random(sid+str(layer))
    def box(u,v,w,h,d,col):
        for (x0,y0,ww,hh) in ((u+d,v,w,d),(u+d+w,v,w,d),(u,v+d,d,h),(u+d,v+d,w,h),(u+d+w,v+d,d,h),(u+2*d+w,v+d,w,h)):
            for x in range(x0,x0+ww):
                for y in range(y0,y0+hh): P(i,x,y,shade(col,0.9+0.2*r.random()))
    if layer==1:
        box(0,0,8,8,8,m)           # head
        for x in range(8,16): P(i,x,8,t)
        box(16,16,8,12,4,m)        # body
        for y in range(20,32): P(i,23,y,t); P(i,24,y,t)
        P(i,22,22,a); P(i,22,25,a)
        box(40,16,4,12,4,m)        # arm
        for x in range(40,56): P(i,x,27,t)
        box(0,16,4,12,4,shade(m,0.85)) # boots legs region
        for x in range(0,16): P(i,x,31,t)
        if sid=="sukuna_robes":
            for y in range(20,32,3): P(i,26,y,CRIMSON); P(i,20,y,CRIMSON)
    else:
        box(16,16,8,12,4,m); box(0,16,4,12,4,m)
        for x in range(16,40): P(i,x,20,t)
    return i
def gen_armor(root):
    for sid,_,_,_ in ARMOR_SETS:
        for L in (1,2): save(armor_layer(sid,L),f"{root}/textures/models/armor/{sid}_layer_{L}.png")

# ---------- PARTICLES / EFFECTS / GUI ----------
def gen_misc(root):
    for k in range(4):
        i=new(8,8)
        for x in range(8):
            for y in range(8):
                d=math.hypot(x-3.5,y-3.5)
                if d<3.6-k*0.6: P(i,x,y,mix(CE,(60,0,20),d/4))
        save(i,f"{root}/textures/particle/cursed_energy_{k}.png")
        b=new(8,8); rect(b,3-k//2,3-k//2,4+k//3,4+k//3,BLOOD); P(b,3,3,CRIMSON); save(b,f"{root}/textures/particle/blood_{k}.png")
        s=new(16,16)
        for t in range(14):
            a=math.pi*(0.15+0.7*t/13); rr=6+k*0.4
            P(s,round(7.5+rr*math.cos(a)),round(9-rr*math.sin(a)),(255,255,255) if t%3 else (255,180,190)); P(s,round(7.5+(rr-1)*math.cos(a)),round(9-(rr-1)*math.sin(a)),CE)
        save(s,f"{root}/textures/particle/slash_{k}.png")
        a=new(4,4); rect(a,1,1,2,2,(40,8,12) if k%2 else (120,20,30)); save(a,f"{root}/textures/particle/domain_ash_{k}.png")
        rr=new(8,8)
        for t in range(16):
            ang=t/16*2*math.pi; P(rr,round(3.5+(1+k*0.8)*math.cos(ang)),round(3.5+(1+k*0.8)*math.sin(ang)),CE)
        save(rr,f"{root}/textures/particle/resonance_{k}.png")
    icons={"cursed_bleed":BLOOD,"sealed":PAPER,"sukuna_takeover":(60,0,0),"cursed_vigor":CE,"warded":BLUE}
    for k,(eid,c) in enumerate(icons.items()):
        i=new(18,18); rect(i,2,2,15,15,shade(c,0.5)); rect(i,3,3,14,14,c); glyph(i,6,5,BLACK,k); outline(i,BLACK)
        save(i,f"{root}/textures/mob_effect/{eid}.png")
    # ability icons 16x16
    for k,(aid,_,_,_,_,_,_) in enumerate(ABILITIES):
        i=new(); rect(i,0,0,15,15,(20,8,12)); rect(i,1,1,14,14,(50,10,20))
        name=aid.lower()
        if name=="dismantle": line(i,3,12,12,3,WHITE); line(i,4,12,12,4,CE)
        elif name=="cleave": line(i,3,3,12,12,WHITE); line(i,3,12,12,3,WHITE)
        elif name=="reverse_cursed_technique": rect(i,7,3,8,12,(120,255,160)); rect(i,3,7,12,8,(120,255,160))
        elif name=="spiderweb":
            for a in range(8): line(i,7,8,round(7+6*math.cos(a*math.pi/4)),round(8+6*math.sin(a*math.pi/4)),WHITE)
        elif name=="fuga": line(i,2,13,13,2,(255,150,40)); P(i,13,2,(255,255,120)); rect(i,10,2,13,5,(255,90,20))
        elif name=="world_slash": line(i,1,8,14,8,WHITE); line(i,1,7,14,7,CE); line(i,1,9,14,9,CE)
        elif name in("blue","red","hollow_purple"):
            col={"blue":(60,140,255),"red":(255,50,50),"hollow_purple":(170,70,255)}[name]
            rect(i,0,0,15,15,(8,8,20)); rect(i,1,1,14,14,(20,20,40))
            for x in range(16):
                for y in range(16):
                    d=math.hypot(x-7.5,y-7.5)
                    if d<5.5: P(i,x,y,mix(col,WHITE,max(0,1-d/3)))
        elif name=="infinity":
            rect(i,0,0,15,15,(8,8,20)); rect(i,1,1,14,14,(20,20,40))
            for k in range(40):
                t=k/40*2*math.pi; P(i,round(7.5+5*math.sin(t)),round(7.5+2.5*math.sin(2*t)),(200,230,255))
        elif name=="blink":
            rect(i,0,0,15,15,(8,8,20)); rect(i,1,1,14,14,(20,20,40)); line(i,3,8,12,8,(200,230,255)); line(i,9,5,12,8,(200,230,255)); line(i,9,11,12,8,(200,230,255))
        elif name=="infinite_void":
            rect(i,0,0,15,15,(4,4,10)); rect(i,1,1,14,14,(10,10,24))
            for k in range(10): P(i,2+k%7*2,2+(k*5)%12,WHITE)
            for x in range(16):
                for y in range(16):
                    if math.hypot(x-7.5,y-7.5)<3: P(i,x,y,(0,0,0))
            line(i,4,8,11,8,(120,180,255))
        else: glyph(i,5,4,CE,1); rect(i,2,12,13,13,BONE)
        save(i,f"{root}/textures/gui/ability/{name}.png")
    # codex background 256x192
    g=new(256,192); noise_fill(g,(30,18,22),0.06,40); rect(g,6,6,249,185,(222,210,186)); noise_fill(g,(222,210,186),0.04,41,8,8,240,176)
    rect(g,127,8,128,183,(150,130,110)); 
    for k in range(256): P(g,k,0,BLACK); P(g,k,191,BLACK)
    for k in range(192): P(g,0,k,BLACK); P(g,255,k,BLACK)
    for x in range(10,246,6): P(g,x,10,CRIMSON); P(g,x,181,CRIMSON)
    save(g,f"{root}/textures/gui/codex.png")
    # reliquary container 176x168 on 256x256
    c=new(256,256); rect(c,0,0,175,167,(28,18,22)); rect(c,1,1,174,166,(70,48,52))
    def slot(x,y): rect(c,x,y,x+17,y+17,(30,20,24)); rect(c,x+1,y+1,x+17,y+17,(110,90,90)); rect(c,x+1,y+1,x+16,y+16,(52,36,40))
    for row in range(3):
        for col in range(9): slot(7+col*18,17+row*18)
    for row in range(3):
        for col in range(9): slot(7+col*18,85+row*18)
    for col in range(9): slot(7+col*18,143)
    for x in range(4,172,8): P(c,x,3,GOLD)
    save(c,f"{root}/textures/gui/reliquary.png")
    # markings 64x64 (player skin layout): dark tattoo layer + emissive layer, spreading with each tier
    for tier in range(1,6):
        ink,glow=sukuna_markings(tier)
        save(ink,f"{root}/textures/entity/markings/markings_{tier}.png")
        save(glow,f"{root}/textures/entity/markings/markings_{tier}_glow.png")
    # mod logo
    L=new(64,64,(12,6,8,255))
    for k in range(4):
        rect(L,6+k*14,6,9+k*14,57,CRIMSON)
    glyph(L,29,26,CE,0); outline(L,BLACK)
    L=L.resize((128,128),0); save(L,root+"/../../kingofcurses_logo.png")


def i_technique(aid):
    from PIL import Image
    base=new()
    icon=Image.open(ICON_DIR+f"/{aid}.png").convert("RGBA")
    base.alpha_composite(icon,(0,0))
    for k in range(16): P(base,k,0,GOLD); P(base,k,15,GOLD); P(base,0,k,GOLD); P(base,15,k,GOLD)
    for (x,y) in ((0,0),(15,0),(0,15),(15,15)): P(base,x,y,CRIMSON)
    return base
ICON_DIR=""
def gen_v103(root):
    global ICON_DIR
    ICON_DIR=root+"/textures/gui/ability"
    for tid,ab,_,_ in TECHNIQUES: save(i_technique(ab.lower()),f"{root}/textures/item/{tid}.png")
    # blindfold item
    i=new()
    for x in range(1,15):
        y=7+int(1.5*math.sin(x/14*math.pi))
        P(i,x,y-1,(30,30,40)); P(i,x,y,(14,14,20)); P(i,x,y+1,(8,8,12))
    rect(i,12,9,13,13,(14,14,20)); rect(i,13,10,14,14,(10,10,14)); P(i,4,6,(70,70,90)); P(i,9,6,(70,70,90))
    outline(i,BLACK); save(i,f"{root}/textures/item/gojo_blindfold.png")
    # blindfold armor layer (helmet uses layer_1): band across the eyes on every side of the head
    L=new(64,32)
    for u in range(0,32):
        P(L,u,11,(16,16,22)); P(L,u,12,(10,10,14))
        if u%5==0: P(L,u,11,(40,40,52))
    rect(L,24,13,26,15,(12,12,16))   # knot tails on the back face
    save(L,f"{root}/textures/models/armor/gojo_blindfold_layer_1.png"); save(new(64,32),f"{root}/textures/models/armor/gojo_blindfold_layer_2.png")
    # gore texture for sliced cut faces
    g=new(); r=random.Random(5)
    for x in range(16):
        for y in range(16):
            d=math.hypot(x-7.5,y-7.5)
            c=(150,12,26) if d>6 else ((196,64,74) if d>3 else (120,8,20))
            if r.random()<0.2: c=(90,4,12)
            P(g,x,y,c)
    rect(g,7,7,8,8,BONE)
    save(g,f"{root}/textures/entity/gore.png")


# ---------------- v1.0.4 ----------------
def i_sukuna_finger():
    """One single look for every finger: a mummified, blackened finger with a talisman band."""
    i=new(); dark=(92,58,52); mid=(132,92,80); hi=(176,136,116)
    pts=[(3,13),(4,12),(5,11),(6,10),(7,9),(8,8),(9,7),(10,6),(11,5),(12,4)]
    for k,(x,y) in enumerate(pts):
        for dx in (-1,0,1):
            for dy in (-1,0,1): P(i,x+dx,y+dy,mid)
        P(i,x-1,y+1,dark); P(i,x+1,y-1,hi)
    for (x,y) in ((6,10),(9,7)):                       # knuckle creases
        P(i,x-1,y,dark); P(i,x,y+1,dark); P(i,x+1,y,(70,40,38))
    rect(i,12,2,13,3,(26,8,12)); P(i,13,2,(10,4,6)); P(i,12,3,(60,16,22))   # black nail
    for (x,y) in ((4,10),(5,11),(5,10),(6,11),(4,11)): P(i,x,y,PAPER)      # talisman band
    P(i,5,12,shade(PAPER,0.8)); P(i,3,11,shade(PAPER,0.8)); P(i,5,10,CRIMSON); P(i,4,11,CRIMSON)
    for (x,y) in ((8,7),(10,5),(11,6)): P(i,x,y,CRIMSON)                   # cursed veins
    rect(i,1,13,3,15,DEEPRED); P(i,2,14,BLOOD); P(i,1,15,(40,2,8))          # torn base
    outline(i,BLACK); return i

def sukuna_markings(tier):
    """Sukuna-style vessel tattoos on the 64x64 player skin layout. Returns (ink, glow)."""
    ink=new(64,64); glow=new(64,64); INKC=(18,6,10); GL=(200,20,40)
    def d(x,y,g=True):
        P(ink,x,y,INKC)
        if g: P(glow,x,y,GL)
    def band(u,v,w,depth,y):
        # a ring around a box part (arm/leg/body) at row y of the side faces
        for x in range(u, u+2*depth+2*w): d(x,y)
    # face (head front u8..15 v8..15): the second pair of eyes lines + cheek stripes + forehead mark
    for x in (9,10,13,14): d(x,13)
    d(8,12); d(15,12); d(8,14); d(15,14)
    d(11,9); d(12,9); d(11,10,False); d(12,10,False)
    # wrists: double band at the bottom of both arms (all four sides)
    for y in (29,31): band(40,20,4,4,y)
    for y in (61,63): band(32,52,4,4,y)
    if tier>=2:
        for y in (12,13): d(0,y); d(1,y); d(6,y); d(7,y)            # right side of head
        for y in (12,13): d(16,y); d(17,y); d(22,y); d(23,y)         # left side
        d(10,15); d(13,15)                                          # chin
        for y in (25,27): band(40,20,4,4,y)                          # forearm bands
        for y in (57,59): band(32,52,4,4,y)
    if tier>=3:
        for x in range(20,28): d(x,22)                              # chest line
        for x in (21,22,25,26): d(x,24)
        for (x,y) in ((22,27),(23,28),(24,28),(25,27)): d(x,y)       # abdomen chevron
        for x in range(32,40): d(x,22)                              # back line
    if tier>=4:
        for y in (21,23): band(40,20,4,4,y)                          # upper arms
        for y in (53,55): band(32,52,4,4,y)
        for y in range(25,31,2): d(32,y); d(39,y)                    # back stripes
        d(9,11); d(14,11)                                            # brow marks
    if tier>=5:
        for x in range(8,16): d(x,8,False)                          # hairline line
        for y in (29,31): band(0,20,4,4,y)                           # ankles
        for y in (61,63): band(16,52,4,4,y)
        for y in range(20,32,2): d(23,y); d(24,y)                    # sternum line
    return ink,glow

def i_cursed_object(kind):
    i=new()
    if kind=="prison_realm":
        for x in range(4,12):
            for y in range(4,12): P(i,x,y,(186,170,140) if (x+y)%2 else (160,140,112))
        rect(i,4,4,11,4,(120,100,80)); rect(i,4,11,11,11,(90,74,60))
        for (x,y) in ((6,6),(9,6),(6,9),(9,9)): P(i,x,y,(40,20,20))
        P(i,7,7,CE); P(i,8,8,CE); P(i,7,8,(255,240,220)); P(i,8,7,(255,240,220))   # the eye
        P(i,3,7,(120,100,80)); P(i,12,8,(120,100,80))
    elif kind=="black_rope":
        for k in range(12):
            x=2+k; y=round(8+3*math.sin(k/2.0))
            P(i,x,y,(20,20,24)); P(i,x,y+1,(44,40,48))
        for k in range(0,12,3): P(i,2+k,round(8+3*math.sin(k/2.0))-1,(70,66,80))
        rect(i,12,3,13,5,(30,30,36))
    elif kind=="death_painting":
        rect(i,3,2,12,13,(70,30,20)); rect(i,4,3,11,12,(170,140,100))
        for x in range(5,11):
            for y in range(5,11):
                if math.hypot(x-7.5,y-7.5)<3: P(i,x,y,(130,30,50))
        P(i,6,7,(255,220,40)); P(i,9,7,(255,220,40)); rect(i,6,9,9,9,(40,4,10))
    elif kind=="cursed_spirit_orb":
        for x in range(16):
            for y in range(16):
                dd=math.hypot(x-7.5,y-7.5)
                if dd<5.5: P(i,x,y,mix((60,50,40),(16,12,10),dd/5.5))
        P(i,6,6,(255,220,40)); P(i,9,8,(255,220,40)); P(i,7,10,(200,40,60)); P(i,5,5,(110,100,90))
    elif kind=="inventory_curse":
        for k in range(10):
            x=3+k; y=round(7+2*math.sin(k/1.6))
            for dy in (-1,0,1): P(i,x,y+dy,(120,70,140) if dy==0 else (80,40,96))
        rect(i,11,3,13,6,(120,70,140)); P(i,12,4,(255,220,40)); P(i,12,5,(20,6,10))
    elif kind=="promise_ring":
        for a in range(20):
            t=a/20*2*math.pi; P(i,round(7.5+4*math.cos(t)),round(9+3*math.sin(t)),(220,220,230))
        for a in range(20):
            t=a/20*2*math.pi; P(i,round(7.5+3*math.cos(t)),round(9+2*math.sin(t)),(150,150,170))
        rect(i,6,3,9,5,(90,40,200)); P(i,7,3,(200,160,255)); P(i,8,4,(160,110,255))
    outline(i,BLACK); return i

def gen_v104(root):
    for oid,_,_ in CURSED_OBJECTS: save(i_cursed_object(oid),f"{root}/textures/item/{oid}.png")


# ---------------- v1.0.5 ----------------
def i_ripped_finger():
    i=i_sukuna_finger()
    for (x,y) in ((1,12),(2,12),(3,12),(1,11),(4,13),(0,14),(2,15),(3,15)): P(i,x,y,(170,10,26))
    for (x,y) in ((13,1),(14,2),(12,1)): P(i,x,y,(170,10,26))
    return i

def vessel_pattern(tier):
    """A tiling pattern of Sukuna's double-line marks; it is stretched over any creature's UV layout."""
    ink=new(64,64); glow=new(64,64); r=random.Random(77+tier)
    n={1:26,2:52,3:90}[tier]
    for _ in range(n):
        x=r.randrange(0,60); y=r.randrange(0,61); L=r.randrange(2,5)
        for k in range(L):
            for yy in (y,y+2):
                P(ink,x+k,yy,(18,6,10)); P(glow,x+k,yy,(200,20,40))
    return ink,glow

def gen_v105(root):
    save(i_ripped_finger(),f"{root}/textures/item/ripped_finger.png")
    for t in (1,2,3):
        ink,glow=vessel_pattern(t)
        save(ink,f"{root}/textures/entity/markings/vessel_{t}.png"); save(glow,f"{root}/textures/entity/markings/vessel_{t}_glow.png")


# ---------------- v1.0.7 ----------------
def gen_v117(root):
    """Heian portal (animated gold/crimson swirl), Sukuna's arm, the gate seal."""
    import os, json as _j
    FR=8; im=new(16,16*FR)
    for f in range(FR):
        for x in range(16):
            for y in range(16):
                dx,dy=x-7.5,y-7.5; d=math.hypot(dx,dy); a=math.atan2(dy,dx)
                v=(math.sin(a*3+d*0.9-f*2*math.pi/FR)+1)/2
                c=mix((250,200,70),(170,20,30),v*0.8)
                P(im,x,16*f+y,c+(int(150+80*v),))
    save(im,f"{root}/textures/block/heian_portal.png")
    _j.dump({"animation":{"frametime":2,"interpolate":True}},open(f"{root}/textures/block/heian_portal.png.mcmeta","w"))
    arm=new(); SK=(222,180,156); NAIL=(20,8,12)
    for k in range(12):
        x,y=2+k,13-k
        for dx in (-1,0,1):
            for dy in (-1,0,1): P(arm,x+dx,y+dy,shade(SK,0.9+0.08*dy))
    for k in (2,5,8): line(arm,1+k,14-k,3+k,12-k,BLACK)          # tattoo bands
    rect(arm,12,1,14,3,shade(SK,1.05)); P(arm,14,0,NAIL); P(arm,15,1,NAIL); P(arm,13,0,NAIL)   # hand + black nails
    rect(arm,0,14,2,15,(140,10,24)); P(arm,1,13,BLOOD)              # torn end
    outline(arm,BLACK); save(arm,f"{root}/textures/item/sukuna_arm.png")
    clue=new()
    rect(clue,3,2,12,13,(222,208,176)); rect(clue,4,3,11,12,(236,224,196))                           # torn paper
    for (x,y) in ((3,2),(12,13),(12,5),(3,10)): P(clue,x,y,(0,0,0,0))
    line(clue,5,5,10,5,(60,40,40)); line(clue,5,7,9,7,(60,40,40)); line(clue,5,9,10,9,(60,40,40))
    glyph(clue,6,4,CRIMSON,2); P(clue,10,11,CE); P(clue,11,11,CE)
    outline(clue,BLACK); save(clue,f"{root}/textures/item/sukuna_clue.png")
    seal=new()
    for x in range(16):
        for y in range(16):
            d=math.hypot(x-7.5,y-7.5)
            if d<7: P(seal,x,y,(214,170,70) if d>5.6 else (240,206,110))
    rect(seal,4,5,11,5,LACQUER); rect(seal,3,4,12,4,(40,10,12)); rect(seal,5,6,5,11,LACQUER); rect(seal,10,6,10,11,LACQUER); rect(seal,5,7,10,7,LACQUER)
    rect(seal,6,8,9,11,(250,210,90))
    outline(seal,BLACK); save(seal,f"{root}/textures/item/heian_seal.png")

def gen_v107(root):
    """Heian Sukuna's second pair of eyes, on the face of the 64x64 player skin, right under the normal eyes."""
    eyes=new(64,64); glow=new(64,64)
    SCL=(232,226,218); IRIS=(200,16,32); LID=(20,6,10)
    for (sx,ix) in ((9,10),(14,13)):
        P(eyes,sx,13,SCL); P(eyes,ix,13,IRIS); P(glow,ix,13,(255,30,50))
        P(eyes,sx,14,LID); P(eyes,ix,14,LID)
    # the same eyes on the hat layer would double them, so only the base head face is painted
    save(eyes,f"{root}/textures/entity/markings/sukuna_eyes.png"); save(glow,f"{root}/textures/entity/markings/sukuna_eyes_glow.png")
