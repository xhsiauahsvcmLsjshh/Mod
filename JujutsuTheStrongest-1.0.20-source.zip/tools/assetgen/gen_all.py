"""Regenerates all assets + data into ../../src/main/resources (run from this folder)."""
import os, shutil, sys
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
PROJECT=os.path.abspath(os.path.join(HERE,'..','..'))
root=os.path.join(PROJECT,'src','main','resources'); A=os.path.join(root,'assets','kingofcurses')
for d in ('assets','data'): shutil.rmtree(os.path.join(root,d),ignore_errors=True)
import textures, entities_art, sounds, structures, gen_data, gen_java_reg
textures.gen_block_textures(A); textures.gen_item_textures(A); textures.gen_armor(A); textures.gen_misc(A)
entities_art.write_all(A); textures.gen_v103(A); textures.gen_v104(A); textures.gen_v105(A); textures.gen_v107(A); textures.gen_v117(A); sounds.write(A); structures.write_all(root); gen_data.run(root)
gen_java_reg.gen(PROJECT)
print("done")
