import numpy as np, os, subprocess
from scipy.io import wavfile
from scipy.signal import butter, lfilter
SR=22050
rng=np.random.default_rng(7)
def t(d): return np.arange(int(SR*d))/SR
def env(n,a=0.01,r=0.3):
    e=np.ones(n); A=int(SR*a); R=int(SR*r)
    if A>0: e[:A]=np.linspace(0,1,A)
    if R>0 and R<n: e[-R:]*=np.linspace(1,0,R)**2
    return e
def bp(x,lo,hi): b,a=butter(2,[lo/(SR/2),min(hi/(SR/2),0.99)],btype='band'); return lfilter(b,a,x)
def lp(x,f): b,a=butter(2,f/(SR/2),btype='low'); return lfilter(b,a,x)
def hp(x,f): b,a=butter(2,f/(SR/2),btype='high'); return lfilter(b,a,x)
def noise(d): return rng.standard_normal(int(SR*d))
def reverb(x,decay=0.4,delays=(0.031,0.047,0.071,0.093)):
    y=np.concatenate([x,np.zeros(int(SR*0.8))])
    for dl in delays:
        for rep in range(1,6):
            D=int(SR*dl*rep)
            seg=x[:max(0,len(y)-D)]
            y[D:D+len(seg)]+=seg*(decay**rep)*0.5
    return y
def fit(x,n): return np.pad(x,(0,max(0,n-len(x))))[:n]
def slash(d=0.35,lo=2500,hi=9000):
    n=noise(d); tt=t(d); sweep=bp(n,lo,hi)*np.exp(-tt*9)
    return sweep*env(len(sweep),0.002,0.15)
def voice(f0,d,formants=((600,1000),(800,1400)),vib=4,grit=0.2):
    tt=t(d); f=f0*(1+0.03*np.sin(2*np.pi*vib*tt)); ph=np.cumsum(2*np.pi*f/SR)
    saw=2*((ph/(2*np.pi))%1)-1; x=saw+grit*noise(d)
    out=sum(bp(x,lo,hi) for lo,hi in formants); return out*env(len(out),0.05,0.3)
def norm(x,g=0.9): return x/(np.max(np.abs(x))+1e-9)*g
def S():
    s={}
    s["dismantle"]=slash(0.4)
    s["cleave"]=np.concatenate([slash(0.25,1800,7000),slash(0.35,1500,8000)])
    s["domain_slash"]=slash(0.18,3000,10000)
    s["cinematic_slash"]=reverb(np.concatenate([slash(0.9,800,9000)*1.0+0.6*lp(noise(0.9),200)*np.exp(-t(0.9)*4)]),0.55)
    s["world_slash"]=reverb(slash(1.8,600,10000)+0.5*np.sin(2*np.pi*55*t(1.8))*np.exp(-t(1.8)*2),0.5)
    s["sukuna_roar"]=reverb(voice(70,2.2,((200,500),(500,900)),6,0.6)+0.4*lp(noise(2.2),300)*env(int(SR*2.2),0.2,0.8))
    ha=[]
    for k,f in enumerate((140,135,130,128,120,112)):
        ha.append(voice(f,0.18,((500,900),(1000,1600)),0,0.15)); ha.append(np.zeros(int(SR*0.07)))
    s["sukuna_laugh"]=reverb(np.concatenate(ha),0.35)
    s["sukuna_voice"]=reverb(np.concatenate([voice(85,0.5,((300,700),(900,1300))),voice(78,0.4,((400,800),(1000,1500))),voice(70,0.7,((250,600),(700,1100)))]),0.4)
    tt=t(1.2); s["fuga_ignite"]=bp(noise(1.2),300,4000)*np.linspace(0,1,len(tt))**1.5*env(len(tt),0.01,0.2)+0.3*np.sign(noise(1.2))*(rng.random(len(tt))>0.995)
    tt=t(1.6); s["fuga_explode"]=reverb(lp(noise(1.6),400)*np.exp(-tt*3)+np.sin(2*np.pi*45*tt)*np.exp(-tt*2.5),0.5)
    tt=t(4.0); drone=sum(np.sin(2*np.pi*f*tt)*a for f,a in ((55,1),(82.4,0.6),(110,0.4),(116.5,0.3),(164.8,0.25)))
    bell=np.sin(2*np.pi*440*tt)*np.exp(-tt*1.2)*0.5+np.sin(2*np.pi*660*tt)*np.exp(-tt*1.5)*0.3
    s["domain_expansion"]=reverb(drone*env(len(tt),1.0,1.2)+bell,0.6)
    crunch=np.concatenate([bp(noise(0.08),800,5000)*np.exp(-t(0.08)*30) if k%2==0 else np.zeros(int(SR*0.06)) for k in range(12)])
    s["finger_eat"]=crunch+0.3*lp(noise(len(crunch)/SR),150)
    def thump(): tt=t(0.18); return np.sin(2*np.pi*(60-80*tt)*tt)*np.exp(-tt*25)
    s["heartbeat"]=np.concatenate([thump(),np.zeros(int(SR*0.12)),thump()*0.7,np.zeros(int(SR*0.35))])
    tt=t(2.5); s["cinematic_sting"]=reverb(sum(np.sin(2*np.pi*f*tt) for f in (98,103.8,146.8,207.6))*env(len(tt),0.02,1.5)*np.exp(-tt*0.6),0.6)
    tt=t(2.0); s["gojo_infinity"]=reverb(sum(np.sin(2*np.pi*f*tt+np.sin(2*np.pi*0.5*tt)*k) for k,f in enumerate((880,1318,1760,2637)))*env(len(tt),0.4,0.8)*0.4,0.5)
    tt=t(0.5); s["blood_splatter"]=lp(noise(0.5),1200)*np.exp(-tt*10)*(1+0.5*np.sin(2*np.pi*30*tt))
    tt=t(2.0); s["curse_ambient"]=bp(noise(2.0),300,2500)*(0.5+0.5*np.sin(2*np.pi*3*tt))**2*env(len(tt),0.3,0.6)
    tt=t(0.45); s["curse_hurt"]=voice(380,0.45,((1200,2400),(2500,3500)),18,0.5)
    tt=t(1.1); f=np.linspace(420,90,len(tt)); ph=np.cumsum(2*np.pi*f/SR); s["curse_death"]=reverb(bp(np.sign(np.sin(ph))+0.4*noise(1.1),300,3000)*env(len(tt),0.01,0.5),0.4)
    s["sorcerer_hurt"]=voice(150,0.3,((500,900),(1100,1700)),0,0.2)
    s["sorcerer_death"]=voice(130,0.9,((400,800),(900,1400)),3,0.25)*np.linspace(1,0.2,int(SR*0.9))
    tt=t(1.3); s["rct_heal"]=reverb(sum(np.sin(2*np.pi*f*(1+tt*0.5)*tt) for f in (523,659,784))*env(len(tt),0.1,0.6)*0.35,0.5)
    s["takeover"]=reverb(fit(np.concatenate([s["heartbeat"],s["heartbeat"]*1.3]),int(SR*2))+0.6*fit(voice(60,2.0,((150,400),(400,800)),8,0.8),int(SR*2)),0.5)
    tt=t(0.7); s["resonance_pulse"]=np.sin(2*np.pi*110*tt)*np.exp(-tt*5)+0.3*np.sin(2*np.pi*220*tt)*np.exp(-tt*7)
    tt=t(3.0); s["seal_ritual"]=reverb(np.sin(2*np.pi*392*tt)*np.exp(-tt*1)+0.4*voice(110,3.0,((400,800),(800,1200)),2,0.05),0.6)
    tt=t(1.0); s["cursed_energy_burst"]=bp(noise(1.0),200,3000)*np.exp(-tt*4)+np.sin(2*np.pi*(80+200*tt)*tt)*np.exp(-tt*3)*0.6
    # boss theme ~24s taiko + drone
    L=24; tt=t(L); drone=0.3*np.sin(2*np.pi*55*tt)+0.2*np.sin(2*np.pi*82.4*tt)+0.12*np.sin(2*np.pi*116.5*tt)
    beat=np.zeros(len(tt)); pat=[0,0.5,0.75,1.5,2.0,2.5,2.75,3.5]
    for bar in range(L//4):
        for p in pat:
            st=int((bar*4+p)*SR*0.5); d=thump(); d=d*(1.4 if p in(0,2.0) else 0.8)
            if st+len(d)<len(beat): beat[st:st+len(d)]+=d
    s["boss_theme"]=drone*env(len(tt),2,2)+beat
    return s
def write(root):
    os.makedirs(f"{root}/sounds",exist_ok=True)
    for k,v in S().items():
        v=norm(np.nan_to_num(v),0.85); w=f"/tmp/{k}.wav"; wavfile.write(w,SR,(v*32767).astype(np.int16))
        subprocess.run(["ffmpeg","-y","-loglevel","error","-i",w,"-ac","1","-c:a","libvorbis","-q:a","3",f"{root}/sounds/{k}.ogg"],check=True)
if __name__=="__main__":
    write("/tmp/snd"); print(sorted(os.listdir("/tmp/snd/sounds")))
