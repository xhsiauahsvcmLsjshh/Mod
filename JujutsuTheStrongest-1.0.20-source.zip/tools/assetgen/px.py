import random, math
from PIL import Image
BLACK=(16,10,14); INK=(28,18,24); CRIMSON=(150,14,32); BLOOD=(110,6,18); DEEPRED=(70,4,12)
CE=(255,42,64); PURPLE=(52,18,64); PURPLE2=(84,30,98); BONE=(226,218,196); BONE2=(196,186,160)
GRAY=(92,88,92); STONE=(118,112,112); WOOD=(58,32,30); WOOD2=(82,46,40); LACQUER=(176,26,30)
GOLD=(196,160,72); PAPER=(232,224,200); SKIN=(222,186,160); WHITE=(245,245,250); BLUE=(70,140,230)
def clamp(v): return max(0,min(255,int(v)))
def shade(c,f): return tuple(clamp(x*f) for x in c[:3])
def mix(a,b,t): return tuple(clamp(a[i]*(1-t)+b[i]*t) for i in range(3))
def new(w=16,h=16,c=(0,0,0,0)): return Image.new("RGBA",(w,h),c)
def P(img,x,y,c):
    if 0<=x<img.width and 0<=y<img.height:
        img.putpixel((int(x),int(y)), c if len(c)==4 else c+(255,))
def rect(img,x0,y0,x1,y1,c):
    for x in range(x0,x1+1):
        for y in range(y0,y1+1): P(img,x,y,c)
def line(img,x0,y0,x1,y1,c):
    n=max(abs(x1-x0),abs(y1-y0),1)
    for i in range(n+1):
        P(img,round(x0+(x1-x0)*i/n),round(y0+(y1-y0)*i/n),c)
def noise_fill(img,base,amp=0.12,seed=0,x0=0,y0=0,w=None,h=None):
    r=random.Random(seed); w=w or img.width; h=h or img.height
    for x in range(x0,x0+w):
        for y in range(y0,y0+h):
            P(img,x,y,shade(base,1+r.uniform(-amp,amp)))
def outline(img,c):
    src=img.copy()
    for x in range(img.width):
        for y in range(img.height):
            if src.getpixel((x,y))[3]==0:
                for dx,dy in((1,0),(-1,0),(0,1),(0,-1)):
                    xx,yy=x+dx,y+dy
                    if 0<=xx<img.width and 0<=yy<img.height and src.getpixel((xx,yy))[3]>0 and src.getpixel((xx,yy))[:3]!=c:
                        P(img,x,y,c); break
GLYPHS=[ # 5x7 kanji-like stroke glyphs
 ["#####","..#..","#####","..#..",".###.","#.#.#","..#.."],
 ["..#..","#####","#...#","#####","#...#","#####","#...#"],
 [".#.#.","#####",".#.#.","#####","..#..","#.#.#","#...#"],
 ["#####","#.#.#","#####","..#..","#####","..#..","##.##"],
]
def glyph(img,ox,oy,c,k=0):
    g=GLYPHS[k%len(GLYPHS)]
    for y,row in enumerate(g):
        for x,ch in enumerate(row):
            if ch=="#": P(img,ox+x,oy+y,c)
