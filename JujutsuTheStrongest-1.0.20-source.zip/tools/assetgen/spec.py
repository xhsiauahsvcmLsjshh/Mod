MODID = "kingofcurses"
PKG = "com.kingofcurses"

# ---------------- BLOCKS ----------------
# (id, kind, props_code, tool, en, it, extra)
BLOCKS = [
 ("cursed_sand","csand","Properties.copy(Blocks.SAND).mapColor(MapColor.COLOR_RED).strength(0.6f).lightLevel(st -> 4).pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK)","shovel","Cursed Sand","Sabbia Maledetta",{}),
 ("heian_portal","hportal","Properties.of().noCollission().strength(-1.0f, 3600000.0f).lightLevel(s -> 15).noLootTable().noOcclusion().sound(net.minecraft.world.level.block.SoundType.GLASS).pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK)","pickaxe","Heian Era Portal","Portale dell'Era Heian",{}),
 ("temple_stone","cube","Properties.copy(Blocks.STONE).mapColor(MapColor.COLOR_GRAY)","pickaxe","Temple Stone","Pietra del Tempio",{}),
 ("temple_stone_bricks","cube","Properties.copy(Blocks.STONE_BRICKS)","pickaxe","Temple Stone Bricks","Mattoni di Pietra del Tempio",{}),
 ("cracked_temple_stone_bricks","cube","Properties.copy(Blocks.CRACKED_STONE_BRICKS)","pickaxe","Cracked Temple Stone Bricks","Mattoni del Tempio Incrinati",{}),
 ("chiseled_temple_stone","cube","Properties.copy(Blocks.CHISELED_STONE_BRICKS)","pickaxe","Chiseled Temple Stone","Pietra del Tempio Cesellata",{}),
 ("polished_temple_stone","cube","Properties.copy(Blocks.POLISHED_ANDESITE)","pickaxe","Polished Temple Stone","Pietra del Tempio Levigata",{}),
 ("cursed_wood_planks","cube","Properties.copy(Blocks.DARK_OAK_PLANKS)","axe","Cursed Wood Planks","Assi di Legno Maledetto",{}),
 ("black_lacquer_planks","cube","Properties.copy(Blocks.DARK_OAK_PLANKS).mapColor(MapColor.COLOR_BLACK)","axe","Black Lacquer Planks","Assi Laccate Nere",{}),
 ("torii_beam","cube","Properties.copy(Blocks.DARK_OAK_PLANKS).mapColor(MapColor.COLOR_RED)","axe","Torii Beam","Trave del Torii",{}),
 ("shrine_roof_tiles","cube","Properties.copy(Blocks.DEEPSLATE_TILES)","pickaxe","Shrine Roof Tiles","Tegole del Santuario",{}),
 ("cursed_seal_block","cube","Properties.copy(Blocks.STONE_BRICKS).strength(3.0f, 12.0f).lightLevel(s -> 4)","pickaxe","Cursed Seal Block","Blocco del Sigillo Maledetto",{}),
 ("bone_white_plaster","cube","Properties.copy(Blocks.CALCITE)","pickaxe","Bone-White Plaster","Intonaco Bianco Osso",{}),
 ("crimson_tatami","cube","Properties.copy(Blocks.HAY_BLOCK).mapColor(MapColor.COLOR_RED)","hoe","Crimson Tatami","Tatami Cremisi",{}),
 ("talisman_wall","cube","Properties.copy(Blocks.WHITE_WOOL).strength(1.0f)","axe","Talisman Wall","Muro di Talismani",{}),
 ("blood_soaked_soil","cube","Properties.copy(Blocks.DIRT).mapColor(MapColor.COLOR_RED)","shovel","Blood-Soaked Soil","Terra Intrisa di Sangue",{}),
 ("cursed_soil","cube","Properties.copy(Blocks.COARSE_DIRT).mapColor(MapColor.COLOR_PURPLE)","shovel","Cursed Soil","Terra Maledetta",{}),
 ("cursed_bone_pile","cube","Properties.copy(Blocks.BONE_BLOCK)","pickaxe","Cursed Bone Pile","Cumulo di Ossa Maledette",{}),
 ("sealing_stone","cube","Properties.copy(Blocks.OBSIDIAN).strength(20.0f, 1200.0f)","pickaxe","Sealing Stone","Pietra Sigillante",{}),
 ("cursed_energy_crystal_block","cube","Properties.copy(Blocks.AMETHYST_BLOCK).lightLevel(s -> 9).mapColor(MapColor.COLOR_RED)","pickaxe","Cursed Energy Crystal Block","Blocco di Cristallo di Energia Maledetta",{}),
 ("cursed_crystal_ore","ore","Properties.copy(Blocks.IRON_ORE).lightLevel(s -> 3)","pickaxe","Cursed Crystal Ore","Minerale di Cristallo Maledetto",{}),
 ("deepslate_cursed_crystal_ore","ore","Properties.copy(Blocks.DEEPSLATE_IRON_ORE).lightLevel(s -> 3)","pickaxe","Deepslate Cursed Crystal Ore","Minerale di Cristallo Maledetto di Ardesia",{}),
 ("cursed_wood_log","pillar","Properties.copy(Blocks.DARK_OAK_LOG)","axe","Cursed Wood Log","Tronco di Legno Maledetto",{}),
 ("stripped_cursed_wood_log","pillar","Properties.copy(Blocks.STRIPPED_DARK_OAK_LOG)","axe","Stripped Cursed Wood Log","Tronco Scortecciato Maledetto",{}),
 ("torii_pillar","pillar","Properties.copy(Blocks.DARK_OAK_LOG).mapColor(MapColor.COLOR_RED)","axe","Torii Pillar","Pilastro del Torii",{}),
 ("temple_stone_pillar","pillar","Properties.copy(Blocks.QUARTZ_PILLAR)","pickaxe","Temple Stone Pillar","Pilastro di Pietra del Tempio",{}),
 ("temple_stone_stairs","stairs","temple_stone","pickaxe","Temple Stone Stairs","Scale di Pietra del Tempio",{}),
 ("temple_stone_brick_stairs","stairs","temple_stone_bricks","pickaxe","Temple Stone Brick Stairs","Scale di Mattoni del Tempio",{}),
 ("cursed_wood_stairs","stairs","cursed_wood_planks","axe","Cursed Wood Stairs","Scale di Legno Maledetto",{}),
 ("shrine_roof_stairs","stairs","shrine_roof_tiles","pickaxe","Shrine Roof Stairs","Scale di Tegole del Santuario",{}),
 ("temple_stone_slab","slab","temple_stone","pickaxe","Temple Stone Slab","Lastra di Pietra del Tempio",{}),
 ("temple_stone_brick_slab","slab","temple_stone_bricks","pickaxe","Temple Stone Brick Slab","Lastra di Mattoni del Tempio",{}),
 ("cursed_wood_slab","slab","cursed_wood_planks","axe","Cursed Wood Slab","Lastra di Legno Maledetto",{}),
 ("shrine_roof_slab","slab","shrine_roof_tiles","pickaxe","Shrine Roof Slab","Lastra di Tegole del Santuario",{}),
 ("temple_stone_brick_wall","wall","temple_stone_bricks","pickaxe","Temple Stone Brick Wall","Muretto di Mattoni del Tempio",{}),
 ("cursed_wood_fence","fence","cursed_wood_planks","axe","Cursed Wood Fence","Staccionata di Legno Maledetto",{}),
 ("cursed_wood_fence_gate","fence_gate","cursed_wood_planks","axe","Cursed Wood Fence Gate","Cancello di Legno Maledetto",{}),
 ("cursed_leaves","leaves","Properties.copy(Blocks.DARK_OAK_LEAVES).mapColor(MapColor.COLOR_RED)","hoe","Cursed Leaves","Foglie Maledette",{}),
 ("shrine_lantern","lantern","Properties.copy(Blocks.LANTERN).lightLevel(s -> 15).noOcclusion()","pickaxe","Shrine Lantern","Lanterna del Santuario",{}),
 ("reliquary","reliquary","Properties.copy(Blocks.CHEST).strength(3.5f).sound(SoundType.WOOD)","axe","Cursed Reliquary","Reliquiario Maledetto",{}),
 ("disturbed_soil","burial","Properties.copy(Blocks.DIRT).strength(0.8f)","shovel","Disturbed Soil","Terra Smossa",{}),
 ("cursed_spike_trap","trap","Properties.copy(Blocks.STONE).strength(2.5f).noOcclusion()","pickaxe","Cursed Spike Trap","Trappola a Punte Maledetta",{}),
 ("malevolent_altar","altar","Properties.copy(Blocks.STONE_BRICKS).lightLevel(s -> 6).strength(4.0f, 9.0f)","pickaxe","Malevolent Altar","Altare Malevolo",{}),
]

# ---------------- ITEMS ----------------
# v1.0.4: every finger is the same item. The old numbered ids stay registered only to convert old saves.
FINGER = ("sukuna_finger", "Sukuna's Finger", "Dito di Sukuna")
LEGACY_FINGERS = ["sukuna_finger_%d" % i for i in range(1, 21)]
FINGERS = [FINGER]
# Cursed objects (id, en, it)
CURSED_OBJECTS = [
 ("prison_realm","Prison Realm","Regno della Prigione"),
 ("black_rope","Black Rope","Corda Nera"),
 ("death_painting","Death Painting","Dipinto della Morte"),
 ("cursed_spirit_orb","Cursed Spirit Orb","Sfera di Spirito Maledetto"),
 ("inventory_curse","Inventory Curse","Maledizione Inventario"),
 ("promise_ring","Yuta's Promise Ring","Anello della Promessa di Yuta"),
]

MATERIALS = [
 ("cursed_energy_shard","Cursed Energy Shard","Frammento di Energia Maledetta"),
 ("curse_residue","Curse Residue","Residuo di Maledizione"),
 ("bone_white_fragment","Bone-White Fragment","Frammento Bianco Osso"),
 ("crimson_thread","Crimson Thread","Filo Cremisi"),
 ("jujutsu_cloth","Jujutsu Cloth","Stoffa Jujutsu"),
 ("cursed_ink","Cursed Ink","Inchiostro Maledetto"),
 ("blank_talisman","Blank Talisman","Talismano Vuoto"),
 ("special_grade_core","Special-Grade Core","Nucleo di Grado Speciale"),
]
TALISMANS = [
 ("sealing_talisman","SEALING","Sealing Talisman","Talismano Sigillante"),
 ("warding_talisman","WARDING","Warding Talisman","Talismano di Protezione"),
 ("binding_talisman","BINDING","Binding Talisman","Talismano Vincolante"),
 ("flame_talisman","FLAME","Flame Talisman","Talismano di Fiamma"),
]
VIALS = [
 ("cursed_energy_vial",60,0,"Cursed Energy Vial","Fiala di Energia Maledetta"),
 ("greater_cursed_energy_vial",200,0,"Greater Cursed Energy Vial","Fiala Superiore di Energia Maledetta"),
 ("reverse_curse_tonic",0,12,"Reverse Curse Tonic","Tonico di Maledizione Inversa"),
]
# (id, tier, dmg, speed, perk, en, it)
WEAPONS = [
 ("cursed_katana","CURSED",4,-2.4,"NONE","Cursed Katana","Katana Maledetta"),
 ("slaughter_demon","CURSED",2,-1.6,"BLEED","Slaughter Demon","Demone del Massacro"),
 ("inverted_spear_of_heaven","SPECIAL",4,-2.6,"NULLIFY","Inverted Spear of Heaven","Lancia Celeste Invertita"),
 ("playful_cloud","SPECIAL",6,-3.0,"KNOCKBACK","Playful Cloud","Nuvola Giocosa"),
 ("chain_of_a_thousand_miles","CURSED",3,-2.2,"PULL","Chain of a Thousand Miles","Catena dei Mille Miglia"),
 ("split_soul_katana","SPECIAL",5,-2.4,"SOUL","Split Soul Katana","Katana Spacca-Anime"),
 ("dragon_bone","SPECIAL",6,-2.8,"CURSE_SLAYER","Dragon-Bone","Osso di Drago"),
 ("kings_cleaver","SPECIAL",7,-2.9,"CLEAVER","King's Cleaver","Mannaia del Re"),
]
TOOLS = [
 ("cursed_pickaxe","pickaxe","Cursed Pickaxe","Piccone Maledetto"),
 ("cursed_axe","axe","Cursed Axe","Ascia Maledetta"),
 ("cursed_shovel","shovel","Cursed Shovel","Pala Maledetta"),
 ("cursed_hoe","hoe","Cursed Hoe","Zappa Maledetta"),
]
ARMOR_SETS = [
 ("jujutsu_uniform","JUJUTSU_UNIFORM","Jujutsu High Uniform","Uniforme della Jujutsu High"),
 ("cursed_armor","CURSED_ARMOR","Cursed Armor","Armatura Maledetta"),
 ("sukuna_robes","SUKUNA_ROBES","Sukuna's Robes","Vesti di Sukuna"),
]
ARMOR_PIECES = [("helmet","HELMET","Hood","Cappuccio"),("chestplate","CHESTPLATE","Jacket","Giacca"),("leggings","LEGGINGS","Hakama","Hakama"),("boots","BOOTS","Sandals","Sandali")]
ARMOR_PIECE_NAMES = {
 "jujutsu_uniform": {"helmet":("Jujutsu High Cap","Berretto della Jujutsu High"),"chestplate":("Jujutsu High Jacket","Giacca della Jujutsu High"),"leggings":("Jujutsu High Trousers","Pantaloni della Jujutsu High"),"boots":("Jujutsu High Shoes","Scarpe della Jujutsu High")},
 "cursed_armor": {"helmet":("Cursed Kabuto","Kabuto Maledetto"),"chestplate":("Cursed Do","Do Maledetto"),"leggings":("Cursed Haidate","Haidate Maledetti"),"boots":("Cursed Suneate","Suneate Maledetti")},
 "sukuna_robes": {"helmet":("Sukuna's Headwrap","Fascia di Sukuna"),"chestplate":("Sukuna's Kimono","Kimono di Sukuna"),"leggings":("Sukuna's Hakama","Hakama di Sukuna"),"boots":("Sukuna's Geta","Geta di Sukuna")},
}

# ---------------- ENTITIES ----------------
# (id, javaClassFactory, category, w, h, hp, dmg, speed, armor, egg_bg, egg_fg, en, it, grade, plan)
ENTITIES = [
 ("ryomen_sukuna","SUKUNA","MONSTER",0.6,1.95,500,12,0.32,10,0x1a0505,0xb3122e,"Ryomen Sukuna","Ryomen Sukuna","special","humanoid"),
 ("sukuna_true_form","SUKUNA","MONSTER",0.9,2.6,800,18,0.34,16,0x0c0202,0xe0233f,"Sukuna (True Form)","Sukuna (Forma Vera)","special","humanoid"),
 ("gojo_satoru","GOJO","MONSTER",0.6,1.95,500,10,0.32,10,0x111122,0xf2f2ff,"Gojo Satoru","Gojo Satoru","special","humanoid"),
 ("fly_head","CURSE","MONSTER",0.7,0.7,8,2,0.30,0,0x3a2f2a,0x8a1c1c,"Fly Head","Testa di Mosca","grade_4","blob"),
 ("crawling_eye","CURSE","MONSTER",0.9,0.6,10,3,0.28,0,0x2d1f33,0xd9d4c5,"Crawling Eye","Occhio Strisciante","grade_4","crawler"),
 ("roppongi_curse","CURSE","MONSTER",1.0,1.8,30,5,0.26,2,0x2b2b2b,0x6b1f5e,"Roppongi Curse","Maledizione di Roppongi","grade_3","humanoid"),
 ("lantern_hag","CURSE","MONSTER",0.7,2.4,28,4,0.24,2,0x1f1a14,0xff7a1a,"Lantern Hag","Strega della Lanterna","grade_3","humanoid"),
 ("hanged_bride","CURSE","MONSTER",0.7,2.2,45,6,0.25,4,0xe8e4da,0x5a0d1a,"Hanged Bride","Sposa Impiccata","grade_2","humanoid"),
 ("bone_centipede","CURSE","MONSTER",1.4,0.9,80,8,0.33,6,0xd9d0bd,0x2a0f12,"Bone Centipede","Centopiedi d'Osso","grade_1","serpent"),
 ("finger_bearer","SPECIAL","MONSTER",1.6,2.2,160,10,0.27,8,0x3d0c12,0xd9d0bd,"Finger Bearer","Portatore del Dito","special","crawler"),
 ("smallpox_deity","SPECIAL","MONSTER",1.8,3.0,220,12,0.22,10,0x4a3b2b,0x9e8f6a,"Smallpox Deity","Divinita del Vaiolo","special","humanoid"),
 ("cursed_womb","SPECIAL","MONSTER",1.4,1.6,200,9,0.20,6,0x5c1027,0xff4f6d,"Cursed Womb","Grembo Maledetto","special","floating"),
 ("shrine_warden","SPECIAL","MONSTER",1.4,3.2,300,15,0.26,14,0x14090a,0xb08d57,"Shrine Warden","Guardiano del Santuario","special","humanoid"),
 ("jujutsu_sorcerer","SORCERER","MONSTER",0.6,1.95,40,6,0.30,4,0x101018,0x2f63c9,"Jujutsu Sorcerer","Stregone Jujutsu","grade_2","humanoid"),
 ("sorcerer_elite","SORCERER","MONSTER",0.6,1.95,90,9,0.32,8,0x0a0a12,0xc9b02f,"Grade 1 Sorcerer","Stregone di Grado 1","grade_1","humanoid"),
 ("jujutsu_student","SORCERER","CREATURE",0.6,1.85,28,4,0.30,2,0x1b1b2b,0xdfe3ea,"Jujutsu High Student","Studente della Jujutsu High","grade_4","humanoid"),
 ("gojo_kenjaku","GOJOBOSS","MONSTER",0.6,1.95,900,14,0.34,14,0x0e0e1a,0x7a2ad6,"Gojo Satoru (Yuta, Kenjaku's technique)","Gojo Satoru (Yuta, tecnica di Kenjaku)","special","humanoid"),
 ("yuta_okkotsu","NAMED","CREATURE",0.6,1.9,170,9,0.33,8,0x0f0f14,0xeeeeee,"Yuta Okkotsu","Yuta Okkotsu","special","humanoid"),
 ("kinji_hakari","NAMED","CREATURE",0.6,1.95,160,9,0.32,8,0x161618,0x3c968c,"Kinji Hakari","Kinji Hakari","special","humanoid"),
 ("maki_zenin","NAMED","CREATURE",0.6,1.85,130,10,0.38,10,0x141a18,0xaa1420,"Maki Zen'in","Maki Zen'in","grade_1","humanoid"),
 ("megumi_fushiguro","NAMED","CREATURE",0.6,1.85,120,7,0.31,6,0x12121e,0x28205a,"Megumi Fushiguro","Megumi Fushiguro","grade_1","humanoid"),
 ("aoi_todo","NAMED","CREATURE",0.75,2.3,180,12,0.31,10,0xc49676,0x1e1e2c,"Aoi Todo","Aoi Todo","grade_1","humanoid"),
 ("kento_nanami","NAMED","CREATURE",0.6,1.95,150,10,0.30,10,0xc8b896,0xaa7832,"Kento Nanami","Kento Nanami","grade_1","humanoid"),
 ("sealing_master","BOSS","MONSTER",0.7,2.1,450,14,0.30,12,0xf0ead8,0x2c2c6e,"Tengen's Sealing Master","Maestro del Sigillo di Tengen","special","humanoid"),
 ("malevolent_shrine","SHRINE","MISC",6.0,7.0,0,0,0,0,0,0,"Malevolent Shrine","Santuario Malevolo","",""),
 ("dismantle_slash","DISMANTLE","MISC",0.9,0.5,0,0,0,0,0,0,"Dismantle","Smantellamento","",""),
 ("fuga_arrow","FUGA","MISC",0.5,0.5,0,0,0,0,0,0,"Fuga","Fuga","",""),
 ("sliced_corpse","SLICED","MISC",0.6,0.6,0,0,0,0,0,0,"Sliced Remains","Resti Tagliati","",""),
 ("toji_fushiguro","TOJI","MONSTER",0.6,1.95,320,14,0.36,8,0x101014,0x76399a,"Toji Fushiguro","Toji Fushiguro","special","humanoid"),
 ("suguru_geto","GETO","CREATURE",0.6,1.95,300,10,0.3,10,0x15151c,0xc8a050,"Suguru Geto","Suguru Geto","special","humanoid"),
 ("curse_user","CURSEUSER","MONSTER",0.6,1.95,60,7,0.3,4,0x0d0a10,0x8a1020,"Curse User","Utilizzatore di Maledizioni","grade_2","humanoid"),
 ("heian_sukuna","HEIAN","MONSTER",1.6,4.2,2000,30,0.0,30,0xd8a640,0x8a0c1a,"Sukuna of the Heian Era","Sukuna dell'Era Heian","special","humanoid"),
 ("sukuna_arm_thrown","ARM","MISC",0.8,0.8,0,0,0,0,0,0,"Sukuna's Arm","Braccio di Sukuna","",""),
]

SOUNDS = ["sukuna_laugh","sukuna_roar","sukuna_voice","dismantle","cleave","fuga_ignite","fuga_explode","domain_expansion","domain_slash","finger_eat","heartbeat","cinematic_slash","cinematic_sting","gojo_infinity","blood_splatter","curse_ambient","curse_hurt","curse_death","sorcerer_hurt","sorcerer_death","rct_heal","takeover","resonance_pulse","seal_ritual","cursed_energy_burst","world_slash","boss_theme"]
SOUND_SUBS = {
 "sukuna_laugh":("Sukuna laughs","Sukuna ride"),"sukuna_roar":("Sukuna roars","Sukuna ruggisce"),"sukuna_voice":("Sukuna speaks","Sukuna parla"),
 "dismantle":("Dismantle slashes","Smantellamento taglia"),"cleave":("Cleave cuts","Fendente taglia"),"fuga_ignite":("Fuga ignites","Fuga si accende"),
 "fuga_explode":("Fuga explodes","Fuga esplode"),"domain_expansion":("Domain Expansion","Espansione del Dominio"),"domain_slash":("Sure-hit slashes","Tagli a colpo sicuro"),
 "finger_eat":("Finger consumed","Dito consumato"),"heartbeat":("Cursed heartbeat","Battito maledetto"),"cinematic_slash":("A world-splitting slash","Un taglio che divide il mondo"),
 "cinematic_sting":("Ominous sting","Nota minacciosa"),"gojo_infinity":("Infinity hums","L'Infinito vibra"),"blood_splatter":("Blood splatters","Schizzo di sangue"),
 "curse_ambient":("Curse murmurs","La maledizione mormora"),"curse_hurt":("Curse hurts","La maledizione soffre"),"curse_death":("Curse exorcised","Maledizione esorcizzata"),
 "sorcerer_hurt":("Sorcerer hurts","Lo stregone soffre"),"sorcerer_death":("Sorcerer dies","Lo stregone muore"),"rct_heal":("Reverse Cursed Technique","Tecnica Maledetta Inversa"),
 "takeover":("Sukuna takes control","Sukuna prende il controllo"),"resonance_pulse":("Finger resonance","Risonanza del dito"),"seal_ritual":("Sealing ritual","Rituale di sigillo"),
 "cursed_energy_burst":("Cursed energy bursts","Esplosione di energia maledetta"),"world_slash":("World Cutting Slash","Taglio del Mondo"),"boss_theme":("Ominous chanting","Canto minaccioso"),
}
PARTICLES = ["cursed_energy","blood","slash","domain_ash","resonance"]
EFFECTS = [
 ("cursed_bleed","HARMFUL",0x8a0303,"Cursed Bleed","Sanguinamento Maledetto"),
 ("sealed","HARMFUL",0xe8e2c8,"Sealed","Sigillato"),
 ("sukuna_takeover","NEUTRAL",0x3d0000,"Sukuna's Takeover","Possessione di Sukuna"),
 ("cursed_vigor","BENEFICIAL",0xb3122e,"Cursed Vigor","Vigore Maledetto"),
 ("warded","BENEFICIAL",0xf0e6c8,"Warded","Protetto"),
]
ABILITIES = [
 ("DISMANTLE",1,15,10,"Dismantle","Smantellamento","A fast invisible slash that flies forward and cuts everything in its path."),
 ("CLEAVE",3,30,40,"Cleave","Fendente","An adaptive slash that scales with the target's toughness and size."),
 ("REVERSE_CURSED_TECHNIQUE",5,40,200,"Reverse Cursed Technique","Tecnica Maledetta Inversa","Turns negative energy positive to heal wounds and purge ailments."),
 ("SPIDERWEB",8,45,120,"Dismantle: Spiderweb","Smantellamento: Ragnatela","Slashes radiate through the ground around you."),
 ("FUGA",10,70,300,"Fuga (Open)","Fuga (Apri)","Draws a bow of flame and looses a searing fire arrow."),
 ("WORLD_SLASH",17,120,600,"World Cutting Slash","Taglio del Mondo","A slash that cuts the very space in front of you."),
 ("DOMAIN_EXPANSION",20,0,6000,"Domain Expansion: Malevolent Shrine","Espansione del Dominio: Santuario Malevolo","Manifest your shrine. Every living thing within is slashed without end."),
 ("BLUE",0,25,40,"Cursed Technique Lapse: Blue","Tecnica Maledetta Lapse: Blu","Attraction: drags everything at the point you look at into a crushing singularity."),
 ("RED",0,40,80,"Cursed Technique Reversal: Red","Tecnica Maledetta Inversione: Rosso","Repulsion: an explosive burst that blasts enemies away."),
 ("HOLLOW_PURPLE",0,150,600,"Hollow Technique: Purple","Tecnica Cava: Viola","Red and Blue collide into imaginary mass that erases everything in its path."),
 ("INFINITY",0,0,20,"Infinity","Infinito","Toggle. While you have cursed energy, attacks never reach you."),
 ("BLINK",0,15,30,"Blink","Teletrasporto","Teleport a short distance where you look."),
 ("INFINITE_VOID",0,0,6000,"Domain Expansion: Infinite Void","Espansione del Dominio: Vuoto Infinito","Everyone inside receives infinite information and cannot move."),
]

NON_GEO_ENTITIES=("sliced_corpse","sukuna_arm_thrown")
SHARED_GEO={"gojo_kenjaku":"gojo_satoru","heian_sukuna":"sukuna_true_form"}
NO_EGG=("SHRINE","DISMANTLE","FUGA","SLICED","ARM")
TECH_IT_NAMES={"DISMANTLE":"Tecnica: Smantellamento","CLEAVE":"Tecnica: Fendente","REVERSE_CURSED_TECHNIQUE":"Tecnica: Tecnica Maledetta Inversa","SPIDERWEB":"Tecnica: Ragnatela",
 "FUGA":"Tecnica: Fuga","WORLD_SLASH":"Tecnica: Taglio del Mondo","DOMAIN_EXPANSION":"Tecnica: Santuario Malevolo",
 "BLUE":"Tecnica: Blu","RED":"Tecnica: Rosso","HOLLOW_PURPLE":"Tecnica: Viola","INFINITY":"Tecnica: Infinito","BLINK":"Tecnica: Teletrasporto","INFINITE_VOID":"Tecnica: Vuoto Infinito"}
TECHNIQUES=[("technique_"+a[0].lower(),a[0],"Technique: "+a[4].replace("Domain Expansion: ",""),TECH_IT_NAMES[a[0]]) for a in ABILITIES]
