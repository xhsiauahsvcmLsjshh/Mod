import struct, gzip
class Byte(int): pass
class Short(int): pass
class Int(int): pass
class Double(float): pass
class Float(float): pass
class TList(list):
    def __init__(s,t,items): super().__init__(items); s.t=t
def _tid(v):
    if isinstance(v,Byte): return 1
    if isinstance(v,Short): return 2
    if isinstance(v,Int) or (isinstance(v,int) and not isinstance(v,bool)): return 3
    if isinstance(v,Float): return 5
    if isinstance(v,Double) or isinstance(v,float): return 6
    if isinstance(v,str): return 8
    if isinstance(v,TList): return 9
    if isinstance(v,dict): return 10
    raise TypeError(type(v))
def _payload(v,out):
    t=_tid(v)
    if t==1: out+=struct.pack(">b",v)
    elif t==2: out+=struct.pack(">h",v)
    elif t==3: out+=struct.pack(">i",v)
    elif t==5: out+=struct.pack(">f",v)
    elif t==6: out+=struct.pack(">d",v)
    elif t==8: b=v.encode("utf-8"); out+=struct.pack(">H",len(b))+b
    elif t==9:
        out+=struct.pack(">bi",v.t if len(v) else (v.t or 0),len(v))
        for it in v: _payload(it,out)
    elif t==10:
        for k,x in v.items():
            out+=struct.pack(">b",_tid(x)); kb=k.encode(); out+=struct.pack(">H",len(kb))+kb; _payload(x,out)
        out+=b"\x00"
def write(path,root):
    out=bytearray(); out+=b"\x0a\x00\x00"; _payload(root,out)
    with gzip.open(path,"wb") as f: f.write(bytes(out))
