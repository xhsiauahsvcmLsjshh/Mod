import json, os, math, random
from px import *

# ======================= geometry =======================
class Cube:
    def __init__(s,origin,size,col,painter=None,glow=None,mat="cloth",gore=()):
        s.origin=[float(v) for v in origin]; s.size=[int(v) for v in size]; s.col=col; s.painter=painter; s.glow=glow; s.mat=mat; s.gore=tuple(gore); s.uv=None
class Bone:
    def __init__(s,name,parent,pivot,cubes=(),rot=None):
        s.name=name; s.parent=parent; s.pivot=[float(v) for v in pivot]; s.cubes=list(cubes); s.rot=rot
class Model:
    def __init__(s,name): s.name=name; s.bones=[]; s.plan="generic"; s.parts=(); s.body="body"
    def bone(s,*a,**k): b=Bone(*a,**k); s.bones.append(b); return b
    def get(s,n):
        for b in s.bones:
            if b.name==n: return b
        raise KeyError(n)
    def has(s,n): return any(b.name==n for b in s.bones)
    def pack(s):
        cubes=[c for b in s.bones for c in b.cubes]
        order=sorted(cubes,key=lambda c:-(c.size[2]+c.size[1]))
        for W in (64,128,256,512):
            x=y=rowh=0; ok=True
            for c in order:
                w,h,d=c.size; uw,uh=2*d+2*w,d+h
                if uw>W: ok=False;break
                if x+uw>W: x=0;y+=rowh;rowh=0
                c.uv=(x,y); x+=uw; rowh=max(rowh,uh)
            H=y+rowh
            if ok and H<=W:
                hh=32
                while hh<H: hh*=2
                s.W=W; s.H=hh; return
        raise Exception("too big "+s.name)

    # ------------------- painting -------------------
    def paint(s,seed=0):
        img=new(s.W,s.H); glow=new(s.W,s.H); r=random.Random(sum(map(ord,s.name))+seed)
        for b in s.bones:
            for c in b.cubes:
                u,v=c.uv; w,h,d=c.size
                faces={"top":(u+d,v,w,d,1.12),"bottom":(u+d+w,v,w,d,0.72),"east":(u,v+d,d,h,0.9),"front":(u+d,v+d,w,h,1.0),"west":(u+d+w,v+d,d,h,0.9),"back":(u+2*d+w,v+d,w,h,0.82)}
                for fn,(x0,y0,fw,fh,lf) in faces.items():
                    if fn in c.gore: paint_gore(img,x0,y0,fw,fh,r); continue
                    for xx in range(x0,x0+fw):
                        for yy in range(y0,y0+fh):
                            lx,ly=xx-x0,yy-y0
                            col=material(c.mat,c.col,lx,ly,fw,fh,fn,r)
                            f=lf
                            if fh>2 and fn not in("top","bottom"): f*=1.04-0.14*(ly/max(1,fh-1))
                            if fw>2 and fh>2 and (lx==0 or lx==fw-1): f*=0.86
                            if fh>2 and ly==fh-1 and fn not in("top","bottom"): f*=0.8
                            if fh>2 and ly==0 and fn not in("top","bottom"): f*=1.06
                            P(img,xx,yy,shade(col,f))
                if c.glow:
                    for fn,(x0,y0,fw,fh,lf) in faces.items():
                        for xx in range(x0,x0+fw):
                            for yy in range(y0,y0+fh):
                                if c.glow=="full" or (xx+yy)%2==0: P(glow,xx,yy,img.getpixel((xx,yy))[:3])
                if c.painter:
                    x0,y0,fw,fh,_=faces["front"]; c.painter(img,glow,x0,y0,fw,fh,faces)
        # GeckoLib's AutoGlowingGeoLayer crashes on an empty glowmask: always keep one invisible emissive pixel
        if glow.getbbox() is None:
            placed=False
            for yy in range(s.H-1,-1,-1):
                for xx in range(s.W-1,-1,-1):
                    if img.getpixel((xx,yy))[3]==0: glow.putpixel((xx,yy),(255,42,64,255)); placed=True; break
                if placed: break
            if not placed: glow.putpixel((0,0),img.getpixel((0,0))[:3]+(255,))
        return img,glow

    def geo(s):
        bones=[]
        for b in s.bones:
            d={"name":b.name,"pivot":b.pivot}
            if b.parent: d["parent"]=b.parent
            if b.rot: d["rotation"]=b.rot
            if b.cubes: d["cubes"]=[{"origin":c.origin,"size":c.size,"uv":list(c.uv)} for c in b.cubes]
            bones.append(d)
        allc=[c for b in s.bones for c in b.cubes]
        maxy=max(c.origin[1]+c.size[1] for c in allc)/16
        maxw=max(max(abs(c.origin[0]),abs(c.origin[0]+c.size[0]),abs(c.origin[2]),abs(c.origin[2]+c.size[2])) for c in allc)/8
        return {"format_version":"1.12.0","minecraft:geometry":[{"description":{"identifier":"geometry."+s.name,"texture_width":s.W,"texture_height":s.H,
               "visible_bounds_width":round(maxw+3,1),"visible_bounds_height":round(maxy+2,1),"visible_bounds_offset":[0,round(maxy/2+0.25,2),0]},"bones":bones}]}

def _vn(x,y,seed):  # cheap value noise 0..1
    def h(i,j): return (math.sin(i*127.1+j*311.7+seed*74.7)*43758.5453)%1.0
    xi,yi=int(math.floor(x)),int(math.floor(y)); xf,yf=x-xi,y-yi
    a,b,c,d=h(xi,yi),h(xi+1,yi),h(xi,yi+1),h(xi+1,yi+1)
    u,v=xf*xf*(3-2*xf),yf*yf*(3-2*yf)
    return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v

def material(mat,col,lx,ly,fw,fh,fn,r):
    n=r.uniform(-1,1)
    if mat=="skin":
        return shade(col,1+0.025*n)
    if mat=="cloth":
        f=1+0.03*n
        if fn not in("top","bottom") and fw>=4 and (lx*7+3)%5==0: f*=0.9          # folds
        if fn not in("top","bottom") and fh>=6 and ly==fh-2: f*=0.85               # hem
        return shade(col,f)
    if mat=="hair":
        f=1.1 if (lx+(ly//3))%2==0 else 0.9
        if r.random()<0.12: f*=0.8
        return shade(col,f)
    if mat=="bone":
        f=1+0.05*n
        if r.random()<0.06: return shade(col,0.7)
        if ly%4==0 and fn not in("top","bottom"): f*=0.9
        return shade(col,f)
    if mat=="curse":
        t=_vn(lx/2.5,ly/2.5,hash(col)%97)
        base=mix(col,shade(col,0.6),t)
        if t>0.82: base=mix(base,(84,30,98),0.6)
        if r.random()<0.03: base=(140,20,40)
        return shade(base,1+0.04*n)
    if mat=="metal":
        f=1.25 if ly%4==1 else (0.85 if ly%4==3 else 1.0)
        return shade(col,f*(1+0.02*n))
    if mat=="flesh":
        return mix(col,(150,30,40),0.15+0.15*abs(n))
    return shade(col,1+0.03*n)

def paint_gore(img,x0,y0,fw,fh,r):
    cx,cy=x0+fw/2-0.5,y0+fh/2-0.5
    for xx in range(x0,x0+fw):
        for yy in range(y0,y0+fh):
            d=math.hypot((xx-cx)/(fw/2+0.01),(yy-cy)/(fh/2+0.01))
            c=(150,12,26) if d>0.75 else ((200,70,80) if d>0.35 else (120,8,20))
            if r.random()<0.25: c=(90,4,12)
            P(img,xx,yy,c)
    P(img,int(cx),int(cy),(226,218,196)); P(img,int(cx)+1,int(cy),(196,186,160))   # spine

# ======================= painters =======================
def face_human(eye=BLACK,iris=None,hair=None,marks=None,glow_eyes=False,extra_eyes=False,blindfold=None,brow=None,mouth=(110,50,50),skin=None,stitches=None):
    def p(img,glow,x,y,w,h,faces):
        cx=x+w//2; ey=y+int(h*0.5)
        if hair:
            for xx in range(x,x+w):
                P(img,xx,y,shade(hair,1.1 if xx%2 else 0.95))
                if (xx*5)%3!=0: P(img,xx,y+1,shade(hair,0.95))
                if (xx*7)%5==0 and h>=8: P(img,xx,y+2,shade(hair,0.85))
            for fn in("top","back"):
                fx,fy,fw,fh,_=faces[fn]
                for xx in range(fx,fx+fw):
                    for yy in range(fy,fy+(fh if fn=="top" else min(fh,max(2,h*2//3)))):
                        P(img,xx,yy,shade(hair,1.12 if (xx+yy//2)%2 else 0.9))
            for fn in("east","west"):
                fx,fy,fw,fh,_=faces[fn]
                for xx in range(fx,fx+fw):
                    for yy in range(fy,fy+min(fh,3 if (xx%2) else 2)): P(img,xx,yy,shade(hair,1.0 if xx%2 else 0.88))
        if blindfold:
            rect(img,x,ey-1,x+w-1,ey,blindfold)
            for fn in("east","west","back"):
                fx,fy,fw,fh,_=faces[fn]; rect(img,fx,fy+(ey-y)-1,fx+fw-1,fy+(ey-y),blindfold)
            P(img,x+1,ey-1,shade(blindfold,1.6)); P(img,x+w-2,ey-1,shade(blindfold,1.6))
        else:
            for side in (-1,1):
                ex=cx-2 if side<0 else cx+1
                wx=ex-1 if side<0 else ex+1
                P(img,wx,ey,(236,232,226)); P(img,ex,ey,iris or eye)
                if glow_eyes: P(glow,ex,ey,iris or eye); P(glow,wx,ey,iris or eye)
                b=brow or shade(hair or (40,30,30),0.7)
                P(img,ex,ey-2,b); P(img,wx,ey-2,b)
            if extra_eyes:
                for ex in (cx-3,cx+2):
                    P(img,ex,ey+1,iris or eye)
                    if glow_eyes: P(glow,ex,ey+1,iris or eye)
        P(img,cx-1 if w%2==0 else cx,ey+1,shade(skin or SKIN,0.82))       # nose shadow
        my=min(y+h-2,ey+2+(1 if h>=8 else 0))
        rect(img,cx-1,my,cx,my,mouth)
        if marks:
            for ex in (x,x+w-1):
                P(img,ex,ey+1,marks); P(img,ex+(1 if ex==x else -1),ey+2,marks)
            P(img,cx-1,y+2,marks); P(img,cx,y+2,marks); P(img,cx-1,y+3,marks)
            P(img,cx-3,ey+2,marks); P(img,cx+2,ey+2,marks)
        if stitches:
            # Kenjaku's surgical stitches: a seam across the forehead that wraps around the whole head
            sy=y+max(1,(ey-y)//2)
            for xx in range(x,x+w):
                P(img,xx,sy,stitches)
                if xx%2==0: P(img,xx,sy-1,shade(stitches,1.5)); P(img,xx,sy+1,shade(stitches,1.5))
            for fn in("east","west","back"):
                fx,fy,fw,fh,_=faces[fn]
                for xx in range(fx,fx+fw):
                    P(img,xx,fy+(sy-y),stitches)
                    if xx%2==0: P(img,xx,fy+(sy-y)-1,shade(stitches,1.5)); P(img,xx,fy+(sy-y)+1,shade(stitches,1.5))
    return p
def face_curse(n_eyes=3,eye=(255,220,40),mouth=True,teeth=BONE):
    def p(img,glow,x,y,w,h,faces):
        r=random.Random(w*31+h*7+n_eyes)
        for k in range(n_eyes):
            ex=x+1+r.randrange(max(1,w-2)); ey=y+r.randrange(max(1,h//2+1))
            P(img,ex,ey,eye); P(glow,ex,ey,eye)
            P(img,ex,ey-1,shade(eye,0.25)) if ey-1>=y else None
        if mouth:
            my=y+h*2//3
            rect(img,x+1,my,x+w-2,min(y+h-1,my+1),(30,4,8))
            for xx in range(x+1,x+w-1,2):
                P(img,xx,my,teeth)
                if my+1<y+h: P(img,xx+1,my+1,teeth)
            P(glow,x+1,my+1,(150,10,30)) if my+1<y+h else None
    return p
def giant_eye(col=(240,232,210),iris=(200,20,30)):
    def p(img,glow,x,y,w,h,faces):
        cx,cy=x+w/2-0.5,y+h/2-0.5
        for xx in range(x,x+w):
            for yy in range(y,y+h):
                dd=((xx-cx)/(w/2))**2+((yy-cy)/(h/2))**2
                if dd<0.85: P(img,xx,yy,col if dd>0.5 else shade(col,0.92))
                if 0.6<dd<0.85 and (xx+yy)%3==0: P(img,xx,yy,(170,30,40))   # veins
                if dd<0.28: P(img,xx,yy,iris); P(glow,xx,yy,iris)
                if dd<0.07: P(img,xx,yy,BLACK); P(glow,xx,yy,(0,0,0,0)) if False else None
        P(img,int(cx)-1,int(cy)-1,(255,255,255))
    return p
def stripes(col,every=3,vertical=False,glowing=False,faces_only=None):
    def p(img,glow,x,y,w,h,faces):
        for fn,(fx,fy,fw,fh,_) in faces.items():
            if faces_only and fn not in faces_only: continue
            for xx in range(fx,fx+fw):
                for yy in range(fy,fy+fh):
                    if (((xx-fx) if vertical else (yy-fy))%every)==0:
                        P(img,xx,yy,col)
                        if glowing: P(glow,xx,yy,col)
    return p
def tattoo(col=BLACK,glowcol=None):
    """Sukuna-style double bands with points on arms/torso."""
    def p(img,glow,x,y,w,h,faces):
        for fn,(fx,fy,fw,fh,_) in faces.items():
            if fn in("top","bottom"): continue
            for yy in range(fy+1,fy+fh-1,4):
                for xx in range(fx,fx+fw):
                    P(img,xx,yy,col)
                    if glowcol: P(glow,xx,yy,glowcol)
                if fw>=3: P(img,fx+fw//2,yy+1,col)
    return p
def trim(col,top=True,bottom=True,center=False):
    def p(img,glow,x,y,w,h,faces):
        for fn,(fx,fy,fw,fh,_) in faces.items():
            if fn in("top","bottom"): continue
            if top: rect(img,fx,fy,fx+fw-1,fy,col)
            if bottom: rect(img,fx,fy+fh-1,fx+fw-1,fy+fh-1,col)
        if center: rect(img,x+w//2,y,x+w//2,y+h-1,col)
    return p
def buttons(col=GOLD):
    def p(img,glow,x,y,w,h,faces):
        for yy in range(y+2,y+h-1,3): P(img,x+w//2,yy,col)
        rect(img,x+w//2-1,y,x+w//2+1,y,shade(col,0.8))
    return p
def emblem(col,k=0,glowing=True):
    def p(img,glow,x,y,w,h,faces):
        if w>=5 and h>=7:
            glyph(img,x+(w-5)//2,y+(h-7)//2,col,k)
            if glowing: glyph(glow,x+(w-5)//2,y+(h-7)//2,col,k)
        else:
            P(img,x+w//2,y+h//2,col)
            if glowing: P(glow,x+w//2,y+h//2,col)
    return p
def multi(*ps):
    def p(*a):
        for q in ps:
            if q: q(*a)
    return p

# ======================= humanoid builder =======================
def humanoid(name,s=1.0,skin=SKIN,top=BLACK,bottom=BLACK,arms_col=None,face=None,legs_col=None,extra_arms=False,split=False,arm_w=4,
             body_painter=None,arm_painter=None,head_col=None,head_size=None,hands=None,shoes=(30,22,22),skin_mat="skin",cloth_mat="cloth",arm_mat=None,leg_painter=None):
    m=Model(name); I=lambda v:max(1,int(round(v*s)))
    lh,lw=I(12),I(4); bh,bw,bd=I(12),I(8),I(4); hs=head_size or I(8); aw=max(2,I(arm_w)); ah=I(12)
    up_l=max(2,ah//2); fo_l=max(2,ah-up_l-max(1,ah//6)); ha_l=ah-up_l-fo_l
    th_l=max(2,lh//2); sh_l=max(2,lh-th_l-1); ft_l=lh-th_l-sh_l
    m.dims=(lh,bh,hs,bw,aw); ac=arms_col or top; lc=legs_col or bottom; hands=hands or skin
    amat=arm_mat or (skin_mat if ac==skin else cloth_mat)
    m.bone("root",None,[0,0,0])
    top_y=lh+bh
    if split:
        lo=bh//3
        m.bone("hips","root",[0,0,0],[Cube([-bw/2,lh,-bd/2],[bw,lo,bd],bottom,mat=cloth_mat,gore=("top",))])
        m.bone("body","root",[0,lh+lo,0],[Cube([-bw/2,lh+lo,-bd/2],[bw,bh-lo,bd],top,body_painter,mat=cloth_mat,gore=("bottom",))])
        legp="hips"
    else:
        m.bone("body","root",[0,lh,0],[Cube([-bw/2,lh,-bd/2],[bw,bh,bd],top,body_painter,mat=cloth_mat)])
        legp="root"
    m.bone("head","body",[0,top_y,0],[Cube([-hs/2,top_y,-hs/2],[hs,hs,hs],head_col or skin,face,mat=skin_mat)])
    def arm(side,suffix,ytop):
        sx=-1 if side=="right" else 1
        x0=-(bw/2+aw) if sx<0 else bw/2
        m.bone(f"{side}_arm{suffix}","body",[sx*(bw/2+aw/2),ytop-2,0],[Cube([x0,ytop-up_l,-aw/2],[aw,up_l,aw],ac,arm_painter,mat=amat)])
        m.bone(f"{side}_forearm{suffix}",f"{side}_arm{suffix}",[sx*(bw/2+aw/2),ytop-up_l,0],
               [Cube([x0,ytop-up_l-fo_l,-aw/2],[aw,fo_l,aw],ac,arm_painter,mat=amat)]+([Cube([x0,ytop-ah,-aw/2],[aw,ha_l,aw],hands,mat=skin_mat)] if ha_l>0 else []))
    arm("right","",top_y); arm("left","",top_y)
    if extra_arms:
        arm("right","2",top_y-ah//2+1); arm("left","2",top_y-ah//2+1)
    for side,sx in (("right",-1),("left",1)):
        x0=-lw if sx<0 else 0
        m.bone(f"{side}_leg",legp,[sx*lw/2,lh,0],[Cube([x0,lh-th_l,-lw/2],[lw,th_l,lw],lc,leg_painter,mat=cloth_mat)])
        m.bone(f"{side}_shin",f"{side}_leg",[sx*lw/2,lh-th_l,0],[Cube([x0,ft_l,-lw/2],[lw,sh_l,lw],lc,leg_painter,mat=cloth_mat)]+([Cube([x0,0,-lw/2-1 if lw>=4 else -lw/2],[lw,ft_l,lw+(1 if lw>=4 else 0)],shoes,mat="cloth")] if ft_l>0 else []))
    m.plan="humanoid"; m.top_y=top_y; m.hs=hs; m.ah=ah
    return m

def add(m,bone,origin,size,col,painter=None,glow=None,mat="cloth"):
    m.get(bone).cubes.append(Cube(origin,size,col,painter,glow,mat)); return m

# ======================= animation authoring =======================
def _fmt(t): return ("%.2f"%t).rstrip("0").rstrip(".") if t!=int(t) else "%.1f"%t
def _cos(a,b,t):
    k=(1-math.cos(math.pi*t))/2
    return [a[i]+(b[i]-a[i])*k for i in range(3)]
def track(keys,length,step=0.05,smooth=True):
    """keys: list[(t,[x,y,z])] -> GeckoLib keyframe dict sampled with cosine easing (crash-free, plain arrays)."""
    keys=sorted(keys,key=lambda k:k[0])
    if len(keys)==1: return {"0.0":[round(v,3) for v in keys[0][1]]}
    out={}; t=keys[0][0]
    n=int(round((keys[-1][0]-keys[0][0])/step))
    for i in range(n+1):
        t=keys[0][0]+i*step
        for j in range(len(keys)-1):
            if keys[j][0]-1e-9<=t<=keys[j+1][0]+1e-9:
                a,b=keys[j],keys[j+1]; f=(t-a[0])/max(1e-9,b[0]-a[0])
                v=_cos(a[1],b[1],f) if smooth else [a[1][q]+(b[1][q]-a[1][q])*f for q in range(3)]
                break
        out[_fmt(round(t,3))]=[round(x,3) for x in v]
    return out
def A(length,loop,bones,step=0.05):
    out={"animation_length":length,"bones":{}}
    if loop is True: out["loop"]=True
    elif loop=="hold": out["loop"]="hold_on_last_frame"
    for bn,chans in bones.items():
        out["bones"][bn]={ch:track(v,length,step) for ch,v in chans.items()}
    return out
def cyc(length,pairs):
    """periodic helper: pairs [(phase0..1, vec)] -> keys covering [0,length] and closing the loop."""
    ks=[(p*length,v) for p,v in pairs]
    if ks[-1][0]<length: ks.append((length,pairs[0][1]))
    return ks
def R(x=0,y=0,z=0): return [x,y,z]

def humanoid_anims(m,extra=None,torso="body"):
    n=m.name; has2=m.has("right_arm2")
    an={}
    # ---------- idle: breathing, sway, glance ----------
    b={torso:{"rotation":cyc(4,[(0,R()),(0.5,R(2))]),"position":cyc(4,[(0,R()),(0.5,R(0,0.25,0))])},
       "head":{"rotation":cyc(8,[(0,R()),(0.25,R(-3,10)),(0.5,R(2)),(0.75,R(-3,-10))])},
       "right_arm":{"rotation":cyc(4,[(0,R(0,0,4)),(0.5,R(2,0,7))])},"left_arm":{"rotation":cyc(4,[(0,R(0,0,-4)),(0.5,R(2,0,-7))])},
       "right_forearm":{"rotation":cyc(4,[(0,R(-8)),(0.5,R(-12))])},"left_forearm":{"rotation":cyc(4,[(0,R(-8)),(0.5,R(-12))])}}
    if has2:
        b["right_arm2"]={"rotation":cyc(4,[(0,R(-10,0,10)),(0.5,R(-14,0,14))])}; b["left_arm2"]={"rotation":cyc(4,[(0,R(-10,0,-10)),(0.5,R(-14,0,-14))])}
        b["right_forearm2"]={"rotation":cyc(4,[(0,R(-30)),(0.5,R(-38))])}; b["left_forearm2"]={"rotation":cyc(4,[(0,R(-30)),(0.5,R(-38))])}
    an["idle"]=A(8.0,True,b,0.1)
    # ---------- walk / run ----------
    for nm,L,amp,shin,armamp,fore,lean,bob in (("walk",1.0,30,35,24,-18,3,0.5),("run",0.6,52,75,55,-70,14,1.0)):
        b={"right_leg":{"rotation":cyc(L,[(0,R(amp)),(0.5,R(-amp))])},"left_leg":{"rotation":cyc(L,[(0,R(-amp)),(0.5,R(amp))])},
           "right_shin":{"rotation":cyc(L,[(0,R(0)),(0.25,R(shin*0.2)),(0.5,R(shin)),(0.75,R(shin*0.5))])},
           "left_shin":{"rotation":cyc(L,[(0,R(shin)),(0.25,R(shin*0.5)),(0.5,R(0)),(0.75,R(shin*0.2))])},
           "right_arm":{"rotation":cyc(L,[(0,R(-armamp)),(0.5,R(armamp))])},"left_arm":{"rotation":cyc(L,[(0,R(armamp)),(0.5,R(-armamp))])},
           "right_forearm":{"rotation":cyc(L,[(0,R(fore)),(0.5,R(fore*0.4))])},"left_forearm":{"rotation":cyc(L,[(0,R(fore*0.4)),(0.5,R(fore))])},
           torso:{"rotation":cyc(L,[(0,R(lean,-5)),(0.5,R(lean,5))]),"position":cyc(L,[(0,R()),(0.25,R(0,-bob,0)),(0.5,R()),(0.75,R(0,-bob,0))])},
           "head":{"rotation":cyc(L,[(0,R(-lean*0.6,5)),(0.5,R(-lean*0.6,-5))])}}
        if has2:
            b["right_arm2"]={"rotation":cyc(L,[(0,R(armamp*0.6)),(0.5,R(-armamp*0.6))])}; b["left_arm2"]={"rotation":cyc(L,[(0,R(-armamp*0.6)),(0.5,R(armamp*0.6))])}
        an[nm]=A(L,True,b)
    # ---------- attack: wind-up, strike, follow-through ----------
    an["attack"]=A(0.55,False,{"right_arm":{"rotation":[(0,R()),(0.14,R(-40,0,30)),(0.24,R(-115,0,-5)),(0.38,R(-20,0,-10)),(0.55,R())]},
        "right_forearm":{"rotation":[(0,R(-8)),(0.14,R(-70)),(0.24,R(-5)),(0.55,R(-8))]},
        torso:{"rotation":[(0,R()),(0.14,R(0,-25,0)),(0.26,R(6,28,0)),(0.55,R())]},"head":{"rotation":[(0,R()),(0.14,R(0,15,0)),(0.26,R(0,-18,0)),(0.55,R())]},
        "left_arm":{"rotation":[(0,R()),(0.14,R(-25,0,-10)),(0.26,R(20,0,-10)),(0.55,R())]}})
    # ---------- slash: big diagonal cut ----------
    an["slash"]=A(0.9,False,{"right_arm":{"rotation":[(0,R()),(0.25,R(-160,0,45)),(0.42,R(-55,0,-75)),(0.6,R(-35,0,-70)),(0.9,R())]},
        "right_forearm":{"rotation":[(0,R(-8)),(0.25,R(-35)),(0.42,R(0)),(0.9,R(-8))]},
        "left_arm":{"rotation":[(0,R()),(0.25,R(-30,0,-25)),(0.42,R(10,0,-35)),(0.9,R())]},
        torso:{"rotation":[(0,R()),(0.25,R(-6,38,0)),(0.42,R(10,-40,0)),(0.6,R(8,-35,0)),(0.9,R())]},
        "head":{"rotation":[(0,R()),(0.25,R(-8,-25,0)),(0.42,R(5,20,0)),(0.9,R())]},
        "right_leg":{"rotation":[(0,R()),(0.42,R(-20)),(0.9,R())]},"left_leg":{"rotation":[(0,R()),(0.42,R(15)),(0.9,R())]}})
    # ---------- cast ----------
    an["cast"]=A(1.0,False,{"right_arm":{"rotation":[(0,R()),(0.3,R(-85,15,-10)),(0.8,R(-90,15,-10)),(1,R())]},"left_arm":{"rotation":[(0,R()),(0.3,R(-85,-15,10)),(0.8,R(-90,-15,10)),(1,R())]},
        "right_forearm":{"rotation":[(0,R(-8)),(0.3,R(-30)),(0.8,R(-30)),(1,R(-8))]},"left_forearm":{"rotation":[(0,R(-8)),(0.3,R(-30)),(0.8,R(-30)),(1,R(-8))]},
        "head":{"rotation":[(0,R()),(0.3,R(12)),(0.6,R(-10)),(1,R())]},torso:{"rotation":[(0,R()),(0.3,R(6)),(1,R())]}})
    # ---------- domain: hand sign (Malevolent Shrine mudra) ----------
    dom={"right_arm":{"rotation":cyc(2,[(0,R(-75,-20,35)),(0.5,R(-78,-20,38))])},"left_arm":{"rotation":cyc(2,[(0,R(-75,20,-35)),(0.5,R(-78,20,-38))])},
         "right_forearm":{"rotation":cyc(2,[(0,R(-55)),(0.5,R(-58))])},"left_forearm":{"rotation":cyc(2,[(0,R(-55)),(0.5,R(-58))])},
         "head":{"rotation":cyc(2,[(0,R(-10)),(0.5,R(-14))])},torso:{"position":cyc(2,[(0,R()),(0.5,R(0,0.3,0))])}}
    if has2:
        dom["right_arm2"]={"rotation":cyc(2,[(0,R(-30,0,60)),(0.5,R(-34,0,64))])}; dom["left_arm2"]={"rotation":cyc(2,[(0,R(-30,0,-60)),(0.5,R(-34,0,-64))])}
    an["domain"]=A(2.0,True,dom)
    # ---------- eat finger ----------
    an["eat_finger"]=A(1.8,False,{"right_arm":{"rotation":[(0,R()),(0.4,R(-120,-25,20)),(1.2,R(-125,-25,20)),(1.8,R())]},
        "right_forearm":{"rotation":[(0,R(-8)),(0.4,R(-95)),(1.2,R(-95)),(1.8,R(-8))]},
        "head":{"rotation":[(0,R()),(0.5,R(10)),(0.9,R(-30)),(1.1,R(-25)),(1.3,R(-30)),(1.8,R())]},torso:{"rotation":[(0,R()),(0.9,R(-8)),(1.8,R())]}})
    # ---------- dig (kneeling) ----------
    an["dig"]=A(1.2,True,{"root":{"position":cyc(1.2,[(0,R(0,-5,0)),(0.5,R(0,-5.2,0))])},
        torso:{"rotation":cyc(1.2,[(0,R(40)),(0.5,R(46))])},"head":{"rotation":cyc(1.2,[(0,R(-30)),(0.5,R(-34))])},
        "right_leg":{"rotation":cyc(1.2,[(0,R(-85)),(0.5,R(-85))])},"right_shin":{"rotation":cyc(1.2,[(0,R(95)),(0.5,R(95))])},
        "left_leg":{"rotation":cyc(1.2,[(0,R(-30)),(0.5,R(-30))])},"left_shin":{"rotation":cyc(1.2,[(0,R(80)),(0.5,R(80))])},
        "right_arm":{"rotation":cyc(1.2,[(0,R(-55)),(0.5,R(-105))])},"left_arm":{"rotation":cyc(1.2,[(0,R(-105)),(0.5,R(-55))])},
        "right_forearm":{"rotation":cyc(1.2,[(0,R(-50)),(0.5,R(-10))])},"left_forearm":{"rotation":cyc(1.2,[(0,R(-10)),(0.5,R(-50))])}})
    # ---------- vanish ----------
    an["vanish"]=A(2.0,"hold",{"root":{"scale":[(0,R(1,1,1)),(0.5,R(1.08,1.08,1.08)),(2.0,R(0.001,0.001,0.001))],"position":[(0,R()),(0.5,R(0,1,0)),(2.0,R(0,-14,0))],
        "rotation":[(0,R()),(2.0,R(0,540,0))]},"right_arm":{"rotation":[(0,R()),(0.5,R(-170,0,20)),(2,R(-170,0,20))]},"left_arm":{"rotation":[(0,R()),(0.5,R(-170,0,-20)),(2,R(-170,0,-20))]},
        "head":{"rotation":[(0,R()),(0.5,R(-35)),(2,R(-35))]}},0.05)
    # ---------- taunt / laugh ----------
    an["taunt"]=A(1.8,False,{"head":{"rotation":[(0,R()),(0.35,R(-30)),(0.5,R(-24,0,4)),(0.65,R(-30,0,-4)),(0.8,R(-24,0,4)),(0.95,R(-30)),(1.8,R())]},
        torso:{"rotation":[(0,R()),(0.35,R(-10)),(0.5,R(-6)),(0.65,R(-10)),(0.8,R(-6)),(1.8,R())]},
        "right_arm":{"rotation":[(0,R()),(0.35,R(0,0,28)),(1.4,R(0,0,25)),(1.8,R())]},"left_arm":{"rotation":[(0,R()),(0.35,R(-60,30,-10)),(1.4,R(-60,30,-10)),(1.8,R())]},
        "left_forearm":{"rotation":[(0,R(-8)),(0.35,R(-100)),(1.4,R(-100)),(1.8,R(-8))]}})
    # ---------- dash ----------
    an["dash"]=A(0.4,True,{torso:{"rotation":cyc(0.4,[(0,R(38)),(0.5,R(40))])},"head":{"rotation":cyc(0.4,[(0,R(-30)),(0.5,R(-32))])},
        "right_arm":{"rotation":cyc(0.4,[(0,R(55,0,10)),(0.5,R(60,0,10))])},"left_arm":{"rotation":cyc(0.4,[(0,R(55,0,-10)),(0.5,R(60,0,-10))])},
        "right_leg":{"rotation":cyc(0.4,[(0,R(45)),(0.5,R(-55))])},"left_leg":{"rotation":cyc(0.4,[(0,R(-55)),(0.5,R(45))])},
        "right_shin":{"rotation":cyc(0.4,[(0,R(10)),(0.5,R(80))])},"left_shin":{"rotation":cyc(0.4,[(0,R(80)),(0.5,R(10))])}})
    # ---------- combo: rapid alternating strikes ----------
    an["combo"]=A(0.5,True,{"right_arm":{"rotation":cyc(0.5,[(0,R(-20)),(0.2,R(-95,10,0)),(0.4,R(-20)),(0.7,R(-30))])},
        "right_forearm":{"rotation":cyc(0.5,[(0,R(-80)),(0.2,R(0)),(0.4,R(-80)),(0.7,R(-90))])},
        "left_arm":{"rotation":cyc(0.5,[(0,R(-30)),(0.2,R(-20)),(0.45,R(-30)),(0.7,R(-95,-10,0))])},
        "left_forearm":{"rotation":cyc(0.5,[(0,R(-90)),(0.2,R(-80)),(0.45,R(-90)),(0.7,R(0))])},
        torso:{"rotation":cyc(0.5,[(0,R(8,0)),(0.2,R(10,25)),(0.45,R(8,0)),(0.7,R(10,-25))])},
        "right_leg":{"rotation":cyc(0.5,[(0,R(-20)),(0.5,R(-20))])},"left_leg":{"rotation":cyc(0.5,[(0,R(20)),(0.5,R(20))])}})
    # ---------- recoil (hit by Red) ----------
    an["recoil"]=A(0.9,False,{torso:{"rotation":[(0,R()),(0.1,R(-35)),(0.45,R(-20)),(0.9,R())]},"head":{"rotation":[(0,R()),(0.1,R(-25)),(0.9,R())]},
        "right_arm":{"rotation":[(0,R()),(0.1,R(-110,0,40)),(0.5,R(-40,0,30)),(0.9,R())]},"left_arm":{"rotation":[(0,R()),(0.1,R(-110,0,-40)),(0.5,R(-40,0,-30)),(0.9,R())]},
        "right_leg":{"rotation":[(0,R()),(0.1,R(-35)),(0.6,R(-10)),(0.9,R())]},"left_leg":{"rotation":[(0,R()),(0.1,R(25)),(0.9,R())]},
        "root":{"position":[(0,R()),(0.25,R(0,-1.5,0)),(0.9,R())]}})
    # ---------- charge (World Cutting Slash wind-up) ----------
    an["charge"]=A(1.0,True,{"right_arm":{"rotation":cyc(1,[(0,R(-20,0,75)),(0.5,R(-24,0,80))])},"left_arm":{"rotation":cyc(1,[(0,R(-20,0,-75)),(0.5,R(-24,0,-80))])},
        "right_forearm":{"rotation":cyc(1,[(0,R(-35)),(0.5,R(-40))])},"left_forearm":{"rotation":cyc(1,[(0,R(-35)),(0.5,R(-40))])},
        "head":{"rotation":cyc(1,[(0,R(14)),(0.5,R(10))])},torso:{"rotation":cyc(1,[(0,R(-4,1,0)),(0.25,R(-4,-1,0)),(0.5,R(-5,1,0)),(0.75,R(-4,-1,0))])},
        "right_leg":{"rotation":cyc(1,[(0,R(-15,0,8)),(0.5,R(-15,0,8))])},"left_leg":{"rotation":cyc(1,[(0,R(15,0,-8)),(0.5,R(15,0,-8))])}})
    if extra: an.update(extra)
    return {"format_version":"1.8.0","animations":{f"animation.{n}.{k}":v for k,v in an.items()}}

def generic_anims(m,body="body",parts=()):
    n=m.name; an={}
    def P_(k,L):
        out={}
        for idx,(pname,axis,amp,_) in enumerate(parts):
            ph=0.5*(idx%2)
            vec=lambda a:[a if axis==0 else 0,a if axis==1 else 0,a if axis==2 else 0]
            mult={"idle":0.5,"walk":1.0,"run":1.4,"attack":1.6,"slash":1.6,"cast":1.2,"domain":1.0}[k]
            out[pname]={"rotation":cyc(L,[((0+ph)%1,vec(amp*mult)),((0.5+ph)%1,vec(-amp*mult))]) if ph==0 else cyc(L,[(0,vec(-amp*mult)),(0.5,vec(amp*mult))])}
        return out
    an["idle"]=A(3.0,True,{body:{"position":cyc(3,[(0,R()),(0.5,R(0,0.8,0))]),"rotation":cyc(3,[(0,R(0,-2)),(0.5,R(0,2))])},**P_("idle",3.0)},0.1)
    an["walk"]=A(1.0,True,{body:{"position":cyc(1,[(0,R()),(0.25,R(0,1,0)),(0.5,R()),(0.75,R(0,1,0))]),"rotation":cyc(1,[(0,R(0,-5,-2)),(0.5,R(0,5,2))])},**P_("walk",1.0)})
    an["run"]=A(0.6,True,{body:{"position":cyc(0.6,[(0,R()),(0.25,R(0,2,0)),(0.5,R()),(0.75,R(0,2,0))]),"rotation":cyc(0.6,[(0,R(8,-7)),(0.5,R(8,7))])},**P_("run",0.6)})
    an["attack"]=A(0.55,False,{body:{"rotation":[(0,R()),(0.15,R(-15)),(0.28,R(28)),(0.55,R())],"position":[(0,R()),(0.15,R(0,0,2)),(0.28,R(0,0,-5)),(0.55,R())]},**{k:{"rotation":[(0,R()),(0.28,v["rotation"][0][1]),(0.55,R())]} for k,v in P_("attack",0.55).items()}})
    an["slash"]=A(0.8,False,{body:{"rotation":[(0,R()),(0.25,R(0,45,-8)),(0.45,R(5,-45,8)),(0.8,R())],"position":[(0,R()),(0.25,R(0,1,0)),(0.45,R(0,-1,0)),(0.8,R())]}})
    an["cast"]=A(1.0,False,{body:{"scale":[(0,R(1,1,1)),(0.4,R(1.15,1.12,1.15)),(0.6,R(0.95,1.05,0.95)),(1,R(1,1,1))],"rotation":[(0,R()),(0.4,R(-15)),(1,R())]}})
    an["domain"]=A(2.0,True,{body:{"rotation":[(0,R()),(1,R(0,180,0)),(2,R(0,360,0))]}},0.1)
    return {"format_version":"1.8.0","animations":{f"animation.{n}.{k}":v for k,v in an.items()}}
