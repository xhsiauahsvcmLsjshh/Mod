import os, random, json
from nbt import *
M="kingofcurses:"
class Tpl:
    def __init__(s,sx,sy,sz): s.size=(sx,sy,sz); s.blocks={}; s.ents=[]
    def set(s,x,y,z,st,nbt=None):
        if 0<=x<s.size[0] and 0<=y<s.size[1] and 0<=z<s.size[2]: s.blocks[(x,y,z)]=(st,nbt)
    def fill(s,x0,y0,z0,x1,y1,z1,st):
        for x in range(min(x0,x1),max(x0,x1)+1):
            for y in range(min(y0,y1),max(y0,y1)+1):
                for z in range(min(z0,z1),max(z0,z1)+1): s.set(x,y,z,st)
    def hollow(s,x0,y0,z0,x1,y1,z1,wall,inner="minecraft:air"):
        s.fill(x0,y0,z0,x1,y1,z1,wall); s.fill(x0+1,y0+1,z0+1,x1-1,y1-1,z1-1,inner)
    def air(s,x0,y0,z0,x1,y1,z1): s.fill(x0,y0,z0,x1,y1,z1,"minecraft:air")
    def reliquary(s,x,y,z,finger,facing="south"):
        s.set(x,y,z,M+f"reliquary[facing={facing}]",{"id":M+"reliquary","LootTable":M+"chests/finger_%02d"%finger})
    def chest(s,x,y,z,table,facing="south"):
        s.set(x,y,z,f"minecraft:chest[facing={facing}]",{"id":"minecraft:chest","LootTable":table})
    def ent(s,x,y,z,eid,finger=None):
        nbt={"id":M+eid,"PersistenceRequired":Byte(1)}
        if finger: nbt["FingerIndex"]=Int(finger)
        s.ents.append((x+0.5,y,z+0.5,nbt))
    def save(s,path):
        pal=[]; idx={}; blocks=[]
        def parse(st):
            if "[" in st:
                n,p=st[:-1].split("["); props=dict(kv.split("=") for kv in p.split(","))
            else: n,props=st,{}
            return n,props
        for pos,(st,nbt) in sorted(s.blocks.items()):
            if st not in idx:
                idx[st]=len(pal); n,props=parse(st); d={"Name":n}
                if props: d["Properties"]=props
                pal.append(d)
            b={"pos":TList(3,[Int(v) for v in pos]),"state":Int(idx[st])}
            if nbt: b["nbt"]=nbt
            blocks.append(b)
        ents=[{"pos":TList(6,[Double(x),Double(y),Double(z)]),"blockPos":TList(3,[Int(int(x)),Int(int(y)),Int(int(z))]),"nbt":n} for x,y,z,n in s.ents]
        root={"DataVersion":Int(3465),"size":TList(3,[Int(v) for v in s.size]),"palette":TList(10,pal),"blocks":TList(10,blocks),"entities":TList(10,ents)}
        os.makedirs(os.path.dirname(path),exist_ok=True); write(path,root)

def torii(t,x,y,z,w=5,h=6):
    for px in (x,x+w-1): t.fill(px,y,z,px,y+h-1,z,M+"torii_pillar")
    t.fill(x,y+h-2,z,x+w-1,y+h-2,z,M+"torii_beam")
    t.fill(x-1,y+h,z,x+w,y+h,z,M+"torii_beam")
    t.fill(x-1,y+h+1,z,x+w,y+h+1,z,M+"black_lacquer_planks")
    t.set(x-2,y+h+1,z,M+"shrine_roof_stairs[facing=east,half=top]"); t.set(x+w+1,y+h+1,z,M+"shrine_roof_stairs[facing=west,half=top]")
    t.set(x+w//2,y+h-1,z,M+"cursed_seal_block")
def roof(t,x0,y,z0,x1,z1,layers=3,mat="shrine_roof_stairs",cap="shrine_roof_tiles"):
    for k in range(layers):
        a0,a1,b0,b1=x0+k,x1-k,z0+k,z1-k
        if a0>a1 or b0>b1: break
        for xx in range(a0,a1+1):
            t.set(xx,y+k,b0,M+f"{mat}[facing=south]"); t.set(xx,y+k,b1,M+f"{mat}[facing=north]")
        for zz in range(b0+1,b1):
            t.set(a0,y+k,zz,M+f"{mat}[facing=east]"); t.set(a1,y+k,zz,M+f"{mat}[facing=west]")
        if k==layers-1 or a1-a0<=2 or b1-b0<=2: t.fill(a0+1,y+k,b0+1,a1-1,y+k,b1-1,M+cap)
def lantern_post(t,x,y,z):
    t.set(x,y,z,M+"temple_stone_brick_wall"); t.set(x,y+1,z,M+"temple_stone_brick_wall"); t.set(x,y+2,z,M+"shrine_lantern")
def tree(t,x,y,z,h=5,r=random.Random(1)):
    t.fill(x,y,z,x,y+h-1,z,M+"cursed_wood_log")
    for dx in range(-2,3):
        for dz in range(-2,3):
            for dy in (h-2,h-1,h):
                if abs(dx)+abs(dz)<=(3 if dy<h else 1) and r.random()<0.92 and not(dx==0 and dz==0 and dy<h):
                    t.set(x+dx,y+dy,z+dz,M+"cursed_leaves[persistent=true]")

def cursed_shrine():
    t=Tpl(13,13,15); t.air(0,1,0,12,12,14)
    t.fill(0,0,0,12,0,14,M+"temple_stone_bricks"); t.fill(1,0,1,11,0,13,M+"polished_temple_stone")
    t.fill(3,1,2,9,1,10,M+"temple_stone_bricks")
    t.fill(4,2,3,8,2,9,M+"crimson_tatami")
    for (x,z) in ((3,2),(9,2),(3,10),(9,10)): t.fill(x,2,z,x,6,z,M+"torii_pillar")
    for z in range(3,10): t.fill(3,2,z,3,5,z,M+"talisman_wall"); t.fill(9,2,z,9,5,z,M+"talisman_wall")
    for x in range(4,9): t.fill(x,2,10,x,5,10,M+"black_lacquer_planks")
    t.fill(4,2,2,4,5,2,M+"black_lacquer_planks"); t.fill(8,2,2,8,5,2,M+"black_lacquer_planks"); t.fill(5,5,2,7,5,2,M+"torii_beam")
    t.fill(3,6,2,9,6,10,M+"black_lacquer_planks")
    roof(t,1,7,0,11,12,4)
    t.set(6,2,8,M+"malevolent_altar"); t.reliquary(6,3,8,2,"north")
    t.set(4,3,9,M+"shrine_lantern"); t.set(8,3,9,M+"shrine_lantern")
    torii(t,4,1,13,5,6); lantern_post(t,1,1,12); lantern_post(t,11,1,12)
    t.ent(6,2,5,"fly_head"); t.ent(2,1,7,"fly_head"); t.ent(10,1,4,"crawling_eye")
    return t
def torii_crossing():
    t=Tpl(11,10,25); t.air(0,1,0,10,9,24)
    t.fill(3,0,0,7,0,24,M+"temple_stone_bricks"); t.fill(4,0,0,6,0,24,M+"polished_temple_stone")
    for z in (2,8,14): torii(t,3,1,z,5,6)
    for z in range(1,22,4): lantern_post(t,1,1,z); lantern_post(t,9,1,z)
    t.fill(2,0,19,8,1,23,M+"temple_stone_bricks"); t.set(5,2,22,M+"cursed_seal_block"); t.reliquary(5,2,21,3,"north")
    t.set(3,2,22,M+"shrine_lantern"); t.set(7,2,22,M+"shrine_lantern")
    t.ent(5,1,12,"roppongi_curse"); t.ent(5,2,20,"crawling_eye")
    return t
def curse_den():
    t=Tpl(15,11,15); r=random.Random(4)
    t.fill(0,0,0,14,6,14,M+"cursed_soil"); t.air(2,1,2,12,10,12)
    t.fill(2,0,2,12,0,12,M+"blood_soaked_soil")
    for _ in range(30): t.set(r.randrange(2,13),1,r.randrange(2,13),M+"cursed_bone_pile")
    for _ in range(10): t.set(r.randrange(2,13),1,r.randrange(2,13),M+"cursed_spike_trap")
    for y in range(1,7): t.set(2,y,7,"minecraft:ladder[facing=east]") if False else None
    for y in range(1,7): t.set(1,y,7,M+"cursed_wood_log"); t.set(2,y,7,"minecraft:ladder[facing=east]")
    t.air(7,1,7,7,2,7); t.set(7,1,7,M+"malevolent_altar"); t.reliquary(7,2,7,4)
    for (x,z) in ((3,3),(11,3),(3,11),(11,11)): t.set(x,1,z,M+"shrine_lantern")
    t.ent(5,1,9,"hanged_bride"); t.ent(9,1,5,"roppongi_curse"); t.ent(9,1,9,"finger_bearer",8)
    return t
def cursed_grove():
    t=Tpl(17,12,17); r=random.Random(5); t.air(0,1,0,16,11,16)
    t.fill(0,0,0,16,0,16,M+"cursed_soil")
    for _ in range(25): t.set(r.randrange(17),0,r.randrange(17),M+"blood_soaked_soil")
    for (x,z,h) in ((2,2,6),(13,3,7),(3,13,5),(14,13,6),(8,1,5),(1,8,6),(15,8,5)): tree(t,x,1,z,h,r)
    t.fill(6,1,6,10,1,10,M+"temple_stone_bricks"); t.fill(7,2,7,9,2,9,M+"polished_temple_stone")
    t.set(8,3,8,M+"cursed_seal_block"); t.reliquary(8,3,7,5,"north")
    for (x,z) in ((6,6),(10,6),(6,10),(10,10)): lantern_post(t,x,2,z)
    torii(t,6,1,12,5,5)
    t.ent(8,1,4,"lantern_hag"); t.ent(4,1,8,"fly_head"); t.ent(12,1,8,"fly_head")
    return t
def japanese_temple():
    t=Tpl(21,16,21); t.air(0,1,0,20,15,20)
    t.fill(0,0,0,20,1,20,M+"temple_stone_bricks"); t.fill(1,2,1,19,2,19,M+"temple_stone_slab")
    for x in range(7,14): t.set(x,1,0,M+"temple_stone_brick_stairs[facing=south]") if False else t.set(x,1,0,M+"temple_stone_brick_stairs[facing=north]")
    t.fill(3,2,3,17,2,17,M+"polished_temple_stone")
    for x in (3,7,13,17):
        for z in (3,8,12,17): t.fill(x,3,z,x,8,z,M+"cursed_wood_log")
    for z in range(4,17): t.fill(3,3,z,3,7,z,M+"bone_white_plaster"); t.fill(17,3,z,17,7,z,M+"bone_white_plaster")
    for x in range(4,17): t.fill(x,3,17,x,7,17,M+"bone_white_plaster")
    for x in range(4,17):
        if x not in (9,10,11): t.fill(x,3,3,x,7,3,M+"bone_white_plaster")
    t.fill(4,3,4,16,3,16,M+"crimson_tatami"); t.air(4,4,4,16,8,16)
    t.fill(3,8,3,17,8,17,M+"cursed_wood_planks")
    roof(t,1,9,1,19,19,5)
    t.fill(9,4,14,11,4,15,M+"chiseled_temple_stone"); t.set(10,5,15,M+"malevolent_altar"); t.reliquary(10,5,14,6,"north")
    for (x,z) in ((5,5),(15,5),(5,15),(15,15)): t.set(x,4,z,M+"shrine_lantern")
    for x in (5,8,12,15): t.set(x,7,4,M+"talisman_wall")
    torii(t,8,2,0,5,6) if False else None
    lantern_post(t,6,2,1); lantern_post(t,14,2,1)
    t.ent(10,4,8,"lantern_hag"); t.ent(6,4,12,"lantern_hag"); t.ent(14,4,10,"roppongi_curse")
    return t
def abandoned_school():
    t=Tpl(23,13,15); r=random.Random(6); t.air(0,1,0,22,12,14)
    t.fill(0,0,0,22,0,14,M+"temple_stone")
    t.hollow(1,0,2,21,11,12,M+"bone_white_plaster")
    t.fill(1,6,2,21,6,12,M+"temple_stone_bricks"); t.air(2,1,3,20,5,11); t.air(2,7,3,20,10,11)
    for x in range(3,21,3):
        for y in (2,3,8,9):
            t.set(x,y,2,"minecraft:glass_pane" if r.random()<0.4 else "minecraft:air"); t.set(x,y,12,"minecraft:glass_pane" if r.random()<0.3 else "minecraft:air")
    t.air(10,1,2,12,3,2)
    t.fill(2,1,7,20,5,7,M+"bone_white_plaster"); t.air(10,1,7,12,3,7); t.air(4,1,7,5,3,7); t.air(16,7,7,17,9,7)
    for (x,z) in ((4,4),(7,4),(14,4),(17,4),(4,9),(7,9),(14,9),(17,9)):
        t.set(x,1,z,"minecraft:oak_stairs[facing=north]"); t.set(x,1,z+1,"minecraft:oak_slab[type=top]")
    for k in range(5): t.set(19,1+k,4+k,M+"temple_stone_brick_stairs[facing=south]"); t.air(19,6,4+k,19,6,4+k)
    for _ in range(18):
        x,y,z=r.randrange(2,21),r.choice((0,6)),r.randrange(3,12); t.set(x,y,z,M+"cracked_temple_stone_bricks" if y==6 else M+"blood_soaked_soil")
    for _ in range(12): t.set(r.randrange(1,22),11,r.randrange(2,13),"minecraft:air")
    t.set(4,7,10,M+"crimson_tatami"); t.reliquary(4,8,10,7,"north")
    t.set(11,4,5,M+"shrine_lantern")
    t.ent(6,1,5,"fly_head"); t.ent(15,1,10,"crawling_eye"); t.ent(8,7,9,"hanged_bride"); t.ent(14,7,5,"fly_head")
    return t
def finger_chamber():
    t=Tpl(15,9,15)
    t.hollow(0,0,0,14,8,14,M+"sealing_stone"); t.hollow(1,1,1,13,7,13,M+"temple_stone_bricks")
    t.air(2,2,2,12,6,12)
    t.fill(2,1,2,12,1,12,M+"cracked_temple_stone_bricks")
    for x in range(2,13):
        for z in (4,10): t.set(x,1,z,M+"cursed_spike_trap")
    t.fill(4,1,6,10,1,8,"minecraft:lava"); t.fill(6,1,7,8,1,7,M+"temple_stone_bricks")
    t.fill(6,1,6,8,1,8,"minecraft:lava"); t.set(7,1,7,M+"sealing_stone"); t.set(7,1,6,M+"temple_stone_slab[type=top]"); t.set(7,1,8,M+"temple_stone_slab[type=top]")
    t.set(7,2,7,M+"malevolent_altar"); t.reliquary(7,3,7,9)
    for (x,z) in ((2,2),(12,2),(2,12),(12,12)): t.set(x,2,z,M+"shrine_lantern")
    for x in range(3,12,2): t.set(x,6,2,M+"cursed_seal_block"); t.set(x,6,12,M+"cursed_seal_block")
    t.air(7,1,0,7,3,1); t.air(7,2,1,7,3,1); t.set(7,1,1,M+"cursed_spike_trap")
    t.ent(4,2,11,"cursed_womb",11); t.ent(10,2,3,"crawling_eye")
    return t
def cursed_cemetery():
    t=Tpl(17,8,17); r=random.Random(8); t.air(0,1,0,16,7,16)
    t.fill(0,0,0,16,0,16,M+"cursed_soil")
    for x in range(0,17): t.set(x,1,0,M+"temple_stone_brick_wall"); t.set(x,1,16,M+"temple_stone_brick_wall")
    for z in range(0,17): t.set(0,1,z,M+"temple_stone_brick_wall"); t.set(16,1,z,M+"temple_stone_brick_wall")
    t.air(7,1,0,9,1,0)
    for gx in range(3,15,3):
        for gz in range(3,15,4):
            t.set(gx,1,gz,M+"temple_stone_bricks"); t.set(gx,2,gz,M+"chiseled_temple_stone"); t.set(gx,3,gz,M+"temple_stone_slab")
            t.set(gx,0,gz+1,M+"blood_soaked_soil")
    tree(t,2,1,14,5,r); tree(t,14,1,2,4,r)
    t.reliquary(8,0,13,13); t.set(8,1,13,M+"temple_stone_slab")
    t.set(8,1,14,M+"cursed_seal_block"); t.set(8,2,14,M+"shrine_lantern")
    t.ent(8,1,8,"smallpox_deity",10); t.ent(4,1,12,"fly_head")
    return t
def jujutsu_high():
    t=Tpl(33,16,29); t.air(0,1,0,32,15,28)
    t.fill(0,0,0,32,0,28,"minecraft:grass_block"); t.fill(14,0,0,18,0,28,M+"temple_stone_bricks")
    torii(t,13,1,1,7,7)
    # main hall
    t.fill(9,0,16,23,1,26,M+"temple_stone_bricks")
    t.hollow(10,1,17,22,8,25,M+"bone_white_plaster"); t.air(11,2,18,21,7,24)
    for x in (10,14,18,22):
        for z in (17,25): t.fill(x,2,z,x,8,z,M+"torii_pillar")
    t.fill(11,1,18,21,1,24,M+"crimson_tatami"); t.air(15,2,17,17,4,17)
    t.fill(10,8,17,22,8,25,M+"cursed_wood_planks"); roof(t,8,9,15,24,27,5)
    # vault
    t.fill(14,2,22,18,6,24,M+"sealing_stone"); t.air(15,2,23,17,4,23); t.air(16,2,22,16,3,22)
    t.reliquary(16,2,23,12,"south"); t.set(15,2,23,M+"shrine_lantern"); t.set(17,2,23,M+"shrine_lantern")
    # dorm
    t.fill(1,0,8,9,0,14,M+"temple_stone_bricks"); t.hollow(1,1,8,9,6,14,M+"cursed_wood_planks"); t.air(2,2,9,8,5,13)
    t.fill(2,1,9,8,1,13,M+"crimson_tatami"); t.air(9,2,11,9,3,11); roof(t,0,7,7,10,15,3)
    t.chest(3,2,12,"kingofcurses:chests/jujutsu_high_supplies","east")
    # training yard
    t.fill(23,0,6,31,0,14,M+"polished_temple_stone")
    for (x,z) in ((24,7),(30,7),(24,13),(30,13)): lantern_post(t,x,1,z)
    for z in (5,10,15,20): lantern_post(t,12,1,z); lantern_post(t,20,1,z)
    t.ent(16,1,10,"jujutsu_student"); t.ent(27,1,10,"jujutsu_student"); t.ent(5,2,11,"jujutsu_student"); t.ent(25,1,8,"jujutsu_student")
    t.ent(16,2,20,"jujutsu_sorcerer"); t.ent(12,2,20,"jujutsu_sorcerer"); t.ent(20,2,19,"sorcerer_elite")
    return t
def crimson_shrine():
    t=Tpl(17,11,17)
    t.hollow(0,0,0,16,10,16,"minecraft:nether_bricks"); t.air(1,1,1,15,9,15)
    t.fill(1,1,1,15,1,15,M+"temple_stone_bricks"); t.fill(3,1,3,13,1,13,"minecraft:crimson_planks")
    for (x,z) in ((3,3),(13,3),(3,13),(13,13)): t.fill(x,2,z,x,8,z,M+"torii_pillar")
    roof(t,2,9,2,14,14,1,cap="cursed_seal_block")
    t.fill(7,2,11,9,2,13,M+"chiseled_temple_stone"); t.set(8,3,12,M+"malevolent_altar"); t.reliquary(8,4,12,14,"north")
    for (x,z) in ((2,8),(14,8),(8,2)): t.set(x,2,z,M+"shrine_lantern")
    t.air(7,2,0,9,4,0); t.set(8,1,0,"minecraft:nether_bricks")
    t.ent(8,2,6,"shrine_warden",15)
    return t
def end_reliquary():
    t=Tpl(13,14,13); t.air(0,1,0,12,13,12)
    t.fill(0,0,0,12,0,12,"minecraft:purpur_block"); t.fill(2,1,2,10,1,10,M+"temple_stone_bricks")
    for (x,z) in ((2,2),(10,2),(2,10),(10,10)): t.fill(x,2,z,x,9,z,"minecraft:purpur_pillar")
    t.fill(2,10,2,10,10,10,M+"sealing_stone"); roof(t,1,11,1,11,11,3,cap="cursed_seal_block")
    t.fill(5,2,5,7,2,7,M+"cursed_seal_block"); t.set(6,3,6,M+"malevolent_altar"); t.reliquary(6,4,6,16)
    for (x,z) in ((4,4),(8,4),(4,8),(8,8)): t.set(x,2,z,"minecraft:end_rod")
    t.ent(6,2,10,"shrine_warden",17)
    return t
def malevolent_ruins():
    t=Tpl(19,12,19); r=random.Random(12); t.air(0,1,0,18,11,18)
    t.fill(0,0,0,18,0,18,M+"blood_soaked_soil"); t.fill(3,0,3,15,0,15,M+"temple_stone_bricks")
    for _ in range(40): t.set(r.randrange(19),1,r.randrange(19),M+"cursed_bone_pile")
    for (x,z,h) in ((3,3,8),(15,3,5),(3,15,6),(15,15,9),(9,3,4)): t.fill(x,1,z,x,h,z,M+"torii_pillar")
    t.fill(3,9,15,15,9,15,M+"torii_beam"); t.fill(15,10,3,15,10,15,M+"shrine_roof_tiles")
    t.fill(7,1,7,11,1,11,M+"chiseled_temple_stone"); t.set(9,2,9,M+"malevolent_altar"); t.reliquary(9,3,9,18)
    for (x,z) in ((7,7),(11,7),(7,11),(11,11)): t.set(x,2,z,M+"shrine_lantern")
    t.ent(9,1,14,"shrine_warden",19); t.ent(4,1,9,"hanged_bride")
    return t
def sealed_vault():
    t=Tpl(13,9,13)
    t.hollow(0,0,0,12,8,12,M+"sealing_stone"); t.air(2,2,2,10,6,10); t.fill(1,1,1,11,1,11,M+"cursed_seal_block")
    for x in range(2,11):
        for z in range(2,11):
            if (x+z)%3==0: t.set(x,1,z,M+"cursed_spike_trap")
    t.set(6,2,6,M+"malevolent_altar"); t.reliquary(6,3,6,20)
    for (x,z) in ((2,2),(10,2),(2,10),(10,10)): t.set(x,2,z,M+"shrine_lantern")
    t.ent(3,2,8,"bone_centipede"); t.ent(9,2,4,"hanged_bride"); t.ent(9,2,9,"hanged_bride")
    return t

def dark_institute():
    """v1.0.20: a hidden institute of curse users. The altar chest holds one of Sukuna's clues."""
    t=Tpl(21,13,21); r=random.Random(77); t.air(0,1,0,20,12,20)
    t.fill(0,0,0,20,0,20,"minecraft:blackstone"); t.fill(2,0,2,18,0,18,"minecraft:polished_blackstone_bricks")
    t.hollow(3,1,3,17,7,17,"minecraft:deepslate_bricks"); t.air(4,2,4,16,6,16)
    t.fill(4,1,4,16,1,16,M+"blood_soaked_soil"); t.fill(6,1,6,14,1,14,"minecraft:polished_blackstone")
    for (x,z) in ((3,3),(17,3),(3,17),(17,17),(10,3),(10,17),(3,10),(17,10)): t.fill(x,1,z,x,9,z,"minecraft:polished_basalt[axis=y]")
    t.air(9,2,3,11,4,3)                                                                                 # gate
    for x in range(4,17,3): t.fill(x,3,3,x,5,3,M+"talisman_wall")
    t.fill(3,8,3,17,8,17,"minecraft:deepslate_tiles"); roof(t,2,9,2,18,18,3,mat="shrine_roof_stairs",cap="cursed_seal_block")
    t.fill(8,2,12,12,2,14,M+"cursed_seal_block"); t.set(10,3,13,M+"malevolent_altar")
    t.chest(10,3,12,"kingofcurses:chests/dark_institute","south")
    for (x,z) in ((5,5),(15,5),(5,15),(15,15)): t.set(x,2,z,"minecraft:soul_lantern")
    for _ in range(18): t.set(r.randrange(4,17),2,r.randrange(5,12),M+"cursed_bone_pile")
    for (x,z) in ((6,8),(14,8),(10,7),(7,14)): t.ent(x,2,z,"curse_user")
    t.ent(13,2,13,"curse_user"); t.ent(10,1,1,"roppongi_curse")
    for (x,z) in ((8,1),(12,1)): lantern_post(t,x,1,z)
    return t

STRUCTS={ # name: (builder, biomes, spacing, separation, salt, placement)
 "cursed_shrine":(cursed_shrine,["#minecraft:is_forest","#minecraft:is_taiga","minecraft:plains","minecraft:cherry_grove","minecraft:meadow"],34,12,73001,"surface"),
 "torii_crossing":(torii_crossing,["minecraft:plains","minecraft:sunflower_plains","minecraft:meadow","minecraft:cherry_grove","#minecraft:is_forest"],38,14,73002,"surface"),
 "curse_den":(curse_den,["#minecraft:is_overworld"],40,14,73003,"den"),
 "cursed_grove":(cursed_grove,["minecraft:dark_forest","minecraft:old_growth_spruce_taiga","minecraft:swamp","#minecraft:is_forest"],42,16,73004,"surface"),
 "japanese_temple":(japanese_temple,["#minecraft:is_mountain","minecraft:cherry_grove","#minecraft:is_taiga","minecraft:plains"],48,18,73005,"surface"),
 "abandoned_school":(abandoned_school,["minecraft:plains","minecraft:savanna","minecraft:sunflower_plains","minecraft:forest","minecraft:birch_forest"],52,20,73006,"surface"),
 "finger_chamber":(finger_chamber,["#minecraft:is_overworld"],44,16,73007,"underground"),
 "cursed_cemetery":(cursed_cemetery,["minecraft:swamp","minecraft:dark_forest","#minecraft:is_taiga","minecraft:plains"],46,16,73008,"surface"),
 "jujutsu_high":(jujutsu_high,["#minecraft:is_forest","#minecraft:is_mountain","minecraft:cherry_grove","minecraft:meadow","minecraft:plains"],64,24,73009,"surface"),
 "crimson_shrine":(crimson_shrine,["#minecraft:is_nether"],30,10,73010,"nether"),
 "end_reliquary":(end_reliquary,["minecraft:end_highlands","minecraft:end_midlands"],24,8,73011,"surface"),
 "malevolent_ruins":(malevolent_ruins,["#minecraft:is_badlands","minecraft:desert","minecraft:savanna","minecraft:plains","minecraft:dark_forest"],56,20,73012,"surface"),
 "sealed_vault":(sealed_vault,["#minecraft:is_overworld"],56,20,73013,"deep"),
 "dark_institute":(dark_institute,["#minecraft:is_overworld"],22,8,73014,"surface"),
}
def write_all(res):
    out={}
    for name,(fn,biomes,sp,sep,salt,kind) in STRUCTS.items():
        t=fn(); t.save(f"{res}/data/kingofcurses/structures/{name}.nbt"); out[name]=t
    return out
