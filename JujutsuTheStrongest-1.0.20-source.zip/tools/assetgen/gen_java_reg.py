from spec import *
import os
def up(s): return s.upper()
def write(root, rel, txt):
    p=f"{root}/src/main/java/com/kingofcurses/{rel}"; os.makedirs(os.path.dirname(p),exist_ok=True); open(p,"w").write(txt)
def gen(root):
    # ---------- ModBlocks ----------
    L=[]
    for bid,kind,props,tool,en,it,ex in BLOCKS:
        P=props.replace("Properties.","BlockBehaviour.Properties.") if props.startswith("Properties") else None
        base_v="Blocks.STONE_BRICKS" if tool=="pickaxe" else "Blocks.DARK_OAK_PLANKS"
        if kind in("cube","ore"): ctor=f"() -> new Block({P})"
        elif kind=="pillar": ctor=f"() -> new RotatedPillarBlock({P})"
        elif kind=="stairs": ctor=f"() -> new StairBlock(() -> {up(props)}.get().defaultBlockState(), BlockBehaviour.Properties.copy({base_v}))"
        elif kind=="slab": ctor=f"() -> new SlabBlock(BlockBehaviour.Properties.copy({base_v}))"
        elif kind=="wall": ctor=f"() -> new WallBlock(BlockBehaviour.Properties.copy({base_v}))"
        elif kind=="fence": ctor=f"() -> new FenceBlock(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_FENCE))"
        elif kind=="fence_gate": ctor=f"() -> new FenceGateBlock(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_FENCE_GATE), WoodType.DARK_OAK)"
        elif kind=="leaves": ctor=f"() -> new LeavesBlock({P})"
        elif kind=="lantern": ctor=f"() -> new ShrineLanternBlock({P})"
        elif kind=="reliquary": ctor=f"() -> new ReliquaryBlock({P})"
        elif kind=="burial": ctor=f"() -> new FingerBurialBlock({P})"
        elif kind=="trap": ctor=f"() -> new CursedSpikeTrapBlock({P})"
        elif kind=="altar": ctor=f"() -> new MalevolentAltarBlock({P})"
        elif kind=="csand": ctor=f"() -> new com.kingofcurses.block.CursedSandBlock({P})"
        elif kind=="hportal": ctor=f"() -> new com.kingofcurses.block.HeianPortalBlock({P})"
        L.append(f'    public static final RegistryObject<Block> {up(bid)} = register("{bid}", {ctor});')
    write(root,"registry/ModBlocks.java",f'''package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.block.CursedSpikeTrapBlock;
import com.kingofcurses.block.FingerBurialBlock;
import com.kingofcurses.block.MalevolentAltarBlock;
import com.kingofcurses.block.ReliquaryBlock;
import com.kingofcurses.block.ShrineLanternBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

/** All blocks of the mod. Each block also registers its BlockItem. */
public final class ModBlocks {{
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, KingOfCurses.MODID);

{chr(10).join(L)}

    private ModBlocks() {{}}

    private static RegistryObject<Block> register(String name, Supplier<Block> supplier) {{
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }}
}}
''')
    # ---------- ModItems ----------
    I=[]
    I.append('    public static final RegistryObject<Item> CURSED_CODEX = ITEMS.register("cursed_codex", () -> new CursedCodexItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));')
    I.append('    public static final RegistryObject<Item> SUKUNA_CLUE = ITEMS.register("sukuna_clue", () -> new com.kingofcurses.item.ClueItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));')
    I.append('    public static final RegistryObject<Item> SUKUNA_ARM = ITEMS.register("sukuna_arm", () -> new com.kingofcurses.item.SukunaArmItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));')
    I.append('    public static final RegistryObject<Item> HEIAN_SEAL = ITEMS.register("heian_seal", () -> new com.kingofcurses.item.HeianSealItem(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC)));')
    I.append('    public static final RegistryObject<Item> REMAINS_COMPASS = ITEMS.register("remains_compass", () -> new com.kingofcurses.item.RemainsCompassItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE).fireResistant()));')
    I.append('    public static final RegistryObject<Item> CURSED_COMPASS = ITEMS.register("cursed_compass", () -> new CursedCompassItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));')
    for m,_,_ in MATERIALS:
        r="Rarity.EPIC" if m=="special_grade_core" else "Rarity.COMMON"
        I.append(f'    public static final RegistryObject<Item> {up(m)} = ITEMS.register("{m}", () -> new Item(new Item.Properties().rarity({r})));')
    for tid,ty,_,_ in TALISMANS:
        I.append(f'    public static final RegistryObject<Item> {up(tid)} = ITEMS.register("{tid}", () -> new TalismanItem(TalismanItem.Type.{ty}, new Item.Properties().stacksTo(16)));')
    for vid,ce,heal,_,_ in VIALS:
        I.append(f'    public static final RegistryObject<Item> {up(vid)} = ITEMS.register("{vid}", () -> new CursedVialItem({ce}f, {heal}f, new Item.Properties().stacksTo(16)));')
    for wid,tier,dmg,spd,perk,_,_ in WEAPONS:
        r="Rarity.EPIC" if tier=="SPECIAL" else "Rarity.UNCOMMON"
        I.append(f'    public static final RegistryObject<Item> {up(wid)} = ITEMS.register("{wid}", () -> new CursedWeaponItem(KocTiers.{tier}, {dmg}, {spd}f, CursedWeaponItem.Perk.{perk}, new Item.Properties().rarity({r})));')
    tools={"pickaxe":"new PickaxeItem(KocTiers.CURSED, 1, -2.8f, new Item.Properties())","axe":"new AxeItem(KocTiers.CURSED, 5.0f, -3.0f, new Item.Properties())",
           "shovel":"new ShovelItem(KocTiers.CURSED, 1.5f, -3.0f, new Item.Properties())","hoe":"new HoeItem(KocTiers.CURSED, -3, 0.0f, new Item.Properties())"}
    for tid,kind,_,_ in TOOLS: I.append(f'    public static final RegistryObject<Item> {up(tid)} = ITEMS.register("{tid}", () -> {tools[kind]});')
    for sid,mat,_,_ in ARMOR_SETS:
        for p,ty,_,_ in ARMOR_PIECES:
            I.append(f'    public static final RegistryObject<Item> {up(sid+"_"+p)} = ITEMS.register("{sid}_{p}", () -> new ArmorItem(KocArmorMaterials.{mat}, ArmorItem.Type.{ty}, new Item.Properties()));')
    for tid,ab,_,_ in TECHNIQUES:
        I.append(f'    public static final RegistryObject<Item> {up(tid)} = ITEMS.register("{tid}", () -> new TechniqueItem(com.kingofcurses.ability.Ability.{ab}, new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));')
    for oid,_,_ in CURSED_OBJECTS:
        I.append(f'    public static final RegistryObject<Item> {up(oid)} = ITEMS.register("{oid}", () -> new CursedObjectItem(CursedObjectItem.Kind.{up(oid)}, CursedObjectItem.props(CursedObjectItem.Kind.{up(oid)})));')
    I.append('    public static final RegistryObject<Item> RIPPED_FINGER = ITEMS.register("ripped_finger", () -> new RippedFingerItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));')
    I.append('    public static final RegistryObject<Item> GOJO_BLINDFOLD = ITEMS.register("gojo_blindfold", () -> new CollectibleArmorItem(KocArmorMaterials.GOJO_BLINDFOLD, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));')
    for e in ENTITIES:
        if e[1] in NO_EGG: continue
        I.append(f'    public static final RegistryObject<Item> {up(e[0])}_SPAWN_EGG = ITEMS.register("{e[0]}_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.{up(e[0])}, 0x{e[9]:06x}, 0x{e[10]:06x}, new Item.Properties()));')
    write(root,"registry/ModItems.java",f'''package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.item.*;
import net.minecraft.world.item.*;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModItems {{
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, KingOfCurses.MODID);

    /** v1.0.4: every finger is the same item. Eat it to absorb the next of the twenty. */
    public static final RegistryObject<Item> SUKUNA_FINGER = ITEMS.register("sukuna_finger",
            () -> new SukunaFingerItem(new Item.Properties().stacksTo(20).rarity(Rarity.EPIC).fireResistant()));
    /** Old numbered fingers (1.0.0 - 1.0.3): kept only so old worlds convert them into {{@link #SUKUNA_FINGER}}. */
    public static final List<RegistryObject<Item>> LEGACY_FINGERS;
    static {{
        List<RegistryObject<Item>> list = new ArrayList<>();
        for (int i = 1; i <= 20; i++) list.add(ITEMS.register("sukuna_finger_" + i, () -> new LegacyFingerItem(new Item.Properties().stacksTo(20))));
        LEGACY_FINGERS = Collections.unmodifiableList(list);
    }}

{chr(10).join(I)}

    private ModItems() {{}}
}}
''')
    # ---------- ModEntities ----------
    E=[]; A=[]; SP=[]
    for (eid,fac,cat,w,h,hp,dmg,spd,arm,bg,fg,en,it,grade,plan) in ENTITIES:
        U=up(eid); kindc=U
        fire=".fireImmune()" if eid in("heian_sukuna","sukuna_arm_thrown","ryomen_sukuna","sukuna_true_form","shrine_warden","lantern_hag","malevolent_shrine","fuga_arrow","gojo_kenjaku") else ""
        if fac=="SUKUNA": cls="SukunaEntity"; f=f"(t, l) -> new SukunaEntity(t, l, {'true' if 'true' in eid else 'false'})"
        elif fac=="GOJO": cls="GojoEntity"; f="GojoEntity::new"
        elif fac=="CURSE": cls="CursedSpiritEntity"; f=f"(t, l) -> new CursedSpiritEntity(t, l, CurseKind.{U})"
        elif fac=="SPECIAL": cls="SpecialGradeCurseEntity"; f=f"(t, l) -> new SpecialGradeCurseEntity(t, l, CurseKind.{U})"
        elif fac=="SORCERER": cls="SorcererEntity"; f=f"(t, l) -> new SorcererEntity(t, l, SorcererEntity.Kind.{ {'jujutsu_sorcerer':'SORCERER','sorcerer_elite':'ELITE','jujutsu_student':'STUDENT'}[eid] })"
        elif fac=="NAMED": cls="NamedSorcererEntity"; f=f"(t, l) -> new NamedSorcererEntity(t, l, NamedSorcererEntity.Kind.{U})"
        elif fac=="GOJOBOSS": cls="GojoKenjakuEntity"; f="GojoKenjakuEntity::new"
        elif fac=="BOSS": cls="SealingMasterEntity"; f="SealingMasterEntity::new"
        elif fac=="SHRINE": cls="MalevolentShrineEntity"; f="MalevolentShrineEntity::new"
        elif fac=="DISMANTLE": cls="DismantleSlashEntity"; f="DismantleSlashEntity::new"
        elif fac=="FUGA": cls="FugaArrowEntity"; f="FugaArrowEntity::new"
        elif fac=="SLICED": cls="SlicedCorpseEntity"; f="SlicedCorpseEntity::new"
        elif fac=="HEIAN": cls="HeianSukunaEntity"; f="HeianSukunaEntity::new"
        elif fac=="TOJI": cls="TojiEntity"; f="TojiEntity::new"
        elif fac=="GETO": cls="GetoEntity"; f="GetoEntity::new"
        elif fac=="CURSEUSER": cls="CurseUserEntity"; f="CurseUserEntity::new"
        elif fac=="ARM": cls="SukunaArmEntity"; f="SukunaArmEntity::new"
        rng = "clientTrackingRange(6).updateInterval(1)" if fac=="ARM" else "clientTrackingRange(4).updateInterval(2)" if fac in("DISMANTLE","FUGA") else "clientTrackingRange(8).updateInterval(20)" if fac=="SLICED" else ("clientTrackingRange(10)" if fac!="SHRINE" else "clientTrackingRange(12)")
        E.append(f'    public static final RegistryObject<EntityType<{cls}>> {U} = ENTITIES.register("{eid}",\n            () -> EntityType.Builder.<{cls}>of({f}, MobCategory.{cat}).sized({w}f, {h}f){fire}.{rng}.build(id("{eid}")));')
        if hp>0:
            kb=0.0 if hp<100 else (0.6 if hp<300 else 0.9)
            base={"SUKUNA":"SukunaEntity","GOJO":"GojoEntity","CURSE":"CursedSpiritEntity","SPECIAL":"CursedSpiritEntity","SORCERER":"SorcererEntity","BOSS":"SorcererEntity","GOJOBOSS":"GojoKenjakuEntity","NAMED":"NamedSorcererEntity","HEIAN":"HeianSukunaEntity","TOJI":"TojiEntity","GETO":"GetoEntity","CURSEUSER":"CurseUserEntity"}[fac]
            A.append(f'        event.put({U}.get(), {base}.createAttributes({hp}, {dmg}, {spd}, {arm}, {kb}).build());')
        if fac in("CURSE","CURSEUSER"):
            SP.append(f'        event.register({U}.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);')
    write(root,"registry/ModEntities.java",f'''package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.entity.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {{
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, KingOfCurses.MODID);

{chr(10).join(E)}

    private ModEntities() {{}}

    private static String id(String path) {{
        return new ResourceLocation(KingOfCurses.MODID, path).toString();
    }}

    /** Mod-bus listener. */
    public static void registerAttributes(EntityAttributeCreationEvent event) {{
{chr(10).join(A)}
    }}

    /** Mod-bus listener. */
    public static void registerSpawnPlacements(SpawnPlacementRegisterEvent event) {{
{chr(10).join(SP)}
    }}
}}
''')
    # ---------- Sounds / particles / effects ----------
    S="\n".join(f'    public static final RegistryObject<SoundEvent> {up(s)} = register("{s}");' for s in SOUNDS)
    write(root,"registry/ModSounds.java",f'''package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {{
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, KingOfCurses.MODID);

{S}

    private ModSounds() {{}}

    private static RegistryObject<SoundEvent> register(String name) {{
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(KingOfCurses.MODID, name)));
    }}
}}
''')
    Pp="\n".join(f'    public static final RegistryObject<SimpleParticleType> {up(p)} = PARTICLES.register("{p}", () -> new SimpleParticleType(true));' for p in PARTICLES)
    write(root,"registry/ModParticles.java",f'''package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModParticles {{
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, KingOfCurses.MODID);

{Pp}

    private ModParticles() {{}}
}}
''')
    Ef="\n".join(f'    public static final RegistryObject<MobEffect> {up(e)} = EFFECTS.register("{e}", () -> new KocEffect(MobEffectCategory.{c}, 0x{col:06x}, KocEffect.Kind.{up(e)}));' for e,c,col,_,_ in EFFECTS)
    write(root,"registry/ModEffects.java",f'''package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.effect.KocEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {{
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, KingOfCurses.MODID);

{Ef}

    private ModEffects() {{}}
}}
''')
    # client renderers registration list
    R=[]
    for e in ENTITIES:
        eid=e[0]; U=up(eid); glow="true"; head="false" if e[1] in NO_EGG else "true"
        if e[1]=="SLICED":
            R.append(f'        event.registerEntityRenderer(ModEntities.{U}.get(), com.kingofcurses.client.renderer.SlicedCorpseRenderer::new);'); continue
        if e[1]=="GOJOBOSS":
            R.append(f'        event.registerEntityRenderer(ModEntities.{U}.get(), ctx -> new KocGeoRenderer<>(ctx, new com.kingofcurses.client.renderer.GojoKenjakuGeoModel(), 0.36f));'); continue
        if e[1]=="GOJO":
            R.append(f'        event.registerEntityRenderer(ModEntities.{U}.get(), ctx -> new KocGeoRenderer<>(ctx, new com.kingofcurses.client.renderer.GojoGeoModel(), 0.36f));'); continue
        shadow={"SHRINE":"0.0f","DISMANTLE":"0.0f","FUGA":"0.0f","SLICED":"0.0f"}.get(e[1],f"{max(0.3,e[3]*0.6):.2f}f")
        R.append(f'        event.registerEntityRenderer(ModEntities.{U}.get(), ctx -> new KocGeoRenderer<>(ctx, "{eid}", {head}, {shadow}));')
    return "\n".join(R)
