# Asset generator

Every texture, GeckoLib model/animation, sound, structure NBT and data JSON in `src/main/resources`
was produced by these scripts (Python 3.10+, Pillow, numpy, scipy, ffmpeg with libvorbis).
The registries in `registry/ModBlocks|ModItems|ModEntities|ModSounds|ModParticles|ModEffects.java`
are generated from the same `spec.py`, so IDs, lang keys, models and loot tables never drift apart.

    python3 gen_all.py
    python3 validate.py           # cross-checks every reference (0 errors expected)

Forge's own `runData` task is configured too (output: `src/generated/resources`) if you prefer
to migrate to Java datagen providers later.
