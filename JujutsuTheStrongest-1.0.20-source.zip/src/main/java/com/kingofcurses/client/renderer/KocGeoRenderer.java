package com.kingofcurses.client.renderer;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.world.entity.Entity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** Shared GeckoLib renderer. Every model ships a NAME_glowmask.png for emissive eyes, markings and cursed energy. */
public class KocGeoRenderer<T extends Entity & GeoAnimatable> extends GeoEntityRenderer<T> {
    public KocGeoRenderer(EntityRendererProvider.Context ctx, String name, boolean turnsHead, float shadow) {
        super(ctx, new KocGeoModel<>(name, turnsHead));
        this.shadowRadius = shadow;
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        addRenderLayer(new VesselGeoLayer<>(this));
    }

    public KocGeoRenderer(EntityRendererProvider.Context ctx, software.bernie.geckolib.model.GeoModel<T> model, float shadow) {
        super(ctx, model);
        this.shadowRadius = shadow;
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        addRenderLayer(new VesselGeoLayer<>(this));
    }
}
