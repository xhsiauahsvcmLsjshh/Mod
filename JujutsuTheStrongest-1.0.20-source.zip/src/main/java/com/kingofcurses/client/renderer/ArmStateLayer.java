package com.kingofcurses.client.renderer;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.client.BodyAnims;
import com.kingofcurses.client.ClientData;
import com.kingofcurses.client.ClientForgeEvents;
import com.kingofcurses.client.RipAnim;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * v1.0.7 main-arm states drawn instead of the (hidden) vanilla arms:
 * a bloody stump for a lost arm, an arm growing back out of the shoulder, and the roar pose of the four-arm awakening.
 */
public class ArmStateLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation GORE = new ResourceLocation(KingOfCurses.MODID, "textures/entity/gore.png");

    public ArmStateLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); }

    /** Which main arms ClientForgeEvents must hide for this player this frame (bit 1 right, bit 2 left). */
    public static int hiddenArms(AbstractClientPlayer p, float pt) {
        if (RipAnim.progress(p.getId(), pt) >= 0) return 3;
        if (BodyAnims.roar(p.getId(), pt) > 0) return 3;
        if (BodyAnims.finisher(p.getId(), pt) >= 0) return 3;
        if (BodyAnims.introArm(p.getId(), true, pt, 0f) != null) return 3;
        int mask = ClientData.lostArmsOf(p);
        for (int a : new int[]{CursedData.ARM_RIGHT, CursedData.ARM_LEFT}) if (BodyAnims.regrow(p.getId(), a, pt) >= 0) mask |= a;
        return mask;
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float pt, float age, float netHeadYaw, float headPitch) {
        if (player.isInvisible() || RipAnim.progress(player.getId(), pt) >= 0) return;   // RipArmsLayer handles that one
        PlayerModel<AbstractClientPlayer> m = getParentModel();
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0f);
        int lost = ClientData.lostArmsOf(player);
        float roar = BodyAnims.roar(player.getId(), pt);
        int tier = SukunaMarkingsLayer.tier(player);
        for (int a : new int[]{CursedData.ARM_RIGHT, CursedData.ARM_LEFT}) {
            boolean right = a == CursedData.ARM_RIGHT;
            ModelPart arm = right ? m.rightArm : m.leftArm, sleeve = right ? m.rightSleeve : m.leftSleeve;
            float side = right ? -1f : 1f;
            float rg = BodyAnims.regrow(player.getId(), a, pt);
            float len, thick, gore;
            if (rg >= 0) { float g = rg * rg * (3 - 2 * rg); len = Math.max(0.05f, g); thick = 0.55f + 0.45f * g; gore = 1f - g; }
            else if ((lost & a) != 0) { len = 0.22f; thick = 1f; gore = 1f; }
            else if (roar > 0) { len = 1f; thick = 1f; gore = 0f; }
            else if (BodyAnims.finisher(player.getId(), pt) >= 0 || BodyAnims.introArm(player.getId(), right, pt, age) != null) { len = 1f; thick = 1f; gore = 0f; }
            else continue;
            PartPose ap = arm.storePose(), sp = sleeve.storePose();
            boolean av = arm.visible, sv = sleeve.visible;
            if (roar > 0 && (lost & a) == 0) {      // arms flung open, shaking with power
                arm.xRot = Mth.lerp(roar, ap.xRot, -0.35f) + Mth.sin(age * 2.3f + side) * 0.05f * roar;
                arm.yRot = Mth.lerp(roar, ap.yRot, 0f);
                arm.zRot = Mth.lerp(roar, ap.zRot, -side * 1.25f);
            }
            float[] fin = (lost & a) == 0 ? BodyAnims.finisherArm(player.getId(), right, pt, age) : null;
            if (fin == null && (lost & a) == 0) fin = BodyAnims.introArm(player.getId(), right, pt, age);
            if (fin != null) { arm.xRot = fin[0]; arm.yRot = fin[1]; arm.zRot = fin[2]; }
            arm.yScale = len; arm.xScale = thick; arm.zScale = thick;
            sleeve.copyFrom(arm); sleeve.xScale = thick; sleeve.yScale = len; sleeve.zScale = thick;
            arm.visible = true;
            arm.render(pose, buffers.getBuffer(RenderType.entityCutoutNoCull(player.getSkinTextureLocation())), light, overlay, 1f, 1f, 1f, 1f);
            if (ClientForgeEvents.sleeveWasVisible(sleeve) && gore < 0.5f) {
                sleeve.visible = true;
                sleeve.render(pose, buffers.getBuffer(RenderType.entityTranslucent(player.getSkinTextureLocation())), light, overlay, 1f, 1f, 1f, 1f);
            }
            if (tier > 0 && gore < 0.5f) {
                arm.render(pose, buffers.getBuffer(RenderType.entityTranslucent(SukunaMarkingsLayer.ink(tier))), light, overlay, 1f, 1f, 1f, 1f);
                float p = SukunaMarkingsLayer.pulse(age);
                arm.render(pose, buffers.getBuffer(RenderType.eyes(SukunaMarkingsLayer.glow(tier))), 15728640, overlay, p, p, p, 1f);
            }
            if (gore > 0.01f) arm.render(pose, buffers.getBuffer(RenderType.entityTranslucent(GORE)), light, overlay, 1f, 1f, 1f, Math.min(1f, gore * 0.9f));
            arm.visible = av; sleeve.visible = sv;
            arm.loadPose(ap); sleeve.loadPose(sp);
            arm.xScale = arm.yScale = arm.zScale = 1f;
            sleeve.xScale = sleeve.yScale = sleeve.zScale = 1f;
        }
    }
}
