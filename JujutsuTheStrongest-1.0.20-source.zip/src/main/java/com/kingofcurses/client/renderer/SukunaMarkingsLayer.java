package com.kingofcurses.client.renderer;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.client.ClientData;
import com.kingofcurses.client.ClientFx;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Sukuna's vessel tattoos on the player's skin (v1.0.4: visible from the very first finger).
 * Pass 1 draws the black ink like real tattoos, pass 2 adds a faint crimson glow that pulses brighter when a finger is eaten.
 */
public class SukunaMarkingsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation[] INK = new ResourceLocation[5];
    private static final ResourceLocation[] GLOW = new ResourceLocation[5];
    static {
        for (int i = 0; i < 5; i++) {
            INK[i] = new ResourceLocation(KingOfCurses.MODID, "textures/entity/markings/markings_" + (i + 1) + ".png");
            GLOW[i] = new ResourceLocation(KingOfCurses.MODID, "textures/entity/markings/markings_" + (i + 1) + "_glow.png");
        }
    }

    public SukunaMarkingsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); }

    /** 0 = no markings, otherwise 1..5. */
    public static int tier(AbstractClientPlayer player) {
        int f = ClientData.fingersOf(player);
        int ending = ClientData.endingOf(player);
        if (f <= 0 && ending != CursedData.ENDING_EMBRACE) return 0;
        int tier = (ending == CursedData.ENDING_EMBRACE || f >= 20) ? 5 : f >= 15 ? 4 : f >= 10 ? 3 : f >= 5 ? 2 : 1;
        if (ending == CursedData.ENDING_REJECT) tier = Math.min(tier, 2);
        return tier;
    }

    public static ResourceLocation ink(int tier) { return INK[Mth.clamp(tier, 1, 5) - 1]; }
    public static ResourceLocation glow(int tier) { return GLOW[Mth.clamp(tier, 1, 5) - 1]; }

    public static float pulse(float ageInTicks) {
        return Mth.clamp(0.35f + 0.2f * Mth.sin(ageInTicks * 0.1f) + ClientFx.markingsBoost(), 0f, 1f);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (player.isInvisible()) return;
        int tier = tier(player);
        if (tier <= 0) return;
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0f);
        getParentModel().renderToBuffer(pose, buffers.getBuffer(RenderType.entityTranslucent(ink(tier))), light, overlay, 1f, 1f, 1f, 1f);
        float p = pulse(ageInTicks);
        getParentModel().renderToBuffer(pose, buffers.getBuffer(RenderType.eyes(glow(tier))), 15728640, overlay, p, p, p, 1f);
        // v1.0.7: Heian-era Sukuna's second pair of eyes once all twenty fingers are inside
        if (FourArmsLayer.hasFourArms(player)) {
            float open = com.kingofcurses.client.BodyAnims.eyesOpen(player.getId(), partialTick);
            if (open > 0.02f) {
                getParentModel().head.render(pose, buffers.getBuffer(RenderType.entityTranslucent(EYES)), light, overlay, 1f, 1f, 1f, open);
                getParentModel().head.render(pose, buffers.getBuffer(RenderType.eyes(EYES_GLOW)), 15728640, overlay, open, open, open, 1f);
            }
        }
    }

    private static final ResourceLocation EYES = new ResourceLocation(KingOfCurses.MODID, "textures/entity/markings/sukuna_eyes.png");
    private static final ResourceLocation EYES_GLOW = new ResourceLocation(KingOfCurses.MODID, "textures/entity/markings/sukuna_eyes_glow.png");
}
