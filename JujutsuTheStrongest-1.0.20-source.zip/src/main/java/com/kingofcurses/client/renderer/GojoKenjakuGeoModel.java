package com.kingofcurses.client.renderer;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.entity.GojoKenjakuEntity;
import net.minecraft.resources.ResourceLocation;

/** Same body, rig and animations as Gojo, with Kenjaku's stitched forehead and open Six Eyes. */
public class GojoKenjakuGeoModel extends KocGeoModel<GojoKenjakuEntity> {
    private static final ResourceLocation TEX = new ResourceLocation(KingOfCurses.MODID, "textures/entity/gojo_kenjaku.png");

    public GojoKenjakuGeoModel() { super("gojo_satoru", true); }

    @Override
    public ResourceLocation getTextureResource(GojoKenjakuEntity animatable) { return TEX; }
}
