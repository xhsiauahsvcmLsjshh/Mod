package com.kingofcurses.client.renderer;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.client.ClientData;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/** v1.0.5: Sukuna's tattoos on any vanilla creature that ate a ripped finger. The pattern texture tiles over any UV layout. */
public class VesselTattooLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation[] INK = new ResourceLocation[3], GLOW = new ResourceLocation[3];
    static {
        for (int i = 0; i < 3; i++) {
            INK[i] = new ResourceLocation(KingOfCurses.MODID, "textures/entity/markings/vessel_" + (i + 1) + ".png");
            GLOW[i] = new ResourceLocation(KingOfCurses.MODID, "textures/entity/markings/vessel_" + (i + 1) + "_glow.png");
        }
    }

    public VesselTattooLayer(RenderLayerParent<T, M> parent) { super(parent); }

    static int tier(int power) { return power >= 15 ? 3 : power >= 7 ? 2 : 1; }
    static ResourceLocation ink(int power) { return INK[tier(power) - 1]; }
    static ResourceLocation glow(int power) { return GLOW[tier(power) - 1]; }
    static float pulse(float age) { return Mth.clamp(0.45f + 0.25f * Mth.sin(age * 0.12f), 0f, 1f); }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, T entity, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        int power = ClientData.vesselPower(entity.getId());
        if (power <= 0 || entity.isInvisible()) return;
        int overlay = LivingEntityRenderer.getOverlayCoords(entity, 0.0f);
        getParentModel().renderToBuffer(pose, buffers.getBuffer(RenderType.entityTranslucent(ink(power))), light, overlay, 1f, 1f, 1f, 1f);
        float p = pulse(ageInTicks);
        getParentModel().renderToBuffer(pose, buffers.getBuffer(RenderType.eyes(glow(power))), 15728640, overlay, p, p, p, 1f);
    }
}
