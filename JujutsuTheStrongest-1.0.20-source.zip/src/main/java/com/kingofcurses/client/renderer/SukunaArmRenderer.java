package com.kingofcurses.client.renderer;

import com.kingofcurses.entity.SukunaArmEntity;
import com.kingofcurses.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** The flying arm: the item model, big and spinning. */
public class SukunaArmRenderer extends EntityRenderer<SukunaArmEntity> {
    private final ItemRenderer items;
    private ItemStack stack;

    public SukunaArmRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.items = ctx.getItemRenderer();
        this.shadowRadius = 0.3f;
    }

    @Override
    public void render(SukunaArmEntity e, float yaw, float pt, PoseStack pose, MultiBufferSource buffers, int light) {
        if (stack == null) stack = new ItemStack(ModItems.SUKUNA_ARM.get());
        pose.pushPose();
        pose.translate(0, 0.3, 0);
        pose.scale(2.4f, 2.4f, 2.4f);
        pose.mulPose(Axis.YP.rotationDegrees(e.spin(pt) * 0.6f));
        pose.mulPose(Axis.ZP.rotationDegrees(e.spin(pt)));
        items.renderStatic(stack, ItemDisplayContext.FIXED, light, OverlayTexture.NO_OVERLAY, pose, buffers, e.level(), e.getId());
        pose.popPose();
        super.render(e, yaw, pt, pose, buffers, light);
    }

    @Override
    @SuppressWarnings("deprecation")
    public ResourceLocation getTextureLocation(SukunaArmEntity e) { return TextureAtlas.LOCATION_BLOCKS; }
}
