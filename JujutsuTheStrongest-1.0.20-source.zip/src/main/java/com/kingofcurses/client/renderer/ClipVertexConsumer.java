package com.kingofcurses.client.renderer;

import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Wraps a VertexConsumer and keeps only the part of every quad on one side of a horizontal plane
 * (in the local space given by {@code toLocal}). Quads crossing the plane are trimmed exactly onto it,
 * with UVs/colours interpolated, so a model can be "cut in half" without any shader.
 */
final class ClipVertexConsumer implements VertexConsumer {
    private final VertexConsumer out;
    private final Matrix4f toLocal;
    private final float cut;
    private final boolean keepBelow;
    private final float[][] q = new float[4][16]; // x,y,z, r,g,b,a, u,v, ou,ov, lu,lv, nx,ny,nz
    private final float[] cur = new float[16];
    private int n;
    private boolean defaultColor;
    private int dr = 255, dg = 255, db = 255, da = 255;

    private float px = 0, py = 1, pz = 0; // plane normal (local space), default horizontal cut

    ClipVertexConsumer(VertexConsumer out, Matrix4f toLocal, float cut, boolean keepBelow, float nx, float ny, float nz) {
        this(out, toLocal, cut, keepBelow);
        px = nx; py = ny; pz = nz;
    }

    ClipVertexConsumer(VertexConsumer out, Matrix4f toLocal, float cut, boolean keepBelow) {
        this.out = out; this.toLocal = toLocal; this.cut = cut; this.keepBelow = keepBelow;
        cur[3] = cur[4] = cur[5] = cur[6] = 255;
    }

    @Override public VertexConsumer vertex(double x, double y, double z) { cur[0] = (float) x; cur[1] = (float) y; cur[2] = (float) z; return this; }
    @Override public VertexConsumer color(int r, int g, int b, int a) { cur[3] = r; cur[4] = g; cur[5] = b; cur[6] = a; return this; }
    @Override public VertexConsumer uv(float u, float v) { cur[7] = u; cur[8] = v; return this; }
    @Override public VertexConsumer overlayCoords(int u, int v) { cur[9] = u; cur[10] = v; return this; }
    @Override public VertexConsumer uv2(int u, int v) { cur[11] = u; cur[12] = v; return this; }
    @Override public VertexConsumer normal(float x, float y, float z) { cur[13] = x; cur[14] = y; cur[15] = z; return this; }

    @Override
    public void endVertex() {
        if (defaultColor) { cur[3] = dr; cur[4] = dg; cur[5] = db; cur[6] = da; }
        System.arraycopy(cur, 0, q[n], 0, 16);
        if (++n == 4) { emitQuad(); n = 0; }
    }

    @Override
    public void vertex(float x, float y, float z, float r, float g, float b, float a, float u, float v, int overlay, int light, float nx, float ny, float nz) {
        vertex(x, y, z);
        color((int) (r * 255), (int) (g * 255), (int) (b * 255), (int) (a * 255));
        uv(u, v);
        overlayCoords(overlay & 0xFFFF, overlay >> 16 & 0xFFFF);
        uv2(light & 0xFFFF, light >> 16 & 0xFFFF);
        normal(nx, ny, nz);
        endVertex();
    }

    @Override public void defaultColor(int r, int g, int b, int a) { defaultColor = true; dr = r; dg = g; db = b; da = a; out.defaultColor(r, g, b, a); }
    @Override public void unsetDefaultColor() { defaultColor = false; out.unsetDefaultColor(); }

    private float localY(float[] v) {
        Vector3f p = toLocal.transformPosition(new Vector3f(v[0], v[1], v[2]));
        return p.x * px + p.y * py + p.z * pz;
    }

    private boolean inside(float ly) { return keepBelow ? ly <= cut : ly >= cut; }

    private void emitQuad() {
        float[] ly = new float[4];
        int in = 0;
        for (int i = 0; i < 4; i++) { ly[i] = localY(q[i]); if (inside(ly[i])) in++; }
        if (in == 0) return;
        if (in == 4) { for (int i = 0; i < 4; i++) write(q[i]); return; }
        float[][] res = new float[4][];
        for (int i = 0; i < 4; i++) {
            if (inside(ly[i])) { res[i] = q[i]; continue; }
            int prev = (i + 3) & 3, next = (i + 1) & 3;
            int nb = inside(ly[prev]) ? prev : (inside(ly[next]) ? next : -1);
            if (nb < 0) { // opposite corner: collapse onto the nearest kept vertex
                int any = 0;
                for (int j = 0; j < 4; j++) if (inside(ly[j])) { any = j; break; }
                res[i] = q[any];
                continue;
            }
            float t = (cut - ly[i]) / (ly[nb] - ly[i]);
            float[] v = new float[16];
            for (int k = 0; k < 16; k++) v[k] = q[i][k] + (q[nb][k] - q[i][k]) * t;
            res[i] = v;
        }
        for (int i = 0; i < 4; i++) write(res[i]);
    }

    private void write(float[] v) {
        out.vertex(v[0], v[1], v[2]);
        if (!defaultColor) out.color(Math.round(v[3]), Math.round(v[4]), Math.round(v[5]), Math.round(v[6]));
        out.uv(v[7], v[8]);
        out.overlayCoords(Math.round(v[9]), Math.round(v[10]));
        out.uv2(Math.round(v[11]), Math.round(v[12]));
        out.normal(v[13], v[14], v[15]);
        out.endVertex();
    }
}
