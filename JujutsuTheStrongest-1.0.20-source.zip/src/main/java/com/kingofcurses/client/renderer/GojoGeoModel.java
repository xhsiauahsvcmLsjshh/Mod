package com.kingofcurses.client.renderer;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.entity.GojoEntity;
import net.minecraft.resources.ResourceLocation;

/** Gojo shows his Six Eyes once his blindfold has been taken from the body. */
public class GojoGeoModel extends KocGeoModel<GojoEntity> {
    private static final ResourceLocation EYES = new ResourceLocation(KingOfCurses.MODID, "textures/entity/gojo_satoru_eyes.png");

    public GojoGeoModel() { super("gojo_satoru", true); }

    @Override
    public ResourceLocation getTextureResource(GojoEntity animatable) {
        return animatable != null && !animatable.hasBlindfold() ? EYES : super.getTextureResource(animatable);
    }
}
