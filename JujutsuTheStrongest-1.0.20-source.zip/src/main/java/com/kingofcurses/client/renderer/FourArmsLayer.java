package com.kingofcurses.client.renderer;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.client.ClientData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;

/**
 * v1.0.4: with all twenty fingers the vessel grows a second pair of arms, like Sukuna's true form.
 * The extra arms reuse the player's own arm parts (so they wear the player's skin), placed lower on the torso,
 * angled outwards and animated with a slight delay; they carry the tattoos too.
 */
public class FourArmsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static float GROWTH = 1f;

    public FourArmsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); }

    public static boolean hasFourArms(AbstractClientPlayer player) {
        int ending = ClientData.endingOf(player);
        return ClientData.fingersOf(player) >= 20 && ending != CursedData.ENDING_REJECT;
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (player.isInvisible() || !hasFourArms(player)) return;
        PlayerModel<AbstractClientPlayer> m = getParentModel();
        GROWTH = com.kingofcurses.client.BodyAnims.armsGrowth(player.getId(), partialTick);
        if (GROWTH <= 0.02f) return;
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0f);
        int tier = SukunaMarkingsLayer.tier(player);
        float p = SukunaMarkingsLayer.pulse(ageInTicks);
        VertexConsumer skin = buffers.getBuffer(RenderType.entityCutoutNoCull(player.getSkinTextureLocation()));
        drawPair(pose, skin, light, overlay, m, ageInTicks, limbSwing, limbSwingAmount, 1f, 1f, 1f);
        if (tier > 0) {
            drawPair(pose, buffers.getBuffer(RenderType.entityTranslucent(SukunaMarkingsLayer.ink(tier))), light, overlay, m, ageInTicks, limbSwing, limbSwingAmount, 1f, 1f, 1f);
            drawPair(pose, buffers.getBuffer(RenderType.eyes(SukunaMarkingsLayer.glow(tier))), 15728640, overlay, m, ageInTicks, limbSwing, limbSwingAmount, p, p, p);
        }
    }

    private static void drawPair(PoseStack pose, VertexConsumer vc, int light, int overlay, PlayerModel<AbstractClientPlayer> m,
                                 float age, float limbSwing, float limbAmount, float r, float g, float b) {
        drawArm(pose, vc, light, overlay, m.rightArm, m.rightSleeve, -1f, age, limbSwing, limbAmount, r, g, b);
        drawArm(pose, vc, light, overlay, m.leftArm, m.leftSleeve, 1f, age, limbSwing, limbAmount, r, g, b);
    }

    private static void drawArm(PoseStack pose, VertexConsumer vc, int light, int overlay, ModelPart arm, ModelPart sleeve, float side,
                                float age, float limbSwing, float limbAmount, float r, float gg, float b) {
        PartPose armPose = arm.storePose(), sleevePose = sleeve.storePose();
        boolean av = arm.visible, sv = sleeve.visible;
        float g = GROWTH;
        float ys = arm.yScale;
        // lower pair: hangs from the ribs, a bit inwards, swinging in counter-phase with a small delay
        float swing = Mth.cos(limbSwing * 0.6662f + (side > 0 ? 0f : (float) Math.PI) + 0.6f) * 1.0f * limbAmount;
        arm.y = armPose.y + 5.0f;
        arm.x = armPose.x - side * 0.6f;
        arm.z = armPose.z + 0.4f;
        arm.xRot = armPose.xRot * 0.55f - swing * 0.45f - 0.15f + Mth.sin(age * 0.067f + side) * 0.04f;
        arm.yRot = armPose.yRot * 0.5f;
        arm.zRot = -side * (0.42f + Mth.cos(age * 0.09f + 1.3f) * 0.05f);
        if (g < 1f) {                     // v1.0.7: the arms tear their way out of the sides
            arm.x -= side * (1f - g) * 2.0f;
            arm.zRot *= 0.4f + 0.6f * g;
            arm.zRot += Mth.sin(age * 3.1f) * 0.08f * (1f - g);
        }
        arm.yScale = ys * 0.88f * g;
        arm.xScale = 0.55f + 0.45f * g;
        arm.zScale = 0.55f + 0.45f * g;
        sleeve.copyFrom(arm);
        sleeve.xScale = arm.xScale; sleeve.yScale = arm.yScale; sleeve.zScale = arm.zScale;
        arm.visible = true;
        arm.render(pose, vc, light, overlay, r, gg, b, 1f);
        if (sleeveOn(sleeve, sv)) { sleeve.visible = true; sleeve.render(pose, vc, light, overlay, r, gg, b, 1f); }
        arm.visible = av; sleeve.visible = sv;
        arm.loadPose(armPose);
        sleeve.loadPose(sleevePose);
        arm.xScale = arm.zScale = 1f; arm.yScale = ys;
        sleeve.xScale = sleeve.zScale = 1f; sleeve.yScale = ys;
    }

    /** The real sleeve visibility (it may be hidden temporarily by ClientForgeEvents during an animation). */
    private static boolean sleeveOn(ModelPart sleeve, boolean current) {
        return current || com.kingofcurses.client.ClientForgeEvents.sleeveWasVisible(sleeve);
    }
}
