package com.kingofcurses.client.renderer;

import com.kingofcurses.client.RipAnim;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;

/**
 * v1.0.6 third-person finger ripping: the vanilla arms are hidden for the duration (see ClientForgeEvents)
 * and redrawn here in the ripping pose, with skin and tattoos.
 */
public class RipArmsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public RipArmsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        float t = RipAnim.progress(player.getId(), partialTick);
        if (t < 0 || player.isInvisible()) return;
        PlayerModel<AbstractClientPlayer> m = getParentModel();
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0f);
        float up = RipAnim.raise(t), tug = RipAnim.tug(t), sh = RipAnim.shake(t, ageInTicks);
        draw(pose, buffers.getBuffer(RenderType.entityCutoutNoCull(player.getSkinTextureLocation())), light, overlay, m, up, tug, sh, 1f);
        int tier = SukunaMarkingsLayer.tier(player);
        if (tier > 0) {
            draw(pose, buffers.getBuffer(RenderType.entityTranslucent(SukunaMarkingsLayer.ink(tier))), light, overlay, m, up, tug, sh, 1f);
            float p = SukunaMarkingsLayer.pulse(ageInTicks);
            draw(pose, buffers.getBuffer(RenderType.eyes(SukunaMarkingsLayer.glow(tier))), 15728640, overlay, m, up, tug, sh, p);
        }
    }

    private static void draw(PoseStack pose, VertexConsumer vc, int light, int overlay, PlayerModel<AbstractClientPlayer> m, float up, float tug, float sh, float c) {
        // left hand holds the finger up in front of the face
        arm(pose, vc, light, overlay, m.leftArm, m.leftSleeve, -1.75f * up + sh, 0.55f * up, -0.1f * up, c);
        // right hand grips it, strains, then yanks down and outwards
        arm(pose, vc, light, overlay, m.rightArm, m.rightSleeve, -1.65f * up + 0.9f * tug - sh, -0.6f * up + 0.2f * tug, 0.15f * up + 0.7f * tug, c);
    }

    private static void arm(PoseStack pose, VertexConsumer vc, int light, int overlay, ModelPart arm, ModelPart sleeve, float xr, float yr, float zr, float c) {
        PartPose a = arm.storePose(), s = sleeve.storePose();
        arm.xRot = Mth.lerp(Math.min(1f, Math.abs(xr) * 2f), a.xRot, 0f) + xr;
        arm.yRot = yr;
        arm.zRot = zr;
        sleeve.copyFrom(arm);
        arm.visible = true;
        arm.render(pose, vc, light, overlay, c, c, c, 1f);
        if (sleeveShown(sleeve)) { sleeve.visible = true; sleeve.render(pose, vc, light, overlay, c, c, c, 1f); sleeve.visible = false; }
        arm.visible = false;
        arm.loadPose(a);
        sleeve.loadPose(s);
    }

    /** ClientForgeEvents remembers whether the sleeve was visible before hiding it. */
    private static boolean sleeveShown(ModelPart sleeve) { return com.kingofcurses.client.ClientForgeEvents.sleeveWasVisible(sleeve); }
}
