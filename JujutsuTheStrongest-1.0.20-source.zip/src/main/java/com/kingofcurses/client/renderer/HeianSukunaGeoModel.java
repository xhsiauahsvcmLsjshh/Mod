package com.kingofcurses.client.renderer;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.entity.HeianSukunaEntity;
import net.minecraft.resources.ResourceLocation;

/** True-form rig and animations, Heian texture. */
public class HeianSukunaGeoModel extends KocGeoModel<HeianSukunaEntity> {
    private static final ResourceLocation TEX = new ResourceLocation(KingOfCurses.MODID, "textures/entity/heian_sukuna.png");

    public HeianSukunaGeoModel() { super("sukuna_true_form", false); }

    @Override
    public ResourceLocation getTextureResource(HeianSukunaEntity animatable) { return TEX; }
}
