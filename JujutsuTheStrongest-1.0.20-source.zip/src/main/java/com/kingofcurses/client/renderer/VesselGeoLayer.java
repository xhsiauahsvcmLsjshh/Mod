package com.kingofcurses.client.renderer;

import com.kingofcurses.client.ClientData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.Entity;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

/** v1.0.5: the same vessel tattoos for this mod's GeckoLib creatures. */
public class VesselGeoLayer<T extends Entity & GeoAnimatable> extends GeoRenderLayer<T> {
    public VesselGeoLayer(GeoRenderer<T> renderer) { super(renderer); }

    @Override
    public void render(PoseStack poseStack, T animatable, BakedGeoModel bakedModel, RenderType renderType, MultiBufferSource bufferSource,
                       VertexConsumer buffer, float partialTick, int packedLight, int packedOverlay) {
        int power = ClientData.vesselPower(animatable.getId());
        if (power <= 0 || animatable.isInvisible()) return;
        RenderType ink = RenderType.entityTranslucent(VesselTattooLayer.ink(power));
        getRenderer().reRender(bakedModel, poseStack, bufferSource, animatable, ink, bufferSource.getBuffer(ink), partialTick, packedLight, packedOverlay, 1f, 1f, 1f, 1f);
        float p = VesselTattooLayer.pulse(animatable.tickCount + partialTick);
        RenderType glow = RenderType.eyes(VesselTattooLayer.glow(power));
        getRenderer().reRender(bakedModel, poseStack, bufferSource, animatable, glow, bufferSource.getBuffer(glow), partialTick, 15728640, OverlayTexture.NO_OVERLAY, p, p, p, 1f);
    }
}
