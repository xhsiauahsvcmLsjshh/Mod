package com.kingofcurses.client.renderer;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.entity.SlicedCorpseEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/** Renders the victim's real model twice, clipped at mid height: the upper half slides off and falls, the lower half sags. */
public class SlicedCorpseRenderer extends EntityRenderer<SlicedCorpseEntity> {
    private static final ResourceLocation GORE = new ResourceLocation(KingOfCurses.MODID, "textures/entity/gore.png");

    public SlicedCorpseRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.0f;
    }

    @Override
    public ResourceLocation getTextureLocation(SlicedCorpseEntity entity) { return GORE; }

    private static LivingEntity dummy(SlicedCorpseEntity c) {
        if (c.clientDummy != null || c.clientDummyFailed) return c.clientDummy;
        try {
            Entity e = EntityType.byString(c.victimId()).map(t -> t.create(c.level())).orElse(null);
            if (e instanceof LivingEntity le) {
                try { if (!c.victimTag().isEmpty()) le.load(c.victimTag()); } catch (RuntimeException ignored) { }
                le.setInvisible(false);
                le.deathTime = 0;
                le.hurtTime = 0;
                c.clientDummy = le;
            } else {
                c.clientDummyFailed = true;
            }
        } catch (RuntimeException ex) {
            c.clientDummyFailed = true;
        }
        return c.clientDummy;
    }

    @Override
    public void render(SlicedCorpseEntity corpse, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        LivingEntity d = dummy(corpse);
        if (d == null) return;
        EntityRenderer<? super LivingEntity> r;
        try { r = Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(d); } catch (RuntimeException ex) { corpse.clientDummyFailed = true; corpse.clientDummy = null; return; }
        float bodyYaw = corpse.getYRot();
        d.setPos(corpse.getX(), corpse.getY(), corpse.getZ());
        d.xo = d.getX(); d.yo = d.getY(); d.zo = d.getZ();
        d.yBodyRot = d.yBodyRotO = d.yHeadRot = d.yHeadRotO = bodyYaw;
        d.setYRot(bodyYaw); d.yRotO = bodyYaw; d.setXRot(0); d.xRotO = 0;

        float w = corpse.victimWidth(), h = corpse.victimHeight(), cut = h * 0.52f;
        float age = corpse.tickCount + partialTick;
        if (corpse.vertical()) {
            renderVertical(corpse, d, r, bodyYaw, w, h, age, partialTick, pose, buffers, light);
            super.render(corpse, yaw, partialTick, pose, buffers, light);
            return;
        }
        float k = Mth.clamp(age / 11f, 0, 1); k = k * k * (3 - 2 * k);
        float sag = Mth.clamp((age - 6) / 14f, 0, 1);
        double side = Math.toRadians(bodyYaw + (corpse.fallLeft() ? 90 : -90));
        float fx = (float) -Math.sin(side), fz = (float) Math.cos(side); // fall direction (world)
        Quaternionf tip = new Quaternionf().rotationAxis((float) Math.toRadians(82 * k), fz, 0, -fx);
        Quaternionf sagQ = new Quaternionf().rotationAxis((float) Math.toRadians(-10 * sag), fz, 0, -fx);
        try {
            // ---------- lower half ----------
            pose.pushPose();
            pose.translate(-fx * w / 2, 0, -fz * w / 2);
            pose.mulPose(sagQ);
            pose.translate(fx * w / 2, 0, fz * w / 2);
            Matrix4f invLow = new Matrix4f(pose.last().pose()).invert();
            r.render(d, bodyYaw, partialTick, pose, type -> new ClipVertexConsumer(buffers.getBuffer(type), invLow, cut, true), light);
            gore(pose, buffers, light, w, cut, bodyYaw, true);
            pose.popPose();
            // ---------- upper half ----------
            pose.pushPose();
            float slide = 0.35f * k * w + 0.15f;
            pose.translate(fx * slide, -cut * 0.92f * k, fz * slide);
            pose.translate(fx * w / 2, cut, fz * w / 2);
            pose.mulPose(tip);
            pose.translate(-fx * w / 2, -cut, -fz * w / 2);
            Matrix4f invUp = new Matrix4f(pose.last().pose()).invert();
            r.render(d, bodyYaw, partialTick, pose, type -> new ClipVertexConsumer(buffers.getBuffer(type), invUp, cut, false), light);
            gore(pose, buffers, light, w, cut, bodyYaw, false);
            pose.popPose();
        } catch (RuntimeException ex) {
            corpse.clientDummyFailed = true; corpse.clientDummy = null; // never crash the frame: just stop drawing this corpse
        }
        super.render(corpse, yaw, partialTick, pose, buffers, light);
    }

    /** v1.0.14: torn from head to feet, the two halves peel apart and fall to each side. */
    private void renderVertical(SlicedCorpseEntity corpse, LivingEntity d, EntityRenderer<? super LivingEntity> r, float bodyYaw, float w, float h, float age,
                                float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        float k = Mth.clamp(age / 14f, 0, 1); k = k * k * (3 - 2 * k);
        double side = Math.toRadians(bodyYaw + 90);
        float sx = (float) -Math.sin(side), sz = (float) Math.cos(side);   // body's side direction
        float ax = sz, az = -sx;                                            // body's forward axis (rotation axis)
        try {
            for (int half = 0; half < 2; half++) {
                float sign = half == 0 ? -1f : 1f;
                pose.pushPose();
                float sep = 0.08f + 0.12f * k * w;
                pose.translate(sx * sign * sep, 0, sz * sign * sep);
                pose.translate(sx * sign * w / 2, 0, sz * sign * w / 2);
                pose.mulPose(new Quaternionf().rotationAxis((float) Math.toRadians(sign * 84 * k), ax, 0, az));
                pose.translate(-sx * sign * w / 2, 0, -sz * sign * w / 2);
                Matrix4f inv = new Matrix4f(pose.last().pose()).invert();
                boolean keepNeg = half == 0;
                r.render(d, bodyYaw, partialTick, pose, type -> new ClipVertexConsumer(buffers.getBuffer(type), inv, 0f, keepNeg, sx, 0f, sz), light);
                goreVertical(pose, buffers, light, w, h, sx, sz, ax, az, keepNeg);
                pose.popPose();
            }
        } catch (RuntimeException ex) {
            corpse.clientDummyFailed = true; corpse.clientDummy = null;
        }
    }

    private static void goreVertical(PoseStack pose, MultiBufferSource buffers, int light, float w, float h, float sx, float sz, float ax, float az, boolean faceOut) {
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GORE));
        float s = w * 0.42f, y0 = h * 0.05f, y1 = h * 0.92f, off = faceOut ? -0.002f : 0.002f;
        float nx = faceOut ? sx : -sx, nz = faceOut ? sz : -sz;
        float[][] pts = {{-s, y0}, {-s, y1}, {s, y1}, {s, y0}};
        float[][] uvs = {{0, 0}, {0, 1}, {1, 1}, {1, 0}};
        for (int i = 0; i < 4; i++) {
            float x = ax * pts[i][0] + sx * off, z = az * pts[i][0] + sz * off;
            vc.vertex(m, x, pts[i][1], z).color(255, 255, 255, 255).uv(uvs[i][0], uvs[i][1]).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, nx, 0, nz).endVertex();
        }
    }

    /** Flesh disk on the cut surface. */
    private static void gore(PoseStack pose, MultiBufferSource buffers, int light, float w, float cut, float bodyYaw, boolean facingUp) {
        pose.pushPose();
        pose.translate(0, cut + (facingUp ? 0.002f : -0.002f), 0);
        pose.mulPose(Axis.YP.rotationDegrees(-bodyYaw));
        float s = w * 0.42f;
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GORE));
        float ny = facingUp ? 1 : -1;
        float[][] pts = facingUp ? new float[][]{{-s, -s}, {-s, s}, {s, s}, {s, -s}} : new float[][]{{-s, -s}, {s, -s}, {s, s}, {-s, s}};
        float[][] uvs = {{0, 0}, {0, 1}, {1, 1}, {1, 0}};
        for (int i = 0; i < 4; i++) {
            vc.vertex(m, pts[i][0], 0, pts[i][1]).color(255, 255, 255, 255).uv(uvs[i][0], uvs[i][1]).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, 0, ny, 0).endVertex();
        }
        pose.popPose();
    }
}
