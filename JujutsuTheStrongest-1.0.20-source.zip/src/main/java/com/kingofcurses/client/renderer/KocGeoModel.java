package com.kingofcurses.client.renderer;

import com.kingofcurses.KingOfCurses;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;

/** Resolves geo/entity/NAME.geo.json, textures/entity/NAME.png and animations/entity/NAME.animation.json. */
public class KocGeoModel<T extends GeoAnimatable> extends DefaultedEntityGeoModel<T> {
    public KocGeoModel(String name, boolean turnsHead) {
        super(new ResourceLocation(KingOfCurses.MODID, name), turnsHead);
    }
}
