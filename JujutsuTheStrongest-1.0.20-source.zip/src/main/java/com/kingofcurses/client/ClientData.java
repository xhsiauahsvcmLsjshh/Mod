package com.kingofcurses.client;

import com.kingofcurses.capability.CursedData;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;

/** Client-side mirror of server data. Client only. */
public final class ClientData {
    public static final CursedData DATA = new CursedData();
    private static final Map<Integer, int[]> OTHERS = new HashMap<>();
    public static boolean domainActive;
    public static Vec3 domainCenter = Vec3.ZERO;
    public static float domainRadius;
    public static int domainTicks;

    private ClientData() {}

    public static boolean hasEaten(int index) { return DATA.hasEaten(index); }

    public static void setOther(int id, int fingers, int ending) { OTHERS.put(id, new int[]{fingers, ending}); }

    /** v1.0.5: finger power of a non-player vessel creature (0 = not a vessel). */
    public static int vesselPower(int entityId) {
        int[] v = OTHERS.get(entityId);
        return v == null ? 0 : v[0];
    }

    public static int fingersOf(Player p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && p.getId() == mc.player.getId()) return DATA.fingers();
        int[] v = OTHERS.get(p.getId());
        return v == null ? 0 : v[0];
    }

    public static int endingOf(Player p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && p.getId() == mc.player.getId()) return DATA.ending();
        int[] v = OTHERS.get(p.getId());
        return v == null ? 0 : v[1] & 15;
    }

    /** v1.0.7: bit 1 = right arm missing, bit 2 = left arm missing. */
    public static int lostArmsOf(Player p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && p.getId() == mc.player.getId()) return DATA.lostArms();
        int[] v = OTHERS.get(p.getId());
        return v == null ? 0 : (v[1] >> 4) & 3;
    }

    public static boolean insideDomain(Vec3 pos) {
        return domainActive && pos.distanceToSqr(domainCenter) <= domainRadius * domainRadius;
    }

    public static void reset() {
        DATA.loadSync(new CursedData().syncTag());
        OTHERS.clear();
        RipAnim.clear();
        BodyAnims.clear();
        domainActive = false;
    }
}
