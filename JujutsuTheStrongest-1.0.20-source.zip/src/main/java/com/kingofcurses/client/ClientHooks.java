package com.kingofcurses.client;

import com.kingofcurses.client.screen.CodexScreen;
import com.kingofcurses.client.screen.EndingScreen;
import net.minecraft.client.Minecraft;

public final class ClientHooks {
    private ClientHooks() {}
    public static void openTouchPad() { Minecraft.getInstance().setScreen(new com.kingofcurses.client.screen.TouchPadScreen()); }
    public static void openBattleHud() { Minecraft.getInstance().setScreen(new com.kingofcurses.client.screen.BattleHudScreen()); }
    public static void openCodex() { Minecraft.getInstance().setScreen(new CodexScreen()); }
    public static void openEnding() { Minecraft.getInstance().setScreen(new EndingScreen()); }
    public static void openControlMode() { Minecraft.getInstance().setScreen(new com.kingofcurses.client.screen.ControlModeScreen()); }
}
