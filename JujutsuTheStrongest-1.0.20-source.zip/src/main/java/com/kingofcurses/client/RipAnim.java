package com.kingofcurses.client;

import com.kingofcurses.ability.VesselLogic;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;

import java.util.HashMap;
import java.util.Map;

/**
 * v1.0.6 client side of the finger-ripping animation.
 * Timeline (30 ticks): 0-0.40 both hands rise in front of the face, 0.40-0.47 grip and strain,
 * 0.47 (tick 14) the finger tears free with a jerk, 0.47-1.0 the arms drop back down.
 */
public final class RipAnim {
    private static final Map<Integer, Long> START = new HashMap<>();
    private RipAnim() {}

    public static void start(int entityId) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) START.put(entityId, mc.level.getGameTime());
    }

    /** Progress 0..1, or -1 when the entity is not ripping. */
    public static float progress(int entityId, float partialTick) {
        Long s = START.get(entityId);
        Minecraft mc = Minecraft.getInstance();
        if (s == null || mc.level == null) return -1f;
        float t = (mc.level.getGameTime() - s + partialTick) / VesselLogic.RIP_LENGTH;
        if (t >= 1f || t < 0f) { if (t >= 1f) START.remove(entityId); return -1f; }
        return t;
    }

    static float smooth(float x) { x = Mth.clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }

    /** How high the hands are (0 = rest, 1 = in front of the face). */
    public static float raise(float t) {
        if (t < 0.40f) return smooth(t / 0.40f);
        if (t < 0.55f) return 1f;
        return 1f - smooth((t - 0.55f) / 0.45f);
    }

    /** The tearing jerk of the right hand (0..1, peaks just after the tear). */
    public static float tug(float t) {
        float tear = VesselLogic.RIP_TEAR / (float) VesselLogic.RIP_LENGTH;
        if (t < tear - 0.07f) return 0f;
        if (t < tear) return smooth((t - (tear - 0.07f)) / 0.07f) * 0.25f;          // strain
        if (t < tear + 0.08f) return 0.25f + smooth((t - tear) / 0.08f) * 0.75f;      // rip!
        return 1f - smooth((t - tear - 0.08f) / 0.35f);
    }

    /** Small tremble while straining. */
    public static float shake(float t, float age) {
        float tear = VesselLogic.RIP_TEAR / (float) VesselLogic.RIP_LENGTH;
        return t > 0.30f && t < tear ? Mth.sin(age * 2.7f) * 0.04f : 0f;
    }

    public static void clear() { START.clear(); }
}
