package com.kingofcurses.client;

import com.kingofcurses.ability.HeianLogic;
import com.kingofcurses.entity.HeianSukunaEntity;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * v1.0.17 arrival "video" in the Heian Era: aerial shots of the golden land, the road to the throne,
 * Sukuna's welcome ("the Golden Era of Jujutsu"), black screen... and the four-armed jumpscare.
 */
public final class HeianCinematic {
    public static final int T_AERIAL = 0, T_ROAD = 80, T_THRONE = 150, T_VISTA = 250, T_BLACK = 292, T_SCARE = 304, T_FADE = 326;
    private static boolean active;
    private static int tick;
    private static Entity camera;
    private static Vec3 origin, fwd, right, throne;
    private static float baseYaw;

    private HeianCinematic() {}

    public static boolean active() { return active; }
    public static int tick() { return tick; }
    public static boolean jumpscare() { return active && tick >= T_SCARE && tick < T_FADE + 8; }

    public static void start() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        origin = mc.player.position();
        baseYaw = mc.player.getYRot();
        float y = baseYaw * Mth.DEG_TO_RAD;
        fwd = new Vec3(-Mth.sin(y), 0, Mth.cos(y));
        right = new Vec3(-fwd.z, 0, fwd.x);
        throne = origin.add(fwd.scale(19));
        for (HeianSukunaEntity s : mc.level.getEntitiesOfClass(HeianSukunaEntity.class, new AABB(origin, origin).inflate(64))) { throne = s.position(); break; }
        camera = EntityType.MARKER.create(mc.level);
        if (camera == null) return;
        tick = 0;
        active = true;
        place(origin.add(0, 30, 0), origin, true);
        mc.setCameraEntity(camera);
    }

    public static void stop() {
        active = false;
        HeianSukunaEntity.clientJumpscare = false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.setCameraEntity(mc.player);
        camera = null;
    }

    public static void reset() { if (active) stop(); }

    private static void place(Vec3 pos, Vec3 look, boolean snap) {
        Vec3 d = look.subtract(pos);
        float yaw = (float) (Mth.atan2(d.z, d.x) * Mth.RAD_TO_DEG) - 90f;
        float pitch = (float) -(Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * Mth.RAD_TO_DEG);
        if (snap) { camera.xo = pos.x; camera.yo = pos.y; camera.zo = pos.z; camera.yRotO = yaw; camera.xRotO = pitch; }
        else { camera.xo = camera.getX(); camera.yo = camera.getY(); camera.zo = camera.getZ(); camera.yRotO = camera.getYRot(); camera.xRotO = camera.getXRot(); }
        // keep yaw continuous (no 360 jumps)
        while (yaw - camera.yRotO > 180) yaw -= 360;
        while (yaw - camera.yRotO < -180) yaw += 360;
        camera.setPos(pos);
        camera.setYRot(yaw);
        camera.setXRot(pitch);
    }

    private static double ease(double t) { t = Mth.clamp(t, 0, 1); return t * t * (3 - 2 * t); }

    private static void play(SoundEvent s, float vol, float pitch) {
        Minecraft mc = Minecraft.getInstance();
        mc.getSoundManager().play(SimpleSoundInstance.forUI(s, pitch, vol));
    }

    public static void clientTick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || camera == null || mc.player.level().dimension() != HeianLogic.HEIAN) { stop(); return; }
        tick++;
        Vec3 up = new Vec3(0, 1, 0);
        boolean snap = tick == T_ROAD || tick == T_THRONE || tick == T_VISTA || tick == T_SCARE;
        if (tick < T_ROAD) {                        // aerial orbit over the golden land
            double t = tick / (double) T_ROAD;
            double a = Math.toRadians(-70 + 110 * t);
            Vec3 off = fwd.scale(Math.cos(a) * -42).add(right.scale(Math.sin(a) * 42));
            place(origin.add(off).add(0, 32 - 6 * t, 0), origin.add(fwd.scale(8)), false);
        } else if (tick < T_THRONE) {               // down the golden road
            double t = ease((tick - T_ROAD) / (double) (T_THRONE - T_ROAD));
            Vec3 a = origin.add(right.scale(6)).add(fwd.scale(-2)).add(up.scale(1.8));
            Vec3 b = throne.add(fwd.scale(-9)).add(right.scale(3)).add(up.scale(3));
            place(a.lerp(b, t), throne.add(0, 3, 0), snap);
        } else if (tick < T_VISTA) {                // the King on his throne
            double t = ease((tick - T_THRONE) / (double) (T_VISTA - T_THRONE));
            Vec3 a = throne.add(fwd.scale(-11)).add(up.scale(4.5));
            Vec3 b = throne.add(fwd.scale(-6.5)).add(up.scale(4.0));
            place(a.lerp(b, t), throne.add(0, 3.4, 0), snap);
            if (tick == T_THRONE + 6) play(ModSounds.SUKUNA_VOICE.get(), 1.0f, 0.75f);
            if (tick == T_THRONE + 52) play(ModSounds.SUKUNA_LAUGH.get(), 0.9f, 0.8f);
        } else if (tick < T_BLACK) {                // vista from behind the throne
            double t = ease((tick - T_VISTA) / (double) (T_BLACK - T_VISTA));
            Vec3 a = throne.add(fwd.scale(4)).add(up.scale(10));
            Vec3 b = throne.add(fwd.scale(5)).add(up.scale(14));
            place(a.lerp(b, t), origin.add(fwd.scale(-40)).add(0, 4, 0), snap);
            if (tick == T_VISTA + 4) play(ModSounds.SUKUNA_VOICE.get(), 1.0f, 0.65f);
        } else if (tick < T_SCARE) {                // black, heartbeat
            place(throne.add(fwd.scale(-2.4)).add(up.scale(3.4)), throne.add(0, 3.6, 0), tick == T_BLACK);
            if (tick == T_BLACK + 2) play(ModSounds.HEARTBEAT.get(), 1.0f, 0.8f);
            if (tick == T_BLACK + 8) play(ModSounds.HEARTBEAT.get(), 1.0f, 0.8f);
        } else if (tick < T_FADE) {                 // JUMPSCARE
            HeianSukunaEntity.clientJumpscare = true;
            double t = (tick - T_SCARE) / (double) (T_FADE - T_SCARE);
            Vec3 p = throne.add(fwd.scale(-2.2 + t * 0.5)).add(up.scale(3.3));
            place(p, throne.add(fwd.scale(1.0)).add(0, 3.7, 0), tick == T_SCARE);
            if (tick == T_SCARE) {
                play(ModSounds.SUKUNA_ROAR.get(), 1.0f, 0.7f);
                play(ModSounds.CINEMATIC_STING.get(), 1.0f, 0.6f);
                play(SoundEvents.WARDEN_ROAR, 1.0f, 0.8f);
                ClientFx.trigger(com.kingofcurses.network.ScreenFxPacket.RED_FLASH, 16, 1.0f);
                ClientFx.trigger(com.kingofcurses.network.ScreenFxPacket.SHAKE, 22, 1.4f);
            }
        } else if (tick >= HeianLogic.INTRO_LENGTH) {
            stop();
            if (mc.player != null) mc.player.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.kingofcurses.heian_after").withStyle(net.minecraft.ChatFormatting.GOLD), false);
            return;
        }
        if (mc.getCameraEntity() != camera) mc.setCameraEntity(camera);
    }

    /** Subtitle key for the current tick, or null. */
    public static String subtitle() {
        if (tick >= T_THRONE + 4 && tick < T_THRONE + 50) return "cinematic.kingofcurses.heian.line1";
        if (tick >= T_THRONE + 50 && tick < T_VISTA) return "cinematic.kingofcurses.heian.line2";
        if (tick >= T_VISTA && tick < T_BLACK) return "cinematic.kingofcurses.heian.line3";
        return null;
    }

    /** 0..1 black overlay. */
    public static float black() {
        if (tick < 10) return 1f - tick / 10f;
        if (tick >= T_BLACK - 6 && tick < T_SCARE) return Mth.clamp((tick - (T_BLACK - 6)) / 6f, 0, 1);
        if (tick >= T_FADE) return Mth.clamp((tick - T_FADE) / 8f, 0, 1);
        return 0f;
    }
}
