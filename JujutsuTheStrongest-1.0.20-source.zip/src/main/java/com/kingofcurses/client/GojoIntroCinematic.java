package com.kingofcurses.client;

import com.kingofcurses.ability.GojoIntroDirector;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

/** v1.0.18 client camera for the Strongest of Today opening. Shots follow the real actors. */
public final class GojoIntroCinematic {
    private static boolean active;
    private static int tick, gojoId, tojiId, getoId = -1;
    private static Vec3 lastGeto = null;
    private static Entity camera;
    private static Vec3 lastG = Vec3.ZERO, lastT = Vec3.ZERO, fwd = new Vec3(0, 0, 1);

    private GojoIntroCinematic() {}

    public static boolean active() { return active; }
    public static int tick() { return tick; }

    public static void start(int g, int t) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        gojoId = g; tojiId = t; tick = 0; getoId = -1; lastGeto = null;
        camera = EntityType.MARKER.create(mc.level);
        if (camera == null) return;
        float y = mc.player.getYRot() * Mth.DEG_TO_RAD;
        fwd = new Vec3(-Mth.sin(y), 0, Mth.cos(y));
        lastG = mc.player.position();
        lastT = lastG.subtract(fwd.scale(10));
        active = true;
        place(lastG.add(new Vec3(-fwd.z, 0, fwd.x).scale(7)).add(0, 2.2, 0), lastG.add(0, 1.4, 0), true);
        mc.setCameraEntity(camera);
    }

    public static void geto(int id) { getoId = id; }

    public static void sync(int t) { if (active && Math.abs(t - tick) > 3) tick = t; }

    public static void stop() {
        active = false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.setCameraEntity(mc.player);
        camera = null;
    }

    public static void reset() { if (active) stop(); }

    private static void place(Vec3 pos, Vec3 look, boolean snap) {
        Vec3 d = look.subtract(pos);
        float yaw = (float) (Mth.atan2(d.z, d.x) * Mth.RAD_TO_DEG) - 90f;
        float pitch = (float) -(Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * Mth.RAD_TO_DEG);
        if (snap) { camera.xo = pos.x; camera.yo = pos.y; camera.zo = pos.z; camera.yRotO = yaw; camera.xRotO = pitch; }
        else { camera.xo = camera.getX(); camera.yo = camera.getY(); camera.zo = camera.getZ(); camera.yRotO = camera.getYRot(); camera.xRotO = camera.getXRot(); }
        while (yaw - camera.yRotO > 180) yaw -= 360;
        while (yaw - camera.yRotO < -180) yaw += 360;
        camera.setPos(pos); camera.setYRot(yaw); camera.setXRot(pitch);
    }

    private static double ease(double t) { t = Mth.clamp(t, 0, 1); return t * t * (3 - 2 * t); }

    public static void clientTick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || camera == null) { stop(); return; }
        tick++;
        Entity ge = mc.level.getEntity(gojoId), te = mc.level.getEntity(tojiId);
        lastG = mc.player.position();   // v1.0.19: the player IS Gojo
        if (te != null) lastT = te.position();
        Entity gt = getoId >= 0 ? mc.level.getEntity(getoId) : null;
        if (gt != null) lastGeto = gt.position();
        Vec3 G = lastG, T = lastT, up = new Vec3(0, 1, 0);
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        Vec3 toT = T.subtract(G); toT = new Vec3(toT.x, 0, toT.z);
        Vec3 dirT = toT.lengthSqr() < 0.01 ? fwd.reverse() : toT.normalize();
        Vec3 rightT = new Vec3(-dirT.z, 0, dirT.x);
        boolean snap = tick == GojoIntroDirector.T_STAB1 || tick == GojoIntroDirector.T_FALL || tick == GojoIntroDirector.T_LEAVE + 14 || tick == GojoIntroDirector.T_AWAKE
                || tick == GojoIntroDirector.T_TURN || tick == GojoIntroDirector.T_FIRE || tick == GojoIntroDirector.T_AFTER;
        if (tick < GojoIntroDirector.T_STAB1) {                                  // wide: the stranger walks up behind him
            double k = ease(tick / (double) GojoIntroDirector.T_STAB1);
            place(G.add(right.scale(7 - k * 2)).add(fwd.scale(-2)).add(up.scale(2.0)), G.lerp(T, 0.5).add(0, 1.4, 0), false);
        } else if (tick < GojoIntroDirector.T_FALL) {                           // close: the spear goes through, again and again
            double k = (tick - GojoIntroDirector.T_STAB1) / (double) (GojoIntroDirector.T_FALL - GojoIntroDirector.T_STAB1);
            place(G.add(fwd.scale(3.0 - k * 0.6)).add(right.scale(1.4)).add(up.scale(1.7)), G.add(0, 1.45, 0), snap);
        } else if (tick < GojoIntroDirector.T_LEAVE + 14) {                     // he falls
            place(G.add(up.scale(4.5)).add(fwd.scale(1.5)).add(right.scale(1.5)), G.add(0, 0.3, 0), snap);
        } else if (tick < GojoIntroDirector.T_AWAKE) {                          // Toji walks away, from the ground
            place(G.add(up.scale(0.6)).add(fwd.scale(0.8)).add(right.scale(0.7)), T.add(0, 1.2, 0), snap);
        } else if (tick < GojoIntroDirector.T_TURN) {                           // Reverse Cursed Technique
            double k = ease((tick - GojoIntroDirector.T_AWAKE) / (double) (GojoIntroDirector.T_TURN - GojoIntroDirector.T_AWAKE));
            Vec3 a = G.add(up.scale(2.4)).add(right.scale(1.2)), b = G.add(fwd.scale(3.2)).add(up.scale(1.6));
            place(a.lerp(b, k), G.add(0, 0.4 + 1.1 * k, 0), snap);
        } else if (tick < GojoIntroDirector.T_FIRE) {                           // the hero shot: Red and Blue
            double k = ease((tick - GojoIntroDirector.T_TURN) / (double) (GojoIntroDirector.T_FIRE - GojoIntroDirector.T_TURN));
            Vec3 a = G.add(dirT.scale(3.2)).add(rightT.scale(-1.8)).add(up.scale(1.0)), b = G.add(dirT.scale(2.2)).add(rightT.scale(-1.0)).add(up.scale(1.3));
            place(a.lerp(b, k), G.add(0, 1.6, 0), snap);
        } else if (tick < GojoIntroDirector.T_AFTER) {                          // Hollow Purple, over the shoulder
            place(G.subtract(dirT.scale(2.6)).add(rightT.scale(1.0)).add(up.scale(2.1)), T.add(0, 1.0, 0), snap);
        } else if (tick < GojoIntroDirector.T_GETO || lastGeto == null) {    // what is left of him
            double k = ease((tick - GojoIntroDirector.T_AFTER) / (double) (GojoIntroDirector.T_GETO - GojoIntroDirector.T_AFTER));
            place(T.add(up.scale(2.6 + k)).add(rightT.scale(2.6)).add(dirT.scale(-1.5)), T.add(0, 0.2, 0), snap);
        } else {                                                                // v1.0.20 Geto: "Sukuna is back"
            Vec3 P = lastGeto;
            Vec3 toP = new Vec3(P.x - G.x, 0, P.z - G.z);
            Vec3 dirP = toP.lengthSqr() < 0.01 ? fwd : toP.normalize();
            Vec3 sideP = new Vec3(-dirP.z, 0, dirP.x);
            boolean s2 = tick == GojoIntroDirector.T_GETO || tick == GojoIntroDirector.T_TALK || tick == GojoIntroDirector.T_LINE2 || tick == GojoIntroDirector.T_LINE3 || tick == GojoIntroDirector.T_LINE4;
            if (tick < GojoIntroDirector.T_TALK) place(G.subtract(dirP.scale(2.4)).add(sideP.scale(1.1)).add(up.scale(2.0)), P.add(0, 1.5, 0), s2);        // he walks up
            else if (tick < GojoIntroDirector.T_LINE2 || (tick >= GojoIntroDirector.T_LINE3 && tick < GojoIntroDirector.T_LINE4)) {
                Vec3 mid = G.lerp(P, 0.5);
                place(mid.add(sideP.scale(4.2)).add(up.scale(1.7)), mid.add(0, 1.5, 0), s2);                                              // two-shot
            } else if (tick < GojoIntroDirector.T_LINE3) place(P.subtract(dirP.scale(1.9)).add(sideP.scale(0.6)).add(up.scale(1.7)), P.add(0, 1.6, 0), s2);   // close on Geto
            else place(P.add(sideP.scale(-0.6)).add(dirP.scale(0.2)).add(up.scale(1.9)), G.add(0, 1.6, 0), s2);                               // Gojo answers
        }
        if (mc.getCameraEntity() != camera) mc.setCameraEntity(camera);
        if (tick > GojoIntroDirector.T_END + 40) stop();
    }

    public static String subtitle() {
        if (tick >= GojoIntroDirector.T_STAB1 + 6 && tick < GojoIntroDirector.T_FALL) return "cinematic.kingofcurses.gojo.line1";
        if (tick >= GojoIntroDirector.T_FALL + 4 && tick < GojoIntroDirector.T_AWAKE - 6) return "cinematic.kingofcurses.gojo.line2";
        if (tick >= GojoIntroDirector.T_RISE && tick < GojoIntroDirector.T_CHARGE) return "cinematic.kingofcurses.gojo.line3";
        if (tick >= GojoIntroDirector.T_CHARGE && tick < GojoIntroDirector.T_FIRE + 6) return "cinematic.kingofcurses.gojo.line4";
        if (tick >= GojoIntroDirector.T_TALK && tick < GojoIntroDirector.T_LINE2) return "cinematic.kingofcurses.geto.line1";
        if (tick >= GojoIntroDirector.T_LINE2 && tick < GojoIntroDirector.T_LINE3) return "cinematic.kingofcurses.geto.line2";
        if (tick >= GojoIntroDirector.T_LINE3 && tick < GojoIntroDirector.T_LINE4) return "cinematic.kingofcurses.geto.line3";
        if (tick >= GojoIntroDirector.T_LINE4 && tick < GojoIntroDirector.T_END) return "cinematic.kingofcurses.geto.line4";
        return null;
    }

    public static float black() {
        if (tick < 8) return 1f - tick / 8f;
        if (tick >= GojoIntroDirector.T_LEAVE + 50 && tick < GojoIntroDirector.T_AWAKE) return Mth.clamp((tick - (GojoIntroDirector.T_LEAVE + 50)) / 6f, 0, 0.85f);
        if (tick >= GojoIntroDirector.T_END - 8) return Mth.clamp((tick - (GojoIntroDirector.T_END - 8)) / 8f, 0, 1);
        return 0f;
    }
}
