package com.kingofcurses.client.screen;

import com.kingofcurses.ability.EndingLogic;
import com.kingofcurses.network.EndingChoicePacket;
import com.kingofcurses.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** The final choice: Embrace or Reject Sukuna. One time, per player, validated on the server. */
public class EndingScreen extends Screen {
    public EndingScreen() { super(Component.translatable("gui.kingofcurses.ending.title")); }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 + 20;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.ending.embrace"), b -> choose(EndingLogic.EMBRACE)).bounds(cx - 160, y, 150, 22).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.ending.reject"), b -> choose(EndingLogic.REJECT)).bounds(cx + 10, y, 150, 22).build());
    }

    private void choose(int c) {
        ModNetwork.sendToServer(new EndingChoicePacket(c));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fillGradient(0, 0, width, height, 0xF0050002, 0xF0400008);
        int cx = width / 2;
        g.pose().pushPose();
        g.pose().translate(cx, height / 2f - 70, 0);
        g.pose().scale(2f, 2f, 1f);
        g.drawString(font, title, -font.width(title) / 2, 0, 0xFFFF2A40, true);
        g.pose().popPose();
        Component text = Component.translatable("gui.kingofcurses.ending.text");
        int tw = Math.min(320, width - 40);
        g.drawWordWrap(font, text, cx - tw / 2, height / 2 - 38, tw, 0xFFE2DAC4);
        Component e = Component.translatable("gui.kingofcurses.ending.embrace_desc");
        Component r = Component.translatable("gui.kingofcurses.ending.reject_desc");
        g.drawWordWrap(font, e, cx - 160, height / 2 + 48, 150, 0xFFB01020);
        g.drawWordWrap(font, r, cx + 10, height / 2 + 48, 150, 0xFF8AB4FF);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
