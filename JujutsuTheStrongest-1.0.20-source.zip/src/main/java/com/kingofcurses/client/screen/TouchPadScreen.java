package com.kingofcurses.client.screen;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.ability.Ability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.client.ClientData;
import com.kingofcurses.client.ClientHooks;
import com.kingofcurses.network.AbilityPacket;
import com.kingofcurses.network.CodexActionPacket;
import com.kingofcurses.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;

/**
 * v1.0.12 Technique Pad: big touch tiles, made for PojavLauncher.
 * Tap a technique = cast it instantly (and select it). Opens with a double tap on SNEAK in mobile mode, or P.
 */
public class TouchPadScreen extends Screen {
    private final List<Ability> abilities;
    private final List<int[]> tiles = new ArrayList<>(); // x, y, w, h, abilityOrdinal
    private boolean ripArmed = false;

    public TouchPadScreen() {
        super(Component.translatable("gui.kingofcurses.pad.title"));
        CursedData d = ClientData.DATA;
        abilities = Ability.forData(d);
    }

    @Override
    protected void init() {
        tiles.clear();
        CursedData d = ClientData.DATA;
        int cols = 3, gap = 6;
        int tw = Math.min(120, (width - 40 - gap * (cols - 1)) / cols), th = 34;
        int list = abilities.size();
        int rows = Math.max(1, (list + cols - 1) / cols);
        int totalW = cols * tw + (cols - 1) * gap;
        int x0 = (width - totalW) / 2, y0 = Math.max(28, (height - (rows * (th + gap) + 30)) / 2);
        for (int i = 0; i < list; i++) {
            int x = x0 + (i % cols) * (tw + gap), y = y0 + (i / cols) * (th + gap);
            tiles.add(new int[]{x, y, tw, th, abilities.get(i).ordinal()});
        }
        int by = Math.min(height - 26, y0 + rows * (th + gap) + 6);
        int bw = Math.max(60, (totalW - gap * 3) / 4);
        int bx = x0;
        if (d.lostArms() != 0) {
            addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.pad.regrow"), b -> {
                ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.USE_SELECTED, 0)); onClose();
            }).bounds(bx, by, bw, 22).build());
        } else {
            addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.pad.codex"), b -> ClientHooks.openCodex())
                    .bounds(bx, by, bw, 22).build());
        }
        bx += bw + gap;
        Button rip = Button.builder(Component.translatable("gui.kingofcurses.pad.rip"), b -> {
            if (ripArmed) { ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.RIP_FINGER)); onClose(); }
            else { ripArmed = true; b.setMessage(Component.translatable("gui.kingofcurses.pad.rip_confirm")); }
        }).bounds(bx, by, bw, 22).build();
        rip.active = d.fingers() > 0 && d.ending() == CursedData.ENDING_NONE;
        addRenderableWidget(rip);
        bx += bw + gap;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.pad.wheel"), b -> minecraft.setScreen(new AbilityWheelScreen()))
                .bounds(bx, by, bw, 22).build());
        bx += bw + gap;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.pad.hud"), b -> ClientHooks.openBattleHud())
                .bounds(bx, by, bw, 22).build());
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int[] t : tiles) {
            if (mx >= t[0] && mx < t[0] + t[2] && my >= t[1] && my < t[1] + t[3]) {
                ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.CAST, t[4]));
                onClose();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fillGradient(0, 0, width, height, 0x88000000, 0xA0200004);
        CursedData d = ClientData.DATA;
        g.drawCenteredString(font, title, width / 2, 8, 0xFFFF2A40);
        g.drawCenteredString(font, Component.translatable("gui.kingofcurses.pad.energy", (int) d.energy(), (int) d.maxEnergy()), width / 2, 18, 0xFF7FD4FF);
        if (abilities.isEmpty()) g.drawCenteredString(font, Component.translatable("message.kingofcurses.no_ability"), width / 2, height / 2 - 20, 0xFF9A8A8C);
        for (int[] t : tiles) {
            Ability a = Ability.byIndex(t[4]);
            int cd = d.cooldown(a);
            boolean sel = d.selected() == a.ordinal();
            boolean hv = mouseX >= t[0] && mouseX < t[0] + t[2] && mouseY >= t[1] && mouseY < t[1] + t[3];
            int border = sel ? 0xFFFF2A40 : (hv ? 0xFFB00018 : 0xFF4A1018);
            g.fill(t[0], t[1], t[0] + t[2], t[1] + t[3], border);
            g.fill(t[0] + 1, t[1] + 1, t[0] + t[2] - 1, t[1] + t[3] - 1, cd > 0 ? 0xE0151012 : (a == Ability.DOMAIN_EXPANSION ? 0xE0300008 : 0xE01A0406));
            g.blit(new ResourceLocation(KingOfCurses.MODID, "textures/gui/ability/" + a.id() + ".png"), t[0] + 6, t[1] + 9, 0, 0, 16, 16, 16, 16);
            g.drawString(font, a.displayName(), t[0] + 26, t[1] + 7, cd > 0 ? 0xFF9A8A8C : 0xFFF0E6D2, true);
            Component sub = cd > 0 ? Component.literal((cd + 19) / 20 + "s") : Component.literal((int) a.cost + " CE");
            g.drawString(font, sub, t[0] + 26, t[1] + 19, cd > 0 ? 0xFFFF6A6A : 0xFF7FD4FF, true);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
