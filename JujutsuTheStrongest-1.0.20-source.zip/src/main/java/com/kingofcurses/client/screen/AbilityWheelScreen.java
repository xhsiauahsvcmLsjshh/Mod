package com.kingofcurses.client.screen;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.ability.Ability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.client.ClientData;
import com.kingofcurses.client.KeyBindings;
import com.kingofcurses.network.AbilityPacket;
import com.kingofcurses.network.ModNetwork;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.List;

/** Radial technique selector: hold the wheel key, point with the mouse, release (or click) to select. */
public class AbilityWheelScreen extends Screen {
    private final List<Ability> abilities;
    private int hovered = -1;

    public AbilityWheelScreen() {
        super(Component.translatable("gui.kingofcurses.wheel.title"));
        CursedData d = ClientData.DATA;
        abilities = Ability.forData(d);
    }

    @Override
    public void tick() {
        if (minecraft == null) return;
        int key = KeyBindings.ABILITY_WHEEL.getKey().getValue();
        if (key > 0 && !InputConstants.isKeyDown(minecraft.getWindow().getWindow(), key)) select();
    }

    private void select() {
        if (hovered >= 0 && hovered < abilities.size()) ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.SELECT, abilities.get(hovered).ordinal()));
        onClose();
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) { select(); return true; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int cx = width / 2, cy = height / 2, r = 70;
        g.fillGradient(0, 0, width, height, 0x90000000, 0xA0200004);
        g.drawCenteredString(font, title, cx, cy - r - 30, 0xFFFF2A40);
        int n = abilities.size();
        double dist = Math.hypot(mouseX - cx, mouseY - cy);
        hovered = -1;
        if (n > 0 && dist > 18) {
            double ang = Math.atan2(mouseY - cy, mouseX - cx) + Math.PI / 2;
            if (ang < 0) ang += Math.PI * 2;
            hovered = Mth.floor(ang / (Math.PI * 2 / n) + 0.5) % n;
        }
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n - Math.PI / 2;
            int x = cx + (int) (Math.cos(a) * r), y = cy + (int) (Math.sin(a) * r);
            boolean hv = i == hovered;
            g.fill(x - 14, y - 14, x + 14, y + 14, hv ? 0xF0B00018 : 0xC0200508);
            g.fill(x - 13, y - 13, x + 13, y + 13, hv ? 0xF0400008 : 0xC0100204);
            g.blit(new ResourceLocation(KingOfCurses.MODID, "textures/gui/ability/" + abilities.get(i).id() + ".png"), x - 8, y - 8, 0, 0, 16, 16, 16, 16);
            if (hv) g.drawCenteredString(font, abilities.get(i).displayName(), cx, cy - 4, 0xFFFFE0E0);
            int cd = ClientData.DATA.cooldown(abilities.get(i));
            if (cd > 0) g.drawCenteredString(font, String.valueOf((cd + 19) / 20), x, y + 16, 0xFF999999);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
