package com.kingofcurses.client.screen;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.network.ControlModePacket;
import com.kingofcurses.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Shown after the intro (and from the Codex): choose PC keybinds or mobile technique items. */
public class ControlModeScreen extends Screen {
    public ControlModeScreen() { super(Component.translatable("gui.kingofcurses.controls.title")); }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 + 6;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.controls.pc"), b -> choose(CursedData.CONTROL_PC)).bounds(cx - 155, y, 150, 24).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.controls.mobile"), b -> choose(CursedData.CONTROL_MOBILE)).bounds(cx + 5, y, 150, 24).build());
    }

    private void choose(int mode) {
        ModNetwork.sendToServer(new ControlModePacket(mode));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fillGradient(0, 0, width, height, 0xE8050002, 0xE8300006);
        int cx = width / 2;
        g.pose().pushPose();
        g.pose().translate(cx, height / 2f - 62, 0);
        g.pose().scale(2f, 2f, 1f);
        g.drawString(font, title, -font.width(title) / 2, 0, 0xFFFF2A40, true);
        g.pose().popPose();
        Component sub = Component.translatable("gui.kingofcurses.controls.text");
        int tw = Math.min(320, width - 40);
        g.drawWordWrap(font, sub, cx - tw / 2, height / 2 - 34, tw, 0xFFE2DAC4);
        g.drawWordWrap(font, Component.translatable("gui.kingofcurses.controls.pc_desc"), cx - 155, height / 2 + 36, 150, 0xFFB8B0A0);
        g.drawWordWrap(font, Component.translatable("gui.kingofcurses.controls.mobile_desc"), cx + 5, height / 2 + 36, 150, 0xFFB8B0A0);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
