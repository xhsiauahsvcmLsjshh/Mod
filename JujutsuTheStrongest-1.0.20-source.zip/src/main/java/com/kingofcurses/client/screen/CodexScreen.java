package com.kingofcurses.client.screen;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.ability.Ability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.client.ClientData;
import com.kingofcurses.network.CodexActionPacket;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.registry.ModItems;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/** The Cursed Codex: progress, techniques, lore, finger sites, intro replay and ending access. */
public class CodexScreen extends Screen {
    private static final ResourceLocation BG = new ResourceLocation(KingOfCurses.MODID, "textures/gui/codex.png");
    private static final int W = 256, H = 192;
    private boolean ripArmed;
    private int page; // 0 techniques, 1 lore, 2 sites
    private int left, top;

    public CodexScreen() { super(Component.translatable("gui.kingofcurses.codex.title")); }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        CursedData d = ClientData.DATA;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.codex.prev"), b -> page = (page + 2) % 3).bounds(left + 136, top + 164, 20, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.codex.next"), b -> page = (page + 1) % 3).bounds(left + 226, top + 164, 20, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.codex.controls"), b -> com.kingofcurses.client.ClientHooks.openControlMode())
                .bounds(left + 196, top + 8, 52, 14).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.codex.mode").withStyle(net.minecraft.ChatFormatting.DARK_RED),
                b -> ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.TOGGLE_MODE))).bounds(left + 68, top + 164, 54, 18).build());
        addRenderableWidget(Button.builder(hudLabel(), b -> { com.kingofcurses.client.KeyBindings.showControls = !com.kingofcurses.client.KeyBindings.showControls; b.setMessage(hudLabel()); })
                .bounds(left + 158, top + 164, 66, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.codex.replay"), b -> { ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.REPLAY_INTRO)); onClose(); })
                .bounds(left + 10, top + 164, 56, 18).build());
        if (d.fingers() > 0 && d.ending() == CursedData.ENDING_NONE) {
            addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.codex.rip"), b -> {
                if (ripArmed) { ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.RIP_FINGER)); onClose(); }
                else { ripArmed = true; b.setMessage(Component.translatable("gui.kingofcurses.codex.rip_confirm")); }
            }).bounds(left + 136, top + 142, 110, 18).build());
        }
        if (d.fingers() >= 20 && d.ending() == CursedData.ENDING_NONE) {
            if (!d.bossDefeated()) {
                addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.codex.summon"), b -> { ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.SUMMON_BOSS)); onClose(); })
                        .bounds(left + 10, top + 142, 112, 18).build());
            } else {
                addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.codex.ending"), b -> ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.OPEN_ENDING)))
                        .bounds(left + 10, top + 142, 112, 18).build());
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.blit(BG, left, top, 0, 0, W, H, W, H);
        CursedData d = ClientData.DATA;
        int ink = 0xFF2A1014, red = 0xFF8A0414;
        g.drawString(font, title, left + 14, top + 12, red, false);
        g.drawString(font, Component.translatable("gui.kingofcurses.codex.progress", d.fingers()), left + 14, top + 26, ink, false);
        g.drawString(font, Component.translatable("gui.kingofcurses.codex.energy", (int) d.energy(), (int) d.maxEnergy()), left + 14, top + 37, ink, false);
        String status = d.ending() == CursedData.ENDING_EMBRACE ? "gui.kingofcurses.codex.status_embrace" : d.ending() == CursedData.ENDING_REJECT ? "gui.kingofcurses.codex.status_reject" : "gui.kingofcurses.codex.status_none";
        g.drawString(font, Component.translatable(status), left + 14, top + 48, red, false);
        for (int i = 0; i < 20; i++) {
            int fx = left + 14 + (i % 5) * 21, fy = top + 62 + (i / 5) * 19;
            g.renderItem(new ItemStack(ModItems.SUKUNA_FINGER.get()), fx, fy);
            if (!d.hasEaten(i)) g.fill(fx, fy, fx + 16, fy + 16, 0xB0E2D6BE);
            if (mouseX >= fx && mouseX < fx + 16 && mouseY >= fy && mouseY < fy + 16) {
                g.renderTooltip(font, new ItemStack(ModItems.SUKUNA_FINGER.get()), mouseX, mouseY);
            }
        }
        int rx = left + 136, ry = top + 12, rw = 110;
        switch (page) {
            case 0 -> {
                g.drawString(font, Component.translatable("gui.kingofcurses.codex.powers"), rx, ry, red, false);
                int y = ry + 13;
                for (Ability a : Ability.values()) {
                    if (!a.visibleFor(d)) continue;
                    boolean un = Ability.forData(d).contains(a);
                    g.drawString(font, a.displayName(), rx, y, un ? red : 0xFF7A6A60, false);
                    if (!d.isGojo()) g.drawString(font, Component.translatable("gui.kingofcurses.codex.unlocks_at", a.requiredFingers()), rx + 4, y + 9, 0xFF6A5A50, false);
                    y += d.isGojo() ? 11 : 18;
                }
            }
            case 1 -> {
                g.drawString(font, Component.translatable("gui.kingofcurses.codex.lore"), rx, ry, red, false);
                int y = ry + 14;
                for (int i = 0; i < 4; i++) {
                    Component c = Component.translatable("gui.kingofcurses.codex.lore_" + i);
                    g.drawWordWrap(font, c, rx, y, rw, ink);
                    y += font.wordWrapHeight(c, rw) + 6;
                }
            }
            default -> {
                g.drawString(font, Component.translatable("gui.kingofcurses.codex.locations"), rx, ry, red, false);
                int y = ry + 14;
                for (int i = 0; i < 7; i++) {
                    Component c = Component.translatable("gui.kingofcurses.codex.site_" + i);
                    g.drawWordWrap(font, c, rx, y, rw, ink);
                    y += font.wordWrapHeight(c, rw) + 3;
                }
            }
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    private static Component hudLabel() {
        return Component.translatable(com.kingofcurses.client.KeyBindings.showControls ? "gui.kingofcurses.codex.hud_on" : "gui.kingofcurses.codex.hud_off");
    }
}
