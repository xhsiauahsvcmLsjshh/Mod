package com.kingofcurses.client.screen;

import com.kingofcurses.ability.Ability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.client.ClientCinematic;
import com.kingofcurses.client.ClientData;
import com.kingofcurses.client.ClientFx;
import com.kingofcurses.client.ClientHooks;
import com.kingofcurses.network.AbilityPacket;
import com.kingofcurses.network.CodexActionPacket;
import com.kingofcurses.network.ModNetwork;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.lwjgl.glfw.GLFW;

/**
 * v1.0.13 Battle HUD: transparent, non-pausing screen with real touch buttons on the right side.
 * While it is open you keep moving (keys are forwarded), drag anywhere to look around and
 * tap empty space to attack. Opened from the Technique Pad, with O, or automatically in mobile mode.
 */
public class BattleHudScreen extends Screen {
    private Button cast, rip, finisher;
    private double dragDist = 0;
    private boolean pressedEmpty = false;
    private boolean ripArmed = false;
    private int ripTimer = 0;

    public BattleHudScreen() { super(Component.translatable("gui.kingofcurses.hud.title")); }

    @Override
    protected void init() {
        int bw = 74, bh = 24, gap = 4;
        int x = width - bw - 6;
        int y = height / 2 - (bh * 6 + gap * 5) / 2;
        cast = addRenderableWidget(Button.builder(Component.literal("CAST"), b -> ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.USE_SELECTED, 0)))
                .bounds(x - 20, y, bw + 20, bh + 8).build());
        y += bh + 8 + gap;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.hud.next"), b -> ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.CYCLE, 0)))
                .bounds(x, y, bw, bh).build());
        y += bh + gap;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.hud.domain"), b -> ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.DOMAIN, 0)))
                .bounds(x, y, bw, bh).build());
        y += bh + gap;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.hud.pad"), b -> ClientHooks.openTouchPad())
                .bounds(x, y, bw, bh).build());
        y += bh + gap;
        rip = addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.pad.rip"), b -> {
            if (ripArmed) { ripArmed = false; ModNetwork.sendToServer(new CodexActionPacket(CodexActionPacket.RIP_FINGER)); }
            else { ripArmed = true; ripTimer = 60; }
        }).bounds(x, y, bw, bh).build());
        y += bh + gap;
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.hud.exit"), b -> onClose())
                .bounds(x, y, bw, bh).build());
        finisher = addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.hud.finisher"), b -> ModNetwork.sendToServer(new AbilityPacket(AbilityPacket.FINISHER, 0)))
                .bounds(width / 2 - 50, height - 62, 100, 24).build());
        // small top-left buttons
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.pad.codex"), b -> ClientHooks.openCodex())
                .bounds(6, 6, 50, 18).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.hud.jump"), b -> { if (minecraft.player != null && minecraft.player.onGround()) minecraft.player.jumpFromGround(); })
                .bounds(6, height - 60, 50, 22).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.kingofcurses.hud.use"), b -> {
            if (minecraft.player != null && minecraft.gameMode != null) minecraft.gameMode.useItem(minecraft.player, InteractionHand.MAIN_HAND);
        }).bounds(6, height - 34, 50, 22).build());
        refreshLabels();
    }

    private void refreshLabels() {
        CursedData d = ClientData.DATA;
        if (cast != null) {
            if (d.lostArms() != 0) cast.setMessage(Component.translatable("gui.kingofcurses.pad.regrow"));
            else {
                java.util.List<Ability> list = Ability.forData(d);
                Ability sel = Ability.byIndex(d.selected());
                if (!list.isEmpty() && !list.contains(sel)) sel = list.get(0);
                if (list.isEmpty()) cast.setMessage(Component.literal("-"));
                else {
                    int cd = d.cooldown(sel);
                    cast.setMessage(cd > 0 ? sel.displayName().copy().append(" " + (cd + 19) / 20 + "s") : sel.displayName());
                }
            }
        }
        if (finisher != null) finisher.visible = d.finisherReady();
        if (rip != null) {
            rip.active = d.fingers() > 0 && d.ending() == CursedData.ENDING_NONE;
            rip.setMessage(Component.translatable(ripArmed ? "gui.kingofcurses.pad.rip_confirm" : "gui.kingofcurses.pad.rip"));
        }
    }

    @Override
    public void tick() {
        if (minecraft == null || minecraft.player == null || !minecraft.player.isAlive() || ClientCinematic.active() || ClientFx.takeoverActive()) { onClose(); return; }
        if (ripTimer > 0 && --ripTimer == 0) ripArmed = false;
        refreshLabels();
    }

    // ---- touch: drag to look, tap empty space to attack ----
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        pressedEmpty = true;
        dragDist = 0;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (!pressedEmpty) return super.mouseDragged(mx, my, button, dx, dy);
        dragDist += Math.abs(dx) + Math.abs(dy);
        if (minecraft != null && minecraft.player != null) {
            double s = minecraft.options.sensitivity().get() * 0.6 + 0.2;
            double f = s * s * s * 8.0 * minecraft.getWindow().getGuiScale();
            minecraft.player.turn(dx * f, dy * f * (minecraft.options.invertYMouse().get() ? -1 : 1));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (pressedEmpty) {
            pressedEmpty = false;
            if (dragDist < 6) attack();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    private void attack() {
        if (minecraft == null || minecraft.player == null || minecraft.gameMode == null) return;
        HitResult hr = minecraft.hitResult;
        if (hr instanceof EntityHitResult ehr) minecraft.gameMode.attack(minecraft.player, ehr.getEntity());
        minecraft.player.resetAttackStrengthTicker();
        minecraft.player.swing(InteractionHand.MAIN_HAND);
    }

    // ---- keep walking while the HUD is open (Pojav joystick sends WASD keys) ----
    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        KeyMapping.set(InputConstants.getKey(key, scan), true);
        return true;
    }

    @Override
    public boolean keyReleased(int key, int scan, int mods) {
        KeyMapping.set(InputConstants.getKey(key, scan), false);
        return true;
    }

    @Override
    public void removed() { KeyMapping.releaseAll(); super.removed(); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // no dark background: the world stays fully visible
        CursedData d = ClientData.DATA;
        int w = 94, x = width - w - 26, y = height / 2 - 108;
        float e = d.maxEnergy() <= 0 ? 0 : d.energy() / d.maxEnergy();
        g.fill(x, y, x + w + 20, y + 5, 0x90000000);
        g.fill(x, y, x + (int) ((w + 20) * e), y + 5, 0xE07FD4FF);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return true; }
}
