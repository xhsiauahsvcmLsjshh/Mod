package com.kingofcurses.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

public class KocParticle extends TextureSheetParticle {
    public enum Style { CURSED, BLOOD, SLASH, ASH, RESONANCE }
    private final SpriteSet sprites;
    private final Style style;

    protected KocParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites, Style style) {
        super(level, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.style = style;
        this.xd = vx + (random.nextDouble() - 0.5) * 0.02;
        this.yd = vy;
        this.zd = vz + (random.nextDouble() - 0.5) * 0.02;
        switch (style) {
            case CURSED -> { lifetime = 18 + random.nextInt(14); quadSize = 0.12f + random.nextFloat() * 0.1f; gravity = -0.02f; hasPhysics = false; }
            case BLOOD -> { lifetime = 20 + random.nextInt(20); quadSize = 0.06f + random.nextFloat() * 0.05f; gravity = 0.9f; hasPhysics = true; }
            case SLASH -> { lifetime = 6 + random.nextInt(4); quadSize = 0.45f + random.nextFloat() * 0.35f; gravity = 0f; hasPhysics = false; roll = random.nextFloat() * Mth.TWO_PI; oRoll = roll; xd = yd = zd = 0; }
            case ASH -> { lifetime = 40 + random.nextInt(30); quadSize = 0.05f + random.nextFloat() * 0.04f; gravity = 0.02f; hasPhysics = false; }
            case RESONANCE -> { lifetime = 24; quadSize = 0.1f; gravity = -0.01f; hasPhysics = false; }
        }
        setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        setSpriteFromAge(sprites);
        float life = age / (float) lifetime;
        if (style == Style.RESONANCE) quadSize = 0.1f + life * 0.35f;
        if (style == Style.CURSED || style == Style.RESONANCE || style == Style.SLASH) alpha = 1.0f - life;
    }

    @Override
    public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }

    @Override
    protected int getLightColor(float partialTick) {
        return style == Style.BLOOD || style == Style.ASH ? super.getLightColor(partialTick) : 0xF000F0;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Style style;

        public Provider(SpriteSet sprites, Style style) { this.sprites = sprites; this.style = style; }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
            return new KocParticle(level, x, y, z, vx, vy, vz, sprites, style);
        }
    }
}
