package com.kingofcurses.client.overlay;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.ability.Ability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.client.ClientCinematic;
import com.kingofcurses.client.ClientData;
import com.kingofcurses.client.ClientFx;
import com.kingofcurses.client.KeyBindings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Cursed energy HUD, screen effects and the cinematic letterbox. */
public final class KocOverlays {
    private KocOverlays() {}

    private static ResourceLocation icon(Ability a) {
        return new ResourceLocation(KingOfCurses.MODID, "textures/gui/ability/" + a.id() + ".png");
    }

    /** v1.0.15: precise readout for the Cursed Compass and the Compass of Remains while held. */
    public static final IGuiOverlay NAV = (gui, g, partialTick, w, h) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || ClientCinematic.active() || com.kingofcurses.client.HeianCinematic.active() || com.kingofcurses.client.GojoIntroCinematic.active()) return;
        net.minecraft.world.item.ItemStack st = mc.player.getMainHandItem();
        if (!isNav(st)) st = mc.player.getOffhandItem();
        if (!isNav(st)) return;
        boolean remains = st.is(com.kingofcurses.registry.ModItems.REMAINS_COMPASS.get());
        Font font = mc.font;
        if (!st.hasTag() || !st.getTag().contains("Target")) {
            if (remains) {
                Component none = Component.translatable("hud.kingofcurses.nav.no_sand");
                int y0 = h - 103, nw = font.width(none);
                g.fill(w / 2 - nw / 2 - 5, y0 - 4, w / 2 + nw / 2 + 5, y0 + 11, 0x90000000);
                g.drawCenteredString(font, none, w / 2, y0, 0xFF9A8A8C);
            }
            return;
        }
        net.minecraft.nbt.CompoundTag tag = st.getTag();
        net.minecraft.core.BlockPos t = net.minecraft.nbt.NbtUtils.readBlockPos(tag.getCompound("Target"));
        Component what = remains
                ? (tag.getInt("Fingers") > 0 ? Component.translatable("hud.kingofcurses.nav.sand_fingers", tag.getInt("Fingers")) : Component.translatable("hud.kingofcurses.nav.remains"))
                : Component.translatable(tag.getBoolean("Clues") ? "hud.kingofcurses.nav.clue" : "hud.kingofcurses.nav.finger");
        java.util.List<Component> lines = new java.util.ArrayList<>();
        java.util.List<Integer> cols = new java.util.ArrayList<>();
        lines.add(Component.translatable("hud.kingofcurses.nav.coords", what, t.getX(), t.getY(), t.getZ())); cols.add(0xFFFF4A5A);
        String dim = tag.getString("Dim");
        if (!mc.player.level().dimension().location().toString().equals(dim)) {
            lines.add(Component.translatable("hud.kingofcurses.nav.other_dim", dim)); cols.add(0xFFB89A9E);
        } else {
            net.minecraft.world.phys.Vec3 p = mc.player.getPosition(partialTick);
            double dx = t.getX() + 0.5 - p.x, dy = t.getY() - Math.floor(p.y), dz = t.getZ() + 0.5 - p.z;
            float yaw = mc.player.getViewYRot(partialTick) * Mth.DEG_TO_RAD;
            double fx = -Mth.sin(yaw), fz = Mth.cos(yaw);      // facing
            double fwd = dx * fx + dz * fz;
            double right = dx * -fz + dz * fx;                    // right-hand side
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist < 1.8) { lines.add(Component.translatable("hud.kingofcurses.nav.here")); cols.add(0xFF7CFF9A); }
            else {
                double ang = Math.atan2(right, fwd);              // 0 = straight ahead
                String[] arrows = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};
                int idx = Math.floorMod((int) Math.round(ang / (Math.PI / 4)), 8);
                lines.add(Component.translatable("hud.kingofcurses.nav.dist", arrows[idx], (int) Math.round(dist))); cols.add(0xFFF0E6D2);
                net.minecraft.network.chat.MutableComponent rel = Component.empty();
                int f = (int) Math.round(fwd), r = (int) Math.round(right), u = (int) Math.round(dy);
                boolean any = false;
                if (f != 0) { rel.append(Component.translatable(f > 0 ? "hud.kingofcurses.nav.forward" : "hud.kingofcurses.nav.back", Math.abs(f))); any = true; }
                if (r != 0) { if (any) rel.append("  \u00b7  "); rel.append(Component.translatable(r > 0 ? "hud.kingofcurses.nav.right" : "hud.kingofcurses.nav.left", Math.abs(r))); any = true; }
                if (u != 0) { if (any) rel.append("  \u00b7  "); rel.append(Component.translatable(u > 0 ? "hud.kingofcurses.nav.up" : "hud.kingofcurses.nav.down", Math.abs(u))); }
                lines.add(rel); cols.add(0xFFE2DAC4);
            }
        }
        if (!remains && tag.getBoolean("Looted")) { lines.add(Component.translatable("hud.kingofcurses.nav.looted")); cols.add(0xFF9A8A8C); }
        else if (!remains && !tag.getBoolean("Precise")) { lines.add(Component.translatable("hud.kingofcurses.nav.approx")); cols.add(0xFF9A8A8C); }
        int y = h - 92 - lines.size() * 11;
        int maxW = 0;
        for (Component c : lines) maxW = Math.max(maxW, font.width(c));
        g.fill(w / 2 - maxW / 2 - 5, y - 4, w / 2 + maxW / 2 + 5, y + lines.size() * 11 + 2, 0x90000000);
        for (int i = 0; i < lines.size(); i++) g.drawCenteredString(font, lines.get(i), w / 2, y + i * 11, cols.get(i));
    };

    private static boolean isNav(net.minecraft.world.item.ItemStack s) {
        return s.is(com.kingofcurses.registry.ModItems.CURSED_COMPASS.get()) || s.is(com.kingofcurses.registry.ModItems.REMAINS_COMPASS.get());
    }

    /** v1.0.18 Strongest of Today opening: letterbox, subtitles, fades, title. */
    public static final IGuiOverlay GOJO_INTRO = (gui, g, partialTick, w, h) -> {
        if (!com.kingofcurses.client.GojoIntroCinematic.active()) return;
        Minecraft mc = Minecraft.getInstance();
        int t = com.kingofcurses.client.GojoIntroCinematic.tick();
        int bar = (int) (h * 0.12f);
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);
        String key = com.kingofcurses.client.GojoIntroCinematic.subtitle();
        if (key != null) g.drawCenteredString(mc.font, Component.translatable(key), w / 2, h - bar / 2 - 4, 0xFFBFE6FF);
        float black = com.kingofcurses.client.GojoIntroCinematic.black();
        if (black > 0) g.fill(0, 0, w, h, ((int) (black * 255) << 24));
        if (t >= com.kingofcurses.ability.GojoIntroDirector.T_AFTER && t < com.kingofcurses.ability.GojoIntroDirector.T_GETO) {
            float a = Mth.clamp(Math.min((t - com.kingofcurses.ability.GojoIntroDirector.T_AFTER) / 10f, (com.kingofcurses.ability.GojoIntroDirector.T_GETO - t) / 8f), 0, 1);
            Component title = Component.translatable("cinematic.kingofcurses.gojo.title");
            g.pose().pushPose();
            g.pose().translate(w / 2f, h / 2f - 20, 0);
            g.pose().scale(3.2f, 3.2f, 1f);
            g.drawString(mc.font, title, -mc.font.width(title) / 2, 0, ((int) (a * 255) << 24) | 0x7FD4FF, true);
            g.pose().popPose();
        }
        Component hint = Component.translatable("cinematic.kingofcurses.skip_hint", KeyBindings.SKIP.getTranslatedKeyMessage());
        g.drawString(mc.font, hint, w - mc.font.width(hint) - 6, 6, 0x80FFFFFF, false);
    };

    /** v1.0.17 Heian arrival video: letterbox, subtitles, fades, title. */
    public static final IGuiOverlay HEIAN = (gui, g, partialTick, w, h) -> {
        if (!com.kingofcurses.client.HeianCinematic.active()) return;
        Minecraft mc = Minecraft.getInstance();
        int t = com.kingofcurses.client.HeianCinematic.tick();
        boolean scare = t >= com.kingofcurses.client.HeianCinematic.T_SCARE && t < com.kingofcurses.client.HeianCinematic.T_FADE;
        int bar = scare ? 0 : (int) (h * 0.12f);
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);
        if (t > 12 && t < 70) {
            float a = Mth.clamp(Math.min((t - 12) / 12f, (70 - t) / 12f), 0, 1);
            Component title = Component.translatable("cinematic.kingofcurses.heian.title");
            Component sub = Component.translatable("cinematic.kingofcurses.heian.subtitle");
            int col = ((int) (a * 255) << 24) | 0xF2C14E;
            g.pose().pushPose();
            g.pose().translate(w / 2f, h / 2f - 26, 0);
            g.pose().scale(3.5f, 3.5f, 1f);
            g.drawString(mc.font, title, -mc.font.width(title) / 2, 0, col, true);
            g.pose().popPose();
            g.drawCenteredString(mc.font, sub, w / 2, h / 2 + 10, ((int) (a * 255) << 24) | 0xE8D8B0);
        }
        String key = com.kingofcurses.client.HeianCinematic.subtitle();
        if (key != null) {
            Component line = Component.translatable(key);
            g.drawCenteredString(mc.font, line, w / 2, h - bar / 2 - 4, 0xFFF2C14E);
        }
        float black = com.kingofcurses.client.HeianCinematic.black();
        if (black > 0) g.fill(0, 0, w, h, ((int) (black * 255) << 24));
        if (scare && t < com.kingofcurses.client.HeianCinematic.T_SCARE + 3) g.fill(0, 0, w, h, 0xC0FF1020);
        if (!scare) {
            Component hint = Component.translatable("cinematic.kingofcurses.skip_hint", KeyBindings.SKIP.getTranslatedKeyMessage());
            g.drawString(mc.font, hint, w - mc.font.width(hint) - 6, 6, 0x80FFFFFF, false);
        }
    };

    /** Lowest Y used by boss bars this frame (set by ClientForgeEvents). */
    public static int bossBottom = 0;

    /** v1.0.14: Vigor bar at the top of the screen. Full = finisher ready. */
    public static final IGuiOverlay VIGOR = (gui, g, partialTick, w, h) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || ClientCinematic.active() || com.kingofcurses.client.HeianCinematic.active() || com.kingofcurses.client.GojoIntroCinematic.active()) return;
        CursedData d = ClientData.DATA;
        if (!d.hasPowers()) return;
        Font font = mc.font;
        int bw = 140, bh = 7, x = w / 2 - bw / 2, y = 4;
        if (bossBottom > 0) y = bossBottom + 2;   // sit under the boss bars
        bossBottom = 0;
        float v = d.vigor() / CursedData.VIGOR_MAX;
        boolean full = d.finisherReady();
        float age = mc.player.tickCount + partialTick;
        float pulse = full ? 0.5f + 0.5f * Mth.sin(age * 0.35f) : 0f;
        g.fill(x - 2, y - 2, x + bw + 2, y + bh + 2, 0xC0000000);
        g.fill(x - 1, y - 1, x + bw + 1, y + bh + 1, full ? (0xFF000000 | ((int) (120 + 135 * pulse) << 16)) : 0xFF3A0A10);
        g.fill(x, y, x + bw, y + bh, 0xFF120406);
        int fillW = (int) (bw * v);
        g.fillGradient(x, y, x + fillW, y + bh, full ? 0xFFFF3040 : 0xFFB0101E, full ? 0xFF900010 : 0xFF50040C);
        for (int i = 1; i < 5; i++) g.fill(x + bw * i / 5, y, x + bw * i / 5 + 1, y + bh, 0x80000000); // one notch per heart
        Component label = full
                ? Component.translatable(d.controlMode() == CursedData.CONTROL_MOBILE ? "hud.kingofcurses.vigor_ready_mobile" : "hud.kingofcurses.vigor_ready", KeyBindings.FINISHER.getTranslatedKeyMessage())
                : Component.translatable("hud.kingofcurses.vigor");
        g.drawCenteredString(font, label, w / 2, y + bh + 3, full ? (0xFF000000 | ((int) (200 + 55 * pulse) << 16) | 0x3040) : 0xFFB89A9E);
    };

    public static final IGuiOverlay HUD = (gui, g, partialTick, w, h) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || ClientCinematic.active() || com.kingofcurses.client.HeianCinematic.active() || com.kingofcurses.client.GojoIntroCinematic.active()) return;
        CursedData d = ClientData.DATA;
        if (!d.hasPowers() && d.ending() == CursedData.ENDING_NONE) return;
        Font font = mc.font;
        int x = 8, y = 8, bw = 104;
        float pct = d.maxEnergy() <= 0 ? 0 : d.energy() / d.maxEnergy();
        g.fill(x - 1, y - 1, x + bw + 1, y + 9, 0xE0000000);
        g.fillGradient(x, y, x + (int) (bw * pct), y + 8, 0xFFFF2A40, 0xFF6E0414);
        for (int i = 1; i < 10; i++) g.fill(x + i * bw / 10, y, x + i * bw / 10 + 1, y + 8, 0x40000000);
        g.drawString(font, (int) d.energy() + " / " + (int) d.maxEnergy(), x + 3, y, 0xFFF0E6D2, true);
        g.drawString(font, Component.translatable("hud.kingofcurses.fingers", d.fingers()), x, y + 12, 0xFFE2DAC4, true);
        boolean rejected = d.ending() == CursedData.ENDING_REJECT;
        java.util.List<Ability> unlocked = Ability.forData(d);
        if (!unlocked.isEmpty()) {
            Ability a = Ability.byIndex(d.selected());
            if (!unlocked.contains(a)) a = unlocked.get(0);
            int iy = y + 24;
            g.fill(x - 1, iy - 1, x + 17, iy + 17, 0xFF1A0508);
            g.blit(icon(a), x, iy, 0, 0, 16, 16, 16, 16);
            int cd = d.cooldown(a);
            if (cd > 0) {
                float cpct = Mth.clamp(cd / (float) Math.max(1, a.cooldown), 0, 1);
                g.fill(x, iy + (int) (16 * (1 - cpct)), x + 16, iy + 16, 0xA0000000);
                g.drawString(font, String.valueOf((cd + 19) / 20), x + 19, iy + 9, 0xFFAAAAAA, true);
            }
            g.drawString(font, a.displayName(), x + 20, iy, 0xFFFF4A5A, true);
            int dx = x;
            for (Ability other : unlocked) {
                if (other == Ability.DOMAIN_EXPANSION) continue;
                g.fill(dx, iy + 20, dx + 3, iy + 23, other == a ? 0xFFFF2A40 : (d.cooldown(other) > 0 ? 0xFF3A2024 : 0xFF8A6A6E));
                dx += 5;
            }
        }
        if (ClientData.insideDomain(mc.player.position())) {
            Component t = Component.translatable("hud.kingofcurses.domain");
            g.drawString(font, t, w / 2 - font.width(t) / 2, 24, 0xFFFF2A40, true);
        }
    };

    /** v1.0.4: on-screen controls and technique list (toggle with H). */
    public static final IGuiOverlay CONTROLS = (gui, g, partialTick, w, h) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || ClientCinematic.active() || !KeyBindings.showControls) return;
        if (mc.screen instanceof com.kingofcurses.client.screen.BattleHudScreen) return;
        CursedData d = ClientData.DATA;
        if (d.controlMode() == CursedData.CONTROL_NONE && !d.hasPowers()) return;
        Font font = mc.font;
        boolean rejected = d.ending() == CursedData.ENDING_REJECT;
        java.util.List<Ability> unlocked = Ability.forData(d);
        Ability sel = Ability.byIndex(d.selected());
        if (!unlocked.isEmpty() && !unlocked.contains(sel)) sel = unlocked.get(0);
        java.util.List<Component> lines = new java.util.ArrayList<>();
        java.util.List<Integer> cols = new java.util.ArrayList<>();
        java.util.function.BiConsumer<Component, Integer> add = (c, col) -> { lines.add(c); cols.add(col); };
        add.accept(Component.translatable("hud.kingofcurses.controls"), 0xFFFF4A5A);
        if (d.controlMode() == CursedData.CONTROL_MOBILE) {
            Component selNameM = unlocked.isEmpty() ? Component.literal("-") : sel.displayName();
            if (d.lostArms() != 0) add.accept(Component.translatable("hud.kingofcurses.ctrl_mobile_regrow", (int) com.kingofcurses.ability.ArmLogic.REGROW_COST), 0xFF7CFF9A);
            else add.accept(Component.translatable("hud.kingofcurses.ctrl_mobile", selNameM), 0xFFF0E6D2);
            add.accept(Component.translatable("hud.kingofcurses.ctrl_mobile_pad"), 0xFFE2DAC4);
            add.accept(Component.translatable("hud.kingofcurses.ctrl_mobile_hud"), 0xFFE2DAC4);
            if (d.finisherReady()) add.accept(Component.translatable("hud.kingofcurses.ctrl_mobile_finisher"), 0xFFFF2A40);
        } else {
            Component selName = unlocked.isEmpty() ? Component.literal("-") : sel.displayName();
            if (d.lostArms() != 0) add.accept(key(KeyBindings.USE_ABILITY).append(Component.translatable("hud.kingofcurses.ctrl_regrow", (int) com.kingofcurses.ability.ArmLogic.REGROW_COST)), 0xFF7CFF9A);
            else add.accept(key(KeyBindings.USE_ABILITY).append(Component.translatable("hud.kingofcurses.ctrl_cast", selName)), 0xFFF0E6D2);
            add.accept(key(KeyBindings.NEXT_ABILITY).append(Component.translatable("hud.kingofcurses.ctrl_next")), 0xFFE2DAC4);
            add.accept(key(KeyBindings.ABILITY_WHEEL).append(Component.translatable("hud.kingofcurses.ctrl_wheel")), 0xFFE2DAC4);
            boolean domain = unlocked.contains(Ability.DOMAIN_EXPANSION) || unlocked.contains(Ability.INFINITE_VOID);
            add.accept(key(KeyBindings.DOMAIN).append(Component.translatable("hud.kingofcurses.ctrl_domain")), domain ? 0xFFFF2A40 : 0xFF7A6E70);
            add.accept(key(KeyBindings.CODEX).append(Component.translatable("hud.kingofcurses.ctrl_codex")), 0xFFE2DAC4);
            add.accept(key(KeyBindings.FINISHER).append(Component.translatable("hud.kingofcurses.ctrl_finisher")), d.finisherReady() ? 0xFFFF2A40 : 0xFF7A6E70);
            if (d.fingers() > 0 && d.ending() == CursedData.ENDING_NONE)
                add.accept(key(KeyBindings.RIP_FINGER).append(Component.translatable("hud.kingofcurses.ctrl_rip")), 0xFFB3122E);
        }
        add.accept(Component.translatable("hud.kingofcurses.techniques"), 0xFFFF4A5A);
        for (Ability a : Ability.values()) {
            if (!a.visibleFor(d)) continue;
            if (a == Ability.DOMAIN_EXPANSION && rejected) continue;
            boolean has = unlocked.contains(a);
            Component name;
            int col;
            if (!has) { name = Component.literal("  ").append(a.displayName()).append(" · ").append(Component.translatable("hud.kingofcurses.locked", a.requiredFingers())); col = 0xFF6E6466; }
            else {
                int cd = d.cooldown(a);
                name = Component.literal(a == sel ? "> " : "  ").append(a.displayName()).append(cd > 0 ? " (" + ((cd + 19) / 20) + "s)" : "");
                col = a == sel ? 0xFFFF2A40 : (cd > 0 ? 0xFF9A8A8C : 0xFFF0E6D2);
            }
            add.accept(name, col);
        }
        add.accept(key(KeyBindings.TOGGLE_CONTROLS).append(Component.translatable("hud.kingofcurses.ctrl_hide")), 0xFF7A6E70);
        float sc = 0.75f;
        int maxW = 0;
        for (Component c : lines) maxW = Math.max(maxW, font.width(c));
        int pw = (int) (maxW * sc) + 8, lh = 10, ph = (int) (lines.size() * lh * sc) + 6;
        int px = w - pw - 4, py = Math.max(4, h / 2 - ph / 2 - 10);
        g.fill(px, py, px + pw, py + ph, 0x90100406);
        g.fill(px, py, px + 1, py + ph, 0xFFB3122E);
        g.pose().pushPose();
        g.pose().translate(px + 4, py + 3, 0);
        g.pose().scale(sc, sc, 1f);
        for (int i = 0; i < lines.size(); i++) g.drawString(font, lines.get(i), 0, i * lh, cols.get(i), true);
        g.pose().popPose();
    };

    private static net.minecraft.network.chat.MutableComponent key(net.minecraft.client.KeyMapping k) {
        return Component.literal("[").append(k.getTranslatedKeyMessage()).append("] ");
    }

    public static final IGuiOverlay FX = (gui, g, partialTick, w, h) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        float red = ClientFx.redAlpha();
        if (red > 0) g.fill(0, 0, w, h, ((int) (red * 150) << 24) | 0xB00010);
        float white = ClientFx.whiteAlpha();
        if (white > 0) g.fill(0, 0, w, h, ((int) (white * 180) << 24) | 0xFFF4F0);
        float aura = ClientFx.auraAlpha();
        if (aura > 0) vignette(g, w, h, (int) (aura * 200), 0x8A0010);
        if (ClientData.insideDomain(mc.player.position())) vignette(g, w, h, 140, 0x2A0004);
        if (ClientFx.takeoverActive()) {
            float t = (mc.player.tickCount + partialTick) * 0.2f;
            int a = 120 + (int) (60 * Mth.sin(t));
            vignette(g, w, h, a, 0x500000);
            g.fill(0, 0, w, h, 0x30200000);
            Component txt = Component.translatable("hud.kingofcurses.takeover");
            int tw = mc.font.width(txt);
            g.pose().pushPose();
            g.pose().translate(w / 2f, h / 2f - 40, 0);
            g.pose().scale(3f, 3f, 1f);
            g.drawString(mc.font, txt, -tw / 2, 0, 0xFFFF1A2A, true);
            g.pose().popPose();
        }
        if (ClientCinematic.active() && ClientCinematic.slowMotion()) g.fill(0, 0, w, h, 0x28100008);
        int line = ClientFx.subtitleLine();
        if (line >= 0) {                                // v1.0.9 possession: letterbox + big lines
            int bar = h / 9;
            g.fill(0, 0, w, bar, 0xE0000000); g.fill(0, h - bar, w, h, 0xE0000000);
            float a = ClientFx.subtitleAlpha();
            Component txt = Component.translatable("takeover.kingofcurses.line_" + line);
            int col = ((int) (255 * Mth.clamp(a, 0.05f, 1f)) << 24) | (line == 2 || line == 3 ? 0xF0E6D2 : 0xFF2A40);
            float sc = line == 1 ? 1.6f : 1.3f;
            java.util.List<net.minecraft.util.FormattedCharSequence> rows = mc.font.split(txt, (int) ((w - 30) / sc));
            g.pose().pushPose();
            g.pose().translate(w / 2f, h - bar - 14 - rows.size() * 10 * sc, 0);
            g.pose().scale(sc, sc, 1f);
            for (int i = 0; i < rows.size(); i++) g.drawString(mc.font, rows.get(i), -mc.font.width(rows.get(i)) / 2, i * 10, col, true);
            g.pose().popPose();
        }
        int bf = ClientFx.blackFlash();
        if (bf > 0) {                                   // v1.0.7 BLACK FLASH
            float a = Mth.clamp(bf / 30f, 0f, 1f);
            if (bf > 24) g.fill(0, 0, w, h, ((int) (160 * (bf - 24) / 6f) << 24));
            vignette(g, w, h, (int) (200 * a), 0x000000);
            Component txt = Component.translatable("hud.kingofcurses.black_flash");
            int col = ((int) (255 * a) << 24) | ((bf / 2) % 2 == 0 ? 0x101010 : 0xE0102A);
            g.pose().pushPose();
            g.pose().translate(w / 2f, h / 2f - 50, 0);
            float sc = 3.5f + (1f - a) * 0.8f;
            g.pose().scale(sc, sc, 1f);
            g.drawString(mc.font, txt, -mc.font.width(txt) / 2, 0, col, true);
            g.pose().popPose();
        }
    };

    /** v1.0.8 loading screen shown while the world finishes generating, before the intro (max 10 s). */
    public static final IGuiOverlay LOADING = (gui, g, partialTick, w, h) -> {
        float p = ClientFx.loading();
        if (p < 0 || ClientCinematic.active()) return;
        Minecraft mc = Minecraft.getInstance();
        g.fill(0, 0, w, h, 0xFF050203);
        vignette(g, w, h, 160, 0x3A0008);
        Component title = Component.translatable("message.kingofcurses.loading_title");
        g.pose().pushPose();
        g.pose().translate(w / 2f, h / 2f - 40, 0);
        g.pose().scale(3f, 3f, 1f);
        g.drawString(mc.font, title, -mc.font.width(title) / 2, 0, 0xFFE0102A, true);
        g.pose().popPose();
        Component sub = Component.translatable("message.kingofcurses.loading");
        g.drawString(mc.font, sub, w / 2 - mc.font.width(sub) / 2, h / 2 + 4, 0xFFE2DAC4, true);
        int bw = Math.min(220, w - 40), bx = w / 2 - bw / 2, by = h / 2 + 22;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 7, 0xFF2A0A0E);
        g.fillGradient(bx, by, bx + (int) (bw * p), by + 6, 0xFFFF2A40, 0xFF6E0414);
        // twenty finger marks along the bar
        for (int i = 0; i < 20; i++) {
            int x = bx + i * bw / 20 + bw / 40;
            g.fill(x, by + 10, x + 1, by + 13, i < p * 20 ? 0xFFE0102A : 0xFF3A2024);
        }
    };

    public static final IGuiOverlay CINEMATIC = (gui, g, partialTick, w, h) -> {
        if (!ClientCinematic.active()) return;
        Minecraft mc = Minecraft.getInstance();
        int t = ClientCinematic.tick();
        float in = Mth.clamp(t / 20f, 0, 1);
        int bar = (int) (h * 0.12f * in);
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);
        String key = ClientCinematic.subtitle();
        if (key != null) {
            Component line = Component.translatable(key);
            int lw = mc.font.width(line);
            g.drawString(mc.font, line, w / 2 - lw / 2, h - bar / 2 - 4, 0xFFF0E6D2, true);
        }
        if (t >= com.kingofcurses.ability.CinematicDirector.T_GONE) {
            Component title = Component.translatable("cinematic.kingofcurses.title");
            float alpha = Mth.clamp((t - com.kingofcurses.ability.CinematicDirector.T_GONE) / 10f, 0, 1);
            int col = ((int) (alpha * 255) << 24) | 0xE0102A;
            g.pose().pushPose();
            g.pose().translate(w / 2f, h / 2f - 20, 0);
            g.pose().scale(4f, 4f, 1f);
            g.drawString(mc.font, title, -mc.font.width(title) / 2, 0, col, true);
            g.pose().popPose();
        }
        Component hint = Component.translatable("cinematic.kingofcurses.skip_hint", KeyBindings.SKIP.getTranslatedKeyMessage());
        g.drawString(mc.font, hint, w - mc.font.width(hint) - 6, 6, 0x80FFFFFF, false);
    };

    private static void vignette(GuiGraphics g, int w, int h, int alpha, int rgb) {
        int c = (Mth.clamp(alpha, 0, 255) << 24) | rgb;
        int clear = rgb;
        int edge = Math.max(24, h / 5);
        g.fillGradient(0, 0, w, edge, c, clear);
        g.fillGradient(0, h - edge, w, h, clear, c);
        for (int i = 0; i < edge; i += 2) {
            int a = (int) (Mth.clamp(alpha, 0, 255) * (1 - i / (float) edge));
            int cc = (a << 24) | rgb;
            g.fill(i, 0, i + 2, h, cc);
            g.fill(w - i - 2, 0, w - i, h, cc);
        }
    }
}
