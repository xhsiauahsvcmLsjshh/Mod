package com.kingofcurses.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/** All keys are rebindable in Options > Controls > Key Binds > King of Curses. */
public final class KeyBindings {
    public static final String CATEGORY = "key.categories.kingofcurses";
    public static final KeyMapping USE_ABILITY = key("use_ability", GLFW.GLFW_KEY_R);
    public static final KeyMapping NEXT_ABILITY = key("next_ability", GLFW.GLFW_KEY_G);
    public static final KeyMapping ABILITY_WHEEL = key("ability_wheel", GLFW.GLFW_KEY_V);
    public static final KeyMapping DOMAIN = key("domain_expansion", GLFW.GLFW_KEY_B);
    public static final KeyMapping CODEX = key("cursed_codex", GLFW.GLFW_KEY_K);
    public static final KeyMapping TOGGLE_CONTROLS = key("toggle_controls", GLFW.GLFW_KEY_H);
    /** Client-side: whether the on-screen controls panel is visible (toggled with H). */
    public static boolean showControls = true;
    public static final KeyMapping RIP_FINGER = key("rip_finger", GLFW.GLFW_KEY_J);
    /** Client tick until which a second press of RIP_FINGER confirms. */
    public static long ripConfirmUntil = 0;
    /** v1.0.12: Technique Pad (big touch buttons). Mobile: double tap sneak. */
    public static final KeyMapping TOUCH_PAD = key("touch_pad", GLFW.GLFW_KEY_P);
    public static long lastSneakTap = -100;
    /** v1.0.13: Battle HUD with touch buttons. */
    public static final KeyMapping BATTLE_HUD = key("battle_hud", GLFW.GLFW_KEY_O);
    /** v1.0.14: finisher / empowered strike when the Vigor bar is full. */
    public static final KeyMapping FINISHER = key("finisher", GLFW.GLFW_KEY_Z);
    public static final KeyMapping SKIP = new KeyMapping("key.kingofcurses.skip_cinematic", KeyConflictContext.UNIVERSAL, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_X, CATEGORY);

    private KeyBindings() {}

    private static KeyMapping key(String name, int code) {
        return new KeyMapping("key.kingofcurses." + name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, code, CATEGORY);
    }
}
