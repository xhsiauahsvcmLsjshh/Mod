package com.kingofcurses.client;

import com.kingofcurses.ability.CinematicDirector;
import com.kingofcurses.network.CinematicPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Client half of the intro: a detached camera following a shot list synced with the server timeline.
 * Shots track the REAL actor positions (so hills/slopes never desync the framing) and every camera
 * position is collision-checked against terrain, sliding toward the subject instead of clipping into hills.
 */
public final class ClientCinematic {
    private static boolean active;
    private static int tick, serverTick, sinceSync;
    private static Vec3 center = Vec3.ZERO, dig = Vec3.ZERO, s0 = Vec3.ZERO, g0 = Vec3.ZERO, axis = new Vec3(1, 0, 0), perp = new Vec3(0, 0, 1), fwd = new Vec3(0, 0, 1);
    private static int sukunaId = -1, gojoId = -1;
    private static Vec3 lastSukuna = Vec3.ZERO, lastGojo = Vec3.ZERO, returnFrom = Vec3.ZERO;
    private static Entity camera;

    private ClientCinematic() {}

    public static boolean active() { return active; }
    public static int tick() { return tick; }

    public static void start(CinematicPacket p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        center = p.origin; dig = p.dig; s0 = p.sukuna; g0 = p.gojo; sukunaId = p.sukunaId; gojoId = p.gojoId;
        lastSukuna = s0; lastGojo = g0;
        Vec3 a = g0.subtract(s0);
        axis = new Vec3(a.x, 0, a.z).lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : new Vec3(a.x, 0, a.z).normalize();
        Vec3 pp = new Vec3(-axis.z, 0, axis.x);
        perp = pp.dot(mc.player.position().subtract(center)) >= 0 ? pp : pp.scale(-1);
        fwd = Vec3.directionFromRotation(0, p.yaw);
        camera = EntityType.MARKER.create(mc.level);
        if (camera == null) return;
        active = true;
        ClientFx.stopLoading();
        tick = 0; serverTick = 0; sinceSync = 0;
        Shot s = shot(0);
        camera.setPos(s.pos); camera.xo = s.pos.x; camera.yo = s.pos.y; camera.zo = s.pos.z;
        camera.setYRot(s.yaw); camera.setXRot(s.pitch); camera.yRotO = s.yaw; camera.xRotO = s.pitch;
        mc.setCameraEntity(camera);
    }

    /** v1.0.7: follow the server timeline. When the server lags (world generation), the camera waits for the actors. */
    public static void sync(int t) {
        serverTick = t;
        sinceSync = 0;
        if (active && t - tick > 2) tick = t;    // we fell behind: catch up
    }

    public static void stop() {
        active = false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.setCameraEntity(mc.player);
        camera = null;
    }

    public static void clientTick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || camera == null) { active = false; camera = null; return; }
        sinceSync++;
        if (tick < serverTick + 1) tick++;      // never more than one tick ahead of the server
        if (sinceSync > 200) { stop(); return; }
        Entity sk = mc.level.getEntity(sukunaId), gj = mc.level.getEntity(gojoId);
        if (sk != null) lastSukuna = sk.position();
        if (gj != null) lastGojo = gj.position();
        Shot s;
        try { s = shot(tick); } catch (RuntimeException e) { stop(); return; }
        camera.xo = camera.getX(); camera.yo = camera.getY(); camera.zo = camera.getZ();
        camera.yRotO = camera.getYRot(); camera.xRotO = camera.getXRot();
        if (camera.position().distanceToSqr(s.pos) > 9) { camera.xo = s.pos.x; camera.yo = s.pos.y; camera.zo = s.pos.z; camera.yRotO = s.yaw; camera.xRotO = s.pitch; }
        camera.setPos(s.pos);
        camera.setYRot(s.yaw);
        camera.setXRot(s.pitch);
        if (mc.getCameraEntity() != camera) mc.setCameraEntity(camera);
        if (tick > CinematicDirector.LENGTH + 60) stop();
    }

    private record Shot(Vec3 pos, float yaw, float pitch) {}

    /** Keeps the camera out of terrain: if a block sits between subject and camera, move in front of it. */
    private static Vec3 safe(Vec3 pos, Vec3 target) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return pos;
        BlockHitResult hit = mc.level.clip(new ClipContext(target, pos, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
        if (hit.getType() == HitResult.Type.MISS) return pos;
        Vec3 d = target.subtract(hit.getLocation());
        double len = d.length();
        return len < 1.0E-3 ? hit.getLocation() : hit.getLocation().add(d.scale(Math.min(0.4, len * 0.5) / len));
    }

    private static Shot look(Vec3 pos, Vec3 target) {
        Vec3 p = safe(pos, target);
        Vec3 d = target.subtract(p);
        float yaw = (float) (Mth.atan2(d.z, d.x) * Mth.RAD_TO_DEG) - 90f;
        float pitch = (float) (-(Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * Mth.RAD_TO_DEG));
        return new Shot(p, yaw, pitch);
    }

    private static double k(int t, int a, int b) { double x = Mth.clamp((t - a) / (double) (b - a), 0, 1); return x * x * (3 - 2 * x); }
    private static Vec3 up(double y) { return new Vec3(0, y, 0); }

    private static Shot shot(int t) {
        Vec3 S = lastSukuna, G = lastGojo;
        Vec3 mid = S.add(G).scale(0.5);
        Vec3 ax = G.subtract(S); ax = new Vec3(ax.x, 0, ax.z); ax = ax.lengthSqr() < 1.0E-4 ? axis : ax.normalize();
        if (t < 60) {                                   // establishing orbit
            double a = Math.toRadians(Mth.lerp(k(t, 0, 60), -60, 15));
            Vec3 off = perp.scale(Math.cos(a) * 12).add(ax.scale(Math.sin(a) * 12)).add(up(5 - 1.8 * k(t, 0, 60)));
            return look(center.add(off), mid.add(up(1.4)));
        }
        if (t < 112) return look(S.subtract(ax.scale(1.9)).add(perp.scale(0.9)).add(up(2.1)), G.add(up(1.6)));                 // over Sukuna's shoulder
        if (t < 150) return look(mid.add(perp.scale(9.5 - k(t, 112, 150))).add(up(2.6)), mid.add(up(1.1)));                    // wide: Lapse Blue + dodge
        if (t < 200) return look(G.add(ax.scale(2.6)).add(perp.scale(0.9)).add(up(1.9)), S.add(up(1.5)));                     // behind Gojo: dash + barrage
        if (t < 225) return look(mid.add(perp.scale(8.5)).add(ax.scale(-1.5 * k(t, 200, 225))).add(up(2.2)), mid.subtract(ax.scale(1.5)).add(up(1.0))); // Red knock-back
        if (t < 262) return look(S.add(ax.scale(2.4 - 0.4 * k(t, 225, 262))).add(perp.scale(0.4)).add(up(1.7)), S.add(up(1.6))); // close-up: laugh
        if (t < 300) return look(S.add(ax.scale(3.0)).add(perp.scale(1.6)).add(up(0.5)), S.add(up(1.9)));                      // low hero angle: charge
        if (t < 345) {                                  // slow-motion wide slash
            Vec3 pos = mid.add(perp.scale(7.5)).add(ax.scale(-2.0 + 4.0 * k(t, 300, 345))).add(up(1.0));
            return look(pos, mid.add(up(1.1)));
        }
        if (t < 380) return look(G.add(perp.scale(3.0)).add(ax.scale(-1.2)).add(up(1.5 - 0.5 * k(t, 345, 380))), G.add(up(0.35)));   // Gojo's halves
        if (t < 420) return look(S.add(perp.scale(3.6)).add(up(2.2)), S.add(up(1.3)));                                         // tracking Sukuna
        if (t < 470) {
            Vec3 pos = dig.add(perp.scale(2.0)).add(fwd.scale(-1.6)).add(up(1.4 - 0.4 * k(t, 420, 470)));
            return look(pos, dig.add(up(0.3)));
        }
        if (t < CinematicDirector.T_GONE) {
            Vec3 pos = dig.add(perp.scale(3)).add(fwd.scale(-3)).add(up(1.5 + 7 * k(t, 470, CinematicDirector.T_GONE)));
            Shot sh = look(pos, dig.add(up(1)));
            returnFrom = sh.pos;
            return sh;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return look(returnFrom, dig);
        Vec3 eye = mc.player.getEyePosition();
        double kk = k(t, CinematicDirector.T_GONE, CinematicDirector.LENGTH);
        Vec3 pos = returnFrom.add(eye.subtract(returnFrom).scale(kk));
        Shot a = look(returnFrom, dig.add(up(1)));
        float yaw = Mth.rotLerp((float) kk, a.yaw, mc.player.getYRot());
        float pitch = (float) Mth.lerp(kk, a.pitch, mc.player.getXRot());
        return new Shot(pos, yaw, pitch);
    }

    /** Subtitle key for the current tick, or null. */
    public static String subtitle() {
        int[][] lines = {{5, 55}, {62, 108}, {112, 142}, {158, 190}, {192, 222}, {226, 260}, {264, 298}, {302, 342}, {346, 378}, {422, 468}, {472, 515}};
        for (int i = 0; i < lines.length; i++) if (tick >= lines[i][0] && tick <= lines[i][1]) return "cinematic.kingofcurses.line_" + i;
        return null;
    }

    public static boolean slowMotion() { return tick >= CinematicDirector.T_SLOWMO_START && tick <= CinematicDirector.T_SLOWMO_END; }

    public static void reset() { if (active) stop(); }
}
