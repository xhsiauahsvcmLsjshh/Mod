package com.kingofcurses.recipe;

import com.kingofcurses.item.ClueItem;
import com.kingofcurses.registry.ModRecipes;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

/** v1.0.20: two or more clues in the crafting grid become one clue with the pieces added up (max 10). */
public class ClueCombineRecipe extends CustomRecipe {
    public ClueCombineRecipe(ResourceLocation id, CraftingBookCategory category) { super(id, category); }

    @Override
    public boolean matches(CraftingContainer inv, Level level) {
        int clues = 0, total = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) continue;
            if (!(s.getItem() instanceof ClueItem)) return false;
            clues++;
            total += ClueItem.pieces(s);
        }
        return clues >= 2 && total <= ClueItem.TOTAL;
    }

    @Override
    public ItemStack assemble(CraftingContainer inv, RegistryAccess access) {
        int total = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() instanceof ClueItem) total += ClueItem.pieces(s);
        }
        return ClueItem.withPieces(total);
    }

    @Override public boolean canCraftInDimensions(int w, int h) { return w * h >= 2; }
    @Override public RecipeSerializer<?> getSerializer() { return ModRecipes.CLUE_COMBINE.get(); }
}
