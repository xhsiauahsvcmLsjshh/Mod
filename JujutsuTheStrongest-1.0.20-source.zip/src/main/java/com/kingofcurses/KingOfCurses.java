package com.kingofcurses;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.registry.*;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * King of Curses: Twenty Fingers. A Jujutsu Kaisen inspired total-conversion style mod
 * centred on Ryomen Sukuna. Entry point: registers every DeferredRegister on the mod bus.
 */
@Mod(KingOfCurses.MODID)
public final class KingOfCurses {
    public static final String MODID = "kingofcurses";
    public static final Logger LOGGER = LogUtils.getLogger();

    public KingOfCurses() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModParticles.PARTICLES.register(bus);
        ModEffects.EFFECTS.register(bus);
        ModMenus.MENUS.register(bus);
        ModCreativeTabs.TABS.register(bus);
        ModRecipes.SERIALIZERS.register(bus);

        bus.addListener(ModEntities::registerAttributes);
        bus.addListener(ModEntities::registerSpawnPlacements);
        bus.addListener(CursedCapability::register);
        bus.addListener(this::commonSetup);
        com.kingofcurses.ability.KocMode.init();

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, KocConfig.SPEC);
        ModNetwork.register();
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        LOGGER.info("The King of Curses stirs. 20 fingers have been scattered.");
    }
}
