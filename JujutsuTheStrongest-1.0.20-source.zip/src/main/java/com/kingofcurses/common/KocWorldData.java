package com.kingofcurses.common;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** v1.0.9 world-wide flags: Gojo (Yuta) rises only once per world, no matter who reaches twenty fingers. */
public class KocWorldData extends SavedData {
    private static final String NAME = "kingofcurses_world";
    private boolean bossSpawned, bossDefeated;
    private boolean heianBuilt; private int heianY;
    /** v1.0.16: every Cursed Sand block in the world (dimension id -> packed positions). */
    private final java.util.Map<String, java.util.Set<Long>> sand = new java.util.HashMap<>();

    public static KocWorldData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(KocWorldData::load, KocWorldData::new, NAME);
    }

    public static KocWorldData load(CompoundTag tag) {
        KocWorldData d = new KocWorldData();
        d.bossSpawned = tag.getBoolean("BossSpawned");
        d.bossDefeated = tag.getBoolean("BossDefeated");
        d.heianBuilt = tag.getBoolean("HeianBuilt"); d.heianY = tag.getInt("HeianY");
        CompoundTag s = tag.getCompound("CursedSand");
        for (String dim : s.getAllKeys()) {
            java.util.Set<Long> set = new java.util.HashSet<>();
            for (long l : s.getLongArray(dim)) set.add(l);
            d.sand.put(dim, set);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("BossSpawned", bossSpawned);
        tag.putBoolean("BossDefeated", bossDefeated);
        tag.putBoolean("HeianBuilt", heianBuilt); tag.putInt("HeianY", heianY);
        CompoundTag s = new CompoundTag();
        for (var e : sand.entrySet()) s.putLongArray(e.getKey(), e.getValue().stream().mapToLong(Long::longValue).toArray());
        tag.put("CursedSand", s);
        return tag;
    }

    public void addSand(String dim, net.minecraft.core.BlockPos pos) { if (sand.computeIfAbsent(dim, k -> new java.util.HashSet<>()).add(pos.asLong())) setDirty(); }
    public void removeSand(String dim, net.minecraft.core.BlockPos pos) { var s = sand.get(dim); if (s != null && s.remove(pos.asLong())) setDirty(); }
    public java.util.Set<Long> sand(String dim) { return sand.getOrDefault(dim, java.util.Collections.emptySet()); }
    public java.util.Map<String, java.util.Set<Long>> allSand() { return sand; }

    public boolean heianBuilt() { return heianBuilt; }
    public int heianY() { return heianY; }
    public void setHeian(int y) { heianBuilt = true; heianY = y; setDirty(); }

    public boolean bossSpawned() { return bossSpawned; }
    public boolean bossDefeated() { return bossDefeated; }
    public void setBossSpawned() { bossSpawned = true; setDirty(); }
    public void setBossDefeated() { bossDefeated = true; setDirty(); }
}
