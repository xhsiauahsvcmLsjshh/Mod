package com.kingofcurses.block;

import com.kingofcurses.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Freshly dug soil where Sukuna buried Finger #1. Breaks to release the finger (see its loot table). */
public class FingerBurialBlock extends Block {
    public FingerBurialBlock(Properties props) { super(props); }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) == 0) {
            level.addParticle(ModParticles.RESONANCE.get(), pos.getX() + 0.5 + random.nextGaussian() * 0.2, pos.getY() + 1.05, pos.getZ() + 0.5 + random.nextGaussian() * 0.2, 0, 0.015, 0);
        }
        if (random.nextInt(8) == 0) {
            level.addParticle(ModParticles.CURSED_ENERGY.get(), pos.getX() + random.nextDouble(), pos.getY() + 1.0, pos.getZ() + random.nextDouble(), 0, 0.04, 0);
        }
    }
}
