package com.kingofcurses.block;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Altar of malice: Sukuna's vessels gain Cursed Vigor (faster cursed energy regeneration) by praying here. */
public class MalevolentAltarBlock extends Block {
    public MalevolentAltarBlock(Properties props) { super(props); }

    @Override
    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (CursedCapability.fingers(player) > 0) {
            player.addEffect(new MobEffectInstance(ModEffects.CURSED_VIGOR.get(), 1200, 0));
            level.playSound(null, pos, ModSounds.HEARTBEAT.get(), SoundSource.BLOCKS, 1.0f, 0.8f);
        } else {
            player.displayClientMessage(Component.translatable("tooltip.kingofcurses.altar").withStyle(ChatFormatting.DARK_RED), true);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(2) == 0) level.addParticle(ModParticles.CURSED_ENERGY.get(), pos.getX() + random.nextDouble(), pos.getY() + 1.05, pos.getZ() + random.nextDouble(), 0, 0.03, 0);
    }
}
