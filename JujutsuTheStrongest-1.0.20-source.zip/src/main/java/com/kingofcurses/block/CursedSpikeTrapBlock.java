package com.kingofcurses.block;

import com.kingofcurses.entity.CursedSpiritEntity;
import com.kingofcurses.registry.ModEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Trap used in finger chambers: bone spikes that bleed whoever steps on them. Curses are immune. */
public class CursedSpikeTrapBlock extends Block {
    public CursedSpikeTrapBlock(Properties props) { super(props); }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (!level.isClientSide && entity instanceof LivingEntity le && !(entity instanceof CursedSpiritEntity) && !le.isSteppingCarefully()) {
            if (le.hurt(level.damageSources().cactus(), 3.0f)) le.addEffect(new MobEffectInstance(ModEffects.CURSED_BLEED.get(), 80, 0));
        }
        super.stepOn(level, pos, state, entity);
    }
}
