package com.kingofcurses.block;

import com.kingofcurses.item.RippedFingerItem;
import com.kingofcurses.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/** v1.0.10: what is left of a vessel. Holds 1..20 fingers of power; however it is removed, it gives back that finger. */
public class CursedSandBlock extends Block {
    public static final IntegerProperty POWER = IntegerProperty.create("power", 1, 20);

    public CursedSandBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(POWER, 1));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(POWER); }

    @Override
    @SuppressWarnings("deprecation")
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        super.onPlace(state, level, pos, old, moved);
        if (level instanceof ServerLevel sl && !old.is(this))
            com.kingofcurses.common.KocWorldData.get(sl.getServer()).addSand(sl.dimension().location().toString(), pos);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (level instanceof ServerLevel sl0 && !state.is(newState.getBlock()))
            com.kingofcurses.common.KocWorldData.get(sl0.getServer()).removeSand(sl0.dimension().location().toString(), pos);
        if (!level.isClientSide && !state.is(newState.getBlock())) {
            Block.popResource(level, pos, RippedFingerItem.withPower(state.getValue(POWER)));
            if (level instanceof ServerLevel sl)
                sl.sendParticles(ModParticles.CURSED_ENERGY.get(), pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5, 40, 0.3, 0.3, 0.3, 0.1);
        }
        super.onRemove(state, level, pos, newState, moved);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource r) {
        if (r.nextInt(3) == 0)
            level.addParticle(ModParticles.CURSED_ENERGY.get(), pos.getX() + r.nextDouble(), pos.getY() + 1.05, pos.getZ() + r.nextDouble(), 0, 0.03, 0);
    }

    /** The block the vessel fell on becomes Cursed Sand (bedrock, block entities and fluids are skipped). */
    public static boolean canReplace(Level level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return !s.isAir() && s.getFluidState().isEmpty() && !s.hasBlockEntity() && s.getDestroySpeed(level, pos) >= 0 && !s.is(Blocks.BEDROCK)
                && s.isCollisionShapeFullBlock(level, pos);
    }
}
