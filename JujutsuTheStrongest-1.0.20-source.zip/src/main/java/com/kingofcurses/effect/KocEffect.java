package com.kingofcurses.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

public class KocEffect extends MobEffect {
    public enum Kind { CURSED_BLEED, SEALED, SUKUNA_TAKEOVER, CURSED_VIGOR, WARDED }

    private final Kind kind;

    public KocEffect(MobEffectCategory category, int color, Kind kind) {
        super(category, color);
        this.kind = kind;
    }

    public Kind kind() { return kind; }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (kind == Kind.CURSED_BLEED && !entity.level().isClientSide) {
            entity.hurt(entity.damageSources().magic(), 1.0f + amplifier);
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return kind == Kind.CURSED_BLEED && duration % 20 == 0;
    }
}
