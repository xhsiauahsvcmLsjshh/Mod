package com.kingofcurses.capability;

import com.kingofcurses.ability.Ability;
import net.minecraft.nbt.CompoundTag;

/** Per-player Sukuna progress. Server authoritative, mirrored to the owning client. */
public class CursedData {
    public static final int ENDING_NONE = 0;
    public static final int ENDING_EMBRACE = 1;
    public static final int ENDING_REJECT = 2;

    private int fingerMask;
    private float energy;
    private int selected;
    private final int[] cooldowns = new int[Ability.values().length];
    private boolean introSeen;
    private int ending;
    private boolean bossDefeated;
    private boolean bossSpawned;
    private int bossCountdown;
    private int takeoverTicks;
    private int takeoverClock;
    private int huntClock;
    private int controlMode; // 0 = not chosen, 1 = PC (keybinds), 2 = mobile (technique items)
    private int lostArms; // v1.0.7: bit 1 = right arm, bit 2 = left arm
    // v1.0.18 Pick Your Side: 0 = Strongest of History (Sukuna), 1 = Strongest of Today (Gojo)
    public static final int SIDE_HISTORY = 0, SIDE_TODAY = 1;
    private int side;
    private boolean sideChosen;
    private boolean infinity = true;
    private float vigor; // v1.0.14: 0..100, full = finisher ready (100 = 5 hearts of damage dealt)
    // v1.0.15: where the host last died (Compass of Remains)
    private long deathPos;
    private String deathDim = "";
    private int deathFingers;
    private boolean deathPending;
    private boolean dirty = true;

    // ---- fingers ----
    public int fingerMask() { return fingerMask; }
    public void setFingerMask(int mask) { fingerMask = mask & 0xFFFFF; dirty = true; }
    public int fingers() { return Integer.bitCount(fingerMask); }
    public boolean hasEaten(int index) { return index >= 0 && index < 20 && (fingerMask & (1 << index)) != 0; }
    public void eat(int index) { fingerMask |= (1 << index); dirty = true; }

    /** Finger count used for power scaling: rejecting Sukuna caps power at 10 fingers. */
    public int effectiveFingers() {
        if (side == SIDE_TODAY) return 12;   // Gojo's raw power, without any finger
        int f = fingers();
        return ending == ENDING_REJECT ? Math.min(f, 10) : f;
    }
    public float powerMultiplier() {
        return 1.0f + effectiveFingers() * 0.08f + (ending == ENDING_EMBRACE ? 0.5f : 0f);
    }

    // ---- cursed energy ----
    public float maxEnergy() { return side == SIDE_TODAY ? 600f : 100f + effectiveFingers() * 20f + (ending == ENDING_EMBRACE ? 200f : 0f); }
    public float energy() { return energy; }
    public void setEnergy(float v) { float n = Math.max(0, Math.min(maxEnergy(), v)); if (n != energy) { energy = n; dirty = true; } }
    public void addEnergy(float v) { setEnergy(energy + v); }

    // ---- abilities ----
    public int selected() { return selected; }
    public void setSelected(int s) { selected = s; dirty = true; }
    public int cooldown(Ability a) { return cooldowns[a.ordinal()]; }
    public void setCooldown(Ability a, int ticks) { cooldowns[a.ordinal()] = ticks; dirty = true; }
    public void tickCooldowns() {
        for (int i = 0; i < cooldowns.length; i++) if (cooldowns[i] > 0) { cooldowns[i]--; if (cooldowns[i] % 20 == 0) dirty = true; }
    }

    // ---- story ----
    public boolean introSeen() { return introSeen; }
    public void setIntroSeen(boolean v) { introSeen = v; dirty = true; }
    public int ending() { return ending; }
    public void setEnding(int e) { ending = e; dirty = true; }
    public boolean bossDefeated() { return bossDefeated; }
    public void setBossDefeated(boolean v) { bossDefeated = v; dirty = true; }
    public boolean bossSpawned() { return bossSpawned; }
    public void setBossSpawned(boolean v) { bossSpawned = v; }
    public int bossCountdown() { return bossCountdown; }
    public void setBossCountdown(int v) { bossCountdown = v; }
    public int takeoverTicks() { return takeoverTicks; }
    public void setTakeoverTicks(int v) { takeoverTicks = v; dirty = true; }
    public int takeoverClock() { return takeoverClock; }
    public void setTakeoverClock(int v) { takeoverClock = v; }
    public int huntClock() { return huntClock; }
    public void setHuntClock(int v) { huntClock = v; }

    public static final int CONTROL_NONE = 0, CONTROL_PC = 1, CONTROL_MOBILE = 2;
    public int controlMode() { return controlMode; }
    public void setControlMode(int m) { controlMode = m; dirty = true; }

    public static final int ARM_RIGHT = 1, ARM_LEFT = 2;
    public int lostArms() { return lostArms; }
    public void setLostArms(int m) { lostArms = m & 3; dirty = true; }

    public int side() { return side; }
    public boolean isGojo() { return side == SIDE_TODAY; }
    public void setSide(int s) { side = s == SIDE_TODAY ? SIDE_TODAY : SIDE_HISTORY; sideChosen = true; dirty = true; }
    public boolean sideChosen() { return sideChosen; }
    public boolean infinity() { return infinity; }
    public void setInfinity(boolean v) { infinity = v; dirty = true; }
    /** Has cursed powers at all (Sukuna inside, embraced, or Gojo). */
    public boolean hasPowers() { return side == SIDE_TODAY || fingers() > 0 || ending == ENDING_EMBRACE; }

    public static final float VIGOR_MAX = 100f;
    public float vigor() { return vigor; }
    public void setVigor(float v) { float n = Math.max(0f, Math.min(VIGOR_MAX, v)); if (n != vigor) { vigor = n; dirty = true; } }
    public void addVigor(float v) { setVigor(vigor + v); }
    public boolean finisherReady() { return vigor >= VIGOR_MAX; }

    public void setDeathMark(net.minecraft.core.BlockPos pos, String dim, int fingers) {
        deathPos = pos.asLong(); deathDim = dim; deathFingers = fingers; deathPending = true;
    }
    public boolean deathPending() { return deathPending; }
    public void clearDeathPending() { deathPending = false; }
    public net.minecraft.core.BlockPos deathPos() { return net.minecraft.core.BlockPos.of(deathPos); }
    public String deathDim() { return deathDim; }
    public int deathFingers() { return deathFingers; }

    public boolean isDirty() { return dirty; }
    public void markDirty() { dirty = true; }
    public void clean() { dirty = false; }

    public CompoundTag save() {
        CompoundTag t = syncTag();
        t.putBoolean("BossSpawned", bossSpawned);
        t.putInt("BossCountdown", bossCountdown);
        t.putInt("TakeoverClock", takeoverClock);
        t.putInt("HuntClock", huntClock);
        t.putLong("DeathPos", deathPos);
        t.putString("DeathDim", deathDim);
        t.putInt("DeathFingers", deathFingers);
        t.putBoolean("DeathPending", deathPending);
        return t;
    }

    public void load(CompoundTag t) {
        loadSync(t);
        bossSpawned = t.getBoolean("BossSpawned");
        bossCountdown = t.getInt("BossCountdown");
        takeoverClock = t.getInt("TakeoverClock");
        huntClock = t.getInt("HuntClock");
        deathPos = t.getLong("DeathPos");
        deathDim = t.getString("DeathDim");
        deathFingers = t.getInt("DeathFingers");
        deathPending = t.getBoolean("DeathPending");
    }

    /** The subset the client needs. */
    public CompoundTag syncTag() {
        CompoundTag t = new CompoundTag();
        t.putInt("Fingers", fingerMask);
        t.putFloat("Energy", energy);
        t.putInt("Selected", selected);
        t.putIntArray("Cooldowns", cooldowns.clone());
        t.putBoolean("IntroSeen", introSeen);
        t.putInt("Ending", ending);
        t.putBoolean("BossDefeated", bossDefeated);
        t.putInt("Takeover", takeoverTicks);
        t.putInt("ControlMode", controlMode);
        t.putInt("LostArms", lostArms);
        t.putFloat("Vigor", vigor);
        t.putInt("Side", side);
        t.putBoolean("SideChosen", sideChosen);
        t.putBoolean("Infinity", infinity);
        return t;
    }

    public void loadSync(CompoundTag t) {
        fingerMask = t.getInt("Fingers");
        energy = t.getFloat("Energy");
        selected = t.getInt("Selected");
        int[] cd = t.getIntArray("Cooldowns");
        for (int i = 0; i < cooldowns.length; i++) cooldowns[i] = i < cd.length ? cd[i] : 0;
        introSeen = t.getBoolean("IntroSeen");
        ending = t.getInt("Ending");
        bossDefeated = t.getBoolean("BossDefeated");
        takeoverTicks = t.getInt("Takeover");
        controlMode = t.getInt("ControlMode");
        lostArms = t.getInt("LostArms");
        vigor = t.getFloat("Vigor");
        side = t.getInt("Side");
        sideChosen = t.getBoolean("SideChosen");
        infinity = !t.contains("Infinity") || t.getBoolean("Infinity");
        dirty = true;
    }

    public void copyFrom(CursedData o) { load(o.save()); }
}
