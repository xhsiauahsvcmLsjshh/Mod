package com.kingofcurses.capability;

import com.kingofcurses.KingOfCurses;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public final class CursedCapability {
    public static final Capability<CursedData> CURSED = CapabilityManager.get(new CapabilityToken<>() {});
    public static final ResourceLocation ID = new ResourceLocation(KingOfCurses.MODID, "cursed_data");

    private CursedCapability() {}

    public static void register(RegisterCapabilitiesEvent event) {
        event.register(CursedData.class);
    }

    public static Optional<CursedData> get(Player player) {
        return player.getCapability(CURSED).resolve();
    }

    public static int fingers(Player player) {
        return get(player).map(CursedData::fingers).orElse(0);
    }

    public static final class Provider implements ICapabilitySerializable<CompoundTag> {
        private final CursedData data = new CursedData();
        private final LazyOptional<CursedData> optional = LazyOptional.of(() -> data);

        @Override
        public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
            return CURSED.orEmpty(cap, optional);
        }

        @Override
        public CompoundTag serializeNBT() { return data.save(); }

        @Override
        public void deserializeNBT(CompoundTag nbt) { data.load(nbt); }

        public void invalidate() { optional.invalidate(); }
    }
}
