package com.kingofcurses.item;

import com.kingofcurses.block.CursedSandBlock;
import com.kingofcurses.common.KocWorldData;
import com.kingofcurses.registry.ModBlocks;
import com.kingofcurses.registry.ModItems;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * v1.0.16 Compass of Remains: always points at the NEAREST Cursed Sand in the world (where dead hosts left their
 * fingers and their things). Crafted with two sticks, also given on respawn after a host dies.
 * Precise readout (X Y Z, ahead/behind, left/right, up/down) is drawn by the HUD.
 */
public class RemainsCompassItem extends Item {
    public RemainsCompassItem(Properties props) { super(props); }

    public static ItemStack create(BlockPos pos, String dim, int fingers) {
        ItemStack s = new ItemStack(ModItems.REMAINS_COMPASS.get());
        CompoundTag t = s.getOrCreateTag();
        t.put("Target", NbtUtils.writeBlockPos(pos));
        t.putString("Dim", dim);
        t.putBoolean("Precise", true);
        t.putInt("Fingers", fingers);
        return s;
    }

    /** Re-targets the nearest Cursed Sand: same dimension first, otherwise any other dimension. */
    public static void retarget(ServerLevel sl, Player player, ItemStack stack) {
        KocWorldData wd = KocWorldData.get(sl.getServer());
        String here = sl.dimension().location().toString();
        CompoundTag tag = stack.getOrCreateTag();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        Set<Long> set = wd.sand(here);
        Iterator<Long> it = set.iterator();
        boolean changed = false;
        while (it.hasNext()) {
            BlockPos p = BlockPos.of(it.next());
            if (sl.isLoaded(p) && !sl.getBlockState(p).is(ModBlocks.CURSED_SAND.get())) { it.remove(); changed = true; continue; }   // gone
            double d = p.distToCenterSqr(player.position());
            if (d < bd) { bd = d; best = p; }
        }
        if (changed) wd.setDirty();
        if (best != null) {
            tag.put("Target", NbtUtils.writeBlockPos(best));
            tag.putString("Dim", here);
            tag.putBoolean("Precise", true);
            tag.remove("None");
            if (sl.isLoaded(best)) {
                BlockState st = sl.getBlockState(best);
                if (st.hasProperty(CursedSandBlock.POWER)) tag.putInt("Fingers", st.getValue(CursedSandBlock.POWER));
            }
            return;
        }
        for (Map.Entry<String, Set<Long>> e : wd.allSand().entrySet()) {
            if (e.getKey().equals(here) || e.getValue().isEmpty()) continue;
            tag.put("Target", NbtUtils.writeBlockPos(BlockPos.of(e.getValue().iterator().next())));
            tag.putString("Dim", e.getKey());
            tag.putBoolean("Precise", true);
            tag.remove("None");
            return;
        }
        tag.remove("Target");
        tag.putBoolean("None", true);
    }

    /** Registers Cursed Sand placed by older versions of the mod (not yet tracked) around the player. */
    private static int scanAround(ServerLevel sl, BlockPos c) {
        KocWorldData wd = KocWorldData.get(sl.getServer());
        String dim = sl.dimension().location().toString();
        int found = 0;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = -32; x <= 32; x++) for (int z = -32; z <= 32; z++) {
            if (!sl.hasChunkAt(m.set(c.getX() + x, c.getY(), c.getZ() + z))) continue;
            for (int y = -20; y <= 20; y++) {
                m.set(c.getX() + x, c.getY() + y, c.getZ() + z);
                if (sl.getBlockState(m).is(ModBlocks.CURSED_SAND.get())) { wd.addSand(dim, m.immutable()); found++; }
            }
        }
        return found;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel sl) {
            scanAround(sl, player.blockPosition());
            retarget(sl, player, stack);
            CompoundTag tag = stack.getTag();
            if (tag == null || !tag.contains("Target")) {
                player.displayClientMessage(Component.translatable("message.kingofcurses.remains_none").withStyle(ChatFormatting.GRAY), true);
            } else {
                BlockPos p = NbtUtils.readBlockPos(tag.getCompound("Target"));
                player.displayClientMessage(Component.translatable("message.kingofcurses.remains_found", p.getX(), p.getY(), p.getZ()).withStyle(ChatFormatting.DARK_RED), true);
                sl.playSound(null, player.blockPosition(), ModSounds.RESONANCE_PULSE.get(), SoundSource.PLAYERS, 1.0f, 1.2f);
            }
            player.getCooldowns().addCooldown(this, 40);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!(level instanceof ServerLevel sl) || !(entity instanceof Player player) || level.getGameTime() % 20 != 0) return;
        retarget(sl, player, stack);
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains("Target") || !level.dimension().location().toString().equals(tag.getString("Dim"))) return;
        BlockPos target = NbtUtils.readBlockPos(tag.getCompound("Target"));
        double dist = Math.sqrt(target.distToCenterSqr(player.position()));
        boolean held = selected || player.getOffhandItem() == stack;
        if (held && dist < 48) {
            int period = dist < 6 ? 20 : dist < 20 ? 40 : 60;
            if (level.getGameTime() % period == 0) level.playSound(null, player.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.PLAYERS, 0.5f, 1.2f);
        }
    }

    @Override public boolean isFoil(ItemStack stack) { return stack.hasTag() && stack.getTag().contains("Target"); }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.remains_compass").withStyle(ChatFormatting.GRAY));
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains("Target")) {
            BlockPos p = NbtUtils.readBlockPos(tag.getCompound("Target"));
            tooltip.add(Component.translatable("tooltip.kingofcurses.remains_target", p.getX(), p.getY(), p.getZ(), tag.getString("Dim")).withStyle(ChatFormatting.DARK_RED));
            if (tag.getInt("Fingers") > 0) tooltip.add(Component.translatable("tooltip.kingofcurses.remains_fingers", tag.getInt("Fingers")).withStyle(ChatFormatting.RED));
        }
    }
}
