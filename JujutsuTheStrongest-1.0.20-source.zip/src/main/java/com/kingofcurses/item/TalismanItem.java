package com.kingofcurses.item;

import com.kingofcurses.entity.CursedSpiritEntity;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Locale;

public class TalismanItem extends Item {
    public enum Type { SEALING, WARDING, BINDING, FLAME }
    private final Type type;

    public TalismanItem(Type type, Properties props) { super(props); this.type = type; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel sl) {
            List<LivingEntity> near = sl.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(type == Type.SEALING ? 8 : 5),
                    e -> e != player && e.isAlive() && (e instanceof Enemy || e instanceof CursedSpiritEntity));
            switch (type) {
                case SEALING -> near.forEach(e -> {
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 1));
                    if (e instanceof CursedSpiritEntity) e.hurt(player.damageSources().magic(), 6.0f);
                });
                case WARDING -> player.addEffect(new MobEffectInstance(ModEffects.WARDED.get(), 1200, 0));
                case BINDING -> near.forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 5)));
                case FLAME -> near.forEach(e -> { e.setSecondsOnFire(6); e.hurt(player.damageSources().onFire(), 4.0f); });
            }
            sl.sendParticles(type == Type.FLAME ? ParticleTypes.FLAME : ParticleTypes.ENCHANT, player.getX(), player.getY() + 1, player.getZ(), 40, 1.5, 0.8, 1.5, 0.1);
            sl.playSound(null, player.blockPosition(), ModSounds.SEAL_RITUAL.get(), SoundSource.PLAYERS, 0.8f, 1.4f);
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.getCooldowns().addCooldown(this, 40);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.talisman." + type.name().toLowerCase(Locale.ROOT)).withStyle(ChatFormatting.GRAY));
    }
}
