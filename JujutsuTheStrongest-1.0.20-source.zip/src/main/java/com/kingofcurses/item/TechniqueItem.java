package com.kingofcurses.item;

import com.kingofcurses.ability.Ability;
import com.kingofcurses.ability.AbilityLogic;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Mobile control mode: one item per cursed technique. Tap "use" (right click / long press) to cast it. */
public class TechniqueItem extends Item {
    private final Ability ability;

    public TechniqueItem(Ability ability, Properties props) { super(props); this.ability = ability; }

    public Ability ability() { return ability; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            if (AbilityLogic.tryUse(sp, ability)) {
                player.getCooldowns().addCooldown(this, Math.max(6, ability.cooldown));
                return InteractionResultHolder.consume(stack);
            }
            player.getCooldowns().addCooldown(this, 6);
            return InteractionResultHolder.fail(stack);
        }
        return InteractionResultHolder.success(stack);
    }

    @Override public boolean isFoil(ItemStack stack) { return ability == Ability.DOMAIN_EXPANSION; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(ability.description().copy().withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.kingofcurses.technique_item", ability.requiredFingers(), (int) ability.cost, ability.cooldown / 20.0f).withStyle(ChatFormatting.DARK_RED));
    }
}
