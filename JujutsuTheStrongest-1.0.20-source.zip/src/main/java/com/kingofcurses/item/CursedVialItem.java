package com.kingofcurses.item;

import com.kingofcurses.ability.KocSync;
import com.kingofcurses.capability.CursedCapability;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Cursed energy potions. */
public class CursedVialItem extends Item {
    private final float energy, heal;

    public CursedVialItem(float energy, float heal, Properties props) { super(props); this.energy = energy; this.heal = heal; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return ItemUtils.startUsingInstantly(level, player, hand);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (entity instanceof ServerPlayer sp) {
            if (energy > 0) CursedCapability.get(sp).ifPresent(d -> d.addEnergy(energy));
            if (heal > 0) sp.heal(heal);
            KocSync.sync(sp);
            if (!sp.getAbilities().instabuild) {
                stack.shrink(1);
                if (!sp.getInventory().add(new ItemStack(Items.GLASS_BOTTLE))) sp.drop(new ItemStack(Items.GLASS_BOTTLE), false);
            }
        }
        return stack;
    }

    @Override public int getUseDuration(ItemStack stack) { return 24; }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.DRINK; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (energy > 0) tooltip.add(Component.translatable("tooltip.kingofcurses.vial", (int) energy).withStyle(ChatFormatting.RED));
        if (heal > 0) tooltip.add(Component.translatable("tooltip.kingofcurses.tonic", (int) heal).withStyle(ChatFormatting.GREEN));
    }
}
