package com.kingofcurses.item;

import com.kingofcurses.ability.SukunaBossFight;
import com.kingofcurses.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * v1.0.20 Clue of Sukuna. Every clue looks the same; combine them (crafting grid, or one in each hand + right click)
 * and the pieces add up: "Clue 2 of 10"... With 10 of 10, right click: Sukuna rises from the ground.
 */
public class ClueItem extends Item {
    public static final int TOTAL = 10;

    public ClueItem(Properties props) { super(props); }

    public static int pieces(ItemStack s) {
        if (!s.hasTag() || !s.getTag().contains("Pieces")) return 1;
        return Math.max(1, Math.min(TOTAL, s.getTag().getInt("Pieces")));
    }

    public static ItemStack withPieces(int n) {
        ItemStack s = new ItemStack(ModItems.SUKUNA_CLUE.get());
        s.getOrCreateTag().putInt("Pieces", Math.max(1, Math.min(TOTAL, n)));
        return s;
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.translatable("item.kingofcurses.sukuna_clue.n", pieces(stack), TOTAL);
    }

    @Override public boolean isFoil(ItemStack stack) { return pieces(stack) >= TOTAL; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        ItemStack other = player.getItemInHand(hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        if (other.getItem() instanceof ClueItem && pieces(stack) < TOTAL) {          // join the two clues
            int sum = Math.min(TOTAL, pieces(stack) + pieces(other));
            other.shrink(1);
            ItemStack joined = withPieces(sum);
            player.displayClientMessage(Component.translatable("message.kingofcurses.clue_joined", sum, TOTAL).withStyle(ChatFormatting.GOLD), true);
            return InteractionResultHolder.consume(joined);
        }
        if (pieces(stack) < TOTAL) {
            player.displayClientMessage(Component.translatable("message.kingofcurses.clue_incomplete", pieces(stack), TOTAL).withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }
        if (player instanceof ServerPlayer sp && SukunaBossFight.summon(sp)) {
            if (!player.getAbilities().instabuild) stack.shrink(1);
            return InteractionResultHolder.consume(stack);
        }
        return InteractionResultHolder.fail(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        int n = pieces(stack);
        tooltip.add(Component.translatable(n >= TOTAL ? "tooltip.kingofcurses.clue_full" : "tooltip.kingofcurses.clue", n, TOTAL).withStyle(n >= TOTAL ? ChatFormatting.DARK_RED : ChatFormatting.GRAY));
    }
}
