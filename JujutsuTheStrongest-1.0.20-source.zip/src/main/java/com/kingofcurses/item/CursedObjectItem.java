package com.kingofcurses.item;

import com.kingofcurses.ability.KocSync;
import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.entity.GojoKenjakuEntity;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.List;
import java.util.Locale;

/** v1.0.4 cursed objects from the series. Every one works with right-click / Use, so they are mobile friendly too. */
public class CursedObjectItem extends Item {
    public enum Kind {
        PRISON_REALM, BLACK_ROPE, DEATH_PAINTING, CURSED_SPIRIT_ORB, INVENTORY_CURSE, PROMISE_RING;
        public String id() { return name().toLowerCase(Locale.ROOT); }
        boolean edible() { return this == DEATH_PAINTING || this == CURSED_SPIRIT_ORB; }
    }

    private final Kind kind;

    public CursedObjectItem(Kind kind, Properties props) { super(props); this.kind = kind; }

    public static Properties props(Kind k) {
        Properties p = new Properties();
        return switch (k) {
            case PRISON_REALM -> p.stacksTo(1).rarity(Rarity.EPIC).fireResistant();
            case BLACK_ROPE -> p.durability(8).rarity(Rarity.RARE);
            case DEATH_PAINTING, CURSED_SPIRIT_ORB -> p.stacksTo(16).rarity(Rarity.UNCOMMON);
            case INVENTORY_CURSE -> p.stacksTo(1).rarity(Rarity.RARE);
            case PROMISE_RING -> p.stacksTo(1).rarity(Rarity.EPIC).fireResistant();
        };
    }

    @Override public boolean isFoil(ItemStack stack) { return kind == Kind.PROMISE_RING || kind == Kind.PRISON_REALM; }
    @Override public int getUseDuration(ItemStack stack) { return kind.edible() ? 32 : 0; }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return kind.edible() ? UseAnim.EAT : UseAnim.NONE; }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (kind != Kind.PRISON_REALM) return InteractionResult.PASS;
        if (!player.level().isClientSide && player instanceof ServerPlayer sp) seal(sp, stack, target);
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (kind.edible()) { player.startUsingItem(hand); return InteractionResultHolder.consume(stack); }
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(stack);
        ServerLevel sl = sp.serverLevel();
        switch (kind) {
            case PRISON_REALM -> {
                LivingEntity t = lookTarget(sp, 10);
                if (t == null) return InteractionResultHolder.pass(stack);
                seal(sp, stack, t);
            }
            case BLACK_ROPE -> {
                boolean any = false;
                for (GojoKenjakuEntity g : sl.getEntitiesOfClass(GojoKenjakuEntity.class, sp.getBoundingBox().inflate(14))) { g.breakInfinity(160); any = true; }
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(10), e -> e != sp)) {
                    e.removeEffect(MobEffects.DAMAGE_RESISTANCE); e.removeEffect(MobEffects.REGENERATION); e.removeEffect(MobEffects.INVISIBILITY);
                }
                sp.removeEffect(ModEffects.SEALED.get());
                sl.sendParticles(new DustParticleOptions(new Vector3f(0.05f, 0.05f, 0.08f), 1.6f), sp.getX(), sp.getY() + 1, sp.getZ(), 120, 3, 1, 3, 0.02);
                sl.playSound(null, sp.blockPosition(), SoundEvents.CHAIN_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);
                if (any) sp.displayClientMessage(Component.translatable("message.kingofcurses.infinity_broken").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), true);
                stack.hurtAndBreak(1, sp, p -> p.broadcastBreakEvent(hand));
                sp.getCooldowns().addCooldown(this, 200);
            }
            case INVENTORY_CURSE -> {
                sp.openMenu(new SimpleMenuProvider((id, inv, p) -> ChestMenu.threeRows(id, inv, p.getEnderChestInventory()), Component.translatable("item.kingofcurses.inventory_curse")));
                sl.playSound(null, sp.blockPosition(), SoundEvents.ENDER_CHEST_OPEN, SoundSource.PLAYERS, 0.8f, 0.6f);
            }
            case PROMISE_RING -> {
                CursedCapability.get(sp).ifPresent(d -> d.addEnergy(150f));
                sp.heal(10f);
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
                sl.sendParticles(new DustParticleOptions(new Vector3f(0.55f, 0.25f, 1.0f), 1.4f), sp.getX(), sp.getY() + 1, sp.getZ(), 80, 0.6, 1.0, 0.6, 0.05);
                sl.playSound(null, sp.blockPosition(), ModSounds.RCT_HEAL.get(), SoundSource.PLAYERS, 1.0f, 1.3f);
                sp.getCooldowns().addCooldown(this, 1200);
                KocSync.sync(sp);
            }
            default -> {}
        }
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer sp) {
            if (kind == Kind.DEATH_PAINTING) {
                CursedCapability.get(sp).ifPresent(d -> d.addEnergy(100f));
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 1));
                sp.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
            } else if (kind == Kind.CURSED_SPIRIT_ORB) {
                CursedCapability.get(sp).ifPresent(d -> d.addEnergy(30f));
                sp.heal(8f);
                sp.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 1));
                sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0));
            }
            sp.serverLevel().playSound(null, sp.blockPosition(), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.PLAYERS, 0.6f, 1.4f);
            KocSync.sync(sp);
            if (!sp.getAbilities().instabuild) stack.shrink(1);
        }
        return stack;
    }

    private void seal(ServerPlayer sp, ItemStack stack, LivingEntity t) {
        if (sp.getCooldowns().isOnCooldown(this) || t == sp) return;
        boolean boss = t instanceof GojoKenjakuEntity;
        int ticks = boss ? 60 : 200;
        t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 9, false, true));
        t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 4, false, true));
        t.addEffect(new MobEffectInstance(MobEffects.GLOWING, ticks, 0, false, false));
        t.addEffect(new MobEffectInstance(ModEffects.SEALED.get(), ticks, 0));
        if (boss) ((GojoKenjakuEntity) t).breakInfinity(ticks);
        ServerLevel sl = sp.serverLevel();
        sl.sendParticles(ParticleTypes.REVERSE_PORTAL, t.getX(), t.getY() + t.getBbHeight() / 2, t.getZ(), 90, 0.6, 1.0, 0.6, 0.05);
        sl.playSound(null, t.blockPosition(), ModSounds.SEAL_RITUAL.get(), SoundSource.PLAYERS, 1.4f, 0.7f);
        sp.displayClientMessage(boss ? Component.translatable("message.kingofcurses.prison_boss").withStyle(ChatFormatting.GOLD)
                : Component.translatable("message.kingofcurses.prison_sealed", t.getDisplayName()).withStyle(ChatFormatting.GOLD), true);
        sp.getCooldowns().addCooldown(this, 600);
    }

    @Nullable
    private static LivingEntity lookTarget(ServerPlayer sp, double range) {
        Vec3 eye = sp.getEyePosition(), look = sp.getViewVector(1f);
        LivingEntity best = null; double bestD = Double.MAX_VALUE;
        AABB box = sp.getBoundingBox().expandTowards(look.scale(range)).inflate(1.5);
        for (LivingEntity e : sp.level().getEntitiesOfClass(LivingEntity.class, box, e -> e != sp && e.isAlive())) {
            Vec3 to = e.position().add(0, e.getBbHeight() / 2, 0).subtract(eye);
            double along = to.dot(look);
            if (along < 0 || along > range) continue;
            double off = to.subtract(look.scale(along)).length();
            if (off < 1.2 + e.getBbWidth() && along < bestD) { bestD = along; best = e; }
        }
        return best;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.cursed_object").withStyle(ChatFormatting.DARK_PURPLE));
        tooltip.add(Component.translatable("tooltip.kingofcurses.obj." + kind.id()).withStyle(ChatFormatting.GRAY));
    }
}
