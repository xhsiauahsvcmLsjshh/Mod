package com.kingofcurses.item;

import com.kingofcurses.registry.ModSounds;
import com.kingofcurses.worldgen.KocWorldgen;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.Holder;
import net.minecraft.core.SectionPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.Container;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;

import java.util.List;

/**
 * Finger resonance: right-click to lock onto the nearest finger site in this dimension; while held
 * the compass pulses (model property "kingofcurses:resonance") and heartbeats faster as you approach.
 */
public class CursedCompassItem extends Item {
    public CursedCompassItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel sl) {
            CompoundTag tag = stack.getOrCreateTag();
            BlockPos found = null;
            BoundingBox box = null;
            try {
                var reg = sl.registryAccess().registryOrThrow(Registries.STRUCTURE);
                boolean gojo = player instanceof net.minecraft.server.level.ServerPlayer gsp && com.kingofcurses.ability.KocSync.data(gsp).isGojo();
                tag.putBoolean("Clues", gojo);   // v1.0.20: for Gojo the compass hunts the dark institutes
                var set = reg.getTag(gojo ? KocWorldgen.DARK_INSTITUTES : KocWorldgen.FINGER_SITES);
                if (set.isPresent()) {
                    Pair<BlockPos, Holder<Structure>> res = sl.getChunkSource().getGenerator().findNearestMapStructure(sl, set.get(), player.blockPosition(), 64, false);
                    if (res != null) {
                        found = res.getFirst();
                        ChunkPos cp = new ChunkPos(found);
                        ChunkAccess ca = sl.getChunk(cp.x, cp.z, ChunkStatus.STRUCTURE_STARTS);
                        StructureStart ss = sl.structureManager().getStartForStructure(SectionPos.bottomOf(ca), res.getSecond().value(), ca);
                        if (ss != null && ss.isValid()) box = ss.getBoundingBox();
                    }
                }
            } catch (RuntimeException ex) {
                found = sl.findNearestMapStructure(KocWorldgen.FINGER_SITES, player.blockPosition(), 64, false);
            }
            if (found == null) {
                tag.remove("Target");
                player.displayClientMessage(Component.translatable("message.kingofcurses.compass_none").withStyle(ChatFormatting.GRAY), true);
            } else {
                BlockPos target = box != null ? box.getCenter() : new BlockPos(found.getX(), sl.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE, found.getX(), found.getZ()), found.getZ());
                tag.put("Target", NbtUtils.writeBlockPos(target));
                tag.putString("Dim", sl.dimension().location().toString());
                tag.putBoolean("Precise", false);
                tag.putBoolean("Looted", false);
                if (box != null) tag.putIntArray("Box", new int[]{box.minX(), box.minY(), box.minZ(), box.maxX(), box.maxY(), box.maxZ()});
                else tag.remove("Box");
                int dist = (int) Math.sqrt(target.distSqr(player.blockPosition()));
                player.displayClientMessage(Component.translatable("message.kingofcurses.compass_found", dist).withStyle(ChatFormatting.DARK_RED), true);
                sl.playSound(null, player.blockPosition(), ModSounds.RESONANCE_PULSE.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
                refine(sl, tag);
            }
            player.getCooldowns().addCooldown(this, 60);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** v1.0.15: once the site's chunks are loaded, pin the exact chest that holds the finger. */
    private static void refine(ServerLevel sl, CompoundTag tag) {
        if (tag.getBoolean("Precise") || !tag.contains("Box")) return;
        int[] b = tag.getIntArray("Box");
        if (b.length != 6) return;
        boolean allLoaded = true;
        for (int cx = b[0] >> 4; cx <= b[3] >> 4; cx++) {
            for (int cz = b[2] >> 4; cz <= b[5] >> 4; cz++) {
                if (!sl.hasChunk(cx, cz)) { allLoaded = false; continue; }
                LevelChunk chunk = sl.getChunk(cx, cz);
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    BlockPos p = be.getBlockPos();
                    if (p.getX() < b[0] || p.getX() > b[3] || p.getY() < b[1] - 2 || p.getY() > b[4] + 2 || p.getZ() < b[2] || p.getZ() > b[5]) continue;
                    if (holdsFinger(be)) {
                        tag.put("Target", NbtUtils.writeBlockPos(p));
                        tag.putBoolean("Precise", true);
                        return;
                    }
                }
            }
        }
        if (allLoaded) tag.putBoolean("Looted", true);
    }

    private static boolean holdsFinger(BlockEntity be) {
        try {
            CompoundTag t = be.saveWithoutMetadata();
            if (t.getString("LootTable").contains("finger_") || t.getString("LootTable").contains("dark_institute")) return true;
        } catch (RuntimeException ignored) { }
        if (be instanceof Container c) {
            for (int i = 0; i < c.getContainerSize(); i++) {
                ItemStack s = c.getItem(i);
                if (s.getItem() instanceof SukunaFingerItem || s.getItem() instanceof RippedFingerItem || s.getItem() instanceof ClueItem) return true;
            }
        }
        return false;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !(entity instanceof Player player) || level.getGameTime() % 10 != 0) return;
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains("Target") || !level.dimension().location().toString().equals(tag.getString("Dim"))) {
            if (tag != null && tag.getFloat("Resonance") != 0) tag.putFloat("Resonance", 0);
            return;
        }
        BlockPos target = NbtUtils.readBlockPos(tag.getCompound("Target"));
        double dx = target.getX() - player.getX(), dz = target.getZ() - player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (level.getGameTime() % 40 == 0 && dist < 160 && level instanceof ServerLevel sl) refine(sl, tag);
        float resonance = (float) Math.max(0, 1.0 - dist / 256.0);
        tag.putFloat("Resonance", Math.round(resonance * 20) / 20f);
        boolean held = selected || player.getOffhandItem() == stack;
        if (held && dist < 160) {
            int period = dist < 24 ? 10 : dist < 64 ? 20 : 40;
            if (level.getGameTime() % period == 0) level.playSound(null, player.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.PLAYERS, 0.4f + resonance * 0.6f, 1.0f);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.compass").withStyle(ChatFormatting.GRAY));
    }
}
