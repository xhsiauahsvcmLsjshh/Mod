package com.kingofcurses.item;

import com.kingofcurses.registry.ModItems;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

public enum KocTiers implements Tier {
    CURSED(3, 1800, 8.0f, 3.0f, 18, () -> Ingredient.of(ModItems.CURSED_ENERGY_SHARD.get())),
    SPECIAL(4, 2600, 9.0f, 5.0f, 22, () -> Ingredient.of(ModItems.SPECIAL_GRADE_CORE.get()));

    private final int level, uses, enchant;
    private final float speed, damage;
    private final Supplier<Ingredient> repair;

    KocTiers(int level, int uses, float speed, float damage, int enchant, Supplier<Ingredient> repair) {
        this.level = level; this.uses = uses; this.speed = speed; this.damage = damage; this.enchant = enchant; this.repair = repair;
    }

    @Override public int getUses() { return uses; }
    @Override public float getSpeed() { return speed; }
    @Override public float getAttackDamageBonus() { return damage; }
    @Override @SuppressWarnings("deprecation") public int getLevel() { return level; }
    @Override public int getEnchantmentValue() { return enchant; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
}
