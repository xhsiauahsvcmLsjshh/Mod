package com.kingofcurses.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Wearable trophy with no stats (Gojo's blindfold). */
public class CollectibleArmorItem extends ArmorItem {
    public CollectibleArmorItem(ArmorMaterial material, Type type, Properties props) { super(material, type, props); }

    @Override public boolean isDamageable(ItemStack stack) { return false; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.gojo_blindfold").withStyle(ChatFormatting.AQUA, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("tooltip.kingofcurses.collectible").withStyle(ChatFormatting.GRAY));
    }
}
