package com.kingofcurses.item;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.registry.ModItems;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

public enum KocArmorMaterials implements ArmorMaterial {
    JUJUTSU_UNIFORM("jujutsu_uniform", 22, new int[]{2, 5, 6, 2}, 18, 0.5f, 0.0f, () -> Ingredient.of(ModItems.JUJUTSU_CLOTH.get())),
    CURSED_ARMOR("cursed_armor", 33, new int[]{3, 6, 8, 3}, 14, 2.5f, 0.1f, () -> Ingredient.of(ModItems.CURSED_ENERGY_SHARD.get())),
    SUKUNA_ROBES("sukuna_robes", 40, new int[]{3, 7, 8, 3}, 25, 3.0f, 0.15f, () -> Ingredient.of(ModItems.CRIMSON_THREAD.get())),
    /** Collectible only: zero protection, never breaks. */
    GOJO_BLINDFOLD("gojo_blindfold", 0, new int[]{0, 0, 0, 0}, 0, 0.0f, 0.0f, () -> Ingredient.EMPTY);

    // boots, leggings, chestplate, helmet (vanilla order)
    private static final int[] BASE_DURABILITY = {13, 15, 16, 11};
    private final String name;
    private final int durabilityMultiplier, enchant;
    private final int[] protection;
    private final float toughness, knockback;
    private final Supplier<Ingredient> repair;

    KocArmorMaterials(String name, int durability, int[] protection, int enchant, float toughness, float knockback, Supplier<Ingredient> repair) {
        this.name = name; this.durabilityMultiplier = durability; this.protection = protection; this.enchant = enchant;
        this.toughness = toughness; this.knockback = knockback; this.repair = repair;
    }

    private static int slot(ArmorItem.Type type) {
        return switch (type) { case BOOTS -> 0; case LEGGINGS -> 1; case CHESTPLATE -> 2; case HELMET -> 3; };
    }

    @Override public int getDurabilityForType(ArmorItem.Type type) { return BASE_DURABILITY[slot(type)] * durabilityMultiplier; }
    @Override public int getDefenseForType(ArmorItem.Type type) { return protection[slot(type)]; }
    @Override public int getEnchantmentValue() { return enchant; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_LEATHER; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
    @Override public String getName() { return KingOfCurses.MODID + ":" + name; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockback; }
}
