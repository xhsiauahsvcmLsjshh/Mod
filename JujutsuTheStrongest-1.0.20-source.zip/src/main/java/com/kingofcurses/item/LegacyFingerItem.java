package com.kingofcurses.item;

import com.kingofcurses.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** The numbered fingers from 1.0.0 - 1.0.3. They turn into the single {@code sukuna_finger} as soon as they are in an inventory or on the ground. */
public class LegacyFingerItem extends Item {
    public LegacyFingerItem(Properties props) { super(props); }

    private static ItemStack converted(ItemStack old) { return new ItemStack(ModItems.SUKUNA_FINGER.get(), old.getCount()); }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !(entity instanceof Player p)) return;
        if (slot >= 0 && slot < p.getInventory().items.size() && p.getInventory().items.get(slot) == stack) {
            p.getInventory().items.set(slot, converted(stack));
        } else {
            ItemStack copy = converted(stack);
            stack.setCount(0);
            if (!p.getInventory().add(copy)) p.drop(copy, false);
        }
        p.displayClientMessage(Component.translatable("message.kingofcurses.legacy_finger").withStyle(ChatFormatting.GRAY), true);
    }

    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        if (!entity.level().isClientSide) entity.setItem(converted(stack));
        return false;
    }
}
