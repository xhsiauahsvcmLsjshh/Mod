package com.kingofcurses.item;

import com.kingofcurses.ability.HeianLogic;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** v1.0.17: use it on the ground to raise a golden torii with a gate to the Heian Era. */
public class HeianSealItem extends Item {
    public HeianSealItem(Properties props) { super(props); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        if (!(level instanceof ServerLevel sl) || player == null) return InteractionResult.sidedSuccess(level.isClientSide);
        if (sl.dimension() == HeianLogic.HEIAN) {
            player.displayClientMessage(Component.translatable("message.kingofcurses.heian_seal_inside").withStyle(ChatFormatting.GOLD), true);
            return InteractionResult.FAIL;
        }
        BlockPos base = ctx.getClickedFace() == Direction.UP ? ctx.getClickedPos().above() : ctx.getClickedPos().relative(ctx.getClickedFace());
        Direction facing = player.getDirection();
        Direction.Axis axis = facing.getAxis() == Direction.Axis.Z ? Direction.Axis.X : Direction.Axis.Z;
        HeianLogic.buildGate(sl, base.relative(facing, 2), axis);
        if (!player.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        player.displayClientMessage(Component.translatable("message.kingofcurses.heian_gate_built").withStyle(ChatFormatting.GOLD), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.heian_seal").withStyle(ChatFormatting.GOLD));
    }
}
