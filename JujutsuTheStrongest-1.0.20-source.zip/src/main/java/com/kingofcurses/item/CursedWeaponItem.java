package com.kingofcurses.item;

import com.kingofcurses.entity.CursedSpiritEntity;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModParticles;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Cursed tools (weapons) with unique perks. */
public class CursedWeaponItem extends SwordItem {
    public enum Perk { NONE, BLEED, NULLIFY, KNOCKBACK, PULL, SOUL, CURSE_SLAYER, CLEAVER }
    private final Perk perk;

    public CursedWeaponItem(Tier tier, int damage, float speed, Perk perk, Properties props) {
        super(tier, damage, speed, props);
        this.perk = perk;
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        switch (perk) {
            case BLEED -> target.addEffect(new MobEffectInstance(ModEffects.CURSED_BLEED.get(), 100, 0));
            case NULLIFY -> new ArrayList<>(target.getActiveEffects()).stream()
                    .filter(e -> e.getEffect().getCategory() == MobEffectCategory.BENEFICIAL).forEach(e -> target.removeEffect(e.getEffect()));
            case KNOCKBACK -> target.knockback(1.6, attacker.getX() - target.getX(), attacker.getZ() - target.getZ());
            case SOUL -> { target.invulnerableTime = 0; target.hurt(attacker.damageSources().magic(), 3.0f); }
            case CURSE_SLAYER -> { if (target instanceof CursedSpiritEntity) { target.invulnerableTime = 0; target.hurt(attacker.damageSources().magic(), 8.0f); } }
            case CLEAVER -> {
                target.invulnerableTime = 0;
                target.hurt(attacker.damageSources().magic(), 4.0f);
                if (target.level() instanceof ServerLevel sl) sl.sendParticles(ModParticles.SLASH.get(), target.getX(), target.getY() + 1, target.getZ(), 2, 0.3, 0.3, 0.3, 0);
            }
            default -> { }
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (perk == Perk.PULL) {
            if (!level.isClientSide) {
                Vec3 eye = player.getEyePosition(), look = player.getViewVector(1.0f);
                LivingEntity best = null; double bestD = 400;
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().expandTowards(look.scale(16)).inflate(1.5), e -> e != player)) {
                    Vec3 to = e.getEyePosition().subtract(eye);
                    if (to.normalize().dot(look) > 0.93 && to.lengthSqr() < bestD) { bestD = to.lengthSqr(); best = e; }
                }
                if (best != null) {
                    Vec3 pull = eye.subtract(best.position()).normalize().scale(1.4);
                    best.setDeltaMovement(pull.x, 0.4, pull.z);
                    best.hurtMarked = true;
                    stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                }
                player.getCooldowns().addCooldown(this, 30);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return super.use(level, player, hand);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.perk." + perk.name().toLowerCase(Locale.ROOT)).withStyle(ChatFormatting.DARK_RED));
    }
}
