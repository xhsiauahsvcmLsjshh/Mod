package com.kingofcurses.item;

import com.kingofcurses.ability.FingerLogic;
import com.kingofcurses.capability.CursedCapability;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** v1.0.4: every finger is the same item. Eating one absorbs the next of the twenty (max 20 per player). */
public class SukunaFingerItem extends Item {
    public static final int FINGER_COUNT = 20;

    public SukunaFingerItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean full = CursedCapability.get(player).map(d -> d.fingers() >= FINGER_COUNT).orElse(false);
        if (full) {
            if (!level.isClientSide) player.displayClientMessage(Component.translatable("message.kingofcurses.all_fingers").withStyle(ChatFormatting.DARK_RED), true);
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer sp) {
            if (FingerLogic.consumeNext(sp) && !sp.getAbilities().instabuild) stack.shrink(1);
        }
        return stack;
    }

    @Override public int getUseDuration(ItemStack stack) { return 40; }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.EAT; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.finger").withStyle(ChatFormatting.GRAY));
        Integer eaten = DistExecutor.unsafeCallWhenOn(Dist.CLIENT, () -> () -> com.kingofcurses.client.ClientData.DATA.fingers());
        if (eaten != null) {
            tooltip.add(Component.translatable("tooltip.kingofcurses.finger_count", eaten).withStyle(ChatFormatting.DARK_RED));
            if (eaten < FINGER_COUNT) tooltip.add(Component.translatable("tooltip.kingofcurses.finger_uneaten").withStyle(ChatFormatting.RED));
        }
    }
}
