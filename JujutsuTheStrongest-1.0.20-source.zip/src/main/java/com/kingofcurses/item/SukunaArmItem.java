package com.kingofcurses.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** v1.0.17: the arm Heian Sukuna tears off and throws to you. Put it in a crafting grid: five fingers. */
public class SukunaArmItem extends Item {
    public SukunaArmItem(Properties props) { super(props); }

    @Override public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.sukuna_arm").withStyle(ChatFormatting.DARK_RED));
    }
}
