package com.kingofcurses.item;

import com.kingofcurses.ability.VesselLogic;
import com.kingofcurses.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** v1.0.5: a finger torn from the vessel, carrying 1..20 fingers of power (NBT "Power"). Feed it to a creature or eat it back. */
public class RippedFingerItem extends Item {
    public RippedFingerItem(Properties props) { super(props); }

    public static int power(ItemStack stack) {
        return stack.hasTag() ? Math.max(1, Math.min(20, stack.getTag().getInt("Power"))) : 1;
    }

    public static ItemStack withPower(int n) {
        ItemStack s = new ItemStack(ModItems.RIPPED_FINGER.get());
        s.getOrCreateTag().putInt("Power", Math.max(1, Math.min(20, n)));
        return s;
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.translatable("item.kingofcurses.ripped_finger.power", power(stack));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer sp) {
            VesselLogic.reabsorb(sp, power(stack));
            if (!sp.getAbilities().instabuild) stack.shrink(1);
        }
        return stack;
    }

    @Override public int getUseDuration(ItemStack stack) { return 40; }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.EAT; }
    @Override public boolean isFoil(ItemStack stack) { return power(stack) >= 20; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kingofcurses.ripped_finger", power(stack)).withStyle(ChatFormatting.DARK_RED));
        tooltip.add(Component.translatable("tooltip.kingofcurses.ripped_finger_feed").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.kingofcurses.ripped_finger_eat").withStyle(ChatFormatting.GRAY));
    }
}
