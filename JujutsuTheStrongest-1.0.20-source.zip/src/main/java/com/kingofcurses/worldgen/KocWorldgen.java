package com.kingofcurses.worldgen;

import com.kingofcurses.KingOfCurses;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.levelgen.structure.Structure;

/**
 * Worldgen is fully data driven (1.20.1 format): see data/kingofcurses/worldgen/structure,
 * structure_set, template_pool, configured_feature, placed_feature and forge/biome_modifier.
 * This class only exposes the tag keys code needs.
 */
public final class KocWorldgen {
    /** Every structure that holds a Sukuna finger. Used by the Cursed Compass. */
    public static final TagKey<Structure> FINGER_SITES = TagKey.create(Registries.STRUCTURE, new ResourceLocation(KingOfCurses.MODID, "finger_sites"));

    /** v1.0.20 */
    public static final TagKey<Structure> DARK_INSTITUTES = TagKey.create(Registries.STRUCTURE, new ResourceLocation(KingOfCurses.MODID, "dark_institutes"));
    public static final TagKey<Structure> JUJUTSU_INSTITUTES = TagKey.create(Registries.STRUCTURE, new ResourceLocation(KingOfCurses.MODID, "jujutsu_institutes"));

    private KocWorldgen() {}
}
