package com.kingofcurses.entity;

import software.bernie.geckolib.core.animation.RawAnimation;

/** Builds GeckoLib animation handles that match animations/entity/<name>.animation.json. */
public final class KocAnims {
    private KocAnims() {}

    public static String key(String model, String anim) { return "animation." + model + "." + anim; }
    public static RawAnimation loop(String model, String anim) { return RawAnimation.begin().thenLoop(key(model, anim)); }
    public static RawAnimation once(String model, String anim) { return RawAnimation.begin().thenPlay(key(model, anim)); }
    public static RawAnimation onceThenIdle(String model, String anim) { return RawAnimation.begin().thenPlay(key(model, anim)).thenLoop(key(model, "idle")); }
    public static RawAnimation hold(String model, String anim) { return RawAnimation.begin().thenPlayAndHold(key(model, anim)); }
}
