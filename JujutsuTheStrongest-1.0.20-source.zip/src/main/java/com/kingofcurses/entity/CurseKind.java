package com.kingofcurses.entity;

/** Static description of every cursed spirit. Grade 0 = special grade. */
public enum CurseKind {
    FLY_HEAD("fly_head", 4, Special.NONE, -1, 0, 0),
    CRAWLING_EYE("crawling_eye", 4, Special.LEAP, -1, 6, 60),
    ROPPONGI_CURSE("roppongi_curse", 3, Special.SCREAM, -1, 8, 140),
    LANTERN_HAG("lantern_hag", 3, Special.FIREBOLT, -1, 16, 70),
    HANGED_BRIDE("hanged_bride", 2, Special.PULL, -1, 12, 120),
    BONE_CENTIPEDE("bone_centipede", 1, Special.POISON_LUNGE, -1, 8, 80),
    FINGER_BEARER("finger_bearer", 0, Special.SLAM, 8, 5, 100),
    SMALLPOX_DEITY("smallpox_deity", 0, Special.COFFIN, 10, 12, 160),
    CURSED_WOMB("cursed_womb", 0, Special.BROOD, 11, 16, 200),
    SHRINE_WARDEN("shrine_warden", 0, Special.CHARGE, 15, 14, 90);

    public enum Special { NONE, LEAP, SCREAM, FIREBOLT, PULL, POISON_LUNGE, SLAM, COFFIN, BROOD, CHARGE }

    public final String model;
    public final int grade;
    public final Special special;
    /** 1-based finger dropped by default (special grades), -1 for none. */
    public final int defaultFinger;
    public final double specialRange;
    public final int specialCooldown;

    CurseKind(String model, int grade, Special special, int defaultFinger, double specialRange, int specialCooldown) {
        this.model = model; this.grade = grade; this.special = special; this.defaultFinger = defaultFinger;
        this.specialRange = specialRange; this.specialCooldown = specialCooldown;
    }
}
