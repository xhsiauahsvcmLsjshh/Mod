package com.kingofcurses.entity;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Hostile cursed spirit (Grade 4 to special grade). Each kind has its own model, animations and special attack. */
public class CursedSpiritEntity extends Monster implements GeoEntity {
    protected final CurseKind kind;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle, walk, run;
    private int specialCooldown = 40;

    public CursedSpiritEntity(EntityType<? extends Monster> type, Level level, CurseKind kind) {
        super(type, level);
        this.kind = kind;
        this.idle = KocAnims.loop(kind.model, "idle");
        this.walk = KocAnims.loop(kind.model, "walk");
        this.run = KocAnims.loop(kind.model, "run");
        this.xpReward = kind.grade == 0 ? 60 : 4 + (4 - kind.grade) * 6;
    }

    public CurseKind kind() { return kind; }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg).add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 32.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void registerGoals() {
        // NOTE: called from the super constructor, "kind" is not assigned yet here.
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 10.0f));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, this::isValidPlayerTarget));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, SorcererEntity.class, 10, true, false, null));
    }

    /** Weak curses bow to a player who embraced Sukuna. */
    protected boolean isValidPlayerTarget(LivingEntity e) {
        if (!(e instanceof Player p)) return true;
        int ending = CursedCapability.get(p).map(CursedData::ending).orElse(0);
        return !(ending == CursedData.ENDING_EMBRACE && kind != null && kind.grade >= 2);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (specialCooldown > 0) { specialCooldown--; return; }
        LivingEntity target = getTarget();
        if (kind.special == CurseKind.Special.NONE || target == null || !target.isAlive()) return;
        if (distanceTo(target) <= kind.specialRange && hasLineOfSight(target)) {
            performSpecial(target);
            specialCooldown = kind.specialCooldown + random.nextInt(20);
        }
    }

    protected void performSpecial(LivingEntity target) {
        Vec3 dir = target.position().subtract(position()).normalize();
        switch (kind.special) {
            case LEAP -> { setDeltaMovement(dir.x * 0.9, 0.45, dir.z * 0.9); triggerAnim("main", "attack"); }
            case SCREAM -> {
                target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0));
                target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                playSound(ModSounds.CURSE_AMBIENT.get(), 2.0f, 0.6f);
                triggerAnim("main", "cast");
            }
            case FIREBOLT -> {
                double dx = target.getX() - getX(), dy = target.getY(0.5) - getY(0.6), dz = target.getZ() - getZ();
                SmallFireball fb = new SmallFireball(level(), this, dx, dy, dz);
                fb.setPos(getX(), getY(0.6), getZ());
                level().addFreshEntity(fb);
                triggerAnim("main", "cast");
            }
            case PULL -> {
                Vec3 pull = position().subtract(target.position()).normalize().scale(1.1);
                target.setDeltaMovement(pull.x, 0.35, pull.z);
                target.hurtMarked = true;
                triggerAnim("main", "cast");
            }
            case POISON_LUNGE -> {
                setDeltaMovement(dir.x * 1.2, 0.25, dir.z * 1.2);
                if (distanceTo(target) < 4) target.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 1));
                triggerAnim("main", "attack");
            }
            case SLAM -> {
                for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(5), e -> e != this && !(e instanceof CursedSpiritEntity))) {
                    e.hurt(damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.8f);
                    e.setDeltaMovement(e.getDeltaMovement().add(0, 0.6, 0));
                    e.hurtMarked = true;
                }
                triggerAnim("main", "slash");
            }
            case COFFIN -> {
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 3));
                target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                target.hurt(damageSources().mobAttack(this), 6.0f);
                triggerAnim("main", "cast");
            }
            case BROOD -> {
                int nearby = level().getEntitiesOfClass(CursedSpiritEntity.class, getBoundingBox().inflate(16), c -> c.kind == CurseKind.FLY_HEAD).size();
                for (int i = 0; i < 2 && nearby + i < 6; i++) {
                    CursedSpiritEntity fly = ModEntities.FLY_HEAD.get().create(level());
                    if (fly != null) {
                        fly.moveTo(getX() + random.nextGaussian(), getY() + 0.5, getZ() + random.nextGaussian(), random.nextFloat() * 360f, 0);
                        fly.setTarget(target);
                        level().addFreshEntity(fly);
                    }
                }
                triggerAnim("main", "cast");
            }
            case CHARGE -> {
                setDeltaMovement(dir.x * 1.6, 0.15, dir.z * 1.6);
                if (distanceTo(target) < 5) target.hurt(damageSources().mobAttack(this), (float) getAttributeValue(Attributes.ATTACK_DAMAGE));
                triggerAnim("main", "slash");
            }
            default -> { }
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        triggerAnim("main", "attack");
        boolean hit = super.doHurtTarget(target);
        if (hit && kind == CurseKind.LANTERN_HAG) target.setSecondsOnFire(3);
        return hit;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide && random.nextInt(kind.grade == 0 ? 2 : 6) == 0) {
            level().addParticle(ModParticles.CURSED_ENERGY.get(), getRandomX(0.6), getRandomY(), getRandomZ(0.6), 0, 0.02, 0);
        }
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.CURSE_AMBIENT.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return ModSounds.CURSE_HURT.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.CURSE_DEATH.get(); }

    // ---------------- GeckoLib ----------------
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 4, this::predicate)
                .triggerableAnim("attack", KocAnims.once(kind.model, "attack"))
                .triggerableAnim("slash", KocAnims.once(kind.model, "slash"))
                .triggerableAnim("cast", KocAnims.once(kind.model, "cast")));
    }

    private PlayState predicate(AnimationState<CursedSpiritEntity> state) {
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
