package com.kingofcurses.entity;

import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Ryomen Sukuna. In cinematic mode (no AI, invulnerable, not saved) the director drives his
 * animation state. Spawned normally he is a deadly boss that hurls Dismantle slashes.
 */
public class SukunaEntity extends PathfinderMob implements GeoEntity {
    public static final int STATE_AUTO = 0, STATE_IDLE = 1, STATE_TAUNT = 2, STATE_SLASH = 3, STATE_WALK = 4, STATE_DIG = 5, STATE_VANISH = 6, STATE_DOMAIN = 7, STATE_EAT = 8, STATE_DASH = 9, STATE_COMBO = 10, STATE_RECOIL = 11, STATE_CHARGE = 12;
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(SukunaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> ANIM_SPEED = SynchedEntityData.defineId(SukunaEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> CINEMATIC = SynchedEntityData.defineId(SukunaEntity.class, EntityDataSerializers.BOOLEAN);

    private final boolean trueForm;
    private final String model;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle, walk, run, taunt, slash, dig, vanish, domain, eat, dash, combo, recoil, charge;
    private int lifetime = -1;
    private int slashCd = 60;

    public SukunaEntity(EntityType<? extends PathfinderMob> type, Level level, boolean trueForm) {
        super(type, level);
        this.trueForm = trueForm;
        this.model = trueForm ? "sukuna_true_form" : "ryomen_sukuna";
        idle = KocAnims.loop(model, "idle"); walk = KocAnims.loop(model, "walk"); run = KocAnims.loop(model, "run");
        taunt = KocAnims.onceThenIdle(model, "taunt"); slash = KocAnims.onceThenIdle(model, "slash"); dig = KocAnims.loop(model, "dig");
        vanish = KocAnims.hold(model, "vanish"); domain = KocAnims.loop(model, "domain"); eat = KocAnims.onceThenIdle(model, "eat_finger");
        dash = KocAnims.loop(model, "dash"); combo = KocAnims.loop(model, "combo"); recoil = KocAnims.onceThenIdle(model, "recoil"); charge = KocAnims.loop(model, "charge");
        this.xpReward = 300;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 48.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(STATE, STATE_AUTO);
        entityData.define(ANIM_SPEED, 1.0f);
        entityData.define(CINEMATIC, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25D, true));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 12.0f));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Puts Sukuna into director-controlled mode for {@code ticks}. */
    public void setupCinematic(int ticks) {
        entityData.set(CINEMATIC, true);
        setNoAi(true);
        setInvulnerable(true);
        setNoGravity(true);
        setPersistenceRequired();
        lifetime = ticks;
        entityData.set(STATE, STATE_IDLE);
    }

    public boolean isCinematic() { return entityData.get(CINEMATIC); }
    public void setState(int s) { entityData.set(STATE, s); }
    public int getState() { return entityData.get(STATE); }
    public void setAnimSpeed(float f) { entityData.set(ANIM_SPEED, f); }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && lifetime > 0 && --lifetime == 0) discard();
        if (level().isClientSide && random.nextInt(3) == 0 && getState() != STATE_VANISH) {
            level().addParticle(ModParticles.CURSED_ENERGY.get(), getRandomX(0.5), getRandomY(), getRandomZ(0.5), 0, 0.03, 0);
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (isCinematic()) return;
        LivingEntity t = getTarget();
        if (slashCd > 0) { slashCd--; return; }
        if (t != null && t.isAlive() && distanceTo(t) < 20 && hasLineOfSight(t)) {
            triggerAnim("main", "slash");
            DismantleSlashEntity s = new DismantleSlashEntity(level(), this, (float) getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.8f, 3);
            double dx = t.getX() - getX(), dy = t.getY(0.5) - getEyeY(), dz = t.getZ() - getZ();
            s.shoot(dx, dy, dz, 2.4f, 1.0f);
            level().addFreshEntity(s);
            playSound(ModSounds.DISMANTLE.get(), 1.2f, 0.9f);
            slashCd = trueForm ? 25 : 45;
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        triggerAnim("main", "attack");
        return super.doHurtTarget(target);
    }

    @Override public boolean isInvulnerableTo(DamageSource source) { return isCinematic() || super.isInvulnerableTo(source); }
    @Override public boolean shouldBeSaved() { return !isCinematic() && super.shouldBeSaved(); }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return !isCinematic(); }
    @Override protected SoundEvent getAmbientSound() { return isCinematic() ? null : ModSounds.SUKUNA_LAUGH.get(); }
    @Override public int getAmbientSoundInterval() { return 400; }
    @Override protected SoundEvent getDeathSound() { return ModSounds.SUKUNA_ROAR.get(); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::predicate)
                .triggerableAnim("attack", KocAnims.once(model, "attack"))
                .triggerableAnim("slash", KocAnims.once(model, "slash"))
                .triggerableAnim("domain", KocAnims.once(model, "domain")));
    }

    private PlayState predicate(AnimationState<SukunaEntity> state) {
        state.getController().setAnimationSpeed(entityData.get(ANIM_SPEED));
        switch (getState()) {
            case STATE_IDLE: return state.setAndContinue(idle);
            case STATE_TAUNT: return state.setAndContinue(taunt);
            case STATE_SLASH: return state.setAndContinue(slash);
            case STATE_WALK: return state.setAndContinue(walk);
            case STATE_DIG: return state.setAndContinue(dig);
            case STATE_VANISH: return state.setAndContinue(vanish);
            case STATE_DOMAIN: return state.setAndContinue(domain);
            case STATE_EAT: return state.setAndContinue(eat);
            case STATE_DASH: return state.setAndContinue(dash);
            case STATE_COMBO: return state.setAndContinue(combo);
            case STATE_RECOIL: return state.setAndContinue(recoil);
            case STATE_CHARGE: return state.setAndContinue(charge);
            default: break;
        }
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
