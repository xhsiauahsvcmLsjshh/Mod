package com.kingofcurses.entity;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Gojo Satoru: the cinematic victim. Spawned from an egg he hunts players who embraced Sukuna; projectiles stop at his Infinity. */
public class GojoEntity extends PathfinderMob implements GeoEntity {
    public static final int STATE_AUTO = 0, STATE_IDLE = 1, STATE_INFINITY = 2, STATE_CUT = 3, STATE_BLUE = 4, STATE_RED = 5, STATE_DEAD = 6,
            STATE_STABBED = 7, STATE_FALLEN = 8, STATE_RISE = 9, STATE_PURPLE = 10;   // v1.0.18 Strongest of Today intro
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(GojoEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> ANIM_SPEED = SynchedEntityData.defineId(GojoEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> CINEMATIC = SynchedEntityData.defineId(GojoEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> CORPSE = SynchedEntityData.defineId(GojoEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> BLINDFOLD = SynchedEntityData.defineId(GojoEntity.class, EntityDataSerializers.BOOLEAN);
    private static final String M = "gojo_satoru";

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle = KocAnims.loop(M, "idle"), walk = KocAnims.loop(M, "walk"), run = KocAnims.loop(M, "run"),
            infinity = KocAnims.loop(M, "infinity"), cut = KocAnims.hold(M, "cut_in_half"),
            blue = RawAnimation.begin().thenPlay(KocAnims.key(M, "blue")).thenLoop(KocAnims.key(M, "infinity")),
            red = RawAnimation.begin().thenPlay(KocAnims.key(M, "red")).thenLoop(KocAnims.key(M, "infinity")),
            dead = KocAnims.loop(M, "dead"),
            stabbed = RawAnimation.begin().thenPlay(KocAnims.key(M, "stabbed")).thenLoop(KocAnims.key(M, "idle")),
            fallen = KocAnims.hold(M, "fall_dead"), rise = KocAnims.hold(M, "rise"), purple = KocAnims.hold(M, "purple");
    private int lifetime = -1;

    public GojoEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 48.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(STATE, STATE_AUTO);
        entityData.define(ANIM_SPEED, 1.0f);
        entityData.define(CINEMATIC, false);
        entityData.define(CORPSE, false);
        entityData.define(BLINDFOLD, true);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3D, true));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 12.0f));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                e -> e instanceof Player p && CursedCapability.get(p).map(d -> d.ending() == CursedData.ENDING_EMBRACE).orElse(false)));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, CursedSpiritEntity.class, true));
    }

    public void setupCinematic(int ticks) {
        entityData.set(CINEMATIC, true);
        setNoAi(true);
        setInvulnerable(true);
        setNoGravity(true);
        setPersistenceRequired();
        lifetime = ticks;
        entityData.set(STATE, STATE_IDLE);
    }

    public boolean isCinematic() { return entityData.get(CINEMATIC); }
    public boolean isCorpse() { return entityData.get(CORPSE); }
    public boolean hasBlindfold() { return entityData.get(BLINDFOLD); }

    /** Turns the cut cinematic Gojo into permanent, saved remains that keep bleeding. */
    public void makeCorpse() {
        entityData.set(CINEMATIC, true);
        entityData.set(CORPSE, true);
        setNoAi(true);
        setInvulnerable(true);
        setNoGravity(true);
        setPersistenceRequired();
        lifetime = -1;
        if (getState() != STATE_CUT) setState(STATE_CUT);
    }

    @Override
    protected net.minecraft.world.InteractionResult mobInteract(Player player, net.minecraft.world.InteractionHand hand) {
        if (isCorpse() && hasBlindfold()) {
            if (!level().isClientSide) {
                entityData.set(BLINDFOLD, false);
                net.minecraft.world.item.ItemStack band = new net.minecraft.world.item.ItemStack(com.kingofcurses.registry.ModItems.GOJO_BLINDFOLD.get());
                if (!player.getInventory().add(band)) player.drop(band, false);
                playSound(net.minecraft.sounds.SoundEvents.ARMOR_EQUIP_LEATHER, 1.0f, 0.8f);
                playSound(ModSounds.GOJO_INFINITY.get(), 0.5f, 1.6f);
                player.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.kingofcurses.blindfold_taken").withStyle(net.minecraft.ChatFormatting.AQUA), true);
            }
            return net.minecraft.world.InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Corpse", isCorpse());
        tag.putBoolean("Blindfold", hasBlindfold());
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Blindfold")) entityData.set(BLINDFOLD, tag.getBoolean("Blindfold"));
        if (tag.getBoolean("Corpse")) { makeCorpse(); setState(STATE_DEAD); }
    }
    public void setState(int s) { entityData.set(STATE, s); }
    public int getState() { return entityData.get(STATE); }
    /** Remaining ticks before the (cinematic) entity removes itself. */
    public void setLifetime(int ticks) { lifetime = ticks; }
    public void setAnimSpeed(float f) { entityData.set(ANIM_SPEED, f); }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && lifetime > 0) {
            lifetime--;
            if (lifetime == 0) {
                if (level() instanceof net.minecraft.server.level.ServerLevel sl && getState() == STATE_CUT)
                    sl.sendParticles(com.kingofcurses.registry.ModParticles.CURSED_ENERGY.get(), getX(), getY() + 0.5, getZ(), 60, 0.6, 0.4, 0.6, 0.05);
                discard();
            }
        }
        int bleed = isCorpse() && tickCount > 1200 ? 14 : 3;
        if (level().isClientSide && (getState() == STATE_CUT || getState() == STATE_DEAD || getState() == STATE_FALLEN) && random.nextInt(bleed) == 0) {
            // the halves keep bleeding: drips from both cut surfaces and from the spreading pool
            level().addParticle(com.kingofcurses.registry.ModParticles.BLOOD.get(), getX() + random.nextGaussian() * 0.25, getY() + 0.45 + random.nextDouble() * 0.2, getZ() + random.nextGaussian() * 0.25, 0, 0.02, 0);
            if (random.nextInt(4) == 0) level().addParticle(com.kingofcurses.registry.ModParticles.BLOOD.get(), getX() + random.nextGaussian() * 0.6, getY() + 0.12, getZ() + random.nextGaussian() * 0.6, 0, 0.01, 0);
        }
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (isCinematic()) return true;
        if (source.getDirectEntity() instanceof Projectile) { playSound(ModSounds.GOJO_INFINITY.get(), 0.6f, 1.4f); return true; } // Infinity
        return super.isInvulnerableTo(source);
    }

    @Override public boolean shouldBeSaved() { return (isCorpse() || !isCinematic()) && super.shouldBeSaved(); }
    @Override public boolean isPushable() { return !isCinematic(); }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::predicate));
    }

    private PlayState predicate(AnimationState<GojoEntity> state) {
        state.getController().setAnimationSpeed(entityData.get(ANIM_SPEED));
        int s = entityData.get(STATE);
        if (s == STATE_CUT) return state.setAndContinue(cut);
        if (s == STATE_STABBED) return state.setAndContinue(stabbed);
        if (s == STATE_FALLEN) return state.setAndContinue(fallen);
        if (s == STATE_RISE) return state.setAndContinue(rise);
        if (s == STATE_PURPLE) return state.setAndContinue(purple);
        if (s == STATE_DEAD) return state.setAndContinue(dead);
        if (s == STATE_INFINITY) return state.setAndContinue(infinity);
        if (s == STATE_BLUE) return state.setAndContinue(blue);
        if (s == STATE_RED) return state.setAndContinue(red);
        if (s == STATE_IDLE) return state.setAndContinue(idle);
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
