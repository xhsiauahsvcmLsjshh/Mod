package com.kingofcurses.entity;

import com.kingofcurses.registry.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/** The visible Malevolent Shrine that rises behind the caster during Domain Expansion. Purely visual and never saved. */
public class MalevolentShrineEntity extends Entity implements GeoEntity {
    private static final RawAnimation RISE = RawAnimation.begin().thenPlay(KocAnims.key("malevolent_shrine", "rise")).thenLoop(KocAnims.key("malevolent_shrine", "idle"));
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int lifetime = 600;

    public MalevolentShrineEntity(EntityType<? extends MalevolentShrineEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
    }

    public void setLifetime(int ticks) { lifetime = ticks; }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && --lifetime <= 0) discard();
        if (level().isClientSide) {
            for (int i = 0; i < 3; i++) level().addParticle(ModParticles.DOMAIN_ASH.get(), getRandomX(3.0), getY() + random.nextDouble() * 6, getRandomZ(3.0), 0, 0.02, 0);
        }
    }

    @Override protected void defineSynchedData() { }
    @Override protected void readAdditionalSaveData(CompoundTag tag) { }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { }
    @Override public boolean shouldBeSaved() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 0, state -> state.setAndContinue(RISE)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
