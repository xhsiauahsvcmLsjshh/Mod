package com.kingofcurses.entity;

import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.RipAnimPacket;
import com.kingofcurses.registry.ModItems;
import com.kingofcurses.registry.ModParticles;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.network.PacketDistributor;

import java.util.UUID;

/** v1.0.17: Sukuna's torn arm. Held in his upper left hand, then hurled in an arc straight into the player's hands. */
public class SukunaArmEntity extends Entity {
    public static final int FLIGHT = 16;
    private int ownerId = -1;
    private UUID target;
    private int holdTicks;
    private int age;
    private Vec3 from;

    public SukunaArmEntity(EntityType<? extends SukunaArmEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
    }

    public void setup(HeianSukunaEntity owner, UUID target, int holdTicks) {
        this.ownerId = owner.getId(); this.target = target; this.holdTicks = holdTicks;
    }

    @Override protected void defineSynchedData() { }

    @Override
    public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel sl)) return;
        age++;
        ServerPlayer p = target == null ? null : (ServerPlayer) sl.getPlayerByUUID(target);
        Entity owner = sl.getEntity(ownerId);
        if (age > 200 || p == null || p.level() != sl) { drop(sl); return; }
        if (age <= holdTicks) {                                   // held up high, dripping
            if (owner instanceof HeianSukunaEntity s) { Vec3 h = s.local(-1.6, 4.4 + age * 0.02, 0.2); setPos(h.x, h.y, h.z); }
            if (age % 2 == 0) sl.sendParticles(ModParticles.BLOOD.get(), getX(), getY(), getZ(), 2, 0.1, 0.1, 0.1, 0.02);
            from = position();
            return;
        }
        int f = age - holdTicks;
        Vec3 to = p.getEyePosition().add(p.getLookAngle().scale(0.6)).subtract(0, 0.35, 0);
        double k = Math.min(1.0, f / (double) FLIGHT);
        Vec3 pos = from.lerp(to, k).add(0, Math.sin(k * Math.PI) * 2.2, 0);
        setPos(pos.x, pos.y, pos.z);
        sl.sendParticles(ModParticles.BLOOD.get(), getX(), getY(), getZ(), 1, 0.05, 0.05, 0.05, 0.0);
        if (k >= 1.0) catchIt(sl, p);
    }

    private void catchIt(ServerLevel sl, ServerPlayer p) {
        ItemStack arm = new ItemStack(ModItems.SUKUNA_ARM.get());
        if (!p.getInventory().add(arm)) p.drop(arm, false);
        sl.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0f, 0.6f);
        sl.playSound(null, p.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 1.0f, 0.8f);
        p.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new RipAnimPacket(p.getId(), RipAnimPacket.FINISHER, 7));
        p.displayClientMessage(Component.translatable("message.kingofcurses.arm_caught").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), true);
        discard();
    }

    private void drop(ServerLevel sl) {
        sl.addFreshEntity(new ItemEntity(sl, getX(), getY(), getZ(), new ItemStack(ModItems.SUKUNA_ARM.get())));
        discard();
    }

    public float spin(float pt) { return (tickCount + pt) * 28f; }

    @Override protected void readAdditionalSaveData(CompoundTag tag) { }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { }
    @Override public boolean shouldBeSaved() { return false; }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
