package com.kingofcurses.entity;

import com.kingofcurses.ability.EndingLogic;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.UUID;

/** Final boss: Tengen's Sealing Master arrives when a player has consumed all twenty fingers. */
public class SealingMasterEntity extends SorcererEntity {
    private final ServerBossEvent bossEvent = new ServerBossEvent(getDisplayName(), BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.NOTCHED_10);
    @Nullable private UUID challenger;
    private boolean summoned, barrier;

    public SealingMasterEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level, Kind.MASTER);
    }

    public void setChallenger(UUID id) { this.challenger = id; }
    @Nullable public UUID getChallenger() { return challenger; }

    @Override
    public boolean isHostileTo(LivingEntity e) { return e instanceof Player; }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
        float pct = getHealth() / getMaxHealth();
        if (!summoned && pct < 0.5f && level() instanceof ServerLevel sl) {
            summoned = true;
            triggerAnim("main", "domain");
            for (int i = 0; i < 2; i++) {
                SorcererEntity s = ModEntities.SORCERER_ELITE.get().create(sl);
                if (s != null) {
                    s.moveTo(getX() + random.nextGaussian() * 2, getY(), getZ() + random.nextGaussian() * 2, getYRot(), 0);
                    s.setTarget(getTarget());
                    sl.addFreshEntity(s);
                }
            }
        }
        if (!barrier && pct < 0.25f && level() instanceof ServerLevel sl) {
            barrier = true;
            triggerAnim("main", "domain");
            for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(16))) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 2));
                p.addEffect(new MobEffectInstance(com.kingofcurses.registry.ModEffects.SEALED.get(), 160, 0));
            }
            sl.sendParticles(ModParticles.RESONANCE.get(), getX(), getY() + 1, getZ(), 200, 6, 2, 6, 0.02);
        }
        if (tickCount % 5 == 0 && level() instanceof ServerLevel sl) sl.sendParticles(ModParticles.RESONANCE.get(), getX(), getY() + 2.2, getZ(), 2, 0.6, 0.3, 0.6, 0.0);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide) EndingLogic.onBossDefeated(this, challenger);
    }

    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossEvent.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossEvent.removePlayer(p); }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (challenger != null) tag.putUUID("Challenger", challenger);
        tag.putBoolean("Summoned", summoned);
        tag.putBoolean("Barrier", barrier);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Challenger")) challenger = tag.getUUID("Challenger");
        summoned = tag.getBoolean("Summoned");
        barrier = tag.getBoolean("Barrier");
    }
}
