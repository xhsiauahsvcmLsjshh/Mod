package com.kingofcurses.entity;

import com.kingofcurses.KocConfig;
import com.kingofcurses.ability.DomainManager;
import com.kingofcurses.ability.EndingLogic;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModItems;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * v1.0.4 final boss: Gojo Satoru's body, taken over by Yuta Okkotsu through Kenjaku's brain-swap technique
 * (Kenjaku's stitches run across his forehead). Infinity blocks projectiles and dulls every other hit, unless it is broken by
 * the Black Rope, the Prison Realm, the Inverted Spear of Heaven, an active Malevolent Shrine, or the World Cutting Slash.
 */
public class GojoKenjakuEntity extends PathfinderMob implements GeoEntity {
    /** Set by sure-hit / space-cutting techniques around their hurt() call (World Cutting Slash cuts through Infinity). */
    public static boolean SURE_HIT = false;
    private static final String M = "gojo_satoru";
    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.25f, 0.55f, 1.0f), 1.6f);
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(1.0f, 0.12f, 0.15f), 1.8f);
    private static final DustParticleOptions PURPLE = new DustParticleOptions(new Vector3f(0.62f, 0.2f, 1.0f), 2.4f);
    private static final DustParticleOptions VOID = new DustParticleOptions(new Vector3f(0.92f, 0.95f, 1.0f), 2.0f);

    private final ServerBossEvent bossEvent = new ServerBossEvent(getDisplayName(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle = KocAnims.loop(M, "idle"), walk = KocAnims.loop(M, "walk"), run = KocAnims.loop(M, "run"), guard = KocAnims.loop(M, "infinity");

    @Nullable private UUID challenger;
    private boolean phase2, voidUsed;
    private int infinityBroken, blueCd = 80, redCd = 140, blinkCd = 100, purpleCd = 200, purpleCharge = -1, hintCd;
    private Vec3 purpleDir = Vec3.ZERO;

    public GojoKenjakuEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, Math.max(knockback, 0.8));
    }

    public void setChallenger(UUID id) { this.challenger = id; }
    @Nullable public UUID getChallenger() { return challenger; }
    public void breakInfinity(int ticks) {
        infinityBroken = Math.max(infinityBroken, ticks);
        if (level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1, getZ(), 40, 0.5, 1.0, 0.5, 0.2);
    }
    public boolean infinityUp() { return infinityBroken <= 0; }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25D, true));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 16.0f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // v1.0.8: only those who carry Sukuna, and hostile mobs; never ordinary players
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, com.kingofcurses.ability.KocTargets::hasSukuna));
        targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false, com.kingofcurses.ability.KocTargets::isFoe));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        float pct = getHealth() / getMaxHealth();
        bossEvent.setProgress(pct);
        if (infinityBroken > 0) infinityBroken--;
        if (hintCd > 0) hintCd--;
        if (blueCd > 0) blueCd--;
        if (redCd > 0) redCd--;
        if (blinkCd > 0) blinkCd--;
        if (purpleCd > 0) purpleCd--;
        if (tickCount % 4 == 0 && infinityUp()) sl.sendParticles(BLUE, getX(), getY() + 1.0, getZ(), 1, 0.45, 0.8, 0.45, 0);

        if (!phase2 && pct < 0.5f) {
            phase2 = true;
            triggerAnim("main", "taunt");
            tell(sl, Component.translatable("message.kingofcurses.boss_phase2").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.ITALIC));
            var speed = getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) speed.setBaseValue(speed.getBaseValue() * 1.2);
            sl.sendParticles(PURPLE, getX(), getY() + 1, getZ(), 160, 1.2, 1.4, 1.2, 0.05);
            playSound(ModSounds.CURSED_ENERGY_BURST.get(), 2.0f, 0.6f);
        }
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive()) { purpleCharge = -1; return; }

        if (purpleCharge >= 0) { tickPurple(sl, t); return; }
        if (!voidUsed && pct < 0.3f) { unlimitedVoid(sl); return; }

        double dist = distanceTo(t);
        boolean sees = hasLineOfSight(t);
        if (blinkCd <= 0 && dist < 48 && (dist > 12 || random.nextInt(5) == 0)) { blink(sl, t); blinkCd = phase2 ? 80 : 140; }
        else if (phase2 && purpleCd <= 0 && sees && dist < 36) { startPurple(sl); purpleCd = 420; }
        else if (blueCd <= 0 && sees && dist < 20) { lapseBlue(sl, t); blueCd = phase2 ? 90 : 140; }
        else if (redCd <= 0 && sees && dist < 16) { reversalRed(sl, t); redCd = phase2 ? 120 : 180; }
    }

    private void tell(ServerLevel sl, Component msg) {
        for (ServerPlayer p : sl.getPlayers(p -> p.distanceToSqr(this) < 64 * 64)) p.displayClientMessage(msg, false);
    }

    /** Lapse Blue: an attraction point that drags the target in. */
    private void lapseBlue(ServerLevel sl, LivingEntity t) {
        triggerAnim("main", "blue");
        Vec3 mid = position().add(t.position()).scale(0.5).add(0, 1, 0);
        Vec3 pull = position().subtract(t.position()).normalize();
        t.setDeltaMovement(pull.scale(1.3).add(0, 0.35, 0));
        t.hurtMarked = true;
        t.hurt(damageSources().mobAttack(this), phase2 ? 8f : 6f);
        for (int i = 0; i < 40; i++) {
            double a = i / 40.0 * Math.PI * 2;
            sl.sendParticles(BLUE, mid.x + Math.cos(a) * 1.4, mid.y + Math.sin(a * 2) * 0.5, mid.z + Math.sin(a) * 1.4, 1, 0, 0, 0, 0);
        }
        sl.sendParticles(BLUE, mid.x, mid.y, mid.z, 50, 0.3, 0.3, 0.3, 0.02);
        sl.playSound(null, blockPosition(), ModSounds.GOJO_INFINITY.get(), SoundSource.HOSTILE, 2.0f, 0.6f);
    }

    /** Reversal Red: a repulsion blast at the target. */
    private void reversalRed(ServerLevel sl, LivingEntity t) {
        triggerAnim("main", "red");
        Vec3 c = t.position().add(0, 1, 0);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(3.5), e -> e != this && e.isAlive() && (e == t || com.kingofcurses.ability.KocTargets.isFoe(e)))) {
            e.hurt(damageSources().mobAttack(this), phase2 ? 13f : 10f);
            Vec3 push = e.position().subtract(position()).normalize();
            e.setDeltaMovement(push.scale(2.0).add(0, 0.6, 0));
            e.hurtMarked = true;
        }
        sl.sendParticles(RED, c.x, c.y, c.z, 120, 1.2, 1.2, 1.2, 0.1);
        sl.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 3, 0.5, 0.5, 0.5, 0);
        sl.playSound(null, BlockPos.containing(c), ModSounds.FUGA_EXPLODE.get(), SoundSource.HOSTILE, 2.0f, 1.5f);
    }

    /** Teleports right behind the target. */
    private void blink(ServerLevel sl, LivingEntity t) {
        Vec3 back = t.getLookAngle().multiply(1, 0, 1);
        if (back.lengthSqr() < 1.0E-4) back = new Vec3(0, 0, 1);
        Vec3 dest = t.position().subtract(back.normalize().scale(2.5));
        sl.sendParticles(BLUE, getX(), getY() + 1, getZ(), 40, 0.4, 0.9, 0.4, 0.05);
        if (randomTeleport(dest.x, t.getY(), dest.z, false)) {
            triggerAnim("main", "dash");
            lookAt(t, 360, 360);
            sl.sendParticles(BLUE, getX(), getY() + 1, getZ(), 40, 0.4, 0.9, 0.4, 0.05);
            sl.playSound(null, blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.0f, 1.6f);
        }
    }

    private void startPurple(ServerLevel sl) {
        purpleCharge = 0;
        triggerAnim("main", "charge");
        getNavigation().stop();
        tell(sl, Component.translatable("message.kingofcurses.boss_purple").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
        sl.playSound(null, blockPosition(), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.HOSTILE, 2.5f, 0.5f);
    }

    /** Hollow Purple: 2 s charge (aim locks 0.75 s before release, so it can be dodged), then an erasing beam. */
    private void tickPurple(ServerLevel sl, LivingEntity t) {
        purpleCharge++;
        getNavigation().stop();
        if (purpleCharge < 25) { lookAt(t, 30, 30); purpleDir = t.getEyePosition().subtract(getEyePosition()).normalize(); }
        Vec3 hand = getEyePosition().add(purpleDir.scale(1.0));
        double r = 0.9 - purpleCharge * 0.02;
        sl.sendParticles(BLUE, hand.x + Math.cos(purpleCharge * 0.5) * r, hand.y, hand.z + Math.sin(purpleCharge * 0.5) * r, 2, 0.02, 0.02, 0.02, 0);
        sl.sendParticles(RED, hand.x - Math.cos(purpleCharge * 0.5) * r, hand.y, hand.z - Math.sin(purpleCharge * 0.5) * r, 2, 0.02, 0.02, 0.02, 0);
        if (purpleCharge < 40) return;
        purpleCharge = -1;
        triggerAnim("main", "red");
        boolean grief = KocConfig.bool(KocConfig.ABILITY_GRIEFING, false);
        Set<Integer> hit = new HashSet<>();
        Vec3 start = getEyePosition();
        for (double d = 1; d <= 42; d += 0.5) {
            Vec3 p = start.add(purpleDir.scale(d));
            if (((int) (d * 2)) % 2 == 0) { sl.sendParticles(PURPLE, p.x, p.y, p.z, 6, 0.7, 0.7, 0.7, 0.02); sl.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.4, 0.4, 0.4, 0.01); }
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(p, p).inflate(2.2), e -> e != this && e.isAlive() && com.kingofcurses.ability.KocTargets.isFoe(e))) {
                if (hit.add(e.getId())) { e.invulnerableTime = 0; e.hurt(damageSources().indirectMagic(this, this), 28f); }
            }
            if (grief) {
                BlockPos bp = BlockPos.containing(p);
                for (BlockPos q : BlockPos.betweenClosed(bp.offset(-1, -1, -1), bp.offset(1, 1, 1))) {
                    BlockState st = sl.getBlockState(q);
                    float hard = st.getDestroySpeed(sl, q);
                    if (!st.isAir() && hard >= 0 && hard < 50) sl.removeBlock(q, false);
                }
            }
        }
        sl.playSound(null, blockPosition(), ModSounds.WORLD_SLASH.get(), SoundSource.HOSTILE, 3.0f, 0.5f);
        sl.playSound(null, blockPosition(), ModSounds.FUGA_EXPLODE.get(), SoundSource.HOSTILE, 3.0f, 0.6f);
    }

    /** Unlimited Void (once, below 30 % health). A player with an open Malevolent Shrine clashes with it and is barely touched. */
    private void unlimitedVoid(ServerLevel sl) {
        voidUsed = true;
        triggerAnim("main", "domain");
        sl.playSound(null, blockPosition(), ModSounds.DOMAIN_EXPANSION.get(), SoundSource.HOSTILE, 4.0f, 1.3f);
        sl.sendParticles(VOID, getX(), getY() + 1, getZ(), 400, 8, 3, 8, 0.02);
        for (ServerPlayer p : sl.getPlayers(p -> p.distanceToSqr(this) < 22 * 22 && com.kingofcurses.ability.KocTargets.hasSukuna(p))) {
            boolean clash = DomainManager.isActive(p.getUUID());
            int ticks = clash ? 40 : 120;
            p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, ticks, 0));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, clash ? 1 : 4));
            p.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, ticks, 2));
            if (!clash) p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 1));
            ModNetwork.sendTo(p, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 30, 1.0f));
            p.displayClientMessage(Component.translatable("message.kingofcurses.boss_void").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
            if (clash) {
                p.displayClientMessage(Component.translatable("message.kingofcurses.boss_void_clash").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
                breakInfinity(200);
            }
        }
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (target != null && !com.kingofcurses.ability.KocTargets.isFoe(target)) return;
        super.setTarget(target);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        triggerAnim("main", "combo");
        return super.doHurtTarget(target);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        Entity attacker = source.getEntity();
        boolean bypass = !infinityUp() || SURE_HIT;
        if (attacker instanceof Player p) {
            if (DomainManager.isActive(p.getUUID())) bypass = true;                          // sure-hit
            if (p.getMainHandItem().is(ModItems.INVERTED_SPEAR_OF_HEAVEN.get())) bypass = true; // nullifies techniques
        }
        if (!bypass) {
            if (source.getDirectEntity() instanceof Projectile) { playSound(ModSounds.GOJO_INFINITY.get(), 0.8f, 1.4f); return false; }
            amount *= 0.35f;
            if (level() instanceof ServerLevel sl) sl.sendParticles(BLUE, getX(), getY() + 1.2, getZ(), 8, 0.4, 0.5, 0.4, 0.02);
            if (attacker instanceof ServerPlayer sp && hintCd <= 0) {
                hintCd = 200;
                sp.displayClientMessage(Component.translatable("message.kingofcurses.boss_infinity").withStyle(ChatFormatting.AQUA), true);
            }
        }
        return super.hurt(source, amount);
    }

    @Override public boolean causeFallDamage(float dist, float mult, DamageSource src) { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossEvent.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossEvent.removePlayer(p); }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(PURPLE, getX(), getY() + 1, getZ(), 200, 1.0, 1.5, 1.0, 0.1);
            EndingLogic.onBossDefeated(this, challenger);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (challenger != null) tag.putUUID("Challenger", challenger);
        tag.putBoolean("Phase2", phase2);
        tag.putBoolean("VoidUsed", voidUsed);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Challenger")) challenger = tag.getUUID("Challenger");
        phase2 = tag.getBoolean("Phase2");
        voidUsed = tag.getBoolean("VoidUsed");
        if (hasCustomName()) bossEvent.setName(getDisplayName());
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::predicate)
                .triggerableAnim("blue", KocAnims.once(M, "blue"))
                .triggerableAnim("red", KocAnims.once(M, "red"))
                .triggerableAnim("dash", KocAnims.once(M, "dash"))
                .triggerableAnim("combo", KocAnims.once(M, "combo"))
                .triggerableAnim("charge", KocAnims.once(M, "charge"))
                .triggerableAnim("domain", KocAnims.once(M, "domain"))
                .triggerableAnim("taunt", KocAnims.once(M, "taunt")));
    }

    private PlayState predicate(AnimationState<GojoKenjakuEntity> state) {
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(getTarget() != null ? guard : idle);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    static float wrap(float f) { return Mth.wrapDegrees(f); }
}
