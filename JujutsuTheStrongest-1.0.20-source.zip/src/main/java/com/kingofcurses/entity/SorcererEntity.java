package com.kingofcurses.entity;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Jujutsu sorcerers. Hostile towards players who become too cursed (or who embraced Sukuna),
 * allied with players who rejected him, and always hostile to cursed spirits.
 */
public class SorcererEntity extends PathfinderMob implements GeoEntity {
    public enum Kind {
        SORCERER("jujutsu_sorcerer", 5, 100, 6f), ELITE("sorcerer_elite", 3, 70, 9f), STUDENT("jujutsu_student", 99, 140, 4f), MASTER("sealing_master", 0, 50, 10f);
        public final String model; public final int huntThreshold; public final int specialCooldown; public final float talismanDamage;
        Kind(String model, int huntThreshold, int specialCooldown, float talismanDamage) {
            this.model = model; this.huntThreshold = huntThreshold; this.specialCooldown = specialCooldown; this.talismanDamage = talismanDamage;
        }
    }

    protected final Kind kind;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle, walk, run;
    private int specialCd = 60;

    public SorcererEntity(EntityType<? extends PathfinderMob> type, Level level, Kind kind) {
        super(type, level);
        this.kind = kind;
        this.idle = KocAnims.loop(kind.model, "idle");
        this.walk = KocAnims.loop(kind.model, "walk");
        this.run = KocAnims.loop(kind.model, "run");
        this.xpReward = kind == Kind.MASTER ? 200 : 10;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg).add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 40.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, CursedSpiritEntity.class, 10, true, false, null));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, this::isHostileTo));
    }

    public boolean isHostileTo(LivingEntity e) {
        if (!(e instanceof Player p) || kind == null) return false;
        CursedData d = CursedCapability.get(p).orElse(null);
        if (d == null) return false;
        if (d.ending() == CursedData.ENDING_REJECT) return false;
        if (d.ending() == CursedData.ENDING_EMBRACE) return true;
        return d.fingers() >= kind.huntThreshold;
    }

    @Override
    public void setTarget(LivingEntity target) {
        // allies never turn on a player who sealed Sukuna, even when hit by accident
        if (target instanceof Player p && CursedCapability.get(p).map(d -> d.ending() == CursedData.ENDING_REJECT).orElse(false) && kind != Kind.MASTER) return;
        super.setTarget(target);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (specialCd > 0) { specialCd--; return; }
        LivingEntity t = getTarget();
        if (t != null && t.isAlive() && distanceTo(t) < 14 && hasLineOfSight(t)) {
            talismanStrike(t);
            specialCd = kind.specialCooldown + random.nextInt(30);
        }
    }

    protected void talismanStrike(LivingEntity t) {
        triggerAnim("main", "cast");
        t.hurt(damageSources().mobAttack(this), kind.talismanDamage);
        if (t instanceof Player && kind != Kind.STUDENT) t.addEffect(new MobEffectInstance(ModEffects.SEALED.get(), kind == Kind.SORCERER ? 60 : 110, 0));
        if (level() instanceof ServerLevel sl) {
            Vec3 a = getEyePosition(), b = t.getEyePosition();
            for (int i = 0; i <= 12; i++) {
                Vec3 p = a.add(b.subtract(a).scale(i / 12.0));
                sl.sendParticles(ParticleTypes.ENCHANTED_HIT, p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0);
            }
        }
        playSound(ModSounds.SEAL_RITUAL.get(), 0.6f, 1.6f);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        triggerAnim("main", "slash");
        return super.doHurtTarget(target);
    }

    @Override protected SoundEvent getHurtSound(DamageSource source) { return ModSounds.SORCERER_HURT.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.SORCERER_DEATH.get(); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 4, this::predicate)
                .triggerableAnim("slash", KocAnims.once(kind.model, "slash"))
                .triggerableAnim("cast", KocAnims.once(kind.model, "cast"))
                .triggerableAnim("domain", KocAnims.once(kind.model, "domain")));
    }

    private PlayState predicate(AnimationState<SorcererEntity> state) {
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
