package com.kingofcurses.entity;

import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** v1.0.20 evil sorcerer guarding the dark institutes: melee, and a cursed slash thrown from range. */
public class CurseUserEntity extends Monster implements GeoEntity {
    private static final String M = "curse_user";
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle = KocAnims.loop(M, "idle"), walk = KocAnims.loop(M, "walk"), run = KocAnims.loop(M, "run");
    private int castCd = 60;

    public CurseUserEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 12;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 32.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 12.0f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;
        LivingEntity t = getTarget();
        if (castCd > 0) { castCd--; return; }
        if (t != null && t.isAlive() && distanceToSqr(t) > 16 && distanceToSqr(t) < 400 && hasLineOfSight(t)) {
            castCd = 80 + random.nextInt(60);
            DismantleSlashEntity slash = new DismantleSlashEntity(level(), this, 5.0f, 1);
            double dx = t.getX() - getX(), dy = t.getEyeY() - getEyeY(), dz = t.getZ() - getZ();
            slash.shoot(dx, dy, dz, 1.8f, 2.0f);
            level().addFreshEntity(slash);
            playSound(ModSounds.DISMANTLE.get(), 0.8f, 1.2f);
            if (level() instanceof net.minecraft.server.level.ServerLevel sl)
                sl.sendParticles(ModParticles.CURSED_ENERGY.get(), getX(), getY() + 1.5, getZ(), 12, 0.3, 0.3, 0.3, 0.05);
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::predicate)
                .triggerableAnim("attack", KocAnims.once(M, "attack")));
    }

    private PlayState predicate(AnimationState<CurseUserEntity> state) {
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override
    public void swing(net.minecraft.world.InteractionHand hand, boolean update) {
        super.swing(hand, update);
        if (!level().isClientSide) triggerAnim("main", "attack");
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
