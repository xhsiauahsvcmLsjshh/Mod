package com.kingofcurses.entity;

import com.kingofcurses.KocConfig;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.HashSet;
import java.util.Set;

/** Dismantle: a fast, piercing, invisible-edge slash. */
public class DismantleSlashEntity extends Projectile implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final Set<Integer> hit = new HashSet<>();
    private float damage = 5.0f;
    private int pierce = 2;
    private int life;

    public DismantleSlashEntity(EntityType<? extends DismantleSlashEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
    }

    public DismantleSlashEntity(Level level, LivingEntity owner, float damage, int pierce) {
        this(ModEntities.DISMANTLE_SLASH.get(), level);
        setOwner(owner);
        setPos(owner.getX(), owner.getEyeY() - 0.25, owner.getZ());
        this.damage = damage;
        this.pierce = pierce;
    }

    @Override
    protected void defineSynchedData() { }

    @Override
    public void tick() {
        super.tick();
        Vec3 mv = getDeltaMovement();
        HitResult res = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
        if (res.getType() != HitResult.Type.MISS) onHit(res);
        if (isRemoved()) return;
        setPos(getX() + mv.x, getY() + mv.y, getZ() + mv.z);
        setYRot((float) (Mth.atan2(-mv.x, mv.z) * Mth.RAD_TO_DEG));
        if (level().isClientSide) {
            level().addParticle(ModParticles.SLASH.get(), getX(), getY(), getZ(), 0, 0, 0);
        } else if (++life > 30) {
            discard();
        }
    }

    @Override
    protected boolean canHitEntity(Entity e) {
        return super.canHitEntity(e) && !hit.contains(e.getId()) && e instanceof LivingEntity;
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (level().isClientSide) return;
        Entity e = result.getEntity();
        hit.add(e.getId());
        Entity owner = getOwner();
        DamageSource src = owner instanceof Player p ? damageSources().playerAttack(p) : damageSources().indirectMagic(this, owner);
        if (e instanceof LivingEntity le) com.kingofcurses.ability.SliceLogic.mark(le);
        e.hurt(src, damage);
        if (level() instanceof ServerLevel sl) sl.sendParticles(ModParticles.BLOOD.get(), e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ(), 14, 0.2, 0.3, 0.2, 0.15);
        if (--pierce <= 0) discard();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        if (level().isClientSide) return;
        BlockState st = level().getBlockState(result.getBlockPos());
        if (KocConfig.bool(KocConfig.ABILITY_GRIEFING, false) && (st.is(BlockTags.LEAVES) || st.is(BlockTags.REPLACEABLE) || st.is(BlockTags.FLOWERS))) {
            level().destroyBlock(result.getBlockPos(), true, getOwner());
            return;
        }
        if (level() instanceof ServerLevel sl) sl.sendParticles(ModParticles.SLASH.get(), getX(), getY(), getZ(), 3, 0.2, 0.2, 0.2, 0);
        discard();
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("Damage", damage); tag.putInt("Pierce", pierce); tag.putInt("Life", life);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        damage = tag.getFloat("Damage"); pierce = tag.getInt("Pierce"); life = tag.getInt("Life");
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 0, state -> state.setAndContinue(KocAnims.loop("dismantle_slash", "idle"))));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
