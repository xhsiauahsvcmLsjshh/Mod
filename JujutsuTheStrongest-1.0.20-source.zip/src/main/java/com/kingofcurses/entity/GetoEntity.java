package com.kingofcurses.entity;

import com.kingofcurses.item.ClueItem;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** v1.0.20 Suguru Geto at the Jujutsu Institute. Tells Gojo that Sukuna is back; right click him for your clue progress. */
public class GetoEntity extends PathfinderMob implements GeoEntity {
    private static final String M = "suguru_geto";
    private static final EntityDataAccessor<Boolean> TALKING = SynchedEntityData.defineId(GetoEntity.class, EntityDataSerializers.BOOLEAN);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle = KocAnims.loop(M, "idle"), walk = KocAnims.loop(M, "walk"), talk = KocAnims.loop(M, "talk");

    public GetoEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void defineSynchedData() { super.defineSynchedData(); entityData.define(TALKING, false); }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 10.0f, 1.0f));
        goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    public void setTalking(boolean t) { entityData.set(TALKING, t); }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (level().isClientSide) return InteractionResult.SUCCESS;
        int best = 0;
        for (ItemStack s : player.getInventory().items) if (s.getItem() instanceof ClueItem) best = Math.max(best, ClueItem.pieces(s));
        for (ItemStack s : player.getInventory().offhand) if (s.getItem() instanceof ClueItem) best = Math.max(best, ClueItem.pieces(s));
        String key = best == 0 ? "message.kingofcurses.geto_none" : best >= ClueItem.TOTAL ? "message.kingofcurses.geto_full" : "message.kingofcurses.geto_some";
        player.displayClientMessage(Component.translatable(key, best, ClueItem.TOTAL).withStyle(ChatFormatting.GOLD), false);
        return InteractionResult.CONSUME;
    }

    @Override public boolean isInvulnerableTo(DamageSource s) { return !s.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY); }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 4, this::predicate));
    }

    private PlayState predicate(AnimationState<GetoEntity> state) {
        if (entityData.get(TALKING)) return state.setAndContinue(talk);
        if (state.isMoving()) return state.setAndContinue(walk);
        return state.setAndContinue(idle);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
