package com.kingofcurses.entity;

import com.kingofcurses.ability.KocTargets;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;
import java.util.Locale;

/**
 * v1.0.8 famous sorcerers (KING OF CURSES difficulty). They hunt hostile mobs and anyone carrying Sukuna (players with fingers,
 * vessel creatures), and never attack ordinary players. Each one fights with their own technique.
 * Yuta also plays the boss ritual (stitching Gojo's body) as a no-AI actor.
 */
public class NamedSorcererEntity extends PathfinderMob implements GeoEntity {
    public enum Kind {
        YUTA_OKKOTSU(90), KINJI_HAKARI(80), MAKI_ZENIN(60), MEGUMI_FUSHIGURO(260), AOI_TODO(120), KENTO_NANAMI(100);
        public final int specialCd;
        Kind(int cd) { this.specialCd = cd; }
        public String model() { return name().toLowerCase(Locale.ROOT); }
    }
    public static final int ACTOR_NONE = 0, ACTOR_STITCH = 1, ACTOR_COLLAPSE = 2;
    private static final EntityDataAccessor<Integer> ACTOR = SynchedEntityData.defineId(NamedSorcererEntity.class, EntityDataSerializers.INT);
    private static final DustParticleOptions RIKA = new DustParticleOptions(new Vector3f(0.55f, 0.2f, 0.9f), 2.0f);
    private static final DustParticleOptions HAKARI = new DustParticleOptions(new Vector3f(0.3f, 1.0f, 0.75f), 1.4f);
    private static final DustParticleOptions SHADOW = new DustParticleOptions(new Vector3f(0.05f, 0.05f, 0.12f), 1.8f);

    public final Kind kind;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle, walk, run, stitch, collapse;
    private int specialCd = 60, jackpot, hits, rctCd;
    private boolean overtime;

    public NamedSorcererEntity(EntityType<? extends PathfinderMob> type, Level level, Kind kind) {
        super(type, level);
        this.kind = kind;
        String m = kind.model();
        idle = KocAnims.loop(m, "idle"); walk = KocAnims.loop(m, "walk"); run = KocAnims.loop(m, "run");
        stitch = kind == Kind.YUTA_OKKOTSU ? KocAnims.loop(m, "stitch") : idle;
        collapse = kind == Kind.YUTA_OKKOTSU ? KocAnims.hold(m, "collapse") : idle;
        this.xpReward = 30;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg).add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 40.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(ACTOR, ACTOR_NONE); }

    public void setActor(int state) {
        entityData.set(ACTOR, state);
        setNoAi(state != ACTOR_NONE);
        setInvulnerable(state != ACTOR_NONE);
        if (state != ACTOR_NONE) setPersistenceRequired();
    }
    public int actor() { return entityData.get(ACTOR); }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, kind == Kind.MAKI_ZENIN ? 1.45D : 1.2D, true));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, KocTargets::hasSukuna));
        targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false, KocTargets::isFoe));
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (target != null && !KocTargets.isFoe(target)) return;   // ordinary players are never attacked, even if they hit by accident
        super.setTarget(target);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (actor() != ACTOR_NONE || !(level() instanceof ServerLevel sl)) return;
        if (jackpot > 0) {
            jackpot--;
            if (jackpot % 10 == 0) { heal(4f); sl.sendParticles(ParticleTypes.NOTE, getX(), getY() + 2.2, getZ(), 3, 0.5, 0.3, 0.5, 1); }
        }
        if (rctCd > 0) rctCd--;
        if (kind == Kind.YUTA_OKKOTSU && rctCd <= 0 && getHealth() < getMaxHealth() * 0.5f) {
            rctCd = 300; heal(20f);
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1, getZ(), 20, 0.4, 0.7, 0.4, 0);
            playSound(ModSounds.RCT_HEAL.get(), 1f, 1.1f);
        }
        if (kind == Kind.KENTO_NANAMI && !overtime && getHealth() < getMaxHealth() * 0.5f) {
            overtime = true;
            addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 600, 1));
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 600, 0));
            say(sl, "message.kingofcurses.overtime");
        }
        if (specialCd > 0) { specialCd--; return; }
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive() || !hasLineOfSight(t)) return;
        double d = distanceTo(t);
        boolean used = switch (kind) {
            case YUTA_OKKOTSU -> d < 6 && rika(sl, t);
            case KINJI_HAKARI -> d < 14 && roughEnergy(sl, t);
            case MAKI_ZENIN -> d > 3 && d < 12 && leap(sl, t);
            case MEGUMI_FUSHIGURO -> d < 20 && dogs(sl, t);
            case AOI_TODO -> d > 4 && d < 16 && boogie(sl, t);
            case KENTO_NANAMI -> false; // ratio technique is on every 3rd melee hit
        };
        if (used) { specialCd = kind.specialCd + random.nextInt(40); swing(net.minecraft.world.InteractionHand.MAIN_HAND); triggerAnim("main", "cast"); }
    }

    private void say(ServerLevel sl, String key) {
        for (ServerPlayer p : sl.getPlayers(p -> p.distanceToSqr(this) < 32 * 32))
            p.displayClientMessage(Component.translatable(key).withStyle(ChatFormatting.AQUA, ChatFormatting.ITALIC), true);
    }

    /** Yuta: Rika's claw sweep. */
    private boolean rika(ServerLevel sl, LivingEntity t) {
        Vec3 c = t.position().add(0, 1, 0);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(3.0), e -> e == t || KocTargets.isFoe(e))) {
            e.hurt(damageSources().mobAttack(this), 13f);
            e.setDeltaMovement(e.position().subtract(position()).normalize().scale(1.2).add(0, 0.4, 0)); e.hurtMarked = true;
        }
        sl.sendParticles(RIKA, c.x, c.y, c.z, 120, 1.4, 1.0, 1.4, 0.1);
        sl.sendParticles(ParticleTypes.SWEEP_ATTACK, c.x, c.y, c.z, 5, 1.0, 0.5, 1.0, 0);
        playSound(ModSounds.CURSE_HURT.get(), 1.6f, 0.5f);
        return true;
    }

    /** Hakari: a shot of rough cursed energy; each one may hit the JACKPOT. */
    private boolean roughEnergy(ServerLevel sl, LivingEntity t) {
        Vec3 a = getEyePosition(), b = t.getEyePosition();
        for (int i = 0; i <= 14; i++) { Vec3 p = a.add(b.subtract(a).scale(i / 14.0)); sl.sendParticles(HAKARI, p.x, p.y, p.z, 3, 0.1, 0.1, 0.1, 0); }
        t.hurt(damageSources().mobAttack(this), 8f);
        playSound(SoundEvents.FIREWORK_ROCKET_BLAST, 1.2f, 1.4f);
        if (jackpot <= 0 && random.nextInt(4) == 0) {
            jackpot = 300;
            addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 1));
            addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 300, 1));
            sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, getX(), getY() + 1, getZ(), 120, 0.6, 1.0, 0.6, 0.4);
            playSound(SoundEvents.PLAYER_LEVELUP, 1.5f, 1.2f);
            say(sl, "message.kingofcurses.jackpot");
        }
        return true;
    }

    /** Maki: a heavenly-restricted leap and a crushing blow. */
    private boolean leap(ServerLevel sl, LivingEntity t) {
        Vec3 dir = t.position().subtract(position());
        setDeltaMovement(dir.x * 0.32, 0.45, dir.z * 0.32); hurtMarked = true;
        t.hurt(damageSources().mobAttack(this), 11f);
        sl.sendParticles(ParticleTypes.CRIT, t.getX(), t.getY() + 1, t.getZ(), 30, 0.4, 0.5, 0.4, 0.3);
        playSound(SoundEvents.PLAYER_ATTACK_STRONG, 1.2f, 0.8f);
        return true;
    }

    /** Megumi: Ten Shadows, two Divine Dogs that fight for 30 s. */
    private boolean dogs(ServerLevel sl, LivingEntity t) {
        for (int i = 0; i < 2; i++) {
            Wolf w = EntityType.WOLF.create(sl);
            if (w == null) continue;
            w.moveTo(getX() + random.nextGaussian(), getY(), getZ() + random.nextGaussian(), getYRot(), 0);
            w.setCustomName(Component.translatable("entity.kingofcurses.divine_dog"));
            w.setCollarColor(i == 0 ? net.minecraft.world.item.DyeColor.WHITE : net.minecraft.world.item.DyeColor.BLACK);
            w.getPersistentData().putInt(com.kingofcurses.ability.KocMode.SHIKIGAMI, 600);
            sl.addFreshEntity(w);
            w.setTarget(t);
            w.setRemainingPersistentAngerTime(600);
            if (t instanceof Player) w.setPersistentAngerTarget(t.getUUID());
            sl.sendParticles(SHADOW, w.getX(), w.getY() + 0.3, w.getZ(), 40, 0.4, 0.2, 0.4, 0.02);
        }
        playSound(SoundEvents.WOLF_HOWL, 1.2f, 0.8f);
        say(sl, "message.kingofcurses.divine_dogs");
        return true;
    }

    /** Todo: Boogie Woogie, a clap that swaps places with the target, then a heavy punch. */
    private boolean boogie(ServerLevel sl, LivingEntity t) {
        Vec3 me = position(), them = t.position();
        teleportTo(them.x, them.y, them.z);
        t.teleportTo(me.x, me.y, me.z);
        playSound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 2.0f, 1.6f);
        sl.sendParticles(ParticleTypes.FLASH, them.x, them.y + 1, them.z, 1, 0, 0, 0, 0);
        t.hurt(damageSources().mobAttack(this), 9f);
        say(sl, "message.kingofcurses.boogie");
        return true;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        triggerAnim("main", "slash");
        boolean ok = super.doHurtTarget(target);
        if (ok && target instanceof LivingEntity le && level() instanceof ServerLevel sl) {
            hits++;
            if (kind == Kind.KENTO_NANAMI && hits % 3 == 0) {          // Ratio Technique: the 7:3 weak point
                le.invulnerableTime = 0;
                le.hurt(damageSources().mobAttack(this), 9f);
                sl.sendParticles(ParticleTypes.CRIT, le.getX(), le.getY() + le.getBbHeight() * 0.7, le.getZ(), 25, 0.2, 0.2, 0.2, 0.4);
            }
            if (kind == Kind.AOI_TODO && random.nextInt(5) == 0) {     // Black Flash
                le.invulnerableTime = 0;
                le.hurt(damageSources().mobAttack(this), 14f);
                sl.sendParticles(new DustParticleOptions(new Vector3f(0.02f, 0f, 0.02f), 2f), le.getX(), le.getY() + 1, le.getZ(), 60, 0.4, 0.4, 0.4, 0.2);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, le.getX(), le.getY() + 1, le.getZ(), 30, 0.4, 0.4, 0.4, 0.5);
                playSound(SoundEvents.LIGHTNING_BOLT_IMPACT, 1f, 0.7f);
            }
            if (kind == Kind.KINJI_HAKARI && jackpot > 0) sl.sendParticles(HAKARI, le.getX(), le.getY() + 1, le.getZ(), 20, 0.3, 0.3, 0.3, 0.05);
        }
        return ok;
    }

    @Override public boolean isInvulnerableTo(DamageSource s) { return actor() != ACTOR_NONE || super.isInvulnerableTo(s); }
    @Override public boolean removeWhenFarAway(double distSqr) { return actor() == ACTOR_NONE && distSqr > 128 * 128; }
    @Override public boolean isPushable() { return actor() == ACTOR_NONE && super.isPushable(); }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return ModSounds.SORCERER_HURT.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.SORCERER_DEATH.get(); }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Overtime", overtime);
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        overtime = tag.getBoolean("Overtime");
    }

    /** Actors are never saved: a half-finished ritual simply does not come back. */
    @Override public boolean shouldBeSaved() { return actor() == ACTOR_NONE && super.shouldBeSaved(); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        String m = kind.model();
        controllers.add(new AnimationController<>(this, "main", 4, this::predicate)
                .triggerableAnim("slash", KocAnims.once(m, "slash"))
                .triggerableAnim("cast", KocAnims.once(m, "cast")));
    }

    private PlayState predicate(AnimationState<NamedSorcererEntity> state) {
        int a = actor();
        if (a == ACTOR_STITCH) return state.setAndContinue(stitch);
        if (a == ACTOR_COLLAPSE) return state.setAndContinue(collapse);
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
