package com.kingofcurses.entity;

import com.kingofcurses.registry.ModItems;
import com.kingofcurses.registry.ModParticles;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * v1.0.18 Toji Fushiguro, the Sorcerer Killer. Zero cursed energy, the Inventory Curse coiled around him,
 * the Inverted Spear of Heaven in hand (it cuts through Infinity). After the Strongest of Today intro he stays
 * as a corpse with half his torso erased: right click it to take the worm.
 */
public class TojiEntity extends PathfinderMob implements GeoEntity {
    public static final int STATE_AUTO = 0, STATE_IDLE = 1, STATE_STAB = 2, STATE_WALK = 3, STATE_CORPSE = 4, STATE_SMIRK = 5;
    private static final String M = "toji_fushiguro";
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(TojiEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> CINEMATIC = SynchedEntityData.defineId(TojiEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> HAS_WORM = SynchedEntityData.defineId(TojiEntity.class, EntityDataSerializers.BOOLEAN);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle = KocAnims.loop(M, "idle"), walk = KocAnims.loop(M, "walk"), run = KocAnims.loop(M, "run"),
            stab = RawAnimation.begin().thenPlay(KocAnims.key(M, "stab")).thenLoop(KocAnims.key(M, "idle")),
            corpse = KocAnims.loop(M, "corpse"), corpseNoWorm = KocAnims.loop(M, "corpse_noworm"), smirk = KocAnims.loop(M, "smirk");

    public TojiEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 120;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 40.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(STATE, STATE_AUTO);
        entityData.define(CINEMATIC, false);
        entityData.define(HAS_WORM, true);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.4D, true));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 12.0f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void populateDefaultEquipmentSlots(net.minecraft.util.RandomSource r, net.minecraft.world.DifficultyInstance diff) {
        setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, new ItemStack(ModItems.INVERTED_SPEAR_OF_HEAVEN.get()));
    }

    public void setupCinematic() {
        entityData.set(CINEMATIC, true);
        setNoAi(true); setInvulnerable(true); setPersistenceRequired();
        entityData.set(STATE, STATE_IDLE);
        setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, new ItemStack(ModItems.INVERTED_SPEAR_OF_HEAVEN.get()));
    }

    /** Hollow Purple erased half of him. The body stays (saved) with the Inventory Curse. */
    public void makeCorpse() {
        entityData.set(STATE, STATE_CORPSE);
        entityData.set(CINEMATIC, false);
        setNoAi(true); setInvulnerable(true); setPersistenceRequired();
        setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    }

    public boolean isCorpse() { return entityData.get(STATE) == STATE_CORPSE; }
    public boolean isCinematic() { return entityData.get(CINEMATIC); }
    public void setState(int s) { entityData.set(STATE, s); }
    public int getState() { return entityData.get(STATE); }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!isCorpse() || hand != InteractionHand.MAIN_HAND) return super.mobInteract(player, hand);
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (!entityData.get(HAS_WORM)) {
            player.displayClientMessage(Component.translatable("message.kingofcurses.toji_empty").withStyle(ChatFormatting.GRAY), true);
            return InteractionResult.CONSUME;
        }
        entityData.set(HAS_WORM, false);
        ItemStack worm = new ItemStack(ModItems.INVENTORY_CURSE.get());
        if (!player.getInventory().add(worm)) player.drop(worm, false);
        level().playSound(null, blockPosition(), SoundEvents.SLIME_SQUISH, SoundSource.NEUTRAL, 1.0f, 0.6f);
        player.displayClientMessage(Component.translatable("message.kingofcurses.toji_worm").withStyle(ChatFormatting.LIGHT_PURPLE), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public void tick() {
        super.tick();
        if (isCorpse()) {
            setDeltaMovement(getDeltaMovement().multiply(0, 1, 0));
            if (level().isClientSide && random.nextInt(tickCount > 1200 ? 20 : 4) == 0)
                level().addParticle(ModParticles.BLOOD.get(), getX() + random.nextGaussian() * 0.4, getY() + 0.2, getZ() + random.nextGaussian() * 0.4, 0, 0.01, 0);
        }
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (isCinematic() || isCorpse()) return !source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY);
        return super.isInvulnerableTo(source);
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return !isCinematic() && !isCorpse(); }
    @Override public boolean shouldBeSaved() { return !isCinematic() && super.shouldBeSaved(); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Corpse", isCorpse());
        tag.putBoolean("HasWorm", entityData.get(HAS_WORM));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.getBoolean("Corpse")) makeCorpse();
        entityData.set(HAS_WORM, !tag.contains("HasWorm") || tag.getBoolean("HasWorm"));
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::predicate)
                .triggerableAnim("stab", KocAnims.once(M, "stab")));
    }

    private PlayState predicate(AnimationState<TojiEntity> state) {
        switch (getState()) {
            case STATE_CORPSE: return state.setAndContinue(entityData.get(HAS_WORM) ? corpse : corpseNoWorm);
            case STATE_STAB: return state.setAndContinue(stab);
            case STATE_WALK: return state.setAndContinue(walk);
            case STATE_SMIRK: return state.setAndContinue(smirk);
            case STATE_IDLE: return state.setAndContinue(idle);
            default: break;
        }
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override
    public void swing(InteractionHand hand, boolean update) {
        super.swing(hand, update);
        if (!level().isClientSide) triggerAnim("main", "stab");
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
