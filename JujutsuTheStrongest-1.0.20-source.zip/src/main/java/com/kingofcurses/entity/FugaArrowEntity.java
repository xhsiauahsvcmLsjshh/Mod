package com.kingofcurses.entity;

import com.kingofcurses.KocConfig;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Fuga (Open): a fire arrow that erupts into an inferno on impact. Never harms its caster. */
public class FugaArrowEntity extends Projectile implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private float damage = 14.0f;
    private int life;

    public FugaArrowEntity(EntityType<? extends FugaArrowEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
    }

    public FugaArrowEntity(Level level, LivingEntity owner, float damage) {
        this(ModEntities.FUGA_ARROW.get(), level);
        setOwner(owner);
        setPos(owner.getX(), owner.getEyeY() - 0.2, owner.getZ());
        this.damage = damage;
    }

    @Override
    protected void defineSynchedData() { }

    @Override
    public void tick() {
        super.tick();
        Vec3 mv = getDeltaMovement();
        HitResult res = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
        if (res.getType() != HitResult.Type.MISS && !level().isClientSide) { erupt(res.getLocation()); return; }
        setPos(getX() + mv.x, getY() + mv.y, getZ() + mv.z);
        setYRot((float) (Mth.atan2(-mv.x, mv.z) * Mth.RAD_TO_DEG));
        if (level().isClientSide) {
            level().addParticle(ParticleTypes.FLAME, getX(), getY(), getZ(), 0, 0, 0);
            level().addParticle(ParticleTypes.SMALL_FLAME, getX() - mv.x * 0.5, getY() - mv.y * 0.5, getZ() - mv.z * 0.5, 0, 0.01, 0);
        } else if (++life > 60) {
            erupt(position());
        }
    }

    private void erupt(Vec3 at) {
        if (!(level() instanceof ServerLevel sl)) return;
        Entity owner = getOwner();
        sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, at.x, at.y, at.z, 1, 0, 0, 0, 0);
        sl.sendParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 120, 1.5, 1.0, 1.5, 0.15);
        sl.sendParticles(ParticleTypes.LAVA, at.x, at.y, at.z, 20, 1.0, 0.5, 1.0, 0.1);
        sl.playSound(null, at.x, at.y, at.z, ModSounds.FUGA_EXPLODE.get(), SoundSource.PLAYERS, 3.0f, 1.0f);
        double r = 5.5;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r), e -> e != owner && e.isAlive())) {
            double dist = e.position().distanceTo(at);
            if (dist > r) continue;
            e.hurt(damageSources().indirectMagic(this, owner), (float) (damage * (1.0 - dist / (r * 1.5))));
            e.setSecondsOnFire(8);
        }
        if (KocConfig.bool(KocConfig.ABILITY_GRIEFING, false)) sl.explode(this, at.x, at.y, at.z, 2.5f, true, Level.ExplosionInteraction.MOB);
        discard();
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); tag.putFloat("Damage", damage); }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) { super.readAdditionalSaveData(tag); damage = tag.getFloat("Damage"); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 0, state -> state.setAndContinue(KocAnims.loop("fuga_arrow", "idle"))));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
