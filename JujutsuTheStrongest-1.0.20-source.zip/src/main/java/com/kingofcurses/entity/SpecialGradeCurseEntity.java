package com.kingofcurses.entity;

import com.kingofcurses.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Special-grade curse mini-boss guarding a Sukuna finger. The finger index can be overridden by structure NBT ("FingerIndex"). */
public class SpecialGradeCurseEntity extends CursedSpiritEntity {
    private final ServerBossEvent bossEvent = new ServerBossEvent(getDisplayName(), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_6);
    private int fingerIndex;

    public SpecialGradeCurseEntity(EntityType<? extends Monster> type, Level level, CurseKind kind) {
        super(type, level, kind);
        this.fingerIndex = kind.defaultFinger;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("FingerIndex", fingerIndex);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("FingerIndex")) fingerIndex = tag.getInt("FingerIndex");
        bossEvent.setName(getDisplayName());
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) { super.startSeenByPlayer(player); bossEvent.addPlayer(player); }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) { super.stopSeenByPlayer(player); bossEvent.removePlayer(player); }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        if (fingerIndex >= 1 && fingerIndex <= 20) spawnAtLocation(new ItemStack(ModItems.SUKUNA_FINGER.get()));
    }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }
}
