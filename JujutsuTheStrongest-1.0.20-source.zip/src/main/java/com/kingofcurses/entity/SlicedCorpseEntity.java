package com.kingofcurses.entity;

import com.kingofcurses.registry.ModParticles;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Temporary remains of a creature killed by a slash. Carries the victim's type + a trimmed copy of its NBT
 * so the client can render the real model, split in two halves. Never saved.
 */
public class SlicedCorpseEntity extends Entity {
    public static final int LIFETIME = 110;
    private static final EntityDataAccessor<String> VICTIM = SynchedEntityData.defineId(SlicedCorpseEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<CompoundTag> VICTIM_TAG = SynchedEntityData.defineId(SlicedCorpseEntity.class, EntityDataSerializers.COMPOUND_TAG);
    private static final EntityDataAccessor<Float> V_WIDTH = SynchedEntityData.defineId(SlicedCorpseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> V_HEIGHT = SynchedEntityData.defineId(SlicedCorpseEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> FALL_LEFT = SynchedEntityData.defineId(SlicedCorpseEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> VERTICAL = SynchedEntityData.defineId(SlicedCorpseEntity.class, EntityDataSerializers.BOOLEAN);
    private static final String[] STRIP = {"Brain", "Inventory", "Offers", "Gossips", "Attributes", "ActiveEffects", "Passengers", "Leash", "UUID", "Pos", "Motion",
            "ForgeCaps", "ForgeData", "HandItems", "HandDropChances", "ArmorDropChances", "DeathLootTable", "Tags"};

    /** Client-only render cache (a dummy copy of the victim). */
    public LivingEntity clientDummy;
    public boolean clientDummyFailed;

    public SlicedCorpseEntity(EntityType<? extends SlicedCorpseEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
    }

    public boolean setup(LivingEntity victim) {
        String id = EntityType.getKey(victim.getType()).toString();
        CompoundTag tag = new CompoundTag();
        try {
            victim.saveWithoutId(tag);
            for (String k : STRIP) tag.remove(k);
            if (sizeOf(tag) > 12000) tag = new CompoundTag();
        } catch (RuntimeException e) {
            tag = new CompoundTag();
        }
        entityData.set(VICTIM, id);
        entityData.set(VICTIM_TAG, tag);
        entityData.set(V_WIDTH, victim.getBbWidth());
        entityData.set(V_HEIGHT, victim.getBbHeight());
        entityData.set(FALL_LEFT, random.nextBoolean());
        return true;
    }

    private static int sizeOf(CompoundTag tag) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            NbtIo.write(tag, new DataOutputStream(bos));
            return bos.size();
        } catch (IOException e) {
            return Integer.MAX_VALUE;
        }
    }

    public boolean vertical() { return entityData.get(VERTICAL); }
    public void setVertical(boolean v) { entityData.set(VERTICAL, v); }

    public String victimId() { return entityData.get(VICTIM); }
    public CompoundTag victimTag() { return entityData.get(VICTIM_TAG); }
    public float victimWidth() { return entityData.get(V_WIDTH); }
    public float victimHeight() { return entityData.get(V_HEIGHT); }
    public boolean fallLeft() { return entityData.get(FALL_LEFT); }

    @Override
    protected void defineSynchedData() {
        entityData.define(VICTIM, "minecraft:pig");
        entityData.define(VICTIM_TAG, new CompoundTag());
        entityData.define(V_WIDTH, 0.9f);
        entityData.define(V_HEIGHT, 0.9f);
        entityData.define(FALL_LEFT, false);
        entityData.define(VERTICAL, false);
    }

    @Override
    public void tick() {
        super.tick();
        // v1.0.14: remains fall down (finishers kill creatures held in the air)
        if (!onGround() || getDeltaMovement().y > 0) {
            noPhysics = false;
            net.minecraft.world.phys.Vec3 v = getDeltaMovement().add(0, -0.06, 0);
            move(net.minecraft.world.entity.MoverType.SELF, v);
            setDeltaMovement(onGround() ? net.minecraft.world.phys.Vec3.ZERO : v.scale(0.96));
            noPhysics = true;
        }
        if (level().isClientSide) {
            float h = victimHeight(), w = victimWidth();
            if (tickCount < 40 || random.nextInt(3) == 0) {
                level().addParticle(ModParticles.BLOOD.get(), getX() + (random.nextDouble() - 0.5) * w, getY() + h * 0.5 * (tickCount < 12 ? 1 : 0.3), getZ() + (random.nextDouble() - 0.5) * w, 0, 0.03, 0);
            }
            if (tickCount > LIFETIME - 12) {
                level().addParticle(ModParticles.CURSED_ENERGY.get(), getX() + (random.nextDouble() - 0.5) * w, getY() + random.nextDouble() * h * 0.6, getZ() + (random.nextDouble() - 0.5) * w, 0, 0.03, 0);
            }
        } else if (tickCount >= LIFETIME) {
            discard();
        }
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) { }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { }
    @Override public boolean shouldBeSaved() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean shouldRenderAtSqrDistance(double d) { return d < 64 * 64; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
