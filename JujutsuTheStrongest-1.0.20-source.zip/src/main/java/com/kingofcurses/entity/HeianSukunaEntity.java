package com.kingofcurses.entity;

import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.UUID;

/**
 * v1.0.17 Heian-era Sukuna, four arms, golem sized, sitting on his throne of bones.
 * Right click him ONCE (ever, per world): he tears off his lower right arm and throws it to you.
 */
public class HeianSukunaEntity extends PathfinderMob implements GeoEntity {
    public static final String MODEL = "sukuna_true_form";
    public static final int STATE_SIT = 0, STATE_RIP = 2;
    public static final int RIP_TEAR = 24, RIP_THROW = 36, RIP_END = 52;
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(HeianSukunaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> ARM_TORN = SynchedEntityData.defineId(HeianSukunaEntity.class, EntityDataSerializers.BOOLEAN);
    /** Client only: set by the arrival video for the jumpscare roar. */
    public static volatile boolean clientJumpscare = false;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation sit = KocAnimsHolder.loop("throne_sit"), sitOneArm = KocAnimsHolder.loop("throne_sit_onearm"),
            roar = KocAnimsHolder.hold("throne_roar"), rip = KocAnimsHolder.hold("rip_arm");
    private BlockPos throne;
    private float fixedYaw = 0f;
    private int ripTimer;
    private UUID ripTarget;
    private int armEntity = -1;

    private static final class KocAnimsHolder {
        static RawAnimation loop(String a) { return KocAnims.loop(MODEL, a); }
        static RawAnimation hold(String a) { return KocAnims.hold(MODEL, a); }
    }

    public HeianSukunaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setNoAi(true);
        setPersistenceRequired();
        setInvulnerable(true);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(STATE, STATE_SIT);
        entityData.define(ARM_TORN, false);
    }

    public void setThrone(BlockPos p) { throne = p; }
    public boolean armTorn() { return entityData.get(ARM_TORN); }
    public int state() { return entityData.get(STATE); }

    @Override
    public void moveTo(double x, double y, double z, float yaw, float pitch) {
        super.moveTo(x, y, z, yaw, pitch);
        fixedYaw = yaw;
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isPickable() { return true; }
    @Override public boolean hurt(DamageSource src, float amount) { return src.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY) && super.hurt(src, amount); }
    @Override public boolean isNoGravity() { return true; }

    @Override
    public void tick() {
        super.tick();
        setYRot(fixedYaw); yRotO = fixedYaw; yBodyRot = fixedYaw; yBodyRotO = fixedYaw; yHeadRot = fixedYaw; yHeadRotO = fixedYaw;
        setDeltaMovement(Vec3.ZERO);
        if (level() instanceof ServerLevel sl) {
            if (state() == STATE_RIP) ripTick(sl);
            else if (tickCount % 20 == 0) sl.sendParticles(ModParticles.CURSED_ENERGY.get(), getX(), getY() + 3.0, getZ(), 4, 1.0, 1.2, 1.0, 0.02);
        }
    }

    // ------------------------------------------------------------------ the gift
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (armTorn() || state() == STATE_RIP) {
            player.displayClientMessage(Component.translatable("message.kingofcurses.heian_sukuna_done").withStyle(ChatFormatting.GOLD), true);
            return InteractionResult.CONSUME;
        }
        entityData.set(STATE, STATE_RIP);
        ripTimer = 0;
        ripTarget = player.getUUID();
        player.displayClientMessage(Component.translatable("message.kingofcurses.heian_sukuna_gift").withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC), false);
        level().playSound(null, blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.HOSTILE, 2.0f, 0.7f);
        return InteractionResult.CONSUME;
    }

    /** Point in front/left/up of Sukuna, in blocks. */
    public Vec3 local(double right, double up, double fwd) {
        float yaw = fixedYaw * Mth.DEG_TO_RAD;
        double fx = -Mth.sin(yaw), fz = Mth.cos(yaw);
        double rx = -fz, rz = fx;
        return new Vec3(getX() + fx * fwd + rx * right, getY() + up, getZ() + fz * fwd + rz * right);
    }

    private void ripTick(ServerLevel sl) {
        int t = ++ripTimer;
        if (t == 8) sl.playSound(null, blockPosition(), ModSounds.SUKUNA_ROAR.get(), SoundSource.HOSTILE, 2.5f, 0.6f);
        if (t > 8 && t < RIP_TEAR && t % 4 == 0) {
            Vec3 p = local(1.3, 2.0, 0.6);
            sl.sendParticles(ModParticles.BLOOD.get(), p.x, p.y, p.z, 6, 0.2, 0.2, 0.2, 0.05);
            sl.playSound(null, blockPosition(), net.minecraft.sounds.SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, SoundSource.HOSTILE, 0.6f, 0.4f);
        }
        if (t == RIP_TEAR) {
            entityData.set(ARM_TORN, true);
            Vec3 p = local(1.3, 2.0, 0.6);
            sl.sendParticles(ModParticles.BLOOD.get(), p.x, p.y, p.z, 120, 0.4, 0.4, 0.4, 0.4);
            sl.playSound(null, blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.HOSTILE, 2.0f, 0.6f);
            SukunaArmEntity arm = ModEntities.SUKUNA_ARM_THROWN.get().create(sl);
            if (arm != null) {
                Vec3 h = local(-1.6, 4.4, 0.2);
                arm.moveTo(h.x, h.y, h.z, 0, 0);
                arm.setup(this, ripTarget, RIP_THROW - RIP_TEAR);
                sl.addFreshEntity(arm);
                armEntity = arm.getId();
            }
        }
        if (t == RIP_THROW) sl.playSound(null, blockPosition(), net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 2.0f, 0.5f);
        if (t >= RIP_END) entityData.set(STATE, STATE_SIT);
    }

    // ------------------------------------------------------------------ save
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("ArmTorn", armTorn());
        tag.putFloat("FixedYaw", fixedYaw);
        if (throne != null) tag.put("Throne", NbtUtils.writeBlockPos(throne));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(ARM_TORN, tag.getBoolean("ArmTorn"));
        fixedYaw = tag.getFloat("FixedYaw");
        if (tag.contains("Throne")) throne = NbtUtils.readBlockPos(tag.getCompound("Throne"));
        setNoAi(true);
    }

    // ------------------------------------------------------------------ animation
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 4, this::predicate));
    }

    private PlayState predicate(AnimationState<HeianSukunaEntity> state) {
        if (clientJumpscare) return state.setAndContinue(roar);
        if (state() == STATE_RIP) return state.setAndContinue(rip);
        return state.setAndContinue(armTorn() ? sitOneArm : sit);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
