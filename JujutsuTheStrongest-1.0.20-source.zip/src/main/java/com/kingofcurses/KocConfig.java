package com.kingofcurses;

import net.minecraftforge.common.ForgeConfigSpec;

public final class KocConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue INTRO_CINEMATIC;
    public static final ForgeConfigSpec.BooleanValue ABILITY_GRIEFING;
    public static final ForgeConfigSpec.BooleanValue TAKEOVER_ENABLED;
    public static final ForgeConfigSpec.BooleanValue SORCERER_HUNTS;
    public static final ForgeConfigSpec.IntValue DOMAIN_THRESHOLD;
    public static final ForgeConfigSpec.IntValue DOMAIN_DURATION;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("general");
        INTRO_CINEMATIC = b.comment("Play the Sukuna vs Gojo intro cinematic on a player's first join.").define("introCinematic", true);
        ABILITY_GRIEFING = b.comment("Allow cursed techniques (Fuga, World Cutting Slash) to destroy blocks.").define("abilityGriefing", false);
        TAKEOVER_ENABLED = b.comment("Allow Sukuna to take control of high-finger players.").define("takeoverEnabled", true);
        SORCERER_HUNTS = b.comment("Jujutsu sorcerers periodically hunt cursed players.").define("sorcererHunts", true);
        DOMAIN_THRESHOLD = b.comment("Fingers required for Domain Expansion: Malevolent Shrine.").defineInRange("domainFingerThreshold", 20, 1, 20);
        DOMAIN_DURATION = b.comment("Domain duration in ticks.").defineInRange("domainDuration", 400, 100, 2400);
        b.pop();
        SPEC = b.build();
    }

    private KocConfig() {}

    /** Safe accessor: returns the default when the config is not loaded yet (e.g. on the main menu). */
    public static int domainThreshold() {
        try { return DOMAIN_THRESHOLD.get(); } catch (IllegalStateException e) { return 20; }
    }
    public static boolean bool(ForgeConfigSpec.BooleanValue v, boolean def) {
        try { return v.get(); } catch (IllegalStateException e) { return def; }
    }
}
