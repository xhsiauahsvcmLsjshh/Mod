package com.kingofcurses.network;

import com.kingofcurses.ability.EndingLogic;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class EndingChoicePacket {
    public final int choice;

    public EndingChoicePacket(int choice) { this.choice = choice; }
    public EndingChoicePacket(FriendlyByteBuf buf) { this(buf.readVarInt()); }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(choice); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        if (sp != null) EndingLogic.choose(sp, choice);
    }
}
