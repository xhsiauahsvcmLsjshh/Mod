package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** v1.0.6: a player starts tearing out their finger (plays the animation on every client that sees them). */
public class RipAnimPacket {
    public static final int RIP = 0, TRANSFORM = 1, REGROW = 2, POSSESS = 3, DUST = 4, FINISHER = 5;
    public final int entityId, kind, arg;

    public RipAnimPacket(int entityId) { this(entityId, RIP, 0); }
    public RipAnimPacket(int entityId, int kind, int arg) { this.entityId = entityId; this.kind = kind; this.arg = arg; }
    public RipAnimPacket(FriendlyByteBuf buf) { this(buf.readVarInt(), buf.readVarInt(), buf.readVarInt()); }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(entityId); buf.writeVarInt(kind); buf.writeVarInt(arg); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleRip(this));
    }
}
