package com.kingofcurses.network;

import com.kingofcurses.KingOfCurses;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(KingOfCurses.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);
    private static int id = 0;

    private ModNetwork() {}

    public static void register() {
        // server -> client
        CHANNEL.messageBuilder(SyncDataPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncDataPacket::encode).decoder(SyncDataPacket::new).consumerMainThread(SyncDataPacket::handle).add();
        CHANNEL.messageBuilder(SyncOtherPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncOtherPacket::encode).decoder(SyncOtherPacket::new).consumerMainThread(SyncOtherPacket::handle).add();
        CHANNEL.messageBuilder(CinematicPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(CinematicPacket::encode).decoder(CinematicPacket::new).consumerMainThread(CinematicPacket::handle).add();
        CHANNEL.messageBuilder(ScreenFxPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ScreenFxPacket::encode).decoder(ScreenFxPacket::new).consumerMainThread(ScreenFxPacket::handle).add();
        CHANNEL.messageBuilder(DomainStatePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(DomainStatePacket::encode).decoder(DomainStatePacket::new).consumerMainThread(DomainStatePacket::handle).add();
        CHANNEL.messageBuilder(OpenScreenPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenScreenPacket::encode).decoder(OpenScreenPacket::new).consumerMainThread(OpenScreenPacket::handle).add();
        CHANNEL.messageBuilder(RipAnimPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(RipAnimPacket::encode).decoder(RipAnimPacket::new).consumerMainThread(RipAnimPacket::handle).add();
        CHANNEL.messageBuilder(GojoIntroPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(GojoIntroPacket::encode).decoder(GojoIntroPacket::new).consumerMainThread(GojoIntroPacket::handle).add();
        // client -> server
        CHANNEL.messageBuilder(AbilityPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(AbilityPacket::encode).decoder(AbilityPacket::new).consumerMainThread(AbilityPacket::handle).add();
        CHANNEL.messageBuilder(CodexActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(CodexActionPacket::encode).decoder(CodexActionPacket::new).consumerMainThread(CodexActionPacket::handle).add();
        CHANNEL.messageBuilder(EndingChoicePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(EndingChoicePacket::encode).decoder(EndingChoicePacket::new).consumerMainThread(EndingChoicePacket::handle).add();
        CHANNEL.messageBuilder(ControlModePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ControlModePacket::encode).decoder(ControlModePacket::new).consumerMainThread(ControlModePacket::handle).add();
    }

    public static void sendTo(ServerPlayer player, Object msg) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }

    public static void sendToTrackingAndSelf(Entity entity, Object msg) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> entity), msg);
    }

    public static void sendToServer(Object msg) {
        CHANNEL.sendToServer(msg);
    }
}
