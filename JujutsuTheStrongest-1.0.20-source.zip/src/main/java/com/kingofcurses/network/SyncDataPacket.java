package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncDataPacket {
    public final CompoundTag tag;

    public SyncDataPacket(CompoundTag tag) { this.tag = tag; }
    public SyncDataPacket(FriendlyByteBuf buf) { this.tag = buf.readNbt(); }

    public void encode(FriendlyByteBuf buf) { buf.writeNbt(tag); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleSync(this));
    }
}
