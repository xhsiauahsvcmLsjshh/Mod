package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ScreenFxPacket {
    public static final int SHAKE = 0, RED_FLASH = 1, AURA = 2, TAKEOVER = 3, TAKEOVER_END = 4, ARM_CAST = 5, MARKINGS = 6, WHITE_FLASH = 7, BLACK_FLASH = 8, LOADING = 9, SUBTITLE = 10, HEIAN_INTRO = 11;
    public final int type, duration;
    public final float intensity;

    public ScreenFxPacket(int type, int duration, float intensity) { this.type = type; this.duration = duration; this.intensity = intensity; }
    public ScreenFxPacket(FriendlyByteBuf buf) { this(buf.readVarInt(), buf.readVarInt(), buf.readFloat()); }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(type); buf.writeVarInt(duration); buf.writeFloat(intensity); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleFx(this));
    }
}
