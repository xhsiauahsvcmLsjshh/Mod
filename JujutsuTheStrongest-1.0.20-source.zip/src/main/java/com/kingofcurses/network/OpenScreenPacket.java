package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class OpenScreenPacket {
    public static final int ENDING = 0, CONTROL_MODE = 1;
    public final int screen;

    public OpenScreenPacket(int screen) { this.screen = screen; }
    public OpenScreenPacket(FriendlyByteBuf buf) { this(buf.readVarInt()); }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(screen); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleOpenScreen(this));
    }
}
