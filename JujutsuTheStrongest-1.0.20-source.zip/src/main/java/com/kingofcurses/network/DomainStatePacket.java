package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class DomainStatePacket {
    public final boolean active;
    public final double x, y, z;
    public final float radius;
    public final int ticksLeft;

    public DomainStatePacket(boolean active, double x, double y, double z, float radius, int ticksLeft) {
        this.active = active; this.x = x; this.y = y; this.z = z; this.radius = radius; this.ticksLeft = ticksLeft;
    }
    public DomainStatePacket(FriendlyByteBuf buf) {
        this(buf.readBoolean(), buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readFloat(), buf.readVarInt());
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(active); buf.writeDouble(x); buf.writeDouble(y); buf.writeDouble(z); buf.writeFloat(radius); buf.writeVarInt(ticksLeft);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleDomain(this));
    }
}
