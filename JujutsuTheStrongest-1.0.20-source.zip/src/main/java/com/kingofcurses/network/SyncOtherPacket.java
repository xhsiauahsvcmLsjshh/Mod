package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Finger count / ending of any player, so other clients can render Sukuna's markings. */
public class SyncOtherPacket {
    public final int entityId, fingers, ending;

    public SyncOtherPacket(int entityId, int fingers, int ending) { this.entityId = entityId; this.fingers = fingers; this.ending = ending; }
    public SyncOtherPacket(FriendlyByteBuf buf) { this(buf.readVarInt(), buf.readVarInt(), buf.readVarInt()); }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(entityId); buf.writeVarInt(fingers); buf.writeVarInt(ending); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleOther(this));
    }
}
