package com.kingofcurses.network;

import com.kingofcurses.ability.MobileControls;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ControlModePacket {
    public final int mode;

    public ControlModePacket(int mode) { this.mode = mode; }
    public ControlModePacket(FriendlyByteBuf buf) { this.mode = buf.readVarInt(); }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(mode); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        if (sp != null) MobileControls.setMode(sp, mode);
    }
}
