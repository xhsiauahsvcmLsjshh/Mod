package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CinematicPacket {
    public static final int START = 0, STOP = 1, SYNC = 2;
    public final int action, sukunaId, gojoId;
    public final Vec3 origin, dig, sukuna, gojo;
    public final float yaw;

    public CinematicPacket(int action, Vec3 origin, float yaw, Vec3 dig, Vec3 sukuna, Vec3 gojo, int sukunaId, int gojoId) {
        this.action = action; this.origin = origin; this.yaw = yaw; this.dig = dig; this.sukuna = sukuna; this.gojo = gojo;
        this.sukunaId = sukunaId; this.gojoId = gojoId;
    }

    /** v1.0.7: the server's current scene tick (carried in sukunaId) so the camera never runs ahead of the actors. */
    public static CinematicPacket sync(int tick) { return new CinematicPacket(SYNC, Vec3.ZERO, 0, Vec3.ZERO, Vec3.ZERO, Vec3.ZERO, tick, -1); }

    public static CinematicPacket stop() { return new CinematicPacket(STOP, Vec3.ZERO, 0, Vec3.ZERO, Vec3.ZERO, Vec3.ZERO, -1, -1); }

    public CinematicPacket(FriendlyByteBuf buf) {
        this.action = buf.readVarInt();
        this.origin = readVec(buf);
        this.yaw = buf.readFloat();
        this.dig = readVec(buf);
        this.sukuna = readVec(buf);
        this.gojo = readVec(buf);
        this.sukunaId = buf.readInt();
        this.gojoId = buf.readInt();
    }

    private static Vec3 readVec(FriendlyByteBuf b) { return new Vec3(b.readDouble(), b.readDouble(), b.readDouble()); }
    private static void writeVec(FriendlyByteBuf b, Vec3 v) { b.writeDouble(v.x); b.writeDouble(v.y); b.writeDouble(v.z); }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(action); writeVec(buf, origin); buf.writeFloat(yaw); writeVec(buf, dig); writeVec(buf, sukuna); writeVec(buf, gojo);
        buf.writeInt(sukunaId); buf.writeInt(gojoId);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleCinematic(this));
    }
}
