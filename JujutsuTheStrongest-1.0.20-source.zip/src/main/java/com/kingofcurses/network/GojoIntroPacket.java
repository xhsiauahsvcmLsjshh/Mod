package com.kingofcurses.network;

import com.kingofcurses.client.ClientPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** v1.0.18 Strongest of Today opening (start / timeline sync / stop). */
public class GojoIntroPacket {
    public static final int START = 0, SYNC = 1, STOP = 2, GETO = 3;
    public final int action, gojoId, tojiId, tick;

    public GojoIntroPacket(int action, int gojoId, int tojiId, int tick) { this.action = action; this.gojoId = gojoId; this.tojiId = tojiId; this.tick = tick; }
    public GojoIntroPacket(FriendlyByteBuf b) { this(b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt()); }
    public void encode(FriendlyByteBuf b) { b.writeVarInt(action); b.writeVarInt(gojoId); b.writeVarInt(tojiId); b.writeVarInt(tick); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.handleGojoIntro(this));
    }
}
