package com.kingofcurses.network;

import com.kingofcurses.ability.Ability;
import com.kingofcurses.ability.AbilityLogic;
import com.kingofcurses.ability.KocSync;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class AbilityPacket {
    public static final int USE_SELECTED = 0, SELECT = 1, CYCLE = 2, DOMAIN = 3, CAST = 4, FINISHER = 5;
    public final int action, index;

    public AbilityPacket(int action, int index) { this.action = action; this.index = index; }
    public AbilityPacket(FriendlyByteBuf buf) { this(buf.readVarInt(), buf.readVarInt()); }

    public void encode(FriendlyByteBuf buf) { buf.writeVarInt(action); buf.writeVarInt(index); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        if (sp == null) return;
        switch (action) {
            case USE_SELECTED -> AbilityLogic.useSelected(sp);
            case SELECT -> AbilityLogic.select(sp, index);
            case CYCLE -> AbilityLogic.cycle(sp);
            case DOMAIN -> AbilityLogic.tryUse(sp, KocSync.data(sp).isGojo() ? Ability.INFINITE_VOID : Ability.DOMAIN_EXPANSION);
            case FINISHER -> com.kingofcurses.ability.FinisherLogic.tryStart(sp);
            case CAST -> { AbilityLogic.select(sp, index); AbilityLogic.tryUse(sp, Ability.byIndex(index)); }
            default -> { }
        }
    }
}
