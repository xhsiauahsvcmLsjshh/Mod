package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, KingOfCurses.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.kingofcurses"))
            .icon(() -> new ItemStack(ModItems.SUKUNA_FINGER.get()))
            .displayItems((params, output) -> ModItems.ITEMS.getEntries().forEach(entry -> { if (entry.get() instanceof com.kingofcurses.item.RippedFingerItem) output.accept(com.kingofcurses.item.RippedFingerItem.withPower(20)); else if (!(entry.get() instanceof com.kingofcurses.item.LegacyFingerItem)) output.accept(entry.get()); }))
            .build());

    private ModCreativeTabs() {}
}
