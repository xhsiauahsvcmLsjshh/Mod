package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, KingOfCurses.MODID);

    public static final RegistryObject<SimpleParticleType> CURSED_ENERGY = PARTICLES.register("cursed_energy", () -> new SimpleParticleType(true));
    public static final RegistryObject<SimpleParticleType> BLOOD = PARTICLES.register("blood", () -> new SimpleParticleType(true));
    public static final RegistryObject<SimpleParticleType> SLASH = PARTICLES.register("slash", () -> new SimpleParticleType(true));
    public static final RegistryObject<SimpleParticleType> DOMAIN_ASH = PARTICLES.register("domain_ash", () -> new SimpleParticleType(true));
    public static final RegistryObject<SimpleParticleType> RESONANCE = PARTICLES.register("resonance", () -> new SimpleParticleType(true));

    private ModParticles() {}
}
