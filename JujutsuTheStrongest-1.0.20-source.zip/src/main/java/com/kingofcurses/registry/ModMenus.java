package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.menu.ReliquaryMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, KingOfCurses.MODID);

    public static final RegistryObject<MenuType<ReliquaryMenu>> RELIQUARY = MENUS.register("reliquary",
            () -> IForgeMenuType.create((windowId, inv, buf) -> new ReliquaryMenu(windowId, inv)));

    private ModMenus() {}
}
