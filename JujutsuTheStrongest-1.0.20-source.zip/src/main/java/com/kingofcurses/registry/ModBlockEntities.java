package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.block.ReliquaryBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, KingOfCurses.MODID);

    @SuppressWarnings("DataFlowIssue")
    public static final RegistryObject<BlockEntityType<ReliquaryBlockEntity>> RELIQUARY = BLOCK_ENTITIES.register("reliquary",
            () -> BlockEntityType.Builder.of(ReliquaryBlockEntity::new, ModBlocks.RELIQUARY.get()).build(null));

    private ModBlockEntities() {}
}
