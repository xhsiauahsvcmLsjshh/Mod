package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.recipe.ClueCombineRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.SimpleCraftingRecipeSerializer;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** v1.0.20 custom recipes (hand written, not generated). */
public final class ModRecipes {
    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, KingOfCurses.MODID);
    public static final RegistryObject<RecipeSerializer<ClueCombineRecipe>> CLUE_COMBINE =
            SERIALIZERS.register("clue_combine", () -> new SimpleCraftingRecipeSerializer<>(ClueCombineRecipe::new));

    private ModRecipes() {}
}
