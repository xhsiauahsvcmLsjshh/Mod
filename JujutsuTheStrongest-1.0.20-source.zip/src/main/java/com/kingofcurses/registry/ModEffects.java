package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.effect.KocEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, KingOfCurses.MODID);

    public static final RegistryObject<MobEffect> CURSED_BLEED = EFFECTS.register("cursed_bleed", () -> new KocEffect(MobEffectCategory.HARMFUL, 0x8a0303, KocEffect.Kind.CURSED_BLEED));
    public static final RegistryObject<MobEffect> SEALED = EFFECTS.register("sealed", () -> new KocEffect(MobEffectCategory.HARMFUL, 0xe8e2c8, KocEffect.Kind.SEALED));
    public static final RegistryObject<MobEffect> SUKUNA_TAKEOVER = EFFECTS.register("sukuna_takeover", () -> new KocEffect(MobEffectCategory.NEUTRAL, 0x3d0000, KocEffect.Kind.SUKUNA_TAKEOVER));
    public static final RegistryObject<MobEffect> CURSED_VIGOR = EFFECTS.register("cursed_vigor", () -> new KocEffect(MobEffectCategory.BENEFICIAL, 0xb3122e, KocEffect.Kind.CURSED_VIGOR));
    public static final RegistryObject<MobEffect> WARDED = EFFECTS.register("warded", () -> new KocEffect(MobEffectCategory.BENEFICIAL, 0xf0e6c8, KocEffect.Kind.WARDED));

    private ModEffects() {}
}
