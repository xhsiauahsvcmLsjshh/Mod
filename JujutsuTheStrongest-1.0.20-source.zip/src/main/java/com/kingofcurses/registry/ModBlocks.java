package com.kingofcurses.registry;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.block.CursedSpikeTrapBlock;
import com.kingofcurses.block.FingerBurialBlock;
import com.kingofcurses.block.MalevolentAltarBlock;
import com.kingofcurses.block.ReliquaryBlock;
import com.kingofcurses.block.ShrineLanternBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

/** All blocks of the mod. Each block also registers its BlockItem. */
public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, KingOfCurses.MODID);

    public static final RegistryObject<Block> CURSED_SAND = register("cursed_sand", () -> new com.kingofcurses.block.CursedSandBlock(BlockBehaviour.Properties.copy(Blocks.SAND).mapColor(MapColor.COLOR_RED).strength(0.6f).lightLevel(st -> 4).pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK)));
    public static final RegistryObject<Block> HEIAN_PORTAL = register("heian_portal", () -> new com.kingofcurses.block.HeianPortalBlock(BlockBehaviour.Properties.of().noCollission().strength(-1.0f, 3600000.0f).lightLevel(s -> 15).noLootTable().noOcclusion().sound(net.minecraft.world.level.block.SoundType.GLASS).pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK)));
    public static final RegistryObject<Block> TEMPLE_STONE = register("temple_stone", () -> new Block(BlockBehaviour.Properties.copy(Blocks.STONE).mapColor(MapColor.COLOR_GRAY)));
    public static final RegistryObject<Block> TEMPLE_STONE_BRICKS = register("temple_stone_bricks", () -> new Block(BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS)));
    public static final RegistryObject<Block> CRACKED_TEMPLE_STONE_BRICKS = register("cracked_temple_stone_bricks", () -> new Block(BlockBehaviour.Properties.copy(Blocks.CRACKED_STONE_BRICKS)));
    public static final RegistryObject<Block> CHISELED_TEMPLE_STONE = register("chiseled_temple_stone", () -> new Block(BlockBehaviour.Properties.copy(Blocks.CHISELED_STONE_BRICKS)));
    public static final RegistryObject<Block> POLISHED_TEMPLE_STONE = register("polished_temple_stone", () -> new Block(BlockBehaviour.Properties.copy(Blocks.POLISHED_ANDESITE)));
    public static final RegistryObject<Block> CURSED_WOOD_PLANKS = register("cursed_wood_planks", () -> new Block(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_PLANKS)));
    public static final RegistryObject<Block> BLACK_LACQUER_PLANKS = register("black_lacquer_planks", () -> new Block(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_PLANKS).mapColor(MapColor.COLOR_BLACK)));
    public static final RegistryObject<Block> TORII_BEAM = register("torii_beam", () -> new Block(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_PLANKS).mapColor(MapColor.COLOR_RED)));
    public static final RegistryObject<Block> SHRINE_ROOF_TILES = register("shrine_roof_tiles", () -> new Block(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_TILES)));
    public static final RegistryObject<Block> CURSED_SEAL_BLOCK = register("cursed_seal_block", () -> new Block(BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS).strength(3.0f, 12.0f).lightLevel(s -> 4)));
    public static final RegistryObject<Block> BONE_WHITE_PLASTER = register("bone_white_plaster", () -> new Block(BlockBehaviour.Properties.copy(Blocks.CALCITE)));
    public static final RegistryObject<Block> CRIMSON_TATAMI = register("crimson_tatami", () -> new Block(BlockBehaviour.Properties.copy(Blocks.HAY_BLOCK).mapColor(MapColor.COLOR_RED)));
    public static final RegistryObject<Block> TALISMAN_WALL = register("talisman_wall", () -> new Block(BlockBehaviour.Properties.copy(Blocks.WHITE_WOOL).strength(1.0f)));
    public static final RegistryObject<Block> BLOOD_SOAKED_SOIL = register("blood_soaked_soil", () -> new Block(BlockBehaviour.Properties.copy(Blocks.DIRT).mapColor(MapColor.COLOR_RED)));
    public static final RegistryObject<Block> CURSED_SOIL = register("cursed_soil", () -> new Block(BlockBehaviour.Properties.copy(Blocks.COARSE_DIRT).mapColor(MapColor.COLOR_PURPLE)));
    public static final RegistryObject<Block> CURSED_BONE_PILE = register("cursed_bone_pile", () -> new Block(BlockBehaviour.Properties.copy(Blocks.BONE_BLOCK)));
    public static final RegistryObject<Block> SEALING_STONE = register("sealing_stone", () -> new Block(BlockBehaviour.Properties.copy(Blocks.OBSIDIAN).strength(20.0f, 1200.0f)));
    public static final RegistryObject<Block> CURSED_ENERGY_CRYSTAL_BLOCK = register("cursed_energy_crystal_block", () -> new Block(BlockBehaviour.Properties.copy(Blocks.AMETHYST_BLOCK).lightLevel(s -> 9).mapColor(MapColor.COLOR_RED)));
    public static final RegistryObject<Block> CURSED_CRYSTAL_ORE = register("cursed_crystal_ore", () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_ORE).lightLevel(s -> 3)));
    public static final RegistryObject<Block> DEEPSLATE_CURSED_CRYSTAL_ORE = register("deepslate_cursed_crystal_ore", () -> new Block(BlockBehaviour.Properties.copy(Blocks.DEEPSLATE_IRON_ORE).lightLevel(s -> 3)));
    public static final RegistryObject<Block> CURSED_WOOD_LOG = register("cursed_wood_log", () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_LOG)));
    public static final RegistryObject<Block> STRIPPED_CURSED_WOOD_LOG = register("stripped_cursed_wood_log", () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.STRIPPED_DARK_OAK_LOG)));
    public static final RegistryObject<Block> TORII_PILLAR = register("torii_pillar", () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_LOG).mapColor(MapColor.COLOR_RED)));
    public static final RegistryObject<Block> TEMPLE_STONE_PILLAR = register("temple_stone_pillar", () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.QUARTZ_PILLAR)));
    public static final RegistryObject<Block> TEMPLE_STONE_STAIRS = register("temple_stone_stairs", () -> new StairBlock(() -> TEMPLE_STONE.get().defaultBlockState(), BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS)));
    public static final RegistryObject<Block> TEMPLE_STONE_BRICK_STAIRS = register("temple_stone_brick_stairs", () -> new StairBlock(() -> TEMPLE_STONE_BRICKS.get().defaultBlockState(), BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS)));
    public static final RegistryObject<Block> CURSED_WOOD_STAIRS = register("cursed_wood_stairs", () -> new StairBlock(() -> CURSED_WOOD_PLANKS.get().defaultBlockState(), BlockBehaviour.Properties.copy(Blocks.DARK_OAK_PLANKS)));
    public static final RegistryObject<Block> SHRINE_ROOF_STAIRS = register("shrine_roof_stairs", () -> new StairBlock(() -> SHRINE_ROOF_TILES.get().defaultBlockState(), BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS)));
    public static final RegistryObject<Block> TEMPLE_STONE_SLAB = register("temple_stone_slab", () -> new SlabBlock(BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS)));
    public static final RegistryObject<Block> TEMPLE_STONE_BRICK_SLAB = register("temple_stone_brick_slab", () -> new SlabBlock(BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS)));
    public static final RegistryObject<Block> CURSED_WOOD_SLAB = register("cursed_wood_slab", () -> new SlabBlock(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_PLANKS)));
    public static final RegistryObject<Block> SHRINE_ROOF_SLAB = register("shrine_roof_slab", () -> new SlabBlock(BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS)));
    public static final RegistryObject<Block> TEMPLE_STONE_BRICK_WALL = register("temple_stone_brick_wall", () -> new WallBlock(BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS)));
    public static final RegistryObject<Block> CURSED_WOOD_FENCE = register("cursed_wood_fence", () -> new FenceBlock(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_FENCE)));
    public static final RegistryObject<Block> CURSED_WOOD_FENCE_GATE = register("cursed_wood_fence_gate", () -> new FenceGateBlock(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_FENCE_GATE), WoodType.DARK_OAK));
    public static final RegistryObject<Block> CURSED_LEAVES = register("cursed_leaves", () -> new LeavesBlock(BlockBehaviour.Properties.copy(Blocks.DARK_OAK_LEAVES).mapColor(MapColor.COLOR_RED)));
    public static final RegistryObject<Block> SHRINE_LANTERN = register("shrine_lantern", () -> new ShrineLanternBlock(BlockBehaviour.Properties.copy(Blocks.LANTERN).lightLevel(s -> 15).noOcclusion()));
    public static final RegistryObject<Block> RELIQUARY = register("reliquary", () -> new ReliquaryBlock(BlockBehaviour.Properties.copy(Blocks.CHEST).strength(3.5f).sound(SoundType.WOOD)));
    public static final RegistryObject<Block> DISTURBED_SOIL = register("disturbed_soil", () -> new FingerBurialBlock(BlockBehaviour.Properties.copy(Blocks.DIRT).strength(0.8f)));
    public static final RegistryObject<Block> CURSED_SPIKE_TRAP = register("cursed_spike_trap", () -> new CursedSpikeTrapBlock(BlockBehaviour.Properties.copy(Blocks.STONE).strength(2.5f).noOcclusion()));
    public static final RegistryObject<Block> MALEVOLENT_ALTAR = register("malevolent_altar", () -> new MalevolentAltarBlock(BlockBehaviour.Properties.copy(Blocks.STONE_BRICKS).lightLevel(s -> 6).strength(4.0f, 9.0f)));

    private ModBlocks() {}

    private static RegistryObject<Block> register(String name, Supplier<Block> supplier) {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }
}
