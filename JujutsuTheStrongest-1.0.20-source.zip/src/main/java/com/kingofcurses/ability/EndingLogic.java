package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.GojoKenjakuEntity;
import com.kingofcurses.entity.SealingMasterEntity;
import com.kingofcurses.entity.SukunaEntity;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.OpenScreenPacket;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/** Final boss and the Embrace / Reject ending. */
public final class EndingLogic {
    public static final int EMBRACE = 1, REJECT = 2;
    private EndingLogic() {}

    public static void tickBossCountdown(ServerPlayer sp, CursedData d) {
        if (d.bossCountdown() <= 0) return;
        d.setBossCountdown(d.bossCountdown() - 1);
        if (d.bossCountdown() == 0) spawnBoss(sp, d);
    }

    public static void spawnBoss(ServerPlayer sp, CursedData d) {
        if (d.bossDefeated() || d.ending() != CursedData.ENDING_NONE) return;
        com.kingofcurses.common.KocWorldData w = com.kingofcurses.common.KocWorldData.get(sp.server);
        if (w.bossDefeated()) {            // v1.0.9: already beaten in this world, go straight to the choice
            d.setBossDefeated(true);
            KocSync.sync(sp);
            sp.displayClientMessage(Component.translatable("message.kingofcurses.boss_already_dead").withStyle(ChatFormatting.DARK_RED), false);
            ModNetwork.sendTo(sp, new OpenScreenPacket(OpenScreenPacket.ENDING));
            return;
        }
        if (w.bossSpawned()) {             // he rises only once: whoever reaches twenty fingers must find him
            sp.displayClientMessage(Component.translatable("message.kingofcurses.boss_already_risen").withStyle(ChatFormatting.LIGHT_PURPLE), false);
            return;
        }
        w.setBossSpawned();
        BossRitual.start(sp);   // v1.0.8: Yuta stitches Gojo's body and takes it over first
    }

    /** Old instant arrival (kept as a fallback). */
    public static void spawnBossNow(ServerPlayer sp, CursedData d) {
        ServerLevel level = sp.serverLevel();
        GojoKenjakuEntity boss = ModEntities.GOJO_KENJAKU.get().create(level);
        if (boss == null) return;
        Vec3 dir = Vec3.directionFromRotation(0, sp.getYRot());
        double x = sp.getX() + dir.x * 10, z = sp.getZ() + dir.z * 10;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
        if (Math.abs(y - sp.getY()) > 10) { x = sp.getX(); z = sp.getZ(); y = Mth.floor(sp.getY()); }
        boss.moveTo(x, y, z, sp.getYRot() + 180f, 0);
        boss.setChallenger(sp.getUUID());
        boss.setTarget(sp);
        level.addFreshEntity(boss);
        d.setBossSpawned(true);
        level.sendParticles(ModParticles.CURSED_ENERGY.get(), x, y + 1, z, 80, 0.5, 1.0, 0.5, 0.1);
        level.playSound(null, boss.blockPosition(), ModSounds.SEAL_RITUAL.get(), SoundSource.HOSTILE, 2.0f, 0.8f);
        level.playSound(null, boss.blockPosition(), ModSounds.BOSS_THEME.get(), SoundSource.RECORDS, 1.0f, 1.0f);
        level.sendParticles(net.minecraft.core.particles.ParticleTypes.REVERSE_PORTAL, x, y + 1, z, 120, 0.6, 1.2, 0.6, 0.05);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 20, 0.8f));
        sp.displayClientMessage(Component.translatable("message.kingofcurses.boss_arrives").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), false);
    }

    public static void requestBoss(ServerPlayer sp) {
        CursedData d = KocSync.data(sp);
        boolean alive = BossRitual.active(sp.getUUID()) || !sp.serverLevel().getEntitiesOfClass(GojoKenjakuEntity.class, sp.getBoundingBox().inflate(128)).isEmpty()
                || !sp.serverLevel().getEntitiesOfClass(SealingMasterEntity.class, sp.getBoundingBox().inflate(128)).isEmpty();
        if (d.fingers() < 20 || d.bossDefeated() || d.ending() != CursedData.ENDING_NONE || alive) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.summon_unavailable").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        spawnBoss(sp, d);
    }

    public static void onBossDefeated(net.minecraft.world.entity.LivingEntity boss, @javax.annotation.Nullable java.util.UUID challenger) {
        if (!(boss.level() instanceof ServerLevel level)) return;
        if (boss instanceof GojoKenjakuEntity) com.kingofcurses.common.KocWorldData.get(level.getServer()).setBossDefeated();
        for (ServerPlayer p : level.getPlayers(p -> p.distanceToSqr(boss) < 96 * 96 || p.getUUID().equals(challenger))) {
            CursedCapability.get(p).ifPresent(d -> {
                if (d.fingers() >= 20 && !d.bossDefeated() && d.ending() == CursedData.ENDING_NONE) {
                    d.setBossDefeated(true);
                    KocAdvancements.award(p, "sealer_defeated");
                    p.displayClientMessage(Component.translatable("message.kingofcurses.boss_defeated").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
                    KocSync.sync(p);
                    ModNetwork.sendTo(p, new OpenScreenPacket(OpenScreenPacket.ENDING));
                }
            });
        }
    }

    public static void requestEndingScreen(ServerPlayer sp) {
        CursedData d = KocSync.data(sp);
        if (d.ending() != CursedData.ENDING_NONE) { sp.displayClientMessage(Component.translatable("message.kingofcurses.ending_locked").withStyle(ChatFormatting.GRAY), true); return; }
        if (d.fingers() >= 20 && d.bossDefeated()) ModNetwork.sendTo(sp, new OpenScreenPacket(OpenScreenPacket.ENDING));
    }

    public static void choose(ServerPlayer sp, int choice) {
        CursedData d = KocSync.data(sp);
        if (d.ending() != CursedData.ENDING_NONE) { sp.displayClientMessage(Component.translatable("message.kingofcurses.ending_locked").withStyle(ChatFormatting.GRAY), true); return; }
        if (d.fingers() < 20 || !d.bossDefeated() || (choice != EMBRACE && choice != REJECT)) return;
        ServerLevel level = sp.serverLevel();
        SukunaEntity avatar = ModEntities.SUKUNA_TRUE_FORM.get().create(level);
        if (avatar != null) {
            Vec3 p = sp.position().add(Vec3.directionFromRotation(0, sp.getYRot()).scale(3));
            avatar.setupCinematic(80);
            avatar.moveTo(p.x, sp.getY(), p.z, sp.getYRot() + 180f, 0);
            avatar.setYHeadRot(sp.getYRot() + 180f); avatar.setYBodyRot(sp.getYRot() + 180f);
            level.addFreshEntity(avatar);
            avatar.setState(choice == EMBRACE ? SukunaEntity.STATE_TAUNT : SukunaEntity.STATE_VANISH);
        }
        if (choice == EMBRACE) {
            d.setEnding(CursedData.ENDING_EMBRACE);
            d.setEnergy(d.maxEnergy());
            level.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_ROAR.get(), SoundSource.PLAYERS, 2.0f, 0.8f);
            level.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.PLAYERS, 2.0f, 0.8f);
            level.sendParticles(ModParticles.CURSED_ENERGY.get(), sp.getX(), sp.getY() + 1, sp.getZ(), 300, 1.0, 1.5, 1.0, 0.3);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 40, 1.0f));
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.MARKINGS, 100, 1.0f));
            sp.displayClientMessage(Component.translatable("message.kingofcurses.embraced").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
            KocAdvancements.award(sp, "embrace");
            for (int i = 0; i < 3; i++) SorcererHunts.spawnNear(sp, i == 0 ? ModEntities.SORCERER_ELITE.get() : ModEntities.JUJUTSU_SORCERER.get());
        } else {
            d.setEnding(CursedData.ENDING_REJECT);
            d.setEnergy(Math.min(d.energy(), d.maxEnergy()));
            d.setTakeoverTicks(0);
            level.playSound(null, sp.blockPosition(), ModSounds.SEAL_RITUAL.get(), SoundSource.PLAYERS, 2.0f, 1.0f);
            level.sendParticles(ModParticles.RESONANCE.get(), sp.getX(), sp.getY() + 1, sp.getZ(), 120, 1.0, 1.2, 1.0, 0.05);
            sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 400, 1));
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 40, 1.0f));
            sp.displayClientMessage(Component.translatable("message.kingofcurses.rejected").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
            KocAdvancements.award(sp, "reject");
        }
        PowerScaling.apply(sp, d);
        MobileControls.refresh(sp, d);
        KocSync.sync(sp);
    }
}
