package com.kingofcurses.ability;

import com.kingofcurses.KocConfig;
import com.kingofcurses.capability.CursedData;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Cursed techniques. Sukuna's unlock with fingers (Strongest of History); Gojo's are all available (Strongest of Today). */
public enum Ability {
    DISMANTLE(1, 15f, 10, Side.SUKUNA),
    CLEAVE(3, 30f, 40, Side.SUKUNA),
    REVERSE_CURSED_TECHNIQUE(5, 40f, 200, Side.BOTH),
    SPIDERWEB(8, 45f, 120, Side.SUKUNA),
    FUGA(10, 70f, 300, Side.SUKUNA),
    WORLD_SLASH(17, 120f, 600, Side.SUKUNA),
    DOMAIN_EXPANSION(20, 0f, 6000, Side.SUKUNA),
    // v1.0.18 Gojo Satoru
    BLUE(0, 25f, 40, Side.GOJO),
    RED(0, 40f, 80, Side.GOJO),
    HOLLOW_PURPLE(0, 150f, 600, Side.GOJO),
    INFINITY(0, 0f, 20, Side.GOJO),
    BLINK(0, 15f, 30, Side.GOJO),
    INFINITE_VOID(0, 0f, 6000, Side.GOJO);

    public enum Side { SUKUNA, GOJO, BOTH }

    private final int unlock;
    public final float cost;
    public final int cooldown;
    public final Side side;

    Ability(int unlock, float cost, int cooldown, Side side) { this.unlock = unlock; this.cost = cost; this.cooldown = cooldown; this.side = side; }

    public String id() { return name().toLowerCase(Locale.ROOT); }
    public Component displayName() { return Component.translatable("ability.kingofcurses." + id()); }
    public Component description() { return Component.translatable("ability.kingofcurses." + id() + ".desc"); }
    public int requiredFingers() { return this == DOMAIN_EXPANSION ? KocConfig.domainThreshold() : unlock; }
    public boolean isDomain() { return this == DOMAIN_EXPANSION || this == INFINITE_VOID; }
    public boolean forGojo() { return side != Side.SUKUNA; }
    public boolean forSukuna() { return side != Side.GOJO; }

    /** Sukuna's techniques unlocked by this many fingers. */
    public static List<Ability> unlocked(int effectiveFingers, boolean rejected) {
        List<Ability> out = new ArrayList<>();
        for (Ability a : values()) {
            if (!a.forSukuna()) continue;
            if (a == DOMAIN_EXPANSION && rejected) continue;
            if (effectiveFingers >= a.requiredFingers()) out.add(a);
        }
        return out;
    }

    /** Every technique this player can use right now, depending on the side they picked. */
    public static List<Ability> forData(CursedData d) {
        if (d.isGojo()) {
            List<Ability> out = new ArrayList<>();
            for (Ability a : values()) if (a.forGojo()) out.add(a);
            return out;
        }
        return unlocked(d.effectiveFingers(), d.ending() == CursedData.ENDING_REJECT);
    }

    /** Whether this technique belongs to the player's side (for lists and HUD). */
    public boolean visibleFor(CursedData d) { return d.isGojo() ? forGojo() : forSukuna(); }

    public static Ability byIndex(int i) {
        Ability[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
