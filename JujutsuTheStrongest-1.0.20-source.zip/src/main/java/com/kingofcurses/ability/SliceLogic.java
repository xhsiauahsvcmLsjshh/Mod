package com.kingofcurses.ability;

import com.kingofcurses.entity.GojoEntity;
import com.kingofcurses.entity.MalevolentShrineEntity;
import com.kingofcurses.entity.SlicedCorpseEntity;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.player.Player;

/** Kills by Dismantle (and every other slash technique) cut the victim in half for a few seconds. */
public final class SliceLogic {
    private static final String KEY = "kingofcurses_slashed";
    private SliceLogic() {}

    public static void mark(LivingEntity e) {
        if (!e.level().isClientSide) e.getPersistentData().putLong(KEY, e.level().getGameTime());
    }

    /** v1.0.14: torn in two from head to feet (left/right halves). */
    public static void markVertical(LivingEntity e) {
        if (e.level().isClientSide) return;
        e.getPersistentData().putLong(KEY, e.level().getGameTime());
        e.getPersistentData().putBoolean(KEY + "_vertical", true);
    }

    public static void mark(net.minecraft.world.entity.Entity e) {
        if (e instanceof LivingEntity le) mark(le);
    }

    public static void onDeath(LivingEntity e) {
        if (!(e.level() instanceof ServerLevel sl) || e instanceof Player) return;
        long t = e.getPersistentData().getLong(KEY);
        if (t == 0 || sl.getGameTime() - t > 2) return;
        if (e instanceof EnderDragon || e instanceof WitherBoss || e.getBbHeight() < 0.25f) return;
        if (e instanceof GojoEntity g && g.isCinematic()) return;
        try {
            SlicedCorpseEntity corpse = ModEntities.SLICED_CORPSE.get().create(sl);
            if (corpse == null || !corpse.setup(e)) return;
            if (e.getPersistentData().getBoolean(KEY + "_vertical")) { corpse.setVertical(true); e.getPersistentData().remove(KEY + "_vertical"); }
            corpse.moveTo(e.getX(), e.getY(), e.getZ(), e.yBodyRot, 0);
            sl.addFreshEntity(corpse);
            e.setInvisible(true);
            e.deathTime = Math.max(e.deathTime, 17); // vanish the vanilla death pose almost immediately
            sl.sendParticles(ModParticles.BLOOD.get(), e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 40 + (int) (e.getBbWidth() * 30), e.getBbWidth() * 0.4, 0.1, e.getBbWidth() * 0.4, 0.25);
            sl.sendParticles(ModParticles.SLASH.get(), e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 4, e.getBbWidth() * 0.5, 0.02, e.getBbWidth() * 0.5, 0);
            sl.playSound(null, e.blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.HOSTILE, 1.0f, 0.9f + sl.random.nextFloat() * 0.2f);
        } catch (RuntimeException ex) {
            com.kingofcurses.KingOfCurses.LOGGER.debug("Could not slice {}", e, ex);
        }
    }
}
