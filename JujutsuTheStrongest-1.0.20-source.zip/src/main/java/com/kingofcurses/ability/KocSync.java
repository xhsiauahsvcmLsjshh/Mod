package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.SyncDataPacket;
import com.kingofcurses.network.SyncOtherPacket;
import net.minecraft.server.level.ServerPlayer;

public final class KocSync {
    private KocSync() {}

    public static void sync(ServerPlayer sp) {
        CursedCapability.get(sp).ifPresent(d -> {
            ModNetwork.sendTo(sp, new SyncDataPacket(d.syncTag()));
            ModNetwork.sendToTrackingAndSelf(sp, new SyncOtherPacket(sp.getId(), d.fingers(), d.ending() | (d.lostArms() << 4)));
            d.clean();
        });
    }

    public static void syncOtherTo(ServerPlayer target, ServerPlayer viewer) {
        CursedCapability.get(target).ifPresent(d -> ModNetwork.sendTo(viewer, new SyncOtherPacket(target.getId(), d.fingers(), d.ending() | (d.lostArms() << 4))));
    }

    public static CursedData data(ServerPlayer sp) {
        return CursedCapability.get(sp).orElseGet(CursedData::new);
    }
}
