package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.GojoEntity;
import com.kingofcurses.entity.TojiEntity;
import com.kingofcurses.network.GojoIntroPacket;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModItems;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * v1.0.18 "Strongest of Today" opening: the player, as Gojo, is ambushed and stabbed to death by Toji Fushiguro
 * (Inverted Spear of Heaven, the Inventory Curse on his shoulders). Toji walks away. Gojo awakens Reverse Cursed
 * Technique, heals everything, and erases Toji with Hollow Purple. Toji's body stays, with the worm.
 */
public final class GojoIntroDirector {
    public static final int LENGTH = 520;
    public static final int T_APPROACH = 0, T_STAB1 = 44, T_FALL = 96, T_LEAVE = 112, T_AWAKE = 168, T_RISE = 186, T_TURN = 226, T_CHARGE = 236, T_FIRE = 266, T_HIT = 272, T_AFTER = 300,
            T_GETO = 330, T_TALK = 384, T_LINE2 = 414, T_LINE3 = 444, T_LINE4 = 478, T_END = 506;   // v1.0.20 Geto at the Jujutsu Institute
    private static final Map<UUID, Scene> SCENES = new HashMap<>();
    private static final Map<UUID, int[]> PENDING = new HashMap<>();   // {ticks left, phase 0 = go to the institute, 1 = start}

    private static final class Scene {
        final UUID player; final ServerLevel level; final Vec3 lock; final float yaw; final Vec3 fwd;
        int tick, gojoId = -1, tojiId = -1, getoId = -1;
        Vec3 getoFrom, getoTo;
        float faceYaw;
        Vec3 tojiFrom, tojiAway;
        Scene(UUID p, ServerLevel l, Vec3 lock, float yaw) {
            player = p; level = l; this.lock = lock; this.yaw = yaw;
            float y = yaw * Mth.DEG_TO_RAD;
            fwd = new Vec3(-Mth.sin(y), 0, Mth.cos(y));
            faceYaw = yaw;
        }
    }

    private GojoIntroDirector() {}

    public static boolean isInScene(UUID id) { return SCENES.containsKey(id); }

    public static void schedule(ServerPlayer sp, int delay) {
        if (SCENES.containsKey(sp.getUUID())) return;
        PENDING.put(sp.getUUID(), new int[]{delay, 0});
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.LOADING, delay + 90, 0f));
    }

    /** Teleports the player into the courtyard of the nearest Jujutsu High. */
    private static boolean goToInstitute(ServerPlayer sp) {
        ServerLevel sl = sp.serverLevel();
        try {
            var reg = sl.registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.STRUCTURE);
            var set = reg.getTag(com.kingofcurses.worldgen.KocWorldgen.JUJUTSU_INSTITUTES);
            if (set.isEmpty()) return false;
            var res = sl.getChunkSource().getGenerator().findNearestMapStructure(sl, set.get(), sp.blockPosition(), 100, false);
            if (res == null) return false;
            net.minecraft.world.level.ChunkPos cp = new net.minecraft.world.level.ChunkPos(res.getFirst());
            var ca = sl.getChunk(cp.x, cp.z, net.minecraft.world.level.chunk.ChunkStatus.STRUCTURE_STARTS);
            var ss = sl.structureManager().getStartForStructure(net.minecraft.core.SectionPos.bottomOf(ca), res.getSecond().value(), ca);
            net.minecraft.core.BlockPos c = ss != null && ss.isValid() ? ss.getBoundingBox().getCenter() : res.getFirst();
            int floor = ss != null && ss.isValid() ? ss.getBoundingBox().minY() + 1 : -999;
            for (int cx = (c.getX() >> 4) - 2; cx <= (c.getX() >> 4) + 2; cx++) for (int cz = (c.getZ() >> 4) - 2; cz <= (c.getZ() >> 4) + 2; cz++) sl.getChunk(cx, cz);
            net.minecraft.core.BlockPos best = null;
            for (int r = 3; r <= 14 && best == null; r++) for (int a = 0; a < 16 && best == null; a++) {   // an open yard spot, not a roof
                int x = c.getX() + (int) Math.round(Math.cos(a * Math.PI / 8) * r), z = c.getZ() + (int) Math.round(Math.sin(a * Math.PI / 8) * r);
                int y = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                if (floor == -999 || Math.abs(y - floor) <= 1) best = new net.minecraft.core.BlockPos(x, y, z);
            }
            if (best == null) best = new net.minecraft.core.BlockPos(c.getX(), sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, c.getX(), c.getZ()), c.getZ());
            sp.teleportTo(sl, best.getX() + 0.5, best.getY(), best.getZ() + 0.5, sp.getYRot(), 0);
            return true;
        } catch (RuntimeException ex) {
            com.kingofcurses.KingOfCurses.LOGGER.warn("Could not find a Jujutsu High for the intro", ex);
            return false;
        }
    }

    private static double ground(ServerLevel l, double x, double z) { return l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z)); }

    private static void start(ServerPlayer sp) {
        ServerLevel sl = sp.serverLevel();
        Scene s = new Scene(sp.getUUID(), sl, sp.position(), sp.getYRot());
        TojiEntity toji = ModEntities.TOJI_FUSHIGURO.get().create(sl);
        if (toji == null) return;   // v1.0.19: no Gojo actor, the PLAYER is Gojo
        Vec3 from = sp.position().subtract(s.fwd.scale(10));
        s.tojiFrom = new Vec3(from.x, ground(sl, from.x, from.z), from.z);
        Vec3 away = sp.position().subtract(s.fwd.scale(14)).add(new Vec3(-s.fwd.z, 0, s.fwd.x).scale(4));
        s.tojiAway = new Vec3(away.x, ground(sl, away.x, away.z), away.z);
        toji.setupCinematic();
        toji.moveTo(s.tojiFrom.x, s.tojiFrom.y, s.tojiFrom.z, s.yaw, 0);
        sl.addFreshEntity(toji);
        s.tojiId = toji.getId();
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, LENGTH + 40, 4, true, false, false));
        SCENES.put(sp.getUUID(), s);
        ModNetwork.sendTo(sp, new GojoIntroPacket(GojoIntroPacket.START, s.gojoId, s.tojiId, 0));
    }

    public static void skip(ServerPlayer sp) {
        Scene s = SCENES.remove(sp.getUUID());
        if (s != null) finish(sp, s, true);
        PENDING.remove(sp.getUUID());
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, int[]>> pit = PENDING.entrySet().iterator();
        while (pit.hasNext()) {
            Map.Entry<UUID, int[]> en = pit.next();
            int[] v = en.getValue();
            if (--v[0] > 0) continue;
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null || !sp.isAlive()) { pit.remove(); continue; }
            if (v[1] == 0) {                          // v1.0.20: the story starts at the Jujutsu Institute
                v[1] = 1; v[0] = goToInstitute(sp) ? 70 : 5;
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.LOADING, v[0] + 10, 0f));
                continue;
            }
            pit.remove();
            start(sp);
        }
        Iterator<Map.Entry<UUID, Scene>> it = SCENES.entrySet().iterator();
        while (it.hasNext()) {
            Scene s = it.next().getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(s.player);
            if (sp == null || sp.level() != s.level || !sp.isAlive()) { if (sp != null) finish(sp, s, true); else cleanup(s, true); it.remove(); continue; }
            s.tick++;
            if (sp.position().distanceToSqr(s.lock) > 0.25 || Math.abs(Mth.wrapDegrees(sp.getYRot() - s.faceYaw)) > 1f) sp.connection.teleport(s.lock.x, s.lock.y, s.lock.z, s.faceYaw, 0);
            sp.setDeltaMovement(Vec3.ZERO);
            if (s.tick % 10 == 0) ModNetwork.sendTo(sp, new GojoIntroPacket(GojoIntroPacket.SYNC, s.gojoId, s.tojiId, s.tick));
            try { run(s, sp); } catch (RuntimeException ex) {
                com.kingofcurses.KingOfCurses.LOGGER.error("Gojo intro error, skipping", ex);
                it.remove(); finish(sp, s, true); continue;
            }
            if (s.tick >= T_END) { it.remove(); finish(sp, s, false); }
        }
    }

    private static void face(net.minecraft.world.entity.LivingEntity e, Vec3 at) {
        float yaw = CinematicDirector.yawTowards(e.position(), at);
        e.setYRot(yaw); e.yRotO = yaw; e.setYBodyRot(yaw); e.setYHeadRot(yaw);
    }

    private static void run(Scene s, ServerPlayer sp) {
        ServerLevel sl = s.level;
        TojiEntity toji = sl.getEntity(s.tojiId) instanceof TojiEntity t ? t : null;
        if (toji == null) return;
        int t = s.tick;
        Vec3 g = s.lock;
        ServerPlayer gojo = sp;
        Vec3 behind = g.subtract(s.fwd.scale(1.1));
        // ---- Toji walks up behind Gojo
        if (t < T_STAB1) {
            double k = Mth.clamp(t / (double) (T_STAB1 - 4), 0, 1);
            Vec3 p = s.tojiFrom.lerp(behind, k);
            toji.moveTo(p.x, ground(sl, p.x, p.z), p.z, toji.getYRot(), 0);
            face(toji, g);
            toji.setState(k < 1 ? TojiEntity.STATE_WALK : TojiEntity.STATE_IDLE);
        }
        // ---- the stabbing
        if (t >= T_STAB1 && t < T_FALL && (t - T_STAB1) % 10 == 0) {
            toji.setState(TojiEntity.STATE_IDLE);
            toji.triggerAnim("main", "stab");
            Vec3 c = g.add(0, 1.2, 0);
            sl.sendParticles(ModParticles.BLOOD.get(), c.x, c.y, c.z, 30 + (t - T_STAB1), 0.2, 0.3, 0.2, 0.25);
            sl.playSound(null, gojo.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.HOSTILE, 1.4f, 0.6f);
            sl.playSound(null, gojo.blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.HOSTILE, 1.2f, 0.9f);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 6, 0.5f));
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 6, 0.4f));
        }
        if (t == T_STAB1 + 1) sl.playSound(null, gojo.blockPosition(), ModSounds.GOJO_INFINITY.get(), SoundSource.HOSTILE, 1.0f, 0.5f);   // Infinity fails
        if (t == T_FALL) {
            sl.playSound(null, gojo.blockPosition(), SoundEvents.PLAYER_HURT, SoundSource.HOSTILE, 1.0f, 0.6f);
            toji.setState(TojiEntity.STATE_SMIRK);
        }
        // ---- Toji leaves
        if (t >= T_LEAVE && t < T_AWAKE + 20) {
            double k = Mth.clamp((t - T_LEAVE) / 70.0, 0, 1);
            Vec3 p = behind.lerp(s.tojiAway, k);
            toji.moveTo(p.x, ground(sl, p.x, p.z), p.z, toji.getYRot(), 0);
            face(toji, s.tojiAway.add(s.tojiAway.subtract(behind)));
            toji.setState(k < 1 ? TojiEntity.STATE_WALK : TojiEntity.STATE_IDLE);
        }
        // ---- Reverse Cursed Technique
        if (t == T_AWAKE) {
            sl.playSound(null, gojo.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.HOSTILE, 2.0f, 0.9f);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 10, 0.5f));
        }
        if (t >= T_AWAKE && t < T_TURN && t % 3 == 0) {
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, g.x, g.y + 0.6, g.z, 6, 0.4, 0.3, 0.4, 0.02);
            sl.sendParticles(ParticleTypes.END_ROD, g.x, g.y + 0.6, g.z, 3, 0.4, 0.4, 0.4, 0.02);
        }
        if (t == T_RISE) {
            sl.playSound(null, gojo.blockPosition(), ModSounds.RCT_HEAL.get(), SoundSource.HOSTILE, 2.0f, 1.0f);
        }
        // ---- Hollow Purple
        if (t == T_TURN) { s.faceYaw = CinematicDirector.yawTowards(g, toji.position()); toji.setState(TojiEntity.STATE_IDLE); face(toji, g); }
        if (t == T_CHARGE) {
            sl.playSound(null, gojo.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 2.0f, 0.5f);
        }
        if (t > T_CHARGE && t < T_FIRE) {
            Vec3 dir = toji.position().subtract(g).normalize();
            Vec3 right = new Vec3(-dir.z, 0, dir.x);
            Vec3 c = g.add(0, 1.45, 0).add(dir.scale(0.9));
            double spread = Math.max(0, 1.1 - (t - T_CHARGE) * 0.04);
            Vec3 r = c.add(right.scale(spread)), b = c.add(right.scale(-spread));
            sl.sendParticles(GojoLogic.RED_DUST, r.x, r.y, r.z, 8, 0.1, 0.1, 0.1, 0);
            sl.sendParticles(GojoLogic.BLUE_DUST, b.x, b.y, b.z, 8, 0.1, 0.1, 0.1, 0);
        }
        if (t >= T_FIRE && t <= T_HIT) {
            Vec3 c = g.add(0, 1.45, 0);
            Vec3 to = toji.position().add(0, 1, 0);
            double k = (t - T_FIRE + 1) / (double) (T_HIT - T_FIRE + 1);
            for (int i = 0; i < 6; i++) {
                Vec3 p = c.lerp(to, k * i / 5.0);
                sl.sendParticles(GojoLogic.PURPLE_DUST, p.x, p.y, p.z, 10, 0.6, 0.6, 0.6, 0.02);
            }
            if (t == T_FIRE) {
                sl.playSound(null, gojo.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 3.0f, 0.5f);
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 30, 1.2f));
            }
        }
        // ---- v1.0.20 Geto arrives: "Sukuna is back"
        if (t == T_GETO) {
            com.kingofcurses.entity.GetoEntity geto = null;
            for (com.kingofcurses.entity.GetoEntity e : sl.getEntitiesOfClass(com.kingofcurses.entity.GetoEntity.class, new net.minecraft.world.phys.AABB(g, g).inflate(48))) { geto = e; break; }
            Vec3 side = new Vec3(-s.fwd.z, 0, s.fwd.x);
            Vec3 from = g.add(s.fwd.scale(9)).add(side.scale(6));
            s.getoFrom = new Vec3(from.x, ground(sl, from.x, from.z), from.z);
            Vec3 to = g.add(s.fwd.scale(2.4)).add(side.scale(0.6));
            s.getoTo = new Vec3(to.x, ground(sl, to.x, to.z), to.z);
            if (geto == null) {
                geto = ModEntities.SUGURU_GETO.get().create(sl);
                if (geto != null) { geto.moveTo(s.getoFrom.x, s.getoFrom.y, s.getoFrom.z, 0, 0); sl.addFreshEntity(geto); }
            } else geto.moveTo(s.getoFrom.x, s.getoFrom.y, s.getoFrom.z, 0, 0);
            if (geto != null) {
                s.getoId = geto.getId();
                geto.setNoAi(true);
                ModNetwork.sendTo(sp, new GojoIntroPacket(GojoIntroPacket.GETO, geto.getId(), -1, t));
            }
        }
        if (t > T_GETO && sl.getEntity(s.getoId) instanceof com.kingofcurses.entity.GetoEntity geto) {
            double k = Mth.clamp((t - T_GETO) / (double) (T_TALK - T_GETO - 6), 0, 1);
            Vec3 p = s.getoFrom.lerp(s.getoTo, k);
            geto.moveTo(p.x, ground(sl, p.x, p.z), p.z, geto.getYRot(), 0);
            face(geto, g);
            if (t == T_GETO + 20) s.faceYaw = CinematicDirector.yawTowards(g, s.getoTo);
            if (t == T_TALK) geto.setTalking(true);
            if (t == T_LINE4) geto.setTalking(false);
        }
        if (t == T_HIT) {
            Vec3 c = toji.position().add(0, 1, 0);
            sl.sendParticles(GojoLogic.PURPLE_DUST, c.x, c.y, c.z, 260, 1.4, 1.2, 1.4, 0.3);
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
            sl.sendParticles(ModParticles.BLOOD.get(), c.x, c.y, c.z, 80, 0.5, 0.5, 0.5, 0.3);
            sl.playSound(null, toji.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 2.0f, 0.6f);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 16, 1.0f));
            toji.makeCorpse();
        }

    }

    private static void finish(ServerPlayer sp, Scene s, boolean skipped) {
        ServerLevel sl = s.level;
        if (sl.getEntity(s.getoId) instanceof com.kingofcurses.entity.GetoEntity geto) { geto.setTalking(false); geto.setNoAi(false); }
        TojiEntity toji = sl.getEntity(s.tojiId) instanceof TojiEntity t ? t : null;
        float yaw = s.faceYaw;
        if (toji != null && !toji.isCorpse()) {         // skipped early: Toji still falls to Hollow Purple
            toji.makeCorpse();
        }
        sp.connection.teleport(s.lock.x, s.lock.y, s.lock.z, yaw, 0);
        ModNetwork.sendTo(sp, new GojoIntroPacket(GojoIntroPacket.STOP, -1, -1, 0));
        CursedData d = KocSync.data(sp);
        d.setIntroSeen(true);
        d.setEnergy(d.maxEnergy());
        if (sp.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) sp.setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.GOJO_BLINDFOLD.get()));
        PowerScaling.apply(sp, d);
        KocSync.sync(sp);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.gojo_start").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.gojo_start2").withStyle(ChatFormatting.GRAY), false);
        if (d.controlMode() == CursedData.CONTROL_NONE)
            ModNetwork.sendTo(sp, new com.kingofcurses.network.OpenScreenPacket(com.kingofcurses.network.OpenScreenPacket.CONTROL_MODE));
    }

    private static void cleanup(Scene s, boolean all) {
        if (s.level.getEntity(s.tojiId) instanceof TojiEntity t && !t.isCorpse()) t.makeCorpse();
    }

    public static void clear() { SCENES.clear(); PENDING.clear(); }
}
