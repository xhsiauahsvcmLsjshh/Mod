package com.kingofcurses.ability;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.entity.NamedSorcererEntity;
import com.kingofcurses.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * v1.0.8 "KING OF CURSES" difficulty (game rule kocKingOfCursesMode, also toggled from the Codex or with
 * /kingofcurses mode on|off). Yuta, Hakari, Maki, Megumi, Todo and Nanami roam the Overworld around every player.
 */
@Mod.EventBusSubscriber(modid = KingOfCurses.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class KocMode {
    public static final String SHIKIGAMI = "kingofcurses_shikigami";
    public static GameRules.Key<GameRules.BooleanValue> RULE;
    /** v1.0.18 Pick Your Side, chosen on the Create World screen: 0 = Strongest of History, 1 = Strongest of Today. */
    public static GameRules.Key<GameRules.IntegerValue> SIDE;
    private KocMode() {}

    /** Called from the mod constructor, before any world loads. */
    public static void init() {
        if (RULE == null) RULE = GameRules.register("kocKingOfCursesMode", GameRules.Category.MOBS, GameRules.BooleanValue.create(false));
        if (SIDE == null) SIDE = GameRules.register("kocPickYourSide", GameRules.Category.PLAYER, GameRules.IntegerValue.create(0));
    }

    /** v1.0.18: the roaming named sorcerers now simply follow the world difficulty: Hard only. */
    public static boolean enabled(Level level) { return level.getDifficulty() == net.minecraft.world.Difficulty.HARD; }

    public static int worldSide(Level level) { return SIDE == null ? 0 : Math.max(0, Math.min(1, level.getGameRules().getInt(SIDE))); }

    public static void toggle(ServerPlayer sp) {
        sp.displayClientMessage(Component.translatable("message.kingofcurses.mode_difficulty").withStyle(ChatFormatting.GRAY), false);
    }

    public static void toggleOld(ServerPlayer sp) {
        boolean owner = sp.hasPermissions(2) || sp.server.isSingleplayerOwner(sp.getGameProfile());
        if (!owner) { sp.displayClientMessage(Component.translatable("message.kingofcurses.mode_denied").withStyle(ChatFormatting.GRAY), true); return; }
        set(sp.server, !enabled(sp.level()));
    }

    public static void set(net.minecraft.server.MinecraftServer server, boolean on) {
        server.getGameRules().getRule(RULE).set(on, server);
        for (ServerPlayer p : server.getPlayerList().getPlayers())
            p.displayClientMessage(Component.translatable(on ? "message.kingofcurses.mode_on" : "message.kingofcurses.mode_off")
                    .withStyle(on ? ChatFormatting.DARK_RED : ChatFormatting.GRAY, ChatFormatting.BOLD), false);
    }

    private static final List<java.util.function.Supplier<EntityType<NamedSorcererEntity>>> ROSTER = List.of(
            () -> ModEntities.YUTA_OKKOTSU.get(), () -> ModEntities.KINJI_HAKARI.get(), () -> ModEntities.MAKI_ZENIN.get(),
            () -> ModEntities.MEGUMI_FUSHIGURO.get(), () -> ModEntities.AOI_TODO.get(), () -> ModEntities.KENTO_NANAMI.get());

    @SubscribeEvent
    public static void playerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer sp) || sp.tickCount % 400 != 0) return;
        ServerLevel sl = sp.serverLevel();
        if (!enabled(sl) || sl.dimension() != Level.OVERWORLD || sp.isSpectator() || CinematicDirector.isInScene(sp.getUUID())) return;
        int near = sl.getEntitiesOfClass(NamedSorcererEntity.class, sp.getBoundingBox().inflate(64), e -> e.actor() == NamedSorcererEntity.ACTOR_NONE).size();
        if (near >= 4) return;
        EntityType<NamedSorcererEntity> type = ROSTER.get(sp.getRandom().nextInt(ROSTER.size())).get();
        for (int attempt = 0; attempt < 6; attempt++) {
            double a = sp.getRandom().nextDouble() * Math.PI * 2, r = 22 + sp.getRandom().nextDouble() * 16;
            int x = Mth.floor(sp.getX() + Math.cos(a) * r), z = Mth.floor(sp.getZ() + Math.sin(a) * r);
            if (!sl.hasChunkAt(new BlockPos(x, 0, z))) continue;
            int y = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!sl.getFluidState(pos.below()).isEmpty() || !sl.getBlockState(pos).isAir()) continue;
            NamedSorcererEntity e = type.create(sl);
            if (e == null) return;
            e.moveTo(x + 0.5, y, z + 0.5, sp.getRandom().nextFloat() * 360f, 0);
            e.finalizeSpawn(sl, sl.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null, null);
            sl.addFreshEntity(e);
            return;
        }
    }

    /** Megumi's Divine Dogs fade back into the shadows. */
    @SubscribeEvent
    public static void livingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity e = event.getEntity();
        if (e.level().isClientSide || !e.getPersistentData().contains(SHIKIGAMI)) return;
        int left = e.getPersistentData().getInt(SHIKIGAMI) - 1;
        if (left <= 0 || (e instanceof net.minecraft.world.entity.Mob m && m.getTarget() != null && !KocTargets.isFoe(m.getTarget()))) {
            if (e.level() instanceof ServerLevel sl)
                sl.sendParticles(net.minecraft.core.particles.ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + 0.4, e.getZ(), 20, 0.3, 0.2, 0.3, 0.01);
            e.discard();
            return;
        }
        e.getPersistentData().putInt(SHIKIGAMI, left);
    }
}
