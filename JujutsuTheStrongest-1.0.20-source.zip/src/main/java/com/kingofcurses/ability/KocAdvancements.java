package com.kingofcurses.ability;

import com.kingofcurses.KingOfCurses;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

/** Advancements use the "minecraft:impossible" trigger and are granted from code. */
public final class KocAdvancements {
    private KocAdvancements() {}

    public static void award(ServerPlayer sp, String path) {
        Advancement adv = sp.server.getAdvancements().getAdvancement(new ResourceLocation(KingOfCurses.MODID, path));
        if (adv == null) return;
        AdvancementProgress progress = sp.getAdvancements().getOrStartProgress(adv);
        if (progress.isDone()) return;
        List<String> remaining = new ArrayList<>();
        progress.getRemainingCriteria().forEach(remaining::add);
        for (String c : remaining) sp.getAdvancements().award(adv, c);
    }
}
