package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.RipAnimPacket;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * v1.0.7 body logic:
 *  - losing an arm to heavy hits (vessels only) and regrowing it with cursed energy (R / any technique);
 *  - the four-arm awakening at twenty fingers (60-tick transformation);
 *  - Black Flash: the 4th consecutive melee hit on the same target.
 */
public final class ArmLogic {
    public static final int TRANSFORM_LENGTH = 60, REGROW_LENGTH = 30;
    public static final float REGROW_COST = 30f;
    private static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.02f, 0.0f, 0.02f), 2.2f);
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(1.0f, 0.05f, 0.1f), 1.6f);
    private static final Map<UUID, Integer> TRANSFORMING = new HashMap<>();
    private static final Map<UUID, int[]> COMBO = new HashMap<>(); // targetId, hits, last tick
    private ArmLogic() {}

    private static Vec3 shoulder(ServerPlayer sp, int arm) {
        Vec3 side = Vec3.directionFromRotation(0, sp.yBodyRot + 90f);
        return sp.position().add(0, 1.35, 0).add(side.scale(arm == CursedData.ARM_RIGHT ? -0.38 : 0.38));
    }

    // ------------------------------------------------------------------ losing / regrowing arms
    public static void onHurt(ServerPlayer sp, CursedData d, DamageSource src, float amount) {
        if (d.fingers() <= 0 || d.lostArms() == 3 || src.getEntity() == null || amount < 6f) return;
        if (sp.getHealth() - amount > sp.getMaxHealth() * 0.5f || sp.getHealth() - amount <= 0) return;
        if (sp.getRandom().nextFloat() > 0.3f) return;
        int arm;
        if (d.lostArms() == 0) arm = sp.getRandom().nextBoolean() ? CursedData.ARM_RIGHT : CursedData.ARM_LEFT;
        else arm = d.lostArms() == CursedData.ARM_RIGHT ? CursedData.ARM_LEFT : CursedData.ARM_RIGHT;
        d.setLostArms(d.lostArms() | arm);
        ServerLevel sl = sp.serverLevel();
        Vec3 sh = shoulder(sp, arm);
        sl.sendParticles(ModParticles.BLOOD.get(), sh.x, sh.y, sh.z, 60, 0.15, 0.2, 0.15, 0.25);
        sl.playSound(null, sp.blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.PLAYERS, 1.4f, 0.7f);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 20, 1.0f));
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 16, 0.8f));
        if (arm == CursedData.ARM_LEFT) dropOffhand(sp);
        sp.displayClientMessage(Component.translatable(arm == CursedData.ARM_RIGHT ? "message.kingofcurses.lost_right" : "message.kingofcurses.lost_left",
                Component.keybind("key.kingofcurses.use_ability"), (int) REGROW_COST).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        KocSync.sync(sp);
    }

    private static void dropOffhand(ServerPlayer sp) {
        ItemStack off = sp.getOffhandItem();
        if (!off.isEmpty()) { sp.drop(off.copy(), false); sp.setItemInHand(net.minecraft.world.InteractionHand.OFF_HAND, ItemStack.EMPTY); }
    }

    /** Regrows every missing arm. @return true (the key press is consumed either way). */
    public static boolean regenerate(ServerPlayer sp, CursedData d) {
        int arms = d.lostArms();
        if (arms == 0) return false;
        if (!sp.isCreative() && d.energy() < REGROW_COST) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.regrow_energy", (int) REGROW_COST).withStyle(ChatFormatting.DARK_RED), true);
            return true;
        }
        if (!sp.isCreative()) d.addEnergy(-REGROW_COST);
        d.setLostArms(0);
        ModNetwork.sendToTrackingAndSelf(sp, new RipAnimPacket(sp.getId(), RipAnimPacket.REGROW, arms));
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, REGROW_LENGTH, 3, false, false));
        ServerLevel sl = sp.serverLevel();
        for (int a : new int[]{CursedData.ARM_RIGHT, CursedData.ARM_LEFT}) {
            if ((arms & a) == 0) continue;
            Vec3 sh = shoulder(sp, a);
            sl.sendParticles(ModParticles.CURSED_ENERGY.get(), sh.x, sh.y - 0.3, sh.z, 50, 0.15, 0.35, 0.15, 0.04);
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, sh.x, sh.y - 0.3, sh.z, 12, 0.15, 0.35, 0.15, 0);
        }
        sl.playSound(null, sp.blockPosition(), ModSounds.RCT_HEAL.get(), SoundSource.PLAYERS, 1.2f, 0.9f);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.regrown").withStyle(ChatFormatting.GREEN), true);
        KocSync.sync(sp);
        return true;
    }

    // ------------------------------------------------------------------ four-arm awakening
    public static void startTransform(ServerPlayer sp) {
        TRANSFORMING.put(sp.getUUID(), 0);
        ModNetwork.sendToTrackingAndSelf(sp, new RipAnimPacket(sp.getId(), RipAnimPacket.TRANSFORM, 0));
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, TRANSFORM_LENGTH, 6, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.JUMP, TRANSFORM_LENGTH, 128, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, TRANSFORM_LENGTH, 4, false, false));
        sp.serverLevel().playSound(null, sp.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.PLAYERS, 1.5f, 0.6f);
    }

    public static void tick(ServerPlayer sp, CursedData d) {
        // missing arms: a weak main arm, no off-hand, and dripping blood
        if (d.lostArms() != 0) {
            if ((d.lostArms() & CursedData.ARM_LEFT) != 0) dropOffhand(sp);
            if ((d.lostArms() & CursedData.ARM_RIGHT) != 0 && sp.tickCount % 40 == 0) {
                sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1, false, false, true));
                sp.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 60, 1, false, false, true));
            }
            if (sp.tickCount % 8 == 0) {
                for (int a : new int[]{CursedData.ARM_RIGHT, CursedData.ARM_LEFT}) {
                    if ((d.lostArms() & a) == 0) continue;
                    Vec3 sh = shoulder(sp, a);
                    sp.serverLevel().sendParticles(ModParticles.BLOOD.get(), sh.x, sh.y - 0.1, sh.z, 1, 0.03, 0.03, 0.03, 0);
                }
            }
        }
        Integer t = TRANSFORMING.get(sp.getUUID());
        if (t == null) return;
        t++;
        ServerLevel sl = sp.serverLevel();
        if (t == 18) {                                    // the new arms tear out of the sides
            for (int a : new int[]{CursedData.ARM_RIGHT, CursedData.ARM_LEFT}) {
                Vec3 sh = shoulder(sp, a).add(0, -0.4, 0);
                sl.sendParticles(ModParticles.BLOOD.get(), sh.x, sh.y, sh.z, 50, 0.15, 0.15, 0.15, 0.3);
            }
            sl.playSound(null, sp.blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.PLAYERS, 1.6f, 0.6f);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 30, 1.0f));
        }
        if (t == 34) {                                    // the second pair of eyes opens
            sl.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_ROAR.get(), SoundSource.PLAYERS, 2.0f, 0.8f);
            sl.sendParticles(ModParticles.CURSED_ENERGY.get(), sp.getX(), sp.getY() + 1.6, sp.getZ(), 200, 0.8, 1.0, 0.8, 0.25);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 30, 1.0f));
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.MARKINGS, 80, 1.0f));
        }
        if (t >= TRANSFORM_LENGTH) TRANSFORMING.remove(sp.getUUID()); else TRANSFORMING.put(sp.getUUID(), t);
    }

    // ------------------------------------------------------------------ Black Flash
    public static void blackFlash(LivingHurtEvent event) {
        if (FinisherLogic.dealing) return;
        DamageSource src = event.getSource();
        if (!(src.getEntity() instanceof ServerPlayer sp) || src.getDirectEntity() != sp || !src.is(DamageTypes.PLAYER_ATTACK)) return;
        CursedData d = KocSync.data(sp);
        if (!d.hasPowers()) return;
        LivingEntity target = event.getEntity();
        int[] st = COMBO.computeIfAbsent(sp.getUUID(), k -> new int[3]);
        if (st[0] != target.getId() || sp.tickCount - st[2] > 60) { st[0] = target.getId(); st[1] = 0; }
        st[1]++;
        st[2] = sp.tickCount;
        if (st[1] < 4) return;
        st[1] = 0;
        event.setAmount(event.getAmount() * 2.5f + 4f);
        d.addEnergy(25f);
        ServerLevel sl = sp.serverLevel();
        Vec3 c = target.position().add(0, target.getBbHeight() * 0.55, 0);
        sl.sendParticles(BLACK, c.x, c.y, c.z, 90, 0.5, 0.5, 0.5, 0.25);
        sl.sendParticles(RED, c.x, c.y, c.z, 60, 0.6, 0.6, 0.6, 0.3);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 40, 0.4, 0.4, 0.4, 0.6);
        sl.sendParticles(ParticleTypes.SONIC_BOOM, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        sl.playSound(null, target.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.4f, 0.6f);
        sl.playSound(null, target.blockPosition(), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.PLAYERS, 1.6f, 0.7f);
        Vec3 push = target.position().subtract(sp.position()).normalize();
        target.setDeltaMovement(target.getDeltaMovement().add(push.x * 1.2, 0.35, push.z * 1.2));
        target.hurtMarked = true;
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.BLACK_FLASH, 30, 1.0f));
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 10, 0.7f));
        KocSync.sync(sp);
    }

    public static void clear() { TRANSFORMING.clear(); COMBO.clear(); }
}
