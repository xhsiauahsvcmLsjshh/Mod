package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.item.TechniqueItem;
import com.kingofcurses.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

/** PC vs mobile gameplay. v1.0.12: mobile no longer uses Technique items, it uses gestures + the touch Technique Pad. */
public final class MobileControls {
    private MobileControls() {}

    public static Item itemFor(Ability a) {
        for (RegistryObject<Item> ro : ModItems.ITEMS.getEntries()) {
            if (ro.get() instanceof TechniqueItem t && t.ability() == a) return t;
        }
        return null;
    }

    private static boolean has(ServerPlayer sp, Item item) {
        for (ItemStack s : sp.getInventory().items) if (s.is(item)) return true;
        for (ItemStack s : sp.getInventory().offhand) if (s.is(item)) return true;
        return false;
    }

    /** v1.0.12: technique items are no longer handed out (kept registered so old worlds load). */
    public static void giveUnlocked(ServerPlayer sp, CursedData d) {
        removeInvalid(sp, d);
    }

    /** Removes every leftover Technique item from the inventory. */
    public static void removeInvalid(ServerPlayer sp, CursedData d) {
        for (List<ItemStack> inv : List.of(sp.getInventory().items, sp.getInventory().offhand)) {
            for (int i = 0; i < inv.size(); i++) {
                if (inv.get(i).getItem() instanceof TechniqueItem) inv.set(i, ItemStack.EMPTY);
            }
        }
    }

    public static void refresh(ServerPlayer sp, CursedData d) {
        removeInvalid(sp, d);
    }

    public static void setMode(ServerPlayer sp, int mode) {
        if (mode != CursedData.CONTROL_PC && mode != CursedData.CONTROL_MOBILE) return;
        CursedData d = KocSync.data(sp);
        d.setControlMode(mode);
        refresh(sp, d);
        sp.displayClientMessage(Component.translatable(mode == CursedData.CONTROL_MOBILE ? "message.kingofcurses.mode_mobile" : "message.kingofcurses.mode_pc")
                .withStyle(ChatFormatting.DARK_RED), false);
        KocSync.sync(sp);
    }
}
