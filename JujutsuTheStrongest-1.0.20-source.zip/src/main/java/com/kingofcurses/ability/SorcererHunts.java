package com.kingofcurses.ability;

import com.kingofcurses.KocConfig;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.SorcererEntity;
import com.kingofcurses.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.levelgen.Heightmap;

/** The more cursed a player becomes, the more often jujutsu sorcerers come for them. */
public final class SorcererHunts {
    private SorcererHunts() {}

    public static void tick(ServerPlayer sp, CursedData d) {
        if (!KocConfig.bool(KocConfig.SORCERER_HUNTS, true) || sp.isCreative() || sp.isSpectator()) return;
        if (sp.level().getDifficulty() != net.minecraft.world.Difficulty.HARD) return;   // v1.0.18: sorcerers only on Hard
        boolean embraced = d.ending() == CursedData.ENDING_EMBRACE;
        if (d.ending() == CursedData.ENDING_REJECT || (!embraced && d.fingers() < 5)) return;
        d.setHuntClock(d.huntClock() + 1);
        if (d.huntClock() < 3000) return;
        d.setHuntClock(0);
        float chance = embraced ? 0.6f : d.fingers() * 0.025f;
        if (sp.getRandom().nextFloat() >= chance) return;
        int count = 1 + (d.fingers() >= 12 ? 1 : 0) + (embraced ? 1 : 0);
        int spawned = 0;
        for (int i = 0; i < count; i++) {
            EntityType<SorcererEntity> type = (i == 0 && d.fingers() >= 12) ? ModEntities.SORCERER_ELITE.get() : ModEntities.JUJUTSU_SORCERER.get();
            if (spawnNear(sp, type)) spawned++;
        }
        if (spawned > 0) sp.displayClientMessage(Component.translatable("message.kingofcurses.sorcerers_hunt").withStyle(ChatFormatting.BLUE), false);
    }

    public static boolean spawnNear(ServerPlayer sp, EntityType<? extends SorcererEntity> type) {
        ServerLevel level = sp.serverLevel();
        for (int attempt = 0; attempt < 8; attempt++) {
            double a = sp.getRandom().nextDouble() * Math.PI * 2, r = 14 + sp.getRandom().nextDouble() * 10;
            double x = sp.getX() + Math.cos(a) * r, z = sp.getZ() + Math.sin(a) * r;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
            if (Math.abs(y - sp.getY()) > 12) continue;
            SorcererEntity s = type.create(level);
            if (s == null) return false;
            s.moveTo(x, y, z, sp.getRandom().nextFloat() * 360f, 0);
            if (!level.noCollision(s)) continue;
            s.setTarget(sp);
            level.addFreshEntity(s);
            return true;
        }
        return false;
    }
}
