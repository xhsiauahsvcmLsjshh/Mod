package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;

/** Consuming one of Sukuna's twenty fingers. */
public final class FingerLogic {
    private FingerLogic() {}

    /** Eats the next finger the player has not absorbed yet. @return true if one was consumed. */
    public static boolean consumeNext(ServerPlayer sp) {
        CursedData d = KocSync.data(sp);
        for (int i = 0; i < 20; i++) if (!d.hasEaten(i)) return consume(sp, i);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.all_fingers").withStyle(ChatFormatting.DARK_RED), true);
        return false;
    }

    /** @return true if the finger was consumed (it was not eaten before). */
    public static boolean consume(ServerPlayer sp, int index) {
        CursedData d = KocSync.data(sp);
        if (d.isGojo()) {   // v1.0.18: the Strongest of Today is no vessel
            sp.displayClientMessage(Component.translatable("message.kingofcurses.gojo_no_finger").withStyle(ChatFormatting.AQUA), true);
            return false;
        }
        if (index < 0 || index >= 20 || d.hasEaten(index)) return false;
        int before = d.effectiveFingers();
        d.eat(index);
        int count = d.fingers();
        int after = d.effectiveFingers();
        d.setEnergy(d.maxEnergy());
        PowerScaling.apply(sp, d);

        ServerLevel level = sp.serverLevel();
        level.playSound(null, sp.blockPosition(), ModSounds.FINGER_EAT.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
        level.playSound(null, sp.blockPosition(), count % 5 == 0 || count == 1 ? ModSounds.SUKUNA_ROAR.get() : ModSounds.SUKUNA_LAUGH.get(), SoundSource.PLAYERS, 1.2f, 1.0f);
        level.playSound(null, sp.blockPosition(), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.PLAYERS, 1.0f, 0.8f);
        level.sendParticles(ModParticles.CURSED_ENERGY.get(), sp.getX(), sp.getY() + 1.0, sp.getZ(), 120 + count * 6, 0.6, 1.0, 0.6, 0.18);
        level.sendParticles(ModParticles.BLOOD.get(), sp.getX(), sp.getY() + 1.4, sp.getZ(), 30, 0.3, 0.3, 0.3, 0.1);
        // dark aura burst pushes enemies away
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(6), e -> e != sp && e instanceof Enemy)) {
            e.knockback(1.2, sp.getX() - e.getX(), sp.getZ() - e.getZ());
            e.hurt(sp.damageSources().playerAttack(sp), 2.0f + count * 0.3f);
        }
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 30, 0.4f + count * 0.03f));
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.AURA, 50, 1.0f));
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.MARKINGS, 60, 1.0f));
        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, Math.min(2, count / 7), false, true));

        sp.displayClientMessage(Component.translatable("message.kingofcurses.finger_consumed", index + 1, count).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        if (count == 1) {
            FirstTakeover.start(sp);
            sp.displayClientMessage(Component.translatable("message.kingofcurses.first_finger").withStyle(ChatFormatting.RED, ChatFormatting.ITALIC), false);
            sp.displayClientMessage(Component.translatable("message.kingofcurses.tattoos").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC), false);
        }
        if (count == 20) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.four_arms").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 30, 1.0f));
            level.playSound(null, sp.blockPosition(), ModSounds.TAKEOVER.get(), SoundSource.PLAYERS, 1.5f, 0.7f);
            ArmLogic.startTransform(sp);
        }
        for (Ability a : Ability.values()) {
            int req = a.requiredFingers();
            if (before < req && after >= req && !(a == Ability.DOMAIN_EXPANSION && d.ending() == CursedData.ENDING_REJECT)) {
                sp.displayClientMessage(Component.translatable("message.kingofcurses.ability_unlocked", a.displayName()).withStyle(ChatFormatting.RED), false);
            }
        }
        MobileControls.giveUnlocked(sp, d);
        KocAdvancements.award(sp, "first_finger");
        if (count >= 5) KocAdvancements.award(sp, "five_fingers");
        if (count >= 10) KocAdvancements.award(sp, "ten_fingers");
        if (count >= 15) KocAdvancements.award(sp, "fifteen_fingers");
        if (count >= 20) {
            KocAdvancements.award(sp, "twenty_fingers");
            if (!d.bossDefeated() && d.ending() == CursedData.ENDING_NONE) d.setBossCountdown(100);
        }
        KocSync.sync(sp);
        return true;
    }
}
