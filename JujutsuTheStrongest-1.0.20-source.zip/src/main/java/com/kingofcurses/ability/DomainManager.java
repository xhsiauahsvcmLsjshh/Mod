package com.kingofcurses.ability;

import com.kingofcurses.KocConfig;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.MalevolentShrineEntity;
import com.kingofcurses.network.DomainStatePacket;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Domain Expansion: Malevolent Shrine. Sure-hit slashes on everything inside the radius. */
public final class DomainManager {
    public static final float RADIUS = 24f;
    private static final Map<UUID, Domain> ACTIVE = new HashMap<>();

    private static final class Domain {
        final ResourceKey<Level> dim; final Vec3 center; int ticks; int shrineId = -1;
        Domain(ResourceKey<Level> dim, Vec3 center, int ticks) { this.dim = dim; this.center = center; this.ticks = ticks; }
    }

    private DomainManager() {}

    public static boolean isActive(UUID id) { return ACTIVE.containsKey(id); }

    public static boolean open(ServerPlayer sp, CursedData d) {
        if (ACTIVE.containsKey(sp.getUUID())) return false;
        ServerLevel level = sp.serverLevel();
        Domain dom = new Domain(level.dimension(), sp.position(), KocConfig.DOMAIN_DURATION.get());
        MalevolentShrineEntity shrine = ModEntities.MALEVOLENT_SHRINE.get().create(level);
        if (shrine != null) {
            Vec3 back = sp.position().subtract(Vec3.directionFromRotation(0, sp.getYRot()).scale(9));
            shrine.moveTo(back.x, sp.getY(), back.z, sp.getYRot(), 0);
            shrine.setLifetime(dom.ticks + 40);
            level.addFreshEntity(shrine);
            dom.shrineId = shrine.getId();
        }
        ACTIVE.put(sp.getUUID(), dom);
        level.playSound(null, sp.blockPosition(), ModSounds.DOMAIN_EXPANSION.get(), SoundSource.PLAYERS, 4.0f, 1.0f);
        level.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_VOICE.get(), SoundSource.PLAYERS, 2.0f, 0.8f);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.domain_open").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 30, 1.0f));
        broadcast(level, dom, true);
        KocAdvancements.award(sp, "domain_expansion");
        return true;
    }

    private static void broadcast(ServerLevel level, Domain dom, boolean active) {
        DomainStatePacket pkt = new DomainStatePacket(active, dom.center.x, dom.center.y, dom.center.z, RADIUS, dom.ticks);
        for (ServerPlayer p : level.players()) {
            if (p.position().distanceToSqr(dom.center) < 128 * 128) ModNetwork.sendTo(p, pkt);
        }
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Domain>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Domain> en = it.next();
            Domain dom = en.getValue();
            ServerLevel level = server.getLevel(dom.dim);
            ServerPlayer owner = server.getPlayerList().getPlayer(en.getKey());
            if (level == null) { it.remove(); continue; }
            if (owner == null || !owner.isAlive() || owner.level() != level || --dom.ticks <= 0) {
                close(level, dom, owner);
                it.remove();
                continue;
            }
            CursedData d = KocSync.data(owner);
            if (dom.ticks % 4 == 0) {
                float dmg = (3.0f + d.effectiveFingers() * 0.2f) * d.powerMultiplier();
                AABB box = new AABB(dom.center, dom.center).inflate(RADIUS);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != owner && e.isAlive())) {
                    if (e.position().distanceToSqr(dom.center) > RADIUS * RADIUS) continue;
                    e.invulnerableTime = 0;
                    SliceLogic.mark(e);
                    e.hurt(owner.damageSources().indirectMagic(owner, owner), dmg);
                    level.sendParticles(ModParticles.SLASH.get(), e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 3, 0.4, 0.4, 0.4, 0);
                    level.sendParticles(ModParticles.BLOOD.get(), e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 6, 0.3, 0.3, 0.3, 0.1);
                }
            }
            for (int i = 0; i < 12; i++) {
                double a = level.random.nextDouble() * Math.PI * 2, r = level.random.nextDouble() * RADIUS, h = level.random.nextDouble() * 8;
                level.sendParticles(i % 3 == 0 ? ModParticles.SLASH.get() : ModParticles.DOMAIN_ASH.get(),
                        dom.center.x + Math.cos(a) * r, dom.center.y + h, dom.center.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
            }
            if (dom.ticks % 10 == 0) level.playSound(null, owner.blockPosition(), ModSounds.DOMAIN_SLASH.get(), SoundSource.PLAYERS, 1.5f, 0.8f + level.random.nextFloat() * 0.4f);
            if (dom.ticks % 20 == 0) broadcast(level, dom, true);
        }
    }

    private static void close(ServerLevel level, Domain dom, ServerPlayer owner) {
        if (dom.shrineId >= 0) {
            Entity e = level.getEntity(dom.shrineId);
            if (e != null) e.discard();
        }
        broadcast(level, dom, false);
        if (owner != null) owner.displayClientMessage(Component.translatable("message.kingofcurses.domain_closed").withStyle(ChatFormatting.GRAY), true);
    }

    public static void clear() { ACTIVE.clear(); }
}
