package com.kingofcurses.ability;

import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.RipAnimPacket;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * v1.0.9: the first finger. Sukuna seizes the body (third-person, arms flung open, laughing), proclaims a new era of slaughter,
 * and then the player wrestles control back. Plays once per player.
 */
public final class FirstTakeover {
    public static final int LENGTH = 160;
    private static final String FLAG = "kingofcurses_first_takeover";
    private static final Map<UUID, Integer> ACTIVE = new HashMap<>();
    private FirstTakeover() {}

    public static boolean active(UUID id) { return ACTIVE.containsKey(id); }

    public static void start(ServerPlayer sp) {
        if (sp.getPersistentData().getBoolean(FLAG) || ACTIVE.containsKey(sp.getUUID())) return;
        sp.getPersistentData().putBoolean(FLAG, true);
        ACTIVE.put(sp.getUUID(), 0);
        ModNetwork.sendToTrackingAndSelf(sp, new RipAnimPacket(sp.getId(), RipAnimPacket.POSSESS, 0));
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, LENGTH, 6, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.JUMP, LENGTH, 128, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, LENGTH, 4, false, false));
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.TAKEOVER, 135, 1.0f));
        ServerLevel sl = sp.serverLevel();
        sl.playSound(null, sp.blockPosition(), ModSounds.TAKEOVER.get(), SoundSource.PLAYERS, 1.6f, 0.8f);
    }

    private static void line(ServerPlayer sp, int idx, int dur) { ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SUBTITLE, dur, idx)); }

    public static void tick(ServerPlayer sp) {
        Integer t = ACTIVE.get(sp.getUUID());
        if (t == null) return;
        if (!sp.isAlive()) { ACTIVE.remove(sp.getUUID()); ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.TAKEOVER_END, 1, 0)); return; }
        t++;
        ServerLevel sl = sp.serverLevel();
        switch (t) {
            case 10 -> { line(sp, 0, 45); sl.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_VOICE.get(), SoundSource.PLAYERS, 1.6f, 0.9f); }
            case 35 -> sl.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.PLAYERS, 1.8f, 0.9f);
            case 58 -> {
                line(sp, 1, 60);
                sl.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_ROAR.get(), SoundSource.PLAYERS, 2.0f, 0.85f);
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 25, 1.0f));
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 40, 0.9f));
                sl.sendParticles(ModParticles.CURSED_ENERGY.get(), sp.getX(), sp.getY() + 1, sp.getZ(), 260, 1.2, 1.0, 1.2, 0.3);
                sl.sendParticles(ModParticles.SLASH.get(), sp.getX(), sp.getY() + 1, sp.getZ(), 40, 4, 1, 4, 0);
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(7), e -> e != sp && e instanceof net.minecraft.world.entity.monster.Enemy))
                    e.knockback(1.6, sp.getX() - e.getX(), sp.getZ() - e.getZ());
            }
            case 90 -> sl.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.PLAYERS, 1.6f, 0.75f);
            case 118 -> {
                line(sp, 2, 30);
                sl.playSound(null, sp.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.PLAYERS, 2.0f, 1.0f);
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 20, 0.6f));
            }
            case 135 -> {
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.TAKEOVER_END, 1, 0));
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 20, 1.0f));
                line(sp, 3, 50);
                sl.playSound(null, sp.blockPosition(), ModSounds.SEAL_RITUAL.get(), SoundSource.PLAYERS, 1.2f, 1.2f);
                sp.displayClientMessage(Component.translatable("takeover.kingofcurses.line_3").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), false);
            }
            default -> { }
        }
        if (t >= LENGTH) ACTIVE.remove(sp.getUUID()); else ACTIVE.put(sp.getUUID(), t);
    }

    public static void clear() { ACTIVE.clear(); }
}
