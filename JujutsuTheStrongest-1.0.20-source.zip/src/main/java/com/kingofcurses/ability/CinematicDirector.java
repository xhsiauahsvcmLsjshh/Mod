package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.GojoEntity;
import com.kingofcurses.entity.SukunaEntity;
import com.kingofcurses.network.CinematicPacket;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModBlocks;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Server half of the intro cinematic (v1.0.2).
 * <ul>
 *   <li>Arena search: scans ~275 candidate layouts around the player and picks the one where Sukuna and Gojo
 *       stand at the most similar height with no hill between them. Terrain is never modified.</li>
 *   <li>If no level layout exists, Gojo (who can levitate) floats at Sukuna's height and drops to the ground when cut.</li>
 *   <li>Actors follow the real terrain every tick with smoothed height, so slopes never cause popping.</li>
 *   <li>Fight: Infinity, Lapse Blue (Sukuna dodges), dash + barrage stopped by Infinity, Reversal Red knock-back,
 *       World Cutting Slash in slow motion, Gojo cut in half and left bleeding.</li>
 * </ul>
 */
public final class CinematicDirector {
    public static final int LENGTH = 560;
    public static final int T_BLUE = 115, T_BLUE_HIT = 128, T_DASH = 150, T_COMBO = 160, T_RED = 192, T_RED_HIT = 203;
    public static final int T_LAUGH = 225, T_CHARGE = 262, T_SLASH = 300, T_CUT = 318, T_SLOWMO_START = 300, T_SLOWMO_END = 345;
    public static final int T_WALK = 380, T_DIG = 420, T_BURY = 460, T_VANISH = 472, T_GONE = 515;
    public static final int CORPSE_TICKS = 600;

    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.35f, 0.65f, 1.0f), 1.4f);
    private static final DustParticleOptions BLUE_SMALL = new DustParticleOptions(new Vector3f(0.7f, 0.9f, 1.0f), 0.7f);
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(1.0f, 0.12f, 0.15f), 1.6f);

    private static final Map<UUID, Scene> SCENES = new HashMap<>();
    private static final Map<UUID, int[]> PENDING = new HashMap<>();

    private record Arena(Vec3 s0, Vec3 g0, Vec3 center, Vec3 dig, boolean gojoFloats, double gojoY) {}

    private static final class Scene {
        final UUID player; final ServerLevel level; final Arena arena; final Vec3 lock, axis, perp, fwd; final float yaw; final boolean spawnFinger;
        int tick; int sukunaId = -1, gojoId = -1; boolean fingerPlaced, cut;
        double sukunaY, gojoY;
        Scene(UUID player, ServerLevel level, Arena arena, Vec3 lock, float yaw, boolean spawnFinger) {
            this.player = player; this.level = level; this.arena = arena; this.lock = lock; this.yaw = yaw; this.spawnFinger = spawnFinger;
            Vec3 a = arena.g0.subtract(arena.s0);
            this.axis = new Vec3(a.x, 0, a.z).normalize();
            Vec3 p = new Vec3(-axis.z, 0, axis.x);
            Vec3 toPlayer = lock.subtract(arena.center);
            this.perp = p.dot(toPlayer) >= 0 ? p : p.scale(-1); // always points to the player's side
            this.fwd = Vec3.directionFromRotation(0, yaw);
            this.sukunaY = arena.s0.y; this.gojoY = arena.gojoY;
        }
    }

    private CinematicDirector() {}

    public static boolean isInScene(UUID id) { return SCENES.containsKey(id); }

    /** Longest wait before the intro starts anyway (ticks, includes the login delay). */
    public static final int MAX_WAIT = 200;

    public static void schedule(ServerPlayer sp, int delay, boolean spawnFinger) {
        if (SCENES.containsKey(sp.getUUID())) return;
        int d = spawnFinger ? Math.min(delay, 40) : delay;
        PENDING.put(sp.getUUID(), new int[]{d, spawnFinger ? 1 : 0, d});
        if (spawnFinger) ModNetwork.sendTo(sp, new com.kingofcurses.network.ScreenFxPacket(com.kingofcurses.network.ScreenFxPacket.LOADING, MAX_WAIT + 20, 0f));
    }

    /** True when the chunks around the player are loaded and ticks are fast enough for a smooth scene. */
    private static boolean settled(MinecraftServer server, ServerPlayer sp) {
        if (server.getAverageTickTime() > 40f || sp.tickCount < 60) return false;
        ServerLevel lv = sp.serverLevel();
        int cx = sp.blockPosition().getX() >> 4, cz = sp.blockPosition().getZ() >> 4;
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                if (!lv.hasChunk(cx + dx, cz + dz)) return false;
        return true;
    }

    public static void replay(ServerPlayer sp) {
        sp.displayClientMessage(Component.translatable("message.kingofcurses.intro_replay").withStyle(ChatFormatting.DARK_RED), true);
        schedule(sp, 10, false);
    }

    // ------------------------------------------------------------------ terrain helpers
    static double groundY(ServerLevel level, double x, double z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
    }

    private static boolean standable(ServerLevel level, double x, double y, double z) {
        BlockPos feet = BlockPos.containing(x, y, z);
        if (!level.getFluidState(feet).isEmpty() || !level.getFluidState(feet.below()).isEmpty()) return false;
        BlockState below = level.getBlockState(feet.below());
        if (!below.isFaceSturdy(level, feet.below(), Direction.UP)) return false;
        for (int i = 0; i < 3; i++) if (!level.getBlockState(feet.above(i)).getCollisionShape(level, feet.above(i)).isEmpty()) return false;
        return true;
    }

    private static Arena findArena(ServerLevel level, ServerPlayer sp) {
        float yaw0 = sp.getYRot();
        double py = sp.getY();
        double bestScore = Double.MAX_VALUE;
        Arena best = null;
        int[] dists = {10, 12, 9, 14, 8, 16};
        int[] angs = {0, 15, -15, 30, -30, 50, -50, 75, -75, 110, -110, 180};
        int[] axisRots = {0, 25, -25, 50, -50};
        for (int dist : dists) for (int dAng : angs) for (int aRot : axisRots) {
            Vec3 dir = Vec3.directionFromRotation(0, yaw0 + dAng);
            Vec3 c0 = sp.position().add(dir.scale(dist));
            Vec3 axis = Vec3.directionFromRotation(0, yaw0 + dAng + 90 + aRot);
            double cx = c0.x, cz = c0.z;
            double sx = cx - axis.x * 4, sz = cz - axis.z * 4, gx = cx + axis.x * 4, gz = cz + axis.z * 4;
            double hs = groundY(level, sx, sz), hg = groundY(level, gx, gz), hc = groundY(level, cx, cz);
            if (!standable(level, sx, hs, sz) || !standable(level, gx, hg, gz)) continue;
            double top = Math.max(hs, hg), bump = 0;
            for (double k = 0.2; k < 0.85; k += 0.15) {
                double bx = sx + (gx - sx) * k, bz = sz + (gz - sz) * k;
                bump = Math.max(bump, groundY(level, bx, bz) - top);
            }
            double score = Math.abs(hs - hg) * 3 + Math.max(0, bump) * 5 + Math.abs(dAng) / 25.0 + Math.abs(dist - 11) * 0.3
                    + Math.abs(hc - py) * 0.25 + Math.abs(aRot) / 50.0;
            if (score < bestScore) {
                bestScore = score;
                Vec3 s = new Vec3(sx, hs, sz), g = new Vec3(gx, hg, gz);
                if (hg > hs + 1.0) { Vec3 t = s; s = g; g = t; }          // Gojo always takes the lower spot ...
                boolean floats = s.y - g.y > 1.0;                          // ... and levitates up to Sukuna's level if needed
                Vec3 digXZ = sp.position().add(dir.scale(Math.min(4.0, dist * 0.4)));
                Vec3 dig = new Vec3(digXZ.x, groundY(level, digXZ.x, digXZ.z), digXZ.z);
                best = new Arena(s, g, new Vec3(cx, (s.y + g.y) / 2, cz), dig, floats, floats ? s.y : g.y);
            }
        }
        if (best == null) { // nothing standable (ocean, caves...): stand on the player's level, Gojo floats
            Vec3 dir = Vec3.directionFromRotation(0, yaw0), axis = Vec3.directionFromRotation(0, yaw0 + 90);
            Vec3 c = sp.position().add(dir.scale(10));
            Vec3 s = c.subtract(axis.scale(4)), g = c.add(axis.scale(4));
            Vec3 d = sp.position().add(dir.scale(4));
            best = new Arena(new Vec3(s.x, py, s.z), new Vec3(g.x, py, g.z), c, new Vec3(d.x, groundY(level, d.x, d.z), d.z), true, py);
        }
        return best;
    }

    // ------------------------------------------------------------------ lifecycle
    public static void start(ServerPlayer sp, boolean spawnFinger) {
        if (SCENES.containsKey(sp.getUUID())) return;
        ServerLevel level = sp.serverLevel();
        Arena arena = findArena(level, sp);
        Scene s = new Scene(sp.getUUID(), level, arena, sp.position(), sp.getYRot(), spawnFinger);
        SukunaEntity sukuna = ModEntities.RYOMEN_SUKUNA.get().create(level);
        GojoEntity gojo = ModEntities.GOJO_SATORU.get().create(level);
        if (sukuna != null) {
            float face = yawTowards(arena.s0, arena.g0);
            sukuna.setupCinematic(LENGTH + 40);
            sukuna.moveTo(arena.s0.x, arena.s0.y, arena.s0.z, face, 0);
            sukuna.setYHeadRot(face); sukuna.setYBodyRot(face);
            level.addFreshEntity(sukuna);
            s.sukunaId = sukuna.getId();
        }
        if (gojo != null) {
            float face = yawTowards(arena.g0, arena.s0);
            gojo.setupCinematic(LENGTH + 40);
            gojo.moveTo(arena.g0.x, arena.gojoY, arena.g0.z, face, 0);
            gojo.setYHeadRot(face); gojo.setYBodyRot(face);
            level.addFreshEntity(gojo);
            s.gojoId = gojo.getId();
        }
        SCENES.put(sp.getUUID(), s);
        ModNetwork.sendTo(sp, new CinematicPacket(CinematicPacket.START, arena.center, s.yaw, arena.dig, arena.s0,
                new Vec3(arena.g0.x, arena.gojoY, arena.g0.z), s.sukunaId, s.gojoId));
        level.playSound(null, sp.blockPosition(), ModSounds.CINEMATIC_STING.get(), SoundSource.MASTER, 1.0f, 0.8f);
    }

    static float yawTowards(Vec3 from, Vec3 to) {
        return (float) (Mth.atan2(to.z - from.z, to.x - from.x) * Mth.RAD_TO_DEG) - 90.0f;
    }

    public static void skip(ServerPlayer sp) {
        Scene s = SCENES.remove(sp.getUUID());
        if (s != null) finish(sp, s);
        PENDING.remove(sp.getUUID());
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, int[]>> pit = PENDING.entrySet().iterator();
        while (pit.hasNext()) {
            Map.Entry<UUID, int[]> en = pit.next();
            if (--en.getValue()[0] <= 0) {
                ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
                // v1.0.7: wait until the world around the player has finished generating and the server is not lagging
                int[] v = en.getValue();
                // v1.0.8: at most 10 s in total (delay + waiting), shown as a loading screen
                if (sp != null && v.length > 2 && v[2] < MAX_WAIT && !settled(server, sp)) {
                    v[0] = 10; v[2] += 10;
                    continue;
                }
                pit.remove();
                if (sp != null && sp.isAlive()) start(sp, v[1] == 1);
            }
        }
        Iterator<Map.Entry<UUID, Scene>> it = SCENES.entrySet().iterator();
        while (it.hasNext()) {
            Scene s = it.next().getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(s.player);
            if (sp == null || sp.level() != s.level || !sp.isAlive()) { cleanup(s, true); it.remove(); continue; }
            s.tick++;
            if (sp.position().distanceToSqr(s.lock) > 0.25) sp.connection.teleport(s.lock.x, s.lock.y, s.lock.z, sp.getYRot(), sp.getXRot());
            sp.setDeltaMovement(Vec3.ZERO);
            if (s.tick % 2 == 0) ModNetwork.sendTo(sp, CinematicPacket.sync(s.tick));
            try {
                run(s, sp);
            } catch (RuntimeException ex) { // never let a cinematic glitch take the server down
                com.kingofcurses.KingOfCurses.LOGGER.error("Cinematic error, skipping", ex);
                it.remove(); finish(sp, s); continue;
            }
            if (s.tick >= LENGTH) { it.remove(); finish(sp, s); }
        }
    }

    // ------------------------------------------------------------------ choreography
    private static double ease(double k) { k = Mth.clamp(k, 0, 1); return k * k * (3 - 2 * k); }
    private static double easeOut(double k) { k = Mth.clamp(k, 0, 1); return 1 - (1 - k) * (1 - k) * (1 - k); }
    private static Vec3 lerp(Vec3 a, Vec3 b, double k) { return a.add(b.subtract(a).scale(k)); }

    /** Sukuna's horizontal path over time. */
    private static Vec3 sukunaXZ(Scene s, int t) {
        Arena a = s.arena;
        Vec3 dodge = a.s0.add(s.perp.scale(-3.0));
        Vec3 front = a.g0.subtract(s.axis.scale(1.7));
        Vec3 back = a.s0.subtract(s.axis.scale(2.5));
        Vec3 digSpot = a.dig.add(s.fwd.scale(1.3));
        if (t < 124) return a.s0;
        if (t < 134) return lerp(a.s0, dodge, easeOut((t - 124) / 10.0));
        if (t < 146) return lerp(dodge, a.s0, ease((t - 134) / 12.0));
        if (t < T_DASH) return a.s0;
        if (t < T_COMBO) return lerp(a.s0, front, easeOut((t - T_DASH) / 10.0));
        if (t < T_RED_HIT) return front;
        if (t < T_RED_HIT + 12) return lerp(front, back, easeOut((t - T_RED_HIT) / 12.0));
        if (t < T_WALK) return back;
        if (t < T_DIG) return lerp(back, digSpot, ease((t - T_WALK) / (double) (T_DIG - T_WALK)));
        return digSpot;
    }

    private static void moveActor(Entity e, Vec3 xz, double y, Vec3 lookAt) {
        float face = yawTowards(xz, lookAt);
        e.moveTo(xz.x, y, xz.z, face, 0);
        if (e instanceof net.minecraft.world.entity.LivingEntity le) { le.setYHeadRot(face); le.setYBodyRot(face); }
    }

    private static void run(Scene s, ServerPlayer sp) {
        ServerLevel level = s.level;
        int t = s.tick;
        Arena a = s.arena;
        SukunaEntity sukuna = level.getEntity(s.sukunaId) instanceof SukunaEntity e ? e : null;
        GojoEntity gojo = level.getEntity(s.gojoId) instanceof GojoEntity e ? e : null;

        // ---- actor placement (terrain-following, smoothed) ----
        if (sukuna != null && t < T_GONE) {
            Vec3 xz = sukunaXZ(s, t);
            double target = groundY(level, xz.x, xz.z);
            if (t >= T_DASH && t < T_COMBO) target += Math.sin((t - T_DASH) / 10.0 * Math.PI) * 0.6; // small leap
            s.sukunaY += (target - s.sukunaY) * 0.35;
            Vec3 look = t >= T_DIG - 5 ? a.dig : (t >= T_WALK ? a.dig.add(s.fwd.scale(1.3)) : (gojo != null ? gojo.position() : a.g0));
            if (t >= T_WALK && t < T_DIG - 5) look = sukunaXZ(s, Math.min(T_DIG, t + 8));
            moveActor(sukuna, xz, s.sukunaY, look);
        }
        if (gojo != null) {
            double target = s.cut ? groundY(level, a.g0.x, a.g0.z) : a.gojoY;
            s.gojoY += (target - s.gojoY) * (s.cut ? 0.12 : 0.35);
            Vec3 look = sukuna != null ? sukuna.position() : a.s0;
            if (s.cut) gojo.moveTo(a.g0.x, s.gojoY, a.g0.z, gojo.getYRot(), 0); else moveActor(gojo, a.g0, s.gojoY, look);
        }

        // ---- Infinity aura ----
        if (gojo != null && !s.cut && t % 3 == 0) {
            for (int i = 0; i < 10; i++) {
                double ang = (t * 0.15) + i * Math.PI / 5;
                level.sendParticles(BLUE_SMALL, gojo.getX() + Math.cos(ang) * 1.1, gojo.getY() + 0.2 + (i % 5) * 0.4, gojo.getZ() + Math.sin(ang) * 1.1, 1, 0, 0, 0, 0);
            }
            if (a.gojoFloats) level.sendParticles(BLUE, gojo.getX(), gojo.getY() - 0.1, gojo.getZ(), 3, 0.25, 0.05, 0.25, 0);
        }

        // ---- beats ----
        if (t == 2 && gojo != null) { gojo.setState(GojoEntity.STATE_INFINITY); level.playSound(null, gojo.blockPosition(), ModSounds.GOJO_INFINITY.get(), SoundSource.HOSTILE, 1.0f, 1.0f); }
        if (t == 62 && sukuna != null) { sukuna.setState(SukunaEntity.STATE_TAUNT); level.playSound(null, sukuna.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.HOSTILE, 1.2f, 0.9f); }
        if (t == 100 && sukuna != null) sukuna.setState(SukunaEntity.STATE_IDLE);
        // Lapse: Blue
        if (t == T_BLUE && gojo != null) { gojo.setState(GojoEntity.STATE_BLUE); level.playSound(null, gojo.blockPosition(), ModSounds.GOJO_INFINITY.get(), SoundSource.HOSTILE, 1.4f, 0.6f); }
        if (t > T_BLUE + 3 && t <= T_BLUE_HIT && gojo != null) {
            Vec3 from = gojo.position().add(0, 1.4, 0).add(s.axis.scale(-0.8)), to = a.s0.add(0, 1.0, 0);
            Vec3 p = lerp(from, to, (t - T_BLUE - 3) / (double) (T_BLUE_HIT - T_BLUE - 3));
            level.sendParticles(BLUE, p.x, p.y, p.z, 12, 0.18, 0.18, 0.18, 0);
        }
        if (t == 124 && sukuna != null) sukuna.setState(SukunaEntity.STATE_DASH);
        if (t >= T_BLUE_HIT && t < T_BLUE_HIT + 14) {
            double r = 2.6 * (1 - (t - T_BLUE_HIT) / 14.0);
            for (int i = 0; i < 16; i++) {
                double th = i / 16.0 * Math.PI * 2, ph = (i % 4) / 4.0 * Math.PI;
                level.sendParticles(BLUE, a.s0.x + Math.cos(th) * Math.sin(ph) * r, a.s0.y + 1 + Math.cos(ph) * r, a.s0.z + Math.sin(th) * Math.sin(ph) * r, 1, 0, 0, 0, 0);
            }
            if (t == T_BLUE_HIT) {
                level.playSound(null, BlockPos.containing(a.s0), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 0.8f, 1.6f);
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()), a.s0.x, a.s0.y + 0.2, a.s0.z, 40, 1.0, 0.2, 1.0, 0.3);
            }
        }
        if (t == 146 && sukuna != null) sukuna.setState(SukunaEntity.STATE_IDLE);
        // Dash + barrage on Infinity
        if (t == T_DASH && sukuna != null) { sukuna.setState(SukunaEntity.STATE_DASH); level.playSound(null, sukuna.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 1.0f, 0.6f); }
        if (t == T_COMBO && sukuna != null) sukuna.setState(SukunaEntity.STATE_COMBO);
        if (t >= T_COMBO && t < T_RED + 6 && t % 3 == 0 && gojo != null) {
            Vec3 hit = gojo.position().add(0, 1.3 + (t % 2) * 0.3, 0).subtract(s.axis.scale(0.75)).add(s.perp.scale((t % 6 - 3) * 0.08));
            level.sendParticles(ParticleTypes.ENCHANTED_HIT, hit.x, hit.y, hit.z, 6, 0.1, 0.15, 0.1, 0.2);
            level.sendParticles(BLUE, hit.x, hit.y, hit.z, 4, 0.05, 0.25, 0.25, 0);
            level.playSound(null, BlockPos.containing(hit), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.HOSTILE, 0.8f, 0.7f + (t % 4) * 0.1f);
            if (t % 9 == 0) ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 4, 0.15f));
        }
        // Reversal: Red
        if (t == T_RED && gojo != null) gojo.setState(GojoEntity.STATE_RED);
        if (t > T_RED + 4 && t <= T_RED_HIT && gojo != null) {
            Vec3 p = gojo.position().add(0, 1.3, 0).subtract(s.axis.scale(0.6 + (t - T_RED - 4) * 0.08));
            level.sendParticles(RED, p.x, p.y, p.z, 14, 0.15, 0.15, 0.15, 0);
        }
        if (t == T_RED_HIT && sukuna != null) {
            sukuna.setState(SukunaEntity.STATE_RECOIL);
            Vec3 p = sukuna.position().add(0, 1.2, 0);
            level.sendParticles(ParticleTypes.EXPLOSION, p.x, p.y, p.z, 4, 0.6, 0.6, 0.6, 0);
            level.sendParticles(RED, p.x, p.y, p.z, 80, 0.8, 0.8, 0.8, 0.1);
            level.playSound(null, sukuna.blockPosition(), ModSounds.FUGA_EXPLODE.get(), SoundSource.HOSTILE, 1.6f, 1.4f);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 20, 0.7f));
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 8, 0.4f));
        }
        if (t > T_RED_HIT && t < T_RED_HIT + 12 && sukuna != null) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, level.getBlockState(sukuna.blockPosition().below())), sukuna.getX(), sukuna.getY() + 0.1, sukuna.getZ(), 6, 0.3, 0.05, 0.3, 0.1);
        }
        if (t == T_RED_HIT + 15 && gojo != null) gojo.setState(GojoEntity.STATE_INFINITY);
        // Laugh
        if (t == T_LAUGH && sukuna != null) { sukuna.setState(SukunaEntity.STATE_TAUNT); level.playSound(null, sukuna.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.HOSTILE, 1.4f, 0.85f); }
        // World Cutting Slash
        if (t == T_CHARGE && sukuna != null) { sukuna.setState(SukunaEntity.STATE_CHARGE); level.playSound(null, sukuna.blockPosition(), ModSounds.SUKUNA_VOICE.get(), SoundSource.HOSTILE, 1.2f, 0.85f); }
        if (t > T_CHARGE && t < T_SLASH && sukuna != null) {
            double k = (t - T_CHARGE) / (double) (T_SLASH - T_CHARGE);
            for (int i = 0; i < 4; i++) {
                double ang = t * 0.4 + i * Math.PI / 2, r = 2.5 * (1 - k) + 0.4;
                level.sendParticles(ModParticles.CURSED_ENERGY.get(), sukuna.getX() + Math.cos(ang) * r, sukuna.getY() + 1.2 + Math.sin(t * 0.3 + i) * 0.4, sukuna.getZ() + Math.sin(ang) * r, 1, 0, 0, 0, 0);
            }
            if (t % 10 == 0) level.playSound(null, sukuna.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.HOSTILE, 1.0f, 0.8f);
        }
        if (t == T_SLASH && sukuna != null) {
            sukuna.setState(SukunaEntity.STATE_SLASH);
            level.playSound(null, sukuna.blockPosition(), ModSounds.CINEMATIC_SLASH.get(), SoundSource.HOSTILE, 2.0f, 1.0f);
            level.playSound(null, sukuna.blockPosition(), ModSounds.WORLD_SLASH.get(), SoundSource.HOSTILE, 1.6f, 0.9f);
        }
        if (t == T_SLOWMO_START) { if (sukuna != null) sukuna.setAnimSpeed(0.3f); if (gojo != null) gojo.setAnimSpeed(0.3f); }
        if (t > T_SLASH && t < T_CUT && sukuna != null && gojo != null) {
            Vec3 from = sukuna.position().add(0, 1.15, 0), to = gojo.position().add(0, 1.15, 0);
            double k = (t - T_SLASH) / (double) (T_CUT - T_SLASH);
            Vec3 p = lerp(from, to, k);
            level.sendParticles(ModParticles.SLASH.get(), p.x, p.y, p.z, 3, 0.15, 0.05, 0.15, 0);
            Vec3 q = lerp(from, to, Math.max(0, k - 0.1));
            level.sendParticles(ModParticles.SLASH.get(), q.x + s.perp.x * 1.5, q.y, q.z + s.perp.z * 1.5, 1, 0, 0, 0, 0);
            level.sendParticles(ModParticles.SLASH.get(), q.x - s.perp.x * 1.5, q.y, q.z - s.perp.z * 1.5, 1, 0, 0, 0, 0);
        }
        if (t == T_CUT && gojo != null) {
            s.cut = true;
            gojo.setState(GojoEntity.STATE_CUT);
            double cy = gojo.getY() + 1.05;
            level.sendParticles(ModParticles.BLOOD.get(), gojo.getX(), cy, gojo.getZ(), 220, 0.35, 0.15, 0.35, 0.4);
            level.sendParticles(ModParticles.SLASH.get(), gojo.getX(), cy, gojo.getZ(), 14, 0.8, 0.02, 0.8, 0);
            level.playSound(null, gojo.blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.HOSTILE, 1.6f, 0.8f);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 26, 1.0f));
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 30, 0.9f));
        }
        if (s.cut && gojo != null && t % 2 == 0) {
            int since = t - T_CUT;
            int n = since < 40 ? 10 : 3;
            level.sendParticles(ModParticles.BLOOD.get(), gojo.getX(), gojo.getY() + (since < 25 ? 1.0 : 0.35), gojo.getZ(), n, 0.3, 0.08, 0.3, since < 40 ? 0.15 : 0.03);
        }
        if (t == T_SLOWMO_END) { if (sukuna != null) sukuna.setAnimSpeed(1.0f); if (gojo != null) gojo.setAnimSpeed(1.0f); }
        if (t == 350 && sukuna != null) sukuna.setState(SukunaEntity.STATE_IDLE);
        if (t == T_WALK && sukuna != null) sukuna.setState(SukunaEntity.STATE_WALK);
        if (t == T_DIG && sukuna != null) sukuna.setState(SukunaEntity.STATE_DIG);
        if (t > T_DIG && t < T_BURY && t % 2 == 0) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()), a.dig.x, a.dig.y + 0.2, a.dig.z, 10, 0.4, 0.1, 0.4, 0.15);
        }
        if (t == T_BURY) placeFinger(s);
        if (t == T_VANISH && sukuna != null) {
            sukuna.setState(SukunaEntity.STATE_VANISH);
            level.playSound(null, sukuna.blockPosition(), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.HOSTILE, 1.5f, 0.6f);
        }
        if (t > T_VANISH && t < T_GONE && sukuna != null) {
            level.sendParticles(ModParticles.CURSED_ENERGY.get(), sukuna.getX(), sukuna.getY() + 1.0, sukuna.getZ(), 14, 0.4, 0.9, 0.4, 0.08);
        }
        if (t == T_GONE && sukuna != null) {
            level.sendParticles(ModParticles.CURSED_ENERGY.get(), sukuna.getX(), sukuna.getY() + 1.0, sukuna.getZ(), 120, 0.3, 1.2, 0.3, 0.3);
            sukuna.discard();
        }
    }

    private static void placeFinger(Scene s) {
        if (!s.spawnFinger || s.fingerPlaced) return;
        ServerLevel level = s.level;
        BlockPos pos = BlockPos.containing(s.arena.dig.x, s.arena.dig.y - 1, s.arena.dig.z);
        for (int i = 0; i < 6 && (level.getBlockState(pos).isAir() || !level.getFluidState(pos).isEmpty()); i++) pos = pos.below();
        if (level.getBlockState(pos).getDestroySpeed(level, pos) < 0) pos = pos.above();
        level.setBlockAndUpdate(pos, ModBlocks.DISTURBED_SOIL.get().defaultBlockState());
        level.sendParticles(ModParticles.RESONANCE.get(), pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 20, 0.3, 0.2, 0.3, 0.01);
        s.fingerPlaced = true;
    }

    private static void cleanup(Scene s, boolean removeCorpse) {
        Entity a = s.level.getEntity(s.sukunaId);
        if (a != null) a.discard();
        Entity b = s.level.getEntity(s.gojoId);
        if (b instanceof GojoEntity gojo && !removeCorpse) {
            if (s.spawnFinger) {
                // first intro: Gojo's body stays forever where he fell (even if the scene was skipped)
                if (!s.cut) { s.cut = true; gojo.setState(GojoEntity.STATE_CUT); }
                gojo.moveTo(s.arena.g0.x, groundY(s.level, s.arena.g0.x, s.arena.g0.z), s.arena.g0.z, gojo.getYRot(), 0);
                gojo.makeCorpse();
            } else if (s.cut) {
                gojo.setLifetime(CORPSE_TICKS); // replays: the halves stay for 30 s
            } else {
                gojo.discard();
            }
        } else if (b != null) {
            b.discard();
        }
    }

    private static void finish(ServerPlayer sp, Scene s) {
        cleanup(s, false);
        placeFinger(s);
        CursedData d = KocSync.data(sp);
        boolean first = !d.introSeen();
        d.setIntroSeen(true);
        ModNetwork.sendTo(sp, CinematicPacket.stop());
        if (s.spawnFinger) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.finger_buried").withStyle(ChatFormatting.DARK_RED), false);
            sp.displayClientMessage(Component.translatable("message.kingofcurses.intro_hint").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
        }
        if (first) KocAdvancements.award(sp, "root");
        if (s.spawnFinger) sp.displayClientMessage(Component.translatable("message.kingofcurses.gojo_corpse").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), false);
        if (d.controlMode() == CursedData.CONTROL_NONE) ModNetwork.sendTo(sp, new com.kingofcurses.network.OpenScreenPacket(com.kingofcurses.network.OpenScreenPacket.CONTROL_MODE));
        KocSync.sync(sp);
    }

    /** Used when the intro cinematic is disabled in the config: bury Finger #1 and mark the intro as seen. */
    public static void buryWithoutCinematic(ServerPlayer sp) {
        start(sp, true);
        skip(sp);
    }

    public static void clear() { SCENES.clear(); PENDING.clear(); }
}
