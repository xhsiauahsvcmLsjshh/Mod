package com.kingofcurses.ability;

import com.kingofcurses.KocConfig;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;

import java.util.Comparator;
import java.util.Optional;

/** At 15+ fingers Sukuna may seize the body for a few seconds. */
public final class TakeoverLogic {
    public static final int DURATION = 200;
    private TakeoverLogic() {}

    public static void tick(ServerPlayer sp, CursedData d) {
        if (d.takeoverTicks() > 0) {
            int left = d.takeoverTicks() - 1;
            d.setTakeoverTicks(left);
            if (left % 20 == 10) {
                Optional<LivingEntity> victim = sp.serverLevel().getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(14), e -> e != sp && e.isAlive())
                        .stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(sp)));
                victim.ifPresent(v -> {
                    sp.lookAt(EntityAnchorArgument.Anchor.EYES, v.getEyePosition());
                    AbilityLogic.perform(sp, d, Ability.DISMANTLE, true);
                });
            }
            if (left == 0) {
                sp.displayClientMessage(Component.translatable("message.kingofcurses.takeover_end").withStyle(ChatFormatting.GRAY), true);
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.TAKEOVER_END, 1, 0));
                KocSync.sync(sp);
            }
            return;
        }
        if (!KocConfig.bool(KocConfig.TAKEOVER_ENABLED, true) || d.ending() != CursedData.ENDING_NONE || d.fingers() < 15 || sp.isCreative() || sp.isSpectator()) return;
        if (CinematicDirector.isInScene(sp.getUUID())) return;
        d.setTakeoverClock(d.takeoverClock() + 1);
        if (d.takeoverClock() < 1200) return;
        d.setTakeoverClock(0);
        float chance = (d.fingers() - 14) * 0.04f;
        if (sp.getRandom().nextFloat() < chance) start(sp, d);
    }

    public static void start(ServerPlayer sp, CursedData d) {
        d.setTakeoverTicks(DURATION);
        sp.addEffect(new MobEffectInstance(ModEffects.SUKUNA_TAKEOVER.get(), DURATION, 0, false, true));
        sp.displayClientMessage(Component.translatable("message.kingofcurses.takeover_start").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        sp.serverLevel().playSound(null, sp.blockPosition(), ModSounds.TAKEOVER.get(), SoundSource.PLAYERS, 1.5f, 1.0f);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.TAKEOVER, DURATION, 1.0f));
        KocSync.sync(sp);
    }
}
