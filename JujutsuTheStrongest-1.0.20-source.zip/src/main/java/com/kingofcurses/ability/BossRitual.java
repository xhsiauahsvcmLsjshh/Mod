package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.GojoEntity;
import com.kingofcurses.entity.GojoKenjakuEntity;
import com.kingofcurses.entity.NamedSorcererEntity;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * v1.0.8 boss arrival: Yuta kneels by Gojo's body, stitches his head (Kenjaku's seam), uses Kenjaku's technique to move
 * into it and collapses; Gojo's body then rises as the boss. Uses the intro corpse when it is nearby, otherwise lays a body
 * down in front of the player.
 */
public final class BossRitual {
    public static final int LENGTH = 140;
    private static final DustParticleOptions THREAD = new DustParticleOptions(new Vector3f(0.75f, 0.05f, 0.12f), 0.6f);
    private static final DustParticleOptions SOUL = new DustParticleOptions(new Vector3f(0.6f, 0.25f, 1.0f), 1.3f);
    private static final Map<UUID, Ritual> ACTIVE = new HashMap<>();
    private BossRitual() {}

    private static final class Ritual {
        final ServerLevel level; final Vec3 body; final float yaw; int tick, corpseId = -1, yutaId = -1;
        Ritual(ServerLevel level, Vec3 body, float yaw) { this.level = level; this.body = body; this.yaw = yaw; }
    }

    public static boolean active(UUID id) { return ACTIVE.containsKey(id); }

    public static void start(ServerPlayer sp) {
        if (ACTIVE.containsKey(sp.getUUID())) return;
        ServerLevel level = sp.serverLevel();
        GojoEntity corpse = null;
        double best = 48 * 48;
        for (GojoEntity g : level.getEntitiesOfClass(GojoEntity.class, sp.getBoundingBox().inflate(48), GojoEntity::isCorpse)) {
            double d = g.distanceToSqr(sp);
            if (d < best) { best = d; corpse = g; }
        }
        Vec3 body;
        if (corpse != null) body = corpse.position();
        else {
            Vec3 dir = Vec3.directionFromRotation(0, sp.getYRot());
            double x = sp.getX() + dir.x * 8, z = sp.getZ() + dir.z * 8;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
            if (Math.abs(y - sp.getY()) > 6) { x = sp.getX() + dir.x * 3; z = sp.getZ() + dir.z * 3; y = Mth.floor(sp.getY()); }
            body = new Vec3(x, y, z);
            corpse = ModEntities.GOJO_SATORU.get().create(level);
            if (corpse != null) {
                corpse.moveTo(body.x, body.y, body.z, sp.getYRot(), 0);
                level.addFreshEntity(corpse);
                corpse.makeCorpse();
                corpse.setState(GojoEntity.STATE_DEAD);
            }
        }
        Ritual r = new Ritual(level, body, sp.getYRot());
        if (corpse != null) r.corpseId = corpse.getId();
        NamedSorcererEntity yuta = ModEntities.YUTA_OKKOTSU.get().create(level);
        if (yuta != null) {
            Vec3 side = Vec3.directionFromRotation(0, sp.getYRot() + 90f).scale(1.1);
            Vec3 yp = body.add(side);
            float face = (float) (Mth.atan2(body.z - yp.z, body.x - yp.x) * Mth.RAD_TO_DEG) - 90f;
            yuta.moveTo(yp.x, body.y, yp.z, face, 0);
            yuta.setYHeadRot(face); yuta.setYBodyRot(face);
            level.addFreshEntity(yuta);
            yuta.setActor(NamedSorcererEntity.ACTOR_STITCH);
            r.yutaId = yuta.getId();
        }
        ACTIVE.put(sp.getUUID(), r);
        tell(level, body, "message.kingofcurses.ritual_1", ChatFormatting.AQUA);
        level.playSound(null, net.minecraft.core.BlockPos.containing(body), ModSounds.HEARTBEAT.get(), SoundSource.HOSTILE, 2.0f, 0.7f);
    }

    private static void tell(ServerLevel level, Vec3 at, String key, ChatFormatting col) {
        for (ServerPlayer p : level.getPlayers(p -> p.position().distanceToSqr(at) < 96 * 96))
            p.displayClientMessage(Component.translatable(key).withStyle(col, ChatFormatting.ITALIC), false);
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Ritual>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Ritual> en = it.next();
            Ritual r = en.getValue();
            r.tick++;
            ServerLevel lv = r.level;
            Entity yuta = lv.getEntity(r.yutaId), corpse = lv.getEntity(r.corpseId);
            Vec3 head = r.body.add(0, 0.35, 0);
            if (r.tick < 80) {
                if (r.tick % 3 == 0) lv.sendParticles(THREAD, head.x, head.y, head.z, 4, 0.25, 0.08, 0.25, 0.01);
                if (r.tick % 16 == 0) { lv.playSound(null, net.minecraft.core.BlockPos.containing(head), SoundEvents.WOOL_PLACE, SoundSource.HOSTILE, 1.0f, 1.4f);
                                       lv.sendParticles(ModParticles.BLOOD.get(), head.x, head.y, head.z, 3, 0.1, 0.05, 0.1, 0.02); }
                if (r.tick == 30) tell(lv, r.body, "message.kingofcurses.ritual_2", ChatFormatting.GRAY);
            }
            if (r.tick == 80) {
                tell(lv, r.body, "message.kingofcurses.ritual_3", ChatFormatting.LIGHT_PURPLE);
                if (yuta instanceof NamedSorcererEntity y) y.setActor(NamedSorcererEntity.ACTOR_COLLAPSE);
                lv.playSound(null, net.minecraft.core.BlockPos.containing(head), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.HOSTILE, 2.0f, 0.5f);
            }
            if (r.tick > 80 && r.tick < 110 && yuta != null) {        // Yuta's soul flows into the stitched body
                Vec3 from = yuta.position().add(0, 0.8, 0);
                double k = (r.tick - 80) / 30.0;
                Vec3 p = from.add(head.subtract(from).scale(k));
                lv.sendParticles(SOUL, p.x, p.y, p.z, 6, 0.1, 0.1, 0.1, 0.01);
            }
            if (r.tick == 110) {
                if (corpse != null) corpse.discard();
                ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
                GojoKenjakuEntity boss = ModEntities.GOJO_KENJAKU.get().create(lv);
                if (boss != null) {
                    boss.moveTo(r.body.x, r.body.y, r.body.z, r.yaw + 180f, 0);
                    if (sp != null) { boss.setChallenger(sp.getUUID()); if (KocTargets.hasSukuna(sp)) boss.setTarget(sp); }
                    lv.addFreshEntity(boss);
                    boss.triggerAnim("main", "taunt");
                }
                lv.sendParticles(SOUL, r.body.x, r.body.y + 1, r.body.z, 200, 0.6, 1.2, 0.6, 0.08);
                lv.sendParticles(ParticleTypes.REVERSE_PORTAL, r.body.x, r.body.y + 1, r.body.z, 120, 0.6, 1.2, 0.6, 0.05);
                lv.playSound(null, net.minecraft.core.BlockPos.containing(r.body), ModSounds.GOJO_INFINITY.get(), SoundSource.HOSTILE, 3.0f, 0.6f);
                lv.playSound(null, net.minecraft.core.BlockPos.containing(r.body), ModSounds.BOSS_THEME.get(), SoundSource.RECORDS, 1.0f, 1.0f);
                if (sp != null) {
                    CursedData d = KocSync.data(sp);
                    d.setBossSpawned(true);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 20, 0.8f));
                    sp.displayClientMessage(Component.translatable("message.kingofcurses.boss_arrives").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), false);
                }
            }
            if (r.tick >= LENGTH + 600) {                 // Yuta's empty body stays a while, then fades
                if (yuta != null) {
                    lv.sendParticles(ParticleTypes.LARGE_SMOKE, yuta.getX(), yuta.getY() + 0.3, yuta.getZ(), 20, 0.4, 0.2, 0.4, 0.01);
                    yuta.discard();
                }
                it.remove();
            }
        }
    }

    public static void clear() { ACTIVE.clear(); }
}
