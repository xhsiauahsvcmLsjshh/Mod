package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

import java.util.UUID;

/** Strength, speed, durability and vitality that grow with each finger. */
public final class PowerScaling {
    private static final UUID HEALTH = UUID.fromString("9d1b3c38-3f7e-4d7c-9a8f-0c1d2e3f4a51");
    private static final UUID DAMAGE = UUID.fromString("9d1b3c38-3f7e-4d7c-9a8f-0c1d2e3f4a52");
    private static final UUID SPEED = UUID.fromString("9d1b3c38-3f7e-4d7c-9a8f-0c1d2e3f4a53");
    private static final UUID ARMOR = UUID.fromString("9d1b3c38-3f7e-4d7c-9a8f-0c1d2e3f4a54");
    private static final UUID TOUGH = UUID.fromString("9d1b3c38-3f7e-4d7c-9a8f-0c1d2e3f4a55");
    private static final UUID KNOCK = UUID.fromString("9d1b3c38-3f7e-4d7c-9a8f-0c1d2e3f4a56");

    private PowerScaling() {}

    public static void apply(ServerPlayer sp, CursedData d) {
        float f = d.effectiveFingers() * (d.ending() == CursedData.ENDING_EMBRACE ? 1.25f : 1.0f);
        set(sp, Attributes.MAX_HEALTH, HEALTH, "koc_vitality", f * 1.0, AttributeModifier.Operation.ADDITION);
        set(sp, Attributes.ATTACK_DAMAGE, DAMAGE, "koc_strength", f * 0.6, AttributeModifier.Operation.ADDITION);
        set(sp, Attributes.MOVEMENT_SPEED, SPEED, "koc_speed", f * 0.012, AttributeModifier.Operation.MULTIPLY_BASE);
        set(sp, Attributes.ARMOR, ARMOR, "koc_durability", f * 0.5, AttributeModifier.Operation.ADDITION);
        set(sp, Attributes.ARMOR_TOUGHNESS, TOUGH, "koc_toughness", f * 0.25, AttributeModifier.Operation.ADDITION);
        set(sp, Attributes.KNOCKBACK_RESISTANCE, KNOCK, "koc_stance", Math.min(0.6, f * 0.02), AttributeModifier.Operation.ADDITION);
        if (sp.getHealth() > sp.getMaxHealth()) sp.setHealth(sp.getMaxHealth());
    }

    private static void set(Player p, Attribute attribute, UUID id, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attribute);
        if (inst == null) return;
        AttributeModifier existing = inst.getModifier(id);
        if (existing != null) {
            if (Math.abs(existing.getAmount() - amount) < 1.0E-6) return;
            inst.removeModifier(id);
        }
        if (amount != 0) inst.addPermanentModifier(new AttributeModifier(id, name, amount, op));
    }

    public static float jumpBoost(CursedData d) { return Math.min(0.35f, d.effectiveFingers() * 0.012f); }
    public static float damageReduction(CursedData d) { return Math.min(0.4f, d.effectiveFingers() * 0.015f); }
}
