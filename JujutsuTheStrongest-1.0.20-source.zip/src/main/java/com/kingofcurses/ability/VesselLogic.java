package com.kingofcurses.ability;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.DismantleSlashEntity;
import com.kingofcurses.entity.FugaArrowEntity;
import com.kingofcurses.entity.GojoEntity;
import com.kingofcurses.entity.GojoKenjakuEntity;
import com.kingofcurses.entity.SukunaEntity;
import com.kingofcurses.item.RippedFingerItem;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.network.SyncOtherPacket;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * v1.0.5 "vessels": the player rips out a finger carrying ALL their power (1..20 fingers) and feeds it to any creature.
 * The creature gets Sukuna's tattoos and hunts hostile mobs and players with Sukuna's techniques scaled to that power.
 * When it dies it drops the finger again, worth exactly the same number of fingers.
 */
@Mod.EventBusSubscriber(modid = KingOfCurses.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class VesselLogic {
    public static final String KEY = "kingofcurses_vessel";
    private static final UUID HEALTH_ID = UUID.fromString("6f1a2b3c-4d5e-4f60-8a71-92b3c4d5e6f7");
    private static final UUID SPEED_ID = UUID.fromString("7a2b3c4d-5e6f-4071-8b82-a3c4d5e6f708");
    private static final Map<Mob, int[]> COOLDOWNS = new WeakHashMap<>();
    private VesselLogic() {}

    public static int power(net.minecraft.world.entity.Entity e) { return e == null ? 0 : e.getPersistentData().getInt(KEY); }

    // ---------------------------------------------------------------- the player side

    /** v1.0.6: length of the ripping animation in ticks, and the tick on which the finger tears free. */
    public static final int RIP_LENGTH = 30, RIP_TEAR = 14;
    private static final Map<UUID, Integer> RIPPING = new java.util.HashMap<>();

    private static boolean canRip(ServerPlayer sp, boolean tell) {
        CursedData d = KocSync.data(sp);
        if (CinematicDirector.isInScene(sp.getUUID()) || DomainManager.isActive(sp.getUUID())) return false;
        if (d.ending() != CursedData.ENDING_NONE) { if (tell) sp.displayClientMessage(Component.translatable("message.kingofcurses.rip_locked").withStyle(ChatFormatting.GRAY), true); return false; }
        if (d.fingers() <= 0) { if (tell) sp.displayClientMessage(Component.translatable("message.kingofcurses.rip_none").withStyle(ChatFormatting.GRAY), true); return false; }
        return true;
    }

    /** Starts the ripping animation; the power actually leaves the body on tick {@link #RIP_TEAR}. */
    public static void rip(ServerPlayer sp) {
        if (RIPPING.containsKey(sp.getUUID()) || !canRip(sp, true)) return;
        RIPPING.put(sp.getUUID(), 0);
        ModNetwork.sendToTrackingAndSelf(sp, new com.kingofcurses.network.RipAnimPacket(sp.getId()));
        sp.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, RIP_LENGTH, 6, false, false));
        sp.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.JUMP, RIP_LENGTH, 128, false, false));
        sp.serverLevel().playSound(null, sp.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.PLAYERS, 1.2f, 0.8f);
    }

    /** Called every player tick. */
    public static void tickRip(ServerPlayer sp) {
        Integer t = RIPPING.get(sp.getUUID());
        if (t == null) return;
        if (!sp.isAlive()) { RIPPING.remove(sp.getUUID()); return; }
        t++;
        if (t == RIP_TEAR && canRip(sp, false)) doRip(sp);
        if (t >= RIP_LENGTH) RIPPING.remove(sp.getUUID()); else RIPPING.put(sp.getUUID(), t);
    }

    public static void clearRips() { RIPPING.clear(); }

    private static void doRip(ServerPlayer sp) {
        CursedData d = KocSync.data(sp);
        int n = d.fingers();
        d.setFingerMask(0);
        d.setTakeoverTicks(0);
        d.setBossCountdown(0);
        d.setEnergy(0);
        PowerScaling.apply(sp, d);
        MobileControls.refresh(sp, d);
        KocSync.sync(sp);
        ItemStack finger = RippedFingerItem.withPower(n);
        if (!sp.getInventory().add(finger)) sp.drop(finger, false);
        ServerLevel sl = sp.serverLevel();
        sp.hurt(sp.damageSources().generic(), 2.0f);
        Vec3 hand = sp.getEyePosition().add(sp.getLookAngle().scale(0.6)).add(0, -0.35, 0);
        sl.sendParticles(ModParticles.BLOOD.get(), hand.x, hand.y, hand.z, 50, 0.12, 0.12, 0.12, 0.2);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 14, 0.9f));
        sl.sendParticles(ModParticles.CURSED_ENERGY.get(), sp.getX(), sp.getY() + 1.0, sp.getZ(), 80, 0.4, 0.8, 0.4, 0.1);
        sl.playSound(null, sp.blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.PLAYERS, 1.2f, 0.8f);
        sl.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.PLAYERS, 1.0f, 1.2f);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 20, 0.8f));
        sp.displayClientMessage(Component.translatable("message.kingofcurses.rip_done", n).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
    }

    /** Eating a ripped finger: the player gets back (at least) that many fingers of power. */
    public static void reabsorb(ServerPlayer sp, int n) {
        CursedData d = KocSync.data(sp);
        n = Math.max(1, Math.min(20, n));
        int before = d.effectiveFingers();
        int countBefore = d.fingers();
        d.setFingerMask(d.fingerMask() | ((1 << n) - 1));
        if (countBefore < 20 && d.fingers() >= 20 && d.ending() != CursedData.ENDING_REJECT) ArmLogic.startTransform(sp);
        d.setEnergy(d.maxEnergy());
        PowerScaling.apply(sp, d);
        MobileControls.giveUnlocked(sp, d);
        int after = d.effectiveFingers();
        for (Ability a : Ability.values()) {
            int req = a.requiredFingers();
            if (before < req && after >= req && !(a == Ability.DOMAIN_EXPANSION && d.ending() == CursedData.ENDING_REJECT))
                sp.displayClientMessage(Component.translatable("message.kingofcurses.ability_unlocked", a.displayName()).withStyle(ChatFormatting.RED), false);
        }
        if (d.fingers() >= 20 && !d.bossDefeated() && d.ending() == CursedData.ENDING_NONE) d.setBossCountdown(100);
        ServerLevel sl = sp.serverLevel();
        sl.playSound(null, sp.blockPosition(), ModSounds.FINGER_EAT.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
        sl.playSound(null, sp.blockPosition(), ModSounds.SUKUNA_ROAR.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
        sl.sendParticles(ModParticles.CURSED_ENERGY.get(), sp.getX(), sp.getY() + 1.0, sp.getZ(), 120, 0.6, 1.0, 0.6, 0.18);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.MARKINGS, 60, 1.0f));
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 30, 0.6f));
        sp.displayClientMessage(Component.translatable("message.kingofcurses.reabsorbed", n, d.fingers()).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        KocAdvancements.award(sp, "first_finger");
        KocSync.sync(sp);
    }

    public static boolean canBeVessel(LivingEntity e) {
        if (!(e instanceof Mob) || !e.isAlive()) return false;
        if (e instanceof GojoKenjakuEntity || e instanceof SukunaEntity) return false;
        return !(e instanceof GojoEntity g && (g.isCinematic() || g.isCorpse()));
    }

    /** Feeds a ripped finger to a creature. Powers stack up to 20. */
    public static void feed(Mob mob, int n, ServerPlayer feeder) {
        int total = Math.min(20, power(mob) + Math.max(1, n));
        mob.getPersistentData().putInt(KEY, total);
        mob.setPersistenceRequired();
        applyStats(mob, total);
        mob.setHealth(mob.getMaxHealth());
        ensureGoal(mob);
        ModNetwork.sendToTrackingAndSelf(mob, new SyncOtherPacket(mob.getId(), total, 0));
        ServerLevel sl = (ServerLevel) mob.level();
        sl.sendParticles(ModParticles.CURSED_ENERGY.get(), mob.getX(), mob.getY() + mob.getBbHeight() / 2, mob.getZ(), 120, 0.5, 0.6, 0.5, 0.15);
        sl.sendParticles(ModParticles.BLOOD.get(), mob.getX(), mob.getY() + mob.getBbHeight() / 2, mob.getZ(), 20, 0.3, 0.3, 0.3, 0.1);
        sl.playSound(null, mob.blockPosition(), ModSounds.FINGER_EAT.get(), SoundSource.NEUTRAL, 1.2f, 0.9f);
        sl.playSound(null, mob.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.NEUTRAL, 1.4f, 0.8f);
        feeder.displayClientMessage(Component.translatable("message.kingofcurses.vessel_fed", mob.getDisplayName(), total).withStyle(ChatFormatting.DARK_RED), false);
    }

    private static void applyStats(Mob mob, int n) {
        AttributeInstance hp = mob.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) { hp.removeModifier(HEALTH_ID); hp.addPermanentModifier(new AttributeModifier(HEALTH_ID, "Vessel health", n * 3.0, AttributeModifier.Operation.ADDITION)); }
        AttributeInstance sp = mob.getAttribute(Attributes.MOVEMENT_SPEED);
        if (sp != null) { sp.removeModifier(SPEED_ID); sp.addPermanentModifier(new AttributeModifier(SPEED_ID, "Vessel speed", 0.1 + n * 0.01, AttributeModifier.Operation.MULTIPLY_BASE)); }
    }

    private static void ensureGoal(Mob mob) {
        for (var w : mob.goalSelector.getAvailableGoals()) if (w.getGoal() instanceof VesselGoal) return;
        mob.goalSelector.addGoal(0, new VesselGoal(mob));
    }

    // ---------------------------------------------------------------- events

    @SubscribeEvent
    public static void interact(PlayerInteractEvent.EntityInteract event) {
        ItemStack stack = event.getItemStack();
        if (!(stack.getItem() instanceof RippedFingerItem) || !(event.getTarget() instanceof LivingEntity target)) return;
        if (!canBeVessel(target)) return;
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getEntity() instanceof ServerPlayer sp && target instanceof Mob mob) {
            feed(mob, RippedFingerItem.power(stack), sp);
            if (!sp.getAbilities().instabuild) stack.shrink(1);
        }
    }

    @SubscribeEvent
    public static void join(EntityJoinLevelEvent event) {
        if (!event.getLevel().isClientSide() && event.getEntity() instanceof Mob mob && power(mob) > 0) ensureGoal(mob);
    }

    @SubscribeEvent
    public static void track(PlayerEvent.StartTracking event) {
        if (!(event.getTarget() instanceof Player) && event.getEntity() instanceof ServerPlayer viewer) {
            int p = power(event.getTarget());
            if (p > 0) ModNetwork.sendTo(viewer, new SyncOtherPacket(event.getTarget().getId(), p, 0));
        }
    }

    /** Called from the death hook: the vessel gives the finger back. */
    public static void onDeath(LivingEntity e) {
        int p = power(e);
        if (p <= 0 || e.level().isClientSide) return;
        e.getPersistentData().remove(KEY);
        e.spawnAtLocation(RippedFingerItem.withPower(p));
        if (e.level() instanceof ServerLevel sl) {
            sl.sendParticles(ModParticles.CURSED_ENERGY.get(), e.getX(), e.getY() + 0.6, e.getZ(), 60, 0.4, 0.5, 0.4, 0.1);
            for (ServerPlayer pl : sl.getPlayers(pl -> pl.distanceToSqr(e) < 32 * 32))
                pl.displayClientMessage(Component.translatable("message.kingofcurses.vessel_drop", p).withStyle(ChatFormatting.DARK_RED), true);
        }
    }

    // ---------------------------------------------------------------- the vessel AI

    static boolean validTarget(Mob self, LivingEntity e) {
        if (e == self || !e.isAlive()) return false;
        if (e instanceof Player p) return !p.isCreative() && !p.isSpectator();
        return e instanceof Enemy && power(e) == 0;
    }

    /** Hunts hostile mobs and players and fights with Sukuna's techniques. Indices: 0 dismantle, 1 cleave, 2 rct, 3 web, 4 fuga, 5 world slash, 6 domain cd, 7 domain time. */
    public static class VesselGoal extends Goal {
        private final Mob mob;
        private LivingEntity target;
        private int scan;

        public VesselGoal(Mob mob) { this.mob = mob; setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }

        private LivingEntity find() {
            LivingEntity best = null; double bd = Double.MAX_VALUE;
            for (LivingEntity e : mob.level().getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(20), e -> validTarget(mob, e))) {
                double d = e.distanceToSqr(mob);
                if (d < bd) { bd = d; best = e; }
            }
            return best;
        }

        @Override
        public boolean canUse() {
            if (power(mob) <= 0) return false;
            if (--scan > 0) return false;
            scan = 10;
            target = find();
            return target != null;
        }

        @Override
        public boolean canContinueToUse() {
            return power(mob) > 0 && target != null && validTarget(mob, target) && target.distanceToSqr(mob) < 32 * 32;
        }

        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void stop() { target = null; mob.getNavigation().stop(); }

        @Override
        public void tick() {
            if (target == null || !(mob.level() instanceof ServerLevel sl)) return;
            int n = power(mob);
            int[] cd = COOLDOWNS.computeIfAbsent(mob, m -> new int[8]);
            for (int i = 0; i < 7; i++) if (cd[i] > 0) cd[i]--;
            mob.getLookControl().setLookAt(target, 30f, 30f);
            if (mob.getTarget() != target) mob.setTarget(target);
            double dist = mob.distanceTo(target);
            if (dist > 2.5) mob.getNavigation().moveTo(target, 1.25);
            else mob.getNavigation().stop();
            boolean sees = mob.hasLineOfSight(target);
            float mult = 1.0f + n * 0.05f;

            if (cd[7] > 0) { // vessel's own Malevolent Shrine
                cd[7]--;
                if (cd[7] % 10 == 0) {
                    for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(12), e -> validTarget(mob, e))) {
                        e.invulnerableTime = 0; SliceLogic.mark(e);
                        e.hurt(mob.damageSources().indirectMagic(mob, mob), 4f + n * 0.25f);
                        sl.sendParticles(ModParticles.SLASH.get(), e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 3, 0.4, 0.4, 0.4, 0);
                    }
                    sl.sendParticles(ModParticles.DOMAIN_ASH.get(), mob.getX(), mob.getY() + 2, mob.getZ(), 60, 8, 3, 8, 0.01);
                    sl.playSound(null, mob.blockPosition(), ModSounds.DOMAIN_SLASH.get(), SoundSource.HOSTILE, 1.5f, 1.0f);
                }
            }
            if (n >= 20 && cd[6] <= 0 && dist < 14) {
                cd[6] = 1200; cd[7] = 100;
                sl.playSound(null, mob.blockPosition(), ModSounds.DOMAIN_EXPANSION.get(), SoundSource.HOSTILE, 3.0f, 1.0f);
                for (ServerPlayer p : sl.getPlayers(p -> p.distanceToSqr(mob) < 24 * 24))
                    p.displayClientMessage(Component.translatable("message.kingofcurses.vessel_domain").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
                return;
            }
            if (n >= 5 && cd[2] <= 0 && mob.getHealth() < mob.getMaxHealth() * 0.5f) {
                cd[2] = 240; mob.heal(4f + n * 0.4f);
                sl.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER, mob.getX(), mob.getY() + 1, mob.getZ(), 20, 0.4, 0.6, 0.4, 0);
                sl.playSound(null, mob.blockPosition(), ModSounds.RCT_HEAL.get(), SoundSource.HOSTILE, 1.0f, 1.0f);
                return;
            }
            if (n >= 17 && cd[5] <= 0 && sees && dist < 30) { cd[5] = 420; worldSlash(sl, n); return; }
            if (n >= 10 && cd[4] <= 0 && sees && dist > 4 && dist < 24) {
                cd[4] = 260;
                FugaArrowEntity arrow = new FugaArrowEntity(sl, mob, 8f + n * 0.7f);
                aim(arrow, 2.0f);
                sl.addFreshEntity(arrow);
                sl.playSound(null, mob.blockPosition(), ModSounds.FUGA_IGNITE.get(), SoundSource.HOSTILE, 1.4f, 1.0f);
                return;
            }
            if (n >= 8 && cd[3] <= 0 && dist < 5) {
                cd[3] = 140;
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(4.5), e -> validTarget(mob, e))) {
                    SliceLogic.mark(e); e.hurt(mob.damageSources().mobAttack(mob), (3f + n * 0.4f) * mult);
                }
                sl.sendParticles(ModParticles.SLASH.get(), mob.getX(), mob.getY() + 0.2, mob.getZ(), 40, 3, 0.1, 3, 0);
                sl.playSound(null, mob.blockPosition(), ModSounds.DISMANTLE.get(), SoundSource.HOSTILE, 1.2f, 0.7f);
                return;
            }
            if (n >= 3 && cd[1] <= 0 && dist < 3.5) {
                cd[1] = 50;
                SliceLogic.mark(target);
                target.hurt(mob.damageSources().mobAttack(mob), (4f + n * 0.7f) * mult);
                sl.sendParticles(ModParticles.SLASH.get(), target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(), 6, 0.3, 0.3, 0.3, 0);
                sl.playSound(null, mob.blockPosition(), ModSounds.CLEAVE.get(), SoundSource.HOSTILE, 1.0f, 1.0f);
                return;
            }
            if (cd[0] <= 0 && sees && dist < 16) {
                cd[0] = Math.max(16, 40 - n);
                DismantleSlashEntity slash = new DismantleSlashEntity(sl, mob, (3f + n * 0.6f) * mult, 1 + n / 6);
                aim(slash, 2.4f);
                sl.addFreshEntity(slash);
                sl.playSound(null, mob.blockPosition(), ModSounds.DISMANTLE.get(), SoundSource.HOSTILE, 1.0f, 1.0f);
            }
        }

        private void aim(net.minecraft.world.entity.projectile.Projectile p, float speed) {
            Vec3 from = new Vec3(mob.getX(), mob.getEyeY() - 0.2, mob.getZ());
            p.setPos(from.x, from.y, from.z);
            Vec3 to = target.getEyePosition().subtract(0, 0.3, 0).subtract(from);
            p.shoot(to.x, to.y, to.z, speed, 0.0f);
        }

        private void worldSlash(ServerLevel sl, int n) {
            Vec3 eye = mob.getEyePosition();
            Vec3 dir = target.getEyePosition().subtract(eye).normalize();
            Set<Integer> hit = new HashSet<>();
            for (double t = 1; t <= 32; t += 0.5) {
                Vec3 p = eye.add(dir.scale(t));
                if (((int) (t * 2)) % 2 == 0) sl.sendParticles(ModParticles.SLASH.get(), p.x, p.y, p.z, 2, 0.5, 0.5, 0.5, 0);
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(p, p).inflate(1.3), e -> validTarget(mob, e))) {
                    if (!hit.add(e.getId())) continue;
                    e.invulnerableTime = 0; SliceLogic.mark(e);
                    GojoKenjakuEntity.SURE_HIT = true;
                    try { e.hurt(mob.damageSources().indirectMagic(mob, mob), 12f + n); } finally { GojoKenjakuEntity.SURE_HIT = false; }
                }
            }
            sl.playSound(null, mob.blockPosition(), ModSounds.WORLD_SLASH.get(), SoundSource.HOSTILE, 2.0f, 1.0f);
        }
    }
}
