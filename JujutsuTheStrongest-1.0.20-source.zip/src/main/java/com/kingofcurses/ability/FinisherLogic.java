package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.GojoEntity;
import com.kingofcurses.entity.GojoKenjakuEntity;
import com.kingofcurses.entity.NamedSorcererEntity;
import com.kingofcurses.entity.SorcererEntity;
import com.kingofcurses.entity.SpecialGradeCurseEntity;
import com.kingofcurses.entity.SukunaEntity;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.RipAnimPacket;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.ElderGuardian;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * v1.0.14 Vigor + Finishers. While Sukuna lives in your body, every 5 hearts of damage you deal fill the Vigor bar.
 * Full bar: a brutal finisher on ordinary creatures, or one empowered strike on sorcerers and bosses (vanilla bosses too).
 */
public final class FinisherLogic {
    public static final int TEAR = 0, HEART = 1, SLAM = 2, DISMANTLE_STORM = 3, FUGA_POINT_BLANK = 4, SKY_CLEAVE = 5, BLACK_FLASH_BARRAGE = 6;
    public static final String[] IDS = {"tear", "heart", "slam", "dismantle_storm", "fuga", "sky_cleave", "barrage"};
    /** v1.0.18 Gojo's finishers (kinds 8..13). */
    public static final int RED_POINT_BLANK = 8, BLUE_CRUSH = 9, PURPLE_ERASE = 10, INFINITY_WALL = 11, GOJO_BLACK_FLASH = 12, VOID_PUNCH = 13;
    public static final String[] GOJO_IDS = {"red_point_blank", "blue_crush", "purple_erase", "infinity_wall", "gojo_black_flash", "void_punch"};
    public static final int[] LENGTHS = {50, 40, 44, 40, 50, 46, 40, 20, 40, 44, 46, 40, 36, 44};   // [7] = catching Sukuna's arm (not a finisher)
    /** Damage (HP) needed to fill the bar: 10 HP = 5 hearts. */
    public static final float FILL_DAMAGE = 10f;

    private static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.02f, 0.0f, 0.02f), 2.0f);
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(1.0f, 0.05f, 0.1f), 1.6f);
    private static final Map<UUID, Run> RUNS = new HashMap<>();
    private static final Map<UUID, Integer> LAST = new HashMap<>();
    private static final Map<UUID, Integer> LAST_HIT = new HashMap<>();
    /** True while a finisher deals its own damage (no Vigor gain, no Black Flash). */
    public static boolean dealing = false;

    private static final class Run {
        final int targetId, kind;
        int t;
        final boolean hadNoAi;
        Run(int targetId, int kind, boolean hadNoAi) { this.targetId = targetId; this.kind = kind; this.hadNoAi = hadNoAi; }
    }

    private FinisherLogic() {}

    public static boolean running(UUID id) { return RUNS.containsKey(id); }

    public static boolean canGain(CursedData d) { return d.hasPowers(); }

    /** Sorcerers and bosses only take one empowered strike. */
    public static boolean isSorcererOrBoss(LivingEntity e) {
        if (e instanceof Player) return true;
        if (e instanceof SorcererEntity || e instanceof NamedSorcererEntity || e instanceof GojoEntity || e instanceof GojoKenjakuEntity || e instanceof SukunaEntity) return true;
        if (VesselLogic.power(e) > 0) return true;
        if (e instanceof EnderDragon || e instanceof WitherBoss || e instanceof ElderGuardian || e instanceof Warden || e instanceof SpecialGradeCurseEntity) return true;
        if (e.getType().is(Tags.EntityTypes.BOSSES)) return true;
        return e.getMaxHealth() >= 150f; // big modded bosses without the tag
    }

    // ------------------------------------------------------------------ Vigor gain
    public static void onDamageDealt(ServerPlayer sp, CursedData d, LivingEntity target, float amount) {
        if (dealing || target == sp || !canGain(d) || running(sp.getUUID())) return;
        float real = Math.min(amount, target.getHealth());
        if (real <= 0) return;
        boolean wasReady = d.finisherReady();
        d.addVigor(real / FILL_DAMAGE * CursedData.VIGOR_MAX);
        LAST_HIT.put(sp.getUUID(), sp.tickCount);
        if (!wasReady && d.finisherReady()) {
            sp.serverLevel().playSound(null, sp.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.PLAYERS, 1.6f, 0.7f);
            if (!d.isGojo()) sp.serverLevel().playSound(null, sp.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.PLAYERS, 0.8f, 1.0f);
            sp.displayClientMessage(Component.translatable(d.isGojo() ? "message.kingofcurses.finisher_ready_gojo" : "message.kingofcurses.finisher_ready")
                    .withStyle(d.isGojo() ? ChatFormatting.AQUA : ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 10, 0.5f));
        }
        KocSync.sync(sp);
    }

    /** Per player tick: decay when out of combat (never while full) and drive the running finisher. */
    public static void tick(ServerPlayer sp, CursedData d) {
        if (!canGain(d)) { if (d.vigor() > 0) d.setVigor(0); }
        else if (!d.finisherReady() && d.vigor() > 0 && sp.tickCount - LAST_HIT.getOrDefault(sp.getUUID(), 0) > 200) d.addVigor(-0.25f);
        Run r = RUNS.get(sp.getUUID());
        if (r != null) step(sp, d, r);
    }

    // ------------------------------------------------------------------ trigger
    public static void tryStart(ServerPlayer sp) {
        CursedData d = KocSync.data(sp);
        if (running(sp.getUUID()) || CinematicDirector.isInScene(sp.getUUID()) || d.takeoverTicks() > 0 || FirstTakeover.active(sp.getUUID())) return;
        if (!canGain(d)) return;
        if (!d.finisherReady()) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.finisher_not_ready", (int) d.vigor()).withStyle(ChatFormatting.DARK_RED), true);
            return;
        }
        LivingEntity target = AbilityLogic.lookTarget(sp, 5.0);
        if (target == null) target = nearestInFront(sp);
        if (target == null || !target.isAlive()) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.finisher_no_target").withStyle(ChatFormatting.DARK_RED), true);
            return;
        }
        d.setVigor(0);
        if (isSorcererOrBoss(target)) { empoweredStrike(sp, d, target); KocSync.sync(sp); return; }
        int last = LAST.getOrDefault(sp.getUUID(), -1);
        boolean gojo = d.isGojo();
        int n = gojo ? GOJO_IDS.length : IDS.length, base = gojo ? RED_POINT_BLANK : 0;
        int kind = base + sp.getRandom().nextInt(n);
        if (kind == last) kind = base + (kind - base + 1 + sp.getRandom().nextInt(n - 1)) % n;
        LAST.put(sp.getUUID(), kind);
        boolean hadNoAi = target instanceof Mob m && m.isNoAi();
        if (target instanceof Mob m) { m.setNoAi(true); m.setTarget(null); }
        RUNS.put(sp.getUUID(), new Run(target.getId(), kind, hadNoAi));
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp), new RipAnimPacket(sp.getId(), RipAnimPacket.FINISHER, kind));
        sp.displayClientMessage(Component.translatable("finisher.kingofcurses." + (kind >= RED_POINT_BLANK ? GOJO_IDS[kind - RED_POINT_BLANK] : IDS[kind])).withStyle(gojo ? ChatFormatting.AQUA : ChatFormatting.RED, ChatFormatting.BOLD), true);
        if (!gojo) sp.serverLevel().playSound(null, sp.blockPosition(), ModSounds.SUKUNA_VOICE.get(), SoundSource.PLAYERS, 1.2f, 0.9f);
        KocSync.sync(sp);
    }

    private static LivingEntity nearestInFront(ServerPlayer sp) {
        Vec3 look = sp.getLookAngle();
        LivingEntity best = null;
        double bd = 99;
        for (LivingEntity e : sp.level().getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(4.0), e -> e != sp && e.isAlive() && !e.isSpectator())) {
            Vec3 to = e.position().subtract(sp.position());
            double dist = to.length();
            if (dist < 0.01 || to.normalize().dot(look) < 0.3) continue;
            if (dist < bd) { bd = dist; best = e; }
        }
        return best;
    }

    // ------------------------------------------------------------------ sorcerers / bosses
    private static void empoweredStrike(ServerPlayer sp, CursedData d, LivingEntity target) {
        ServerLevel sl = sp.serverLevel();
        float base = (float) sp.getAttributeValue(Attributes.ATTACK_DAMAGE);
        float dmg = (base * 3f + 12f) * d.powerMultiplier() + Math.min(40f, target.getMaxHealth() * 0.05f);
        hit(sp, target, dmg);
        Vec3 c = target.position().add(0, target.getBbHeight() * 0.55, 0);
        sl.sendParticles(BLACK, c.x, c.y, c.z, 120, 0.6, 0.6, 0.6, 0.3);
        sl.sendParticles(RED, c.x, c.y, c.z, 80, 0.7, 0.7, 0.7, 0.35);
        sl.sendParticles(ParticleTypes.SONIC_BOOM, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 50, 0.5, 0.5, 0.5, 0.7);
        sl.sendParticles(ModParticles.BLOOD.get(), c.x, c.y, c.z, 40, 0.4, 0.4, 0.4, 0.3);
        sl.playSound(null, target.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.6f, 0.5f);
        sl.playSound(null, target.blockPosition(), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.PLAYERS, 1.8f, 0.6f);
        Vec3 push = target.position().subtract(sp.position()).normalize();
        double kb = target.getMaxHealth() > 200 ? 0.4 : 1.8;
        target.setDeltaMovement(target.getDeltaMovement().add(push.x * kb, 0.45, push.z * kb));
        target.hurtMarked = true;
        sp.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.BLACK_FLASH, 30, 1.0f));
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 14, 0.9f));
        sp.displayClientMessage(Component.translatable("message.kingofcurses.finisher_empowered").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
    }

    private static void hit(ServerPlayer sp, LivingEntity target, float dmg) {
        dealing = true;
        try {
            target.invulnerableTime = 0;
            target.hurt(sp.damageSources().playerAttack(sp), dmg);
        } finally { dealing = false; }
    }

    private static void kill(ServerPlayer sp, LivingEntity target) {
        hit(sp, target, Math.max(1000f, target.getMaxHealth() * 4f));
        if (target.isAlive()) target.kill();
    }

    // ------------------------------------------------------------------ choreography
    private static void end(ServerPlayer sp, Run r, LivingEntity target) {
        RUNS.remove(sp.getUUID());
        if (target != null && target.isAlive() && target instanceof Mob m && !r.hadNoAi) m.setNoAi(false);
    }

    /** Point in front of the player at the given distance and height above the feet. */
    private static Vec3 front(ServerPlayer sp, double dist, double up) {
        float yaw = sp.getYRot() * Mth.DEG_TO_RAD;
        return new Vec3(sp.getX() - Mth.sin(yaw) * dist, sp.getY() + up, sp.getZ() + Mth.cos(yaw) * dist);
    }

    private static void hold(ServerPlayer sp, LivingEntity t, Vec3 at) {
        t.teleportTo(at.x, at.y, at.z);
        t.setDeltaMovement(Vec3.ZERO);
        t.fallDistance = 0;
        float face = sp.getYRot() + 180f;
        t.setYRot(face); t.yRotO = face; t.yBodyRot = face; t.yBodyRotO = face; t.yHeadRot = face; t.yHeadRotO = face;
        t.hurtMarked = true;
    }

    private static void step(ServerPlayer sp, CursedData d, Run r) {
        ServerLevel sl = sp.serverLevel();
        net.minecraft.world.entity.Entity ent = sl.getEntity(r.targetId);
        LivingEntity t = ent instanceof LivingEntity le ? le : null;
        if (t == null || !t.isAlive() || !sp.isAlive() || t.distanceToSqr(sp) > 100) { end(sp, r, t); return; }
        int k = r.t++;
        // lock the player in place for the show
        sp.setDeltaMovement(0, Math.min(0, sp.getDeltaMovement().y), 0);
        sp.hurtMarked = true;
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 10, true, false, false));
        double w = t.getBbWidth(), h = t.getBbHeight();
        double gap = 0.75 + w * 0.5;
        Vec3 mid = t.position().add(0, h * 0.5, 0);
        switch (r.kind) {
            case TEAR -> {   // grab, lift overhead, rip in two with bare hands
                double lift = Mth.clamp(k / 12.0, 0, 1);
                double up = Mth.lerp(lift, 0.2, sp.getBbHeight() + 0.15);
                double shake = k >= 12 && k < 36 ? (sp.getRandom().nextDouble() - 0.5) * 0.12 : 0;
                hold(sp, t, front(sp, Mth.lerp(lift, gap, 0.55 + w * 0.25), up).add(shake, 0, shake));
                if (k == 2) sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.2f, 0.6f);
                if (k >= 14 && k < 36 && k % 4 == 0) {
                    sl.playSound(null, t.blockPosition(), SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, SoundSource.PLAYERS, 0.5f, 0.5f + k * 0.01f);
                    sl.sendParticles(ModParticles.BLOOD.get(), mid.x, mid.y, mid.z, 6 + k / 3, w * 0.2, h * 0.3, w * 0.2, 0.08);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 4, 0.3f));
                }
                if (k == 36) {
                    sl.sendParticles(ModParticles.BLOOD.get(), mid.x, mid.y, mid.z, 120, w * 0.4, h * 0.4, w * 0.4, 0.35);
                    sl.playSound(null, t.blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.PLAYERS, 1.6f, 0.7f);
                    sl.playSound(null, t.blockPosition(), SoundEvents.GENERIC_BIG_FALL, SoundSource.PLAYERS, 1.2f, 0.5f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 12, 0.8f));
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 14, 0.8f));
                    SliceLogic.markVertical(t);
                    kill(sp, t);
                }
            }
            case HEART -> {   // hand straight through the chest, rip the heart out
                hold(sp, t, front(sp, gap * 0.85, 0));
                if (k == 12) {
                    Vec3 back = mid.add(t.position().subtract(sp.position()).normalize().scale(w * 0.6));
                    sl.sendParticles(ModParticles.BLOOD.get(), back.x, back.y, back.z, 70, 0.15, 0.2, 0.15, 0.4);
                    sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.5f, 0.5f);
                    sl.playSound(null, t.blockPosition(), ModSounds.BLOOD_SPLATTER.get(), SoundSource.PLAYERS, 1.4f, 0.8f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 10, 0.6f));
                }
                if (k > 12 && k < 30 && k % 3 == 0) sl.sendParticles(ModParticles.BLOOD.get(), mid.x, mid.y, mid.z, 5, w * 0.2, 0.2, w * 0.2, 0.05);
                if (k == 30) {
                    sl.playSound(null, t.blockPosition(), ModSounds.HEARTBEAT.get(), SoundSource.PLAYERS, 1.6f, 1.4f);
                    sl.sendParticles(RED, mid.x, mid.y, mid.z, 50, 0.3, 0.3, 0.3, 0.1);
                    sl.sendParticles(ModParticles.BLOOD.get(), mid.x, mid.y, mid.z, 60, 0.3, 0.3, 0.3, 0.3);
                    kill(sp, t);
                }
            }
            case SLAM -> {   // grab the head, lift high, smash into the ground
                if (k < 18) hold(sp, t, front(sp, gap, Mth.lerp(k / 18.0, 0.3, sp.getBbHeight() + 0.9)));
                else if (k < 24) hold(sp, t, front(sp, gap + 0.2, Mth.lerp((k - 18) / 6.0, sp.getBbHeight() + 0.9, 0)));
                else hold(sp, t, front(sp, gap + 0.2, 0));
                if (k == 24) {
                    BlockPos below = t.blockPosition().below();
                    BlockState bs = sl.getBlockState(below);
                    if (!bs.isAir()) sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, bs), t.getX(), t.getY() + 0.1, t.getZ(), 120, 1.0, 0.2, 1.0, 0.3);
                    sl.sendParticles(ParticleTypes.EXPLOSION, t.getX(), t.getY() + 0.2, t.getZ(), 3, 0.6, 0.1, 0.6, 0);
                    sl.sendParticles(ModParticles.BLOOD.get(), t.getX(), t.getY() + 0.3, t.getZ(), 80, 0.6, 0.2, 0.6, 0.3);
                    sl.playSound(null, t.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.2f, 0.7f);
                    sl.playSound(null, t.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.8f, 0.5f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 16, 1.0f));
                    for (LivingEntity o : sl.getEntitiesOfClass(LivingEntity.class, new AABB(t.blockPosition()).inflate(3), o -> o != sp && o != t)) {
                        Vec3 pv = o.position().subtract(t.position()).normalize();
                        o.setDeltaMovement(pv.x * 0.8, 0.5, pv.z * 0.8); o.hurtMarked = true;
                    }
                    kill(sp, t);
                }
            }
            case DISMANTLE_STORM -> {   // pinned in the air while Dismantle carves it
                hold(sp, t, front(sp, gap + 0.4, Mth.clamp(k / 6.0, 0, 1) * 0.8));
                if (k >= 6 && k < 34 && k % 3 == 0) {
                    sl.sendParticles(ModParticles.SLASH.get(), mid.x, mid.y, mid.z, 3, w * 0.5, h * 0.4, w * 0.5, 0);
                    sl.sendParticles(ModParticles.BLOOD.get(), mid.x, mid.y, mid.z, 10, w * 0.3, h * 0.3, w * 0.3, 0.15);
                    sl.playSound(null, t.blockPosition(), ModSounds.DISMANTLE.get(), SoundSource.PLAYERS, 0.7f, 0.8f + sp.getRandom().nextFloat() * 0.5f);
                }
                if (k == 34) {
                    sl.playSound(null, t.blockPosition(), ModSounds.CLEAVE.get(), SoundSource.PLAYERS, 1.5f, 0.7f);
                    sl.sendParticles(ModParticles.SLASH.get(), mid.x, mid.y, mid.z, 12, w * 0.6, h * 0.5, w * 0.6, 0);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 10, 0.6f));
                    SliceLogic.mark(t);
                    kill(sp, t);
                }
            }
            case FUGA_POINT_BLANK -> {   // "Open": fire arrow point blank
                hold(sp, t, front(sp, gap + 0.6, 0));
                Vec3 hand = front(sp, 0.6, sp.getBbHeight() * 0.75);
                if (k < 30 && k % 2 == 0) sl.sendParticles(ParticleTypes.FLAME, hand.x, hand.y, hand.z, 6 + k / 3, 0.1, 0.1, 0.1, 0.02);
                if (k == 4) sl.playSound(null, sp.blockPosition(), ModSounds.FUGA_IGNITE.get(), SoundSource.PLAYERS, 1.3f, 1.0f);
                if (k == 30) {
                    sl.playSound(null, t.blockPosition(), ModSounds.FUGA_EXPLODE.get(), SoundSource.PLAYERS, 1.6f, 1.0f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 10, 0.7f));
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 12, 0.8f));
                    t.setSecondsOnFire(10);
                }
                if (k >= 30) {
                    sl.sendParticles(ParticleTypes.FLAME, mid.x, mid.y, mid.z, 30, w * 0.4, h * 0.4, w * 0.4, 0.06);
                    sl.sendParticles(ParticleTypes.LARGE_SMOKE, mid.x, mid.y, mid.z, 8, w * 0.3, h * 0.3, w * 0.3, 0.03);
                }
                if (k == 44) {
                    sl.sendParticles(ParticleTypes.LAVA, mid.x, mid.y, mid.z, 20, w * 0.3, h * 0.3, w * 0.3, 0.1);
                    kill(sp, t);
                }
            }
            case SKY_CLEAVE -> {   // kick it into the sky, Cleave it in mid air
                if (k < 8) hold(sp, t, front(sp, gap, 0));
                else if (k < 24) hold(sp, t, front(sp, gap + 0.6, Mth.lerp((k - 8) / 16.0, 0, 4.5)));
                else hold(sp, t, front(sp, gap + 0.6, 4.5));
                if (k == 8) {
                    sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.4f, 0.6f);
                    sl.sendParticles(ParticleTypes.SWEEP_ATTACK, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
                    sl.sendParticles(ParticleTypes.CLOUD, t.getX(), t.getY(), t.getZ(), 20, 0.4, 0.05, 0.4, 0.05);
                }
                if (k == 30) {
                    sl.playSound(null, t.blockPosition(), ModSounds.CLEAVE.get(), SoundSource.PLAYERS, 1.8f, 0.6f);
                    for (int i = 0; i < 10; i++) {
                        Vec3 p = sp.getEyePosition().lerp(mid, i / 9.0);
                        sl.sendParticles(ModParticles.SLASH.get(), p.x, p.y, p.z, 1, 0, 0, 0, 0);
                    }
                    sl.sendParticles(ModParticles.BLOOD.get(), mid.x, mid.y, mid.z, 90, w * 0.4, h * 0.3, w * 0.4, 0.3);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 12, 0.7f));
                    SliceLogic.mark(t);
                    kill(sp, t);
                }
            }
            case BLACK_FLASH_BARRAGE -> {   // a storm of fists, the last one is a Black Flash
                hold(sp, t, front(sp, gap, 0));
                if (k >= 4 && k < 32 && k % 4 == 0) {
                    sl.sendParticles(ParticleTypes.CRIT, mid.x, mid.y, mid.z, 12, w * 0.3, h * 0.3, w * 0.3, 0.3);
                    sl.sendParticles(BLACK, mid.x, mid.y, mid.z, 10, w * 0.3, h * 0.3, w * 0.3, 0.1);
                    sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0f, 0.7f + k * 0.015f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 3, 0.25f));
                }
                if (k == 34) {
                    sl.sendParticles(BLACK, mid.x, mid.y, mid.z, 140, 0.6, 0.6, 0.6, 0.3);
                    sl.sendParticles(RED, mid.x, mid.y, mid.z, 90, 0.7, 0.7, 0.7, 0.35);
                    sl.sendParticles(ParticleTypes.SONIC_BOOM, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
                    sl.playSound(null, t.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.6f, 0.5f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.BLACK_FLASH, 30, 1.0f));
                    Vec3 push = t.position().subtract(sp.position()).normalize();
                    kill(sp, t);
                    t.setDeltaMovement(push.x * 2.5, 0.6, push.z * 2.5);
                    t.hurtMarked = true;
                }
            }
            case RED_POINT_BLANK -> {   // a red point at the fingertip, then the target is blown away
                hold(sp, t, front(sp, gap, 0));
                Vec3 tip = front(sp, 0.7, sp.getBbHeight() * 0.8);
                if (k < 26) sl.sendParticles(GojoLogic.RED_DUST, tip.x, tip.y, tip.z, 4 + k / 3, 0.05 + k * 0.004, 0.05 + k * 0.004, 0.05 + k * 0.004, 0.0);
                if (k == 4) sl.playSound(null, sp.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2f, 1.6f);
                if (k == 26) {
                    sl.sendParticles(GojoLogic.RED_DUST, mid.x, mid.y, mid.z, 160, 0.8, 0.8, 0.8, 0.4);
                    sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
                    sl.playSound(null, t.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.8f, 0.7f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 14, 0.9f));
                    Vec3 push = t.position().subtract(sp.position()).normalize();
                    kill(sp, t);
                    t.setDeltaMovement(push.x * 3.5, 1.0, push.z * 3.5); t.hurtMarked = true;
                }
            }
            case BLUE_CRUSH -> {   // lifted into a Blue singularity and crushed
                hold(sp, t, front(sp, gap + 0.5, Mth.clamp(k / 10.0, 0, 1) * 1.4).add((sp.getRandom().nextDouble() - 0.5) * 0.06 * k / 10, 0, 0));
                sl.sendParticles(GojoLogic.BLUE_DUST, mid.x, mid.y, mid.z, 10, w * 0.6, h * 0.5, w * 0.6, 0.02);
                sl.sendParticles(ParticleTypes.PORTAL, mid.x, mid.y, mid.z, 10, 1.5, 1.5, 1.5, -0.8);
                if (k % 6 == 0 && k > 8 && k < 34) sl.playSound(null, t.blockPosition(), SoundEvents.SKELETON_HURT, SoundSource.PLAYERS, 0.7f, 0.5f);
                if (k == 34) {
                    sl.sendParticles(GojoLogic.BLUE_DUST, mid.x, mid.y, mid.z, 140, 0.2, 0.2, 0.2, 0.6);
                    sl.sendParticles(ModParticles.BLOOD.get(), mid.x, mid.y, mid.z, 90, 0.3, 0.3, 0.3, 0.3);
                    sl.playSound(null, t.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.2f, 1.5f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 10, 0.6f));
                    kill(sp, t);
                }
            }
            case PURPLE_ERASE -> {   // Red and Blue meet point blank: nothing is left
                hold(sp, t, front(sp, gap + 1.0, 0));
                Vec3 c = front(sp, 0.9, sp.getBbHeight() * 0.8);
                Vec3 side = new Vec3(Mth.cos(sp.getYRot() * Mth.DEG_TO_RAD), 0, Mth.sin(sp.getYRot() * Mth.DEG_TO_RAD));
                double spread = Math.max(0, 1.2 - k * 0.04);
                if (k < 30) {
                    Vec3 a = c.add(side.scale(spread)), b = c.add(side.scale(-spread));
                    sl.sendParticles(GojoLogic.RED_DUST, a.x, a.y, a.z, 6, 0.1, 0.1, 0.1, 0);
                    sl.sendParticles(GojoLogic.BLUE_DUST, b.x, b.y, b.z, 6, 0.1, 0.1, 0.1, 0);
                }
                if (k == 30) {
                    sl.playSound(null, sp.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.8f, 0.7f);
                    for (int i = 0; i < 8; i++) { Vec3 p = c.lerp(mid, i / 7.0); sl.sendParticles(GojoLogic.PURPLE_DUST, p.x, p.y, p.z, 20, 0.5, 0.5, 0.5, 0.05); }
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 10, 0.7f));
                    t.setInvisible(true);
                    kill(sp, t);
                }
            }
            case INFINITY_WALL -> {   // it lunges and never arrives; a flick of the finger ends it
                double d0 = gap + 2.5, dk = Mth.clamp(k / 24.0, 0, 1);
                hold(sp, t, front(sp, d0 - (d0 - gap * 0.7) * (1 - Math.pow(1 - dk, 3)), 0));
                if (k % 4 == 0 && k < 26) sl.sendParticles(ParticleTypes.END_ROD, mid.x, mid.y, mid.z, 3, w * 0.3, h * 0.3, w * 0.3, 0.01);
                if (k == 28) {
                    sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.6f, 1.4f);
                    sl.sendParticles(ParticleTypes.SONIC_BOOM, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
                    Vec3 push = t.position().subtract(sp.position()).normalize();
                    kill(sp, t);
                    t.setDeltaMovement(push.x * 4.0, 1.2, push.z * 4.0); t.hurtMarked = true;
                }
            }
            case GOJO_BLACK_FLASH -> {   // two jabs and a Black Flash
                hold(sp, t, front(sp, gap, 0));
                if (k == 6 || k == 14) {
                    sl.sendParticles(ParticleTypes.CRIT, mid.x, mid.y, mid.z, 14, w * 0.3, h * 0.3, w * 0.3, 0.3);
                    sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0f, 0.9f);
                }
                if (k == 26) {
                    sl.sendParticles(BLACK, mid.x, mid.y, mid.z, 140, 0.6, 0.6, 0.6, 0.3);
                    sl.sendParticles(GojoLogic.BLUE_DUST, mid.x, mid.y, mid.z, 60, 0.7, 0.7, 0.7, 0.35);
                    sl.sendParticles(ParticleTypes.SONIC_BOOM, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
                    sl.playSound(null, t.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.6f, 0.6f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.BLACK_FLASH, 30, 1.0f));
                    Vec3 push = t.position().subtract(sp.position()).normalize();
                    kill(sp, t);
                    t.setDeltaMovement(push.x * 2.5, 0.6, push.z * 2.5); t.hurtMarked = true;
                }
            }
            case VOID_PUNCH -> {   // a pocket of Infinite Void, then a fist straight through
                hold(sp, t, front(sp, gap, 0));
                if (k < 26 && k % 2 == 0) {
                    for (int i = 0; i < 8; i++) {
                        double a = sp.getRandom().nextDouble() * Math.PI * 2;
                        sl.sendParticles(i % 2 == 0 ? ParticleTypes.END_ROD : GojoLogic.VOID_DUST, mid.x + Math.cos(a) * 1.4, mid.y + (sp.getRandom().nextDouble() - 0.5) * 2, mid.z + Math.sin(a) * 1.4, 1, 0, 0, 0, 0);
                    }
                }
                if (k == 2) { sl.playSound(null, t.blockPosition(), ModSounds.DOMAIN_EXPANSION.get(), SoundSource.PLAYERS, 1.0f, 1.8f); ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 8, 0.5f)); }
                if (k == 30) {
                    sl.sendParticles(ModParticles.BLOOD.get(), mid.x, mid.y, mid.z, 100, 0.3, 0.3, 0.3, 0.35);
                    sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.6f, 0.5f);
                    ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 10, 0.7f));
                    kill(sp, t);
                }
            }
            default -> { }
        }
        if (r.t >= LENGTHS[r.kind] || !t.isAlive()) {
            if (!t.isAlive() || r.t >= LENGTHS[r.kind]) {
                if (t.isAlive()) kill(sp, t);   // safety net: a finisher always finishes
                end(sp, r, t);
                KocAdvancements.award(sp, "finisher");
            }
        }
    }

    public static void onLogout(UUID id) { RUNS.remove(id); LAST_HIT.remove(id); }
    public static void clear() { RUNS.clear(); LAST.clear(); LAST_HIT.clear(); }
}
