package com.kingofcurses.ability;

import com.kingofcurses.block.CursedSandBlock;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.RipAnimPacket;
import com.kingofcurses.registry.ModBlocks;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * v1.0.10: a vessel that dies crumbles to dust (third-person, from the feet up). The block under the body becomes
 * Cursed Sand holding all of the player's fingers; breaking it gives back a Ripped Finger worth exactly that many.
 */
public final class DustDeath {
    public static final int LENGTH = 22;
    private static final List<Dust> ACTIVE = new ArrayList<>();
    private DustDeath() {}

    private record Dust(ServerLevel level, Vec3 pos, int[] tick) {}

    /** @return true when the body turned to dust (the death mark is then already set on the sand). */
    public static boolean onDeath(ServerPlayer sp) {
        CursedData d = KocSync.data(sp);
        int n = d.fingers();
        if (n <= 0 || d.ending() != CursedData.ENDING_NONE) return false;
        BlockPos mark = sp.blockPosition();
        ServerLevel sl = sp.serverLevel();
        // find the ground under the body (up to 12 blocks down)
        BlockPos p = sp.blockPosition().below();
        for (int i = 0; i < 12 && !CursedSandBlock.canReplace(sl, p) && p.getY() > sl.getMinBuildHeight(); i++) p = p.below();
        BlockState sand = ModBlocks.CURSED_SAND.get().defaultBlockState().setValue(CursedSandBlock.POWER, Math.min(20, n));
        if (CursedSandBlock.canReplace(sl, p)) { sl.setBlockAndUpdate(p, sand); mark = p; }
        else {
            BlockPos at = sp.blockPosition();
            if (sl.getBlockState(at).canBeReplaced() && at.getY() > sl.getMinBuildHeight()) { sl.setBlockAndUpdate(at, sand); mark = at; }
            else sl.addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(sl, sp.getX(), sp.getY() + 0.5, sp.getZ(), com.kingofcurses.item.RippedFingerItem.withPower(n)));
        }
        d.setDeathMark(mark, sl.dimension().location().toString(), n);
        d.setFingerMask(0);
        d.setTakeoverTicks(0);
        d.setBossCountdown(0);
        d.setLostArms(0);
        KocSync.sync(sp);
        ModNetwork.sendToTrackingAndSelf(sp, new RipAnimPacket(sp.getId(), RipAnimPacket.DUST, 0));
        ACTIVE.add(new Dust(sl, sp.position(), new int[]{0}));
        sl.playSound(null, sp.blockPosition(), SoundEvents.SAND_BREAK, SoundSource.PLAYERS, 1.5f, 0.6f);
        sl.playSound(null, sp.blockPosition(), ModSounds.CURSED_ENERGY_BURST.get(), SoundSource.PLAYERS, 1.0f, 0.5f);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.dust_death", n).withStyle(ChatFormatting.DARK_RED), false);
        return true;
    }

    /** The body pours away as ash and cursed sand, from the feet up. */
    public static void tick(MinecraftServer server) {
        Iterator<Dust> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Dust d = it.next();
            int t = ++d.tick()[0];
            double h = 0.2 + 1.7 * Math.min(1.0, t / (double) LENGTH);
            Vec3 c = d.pos();
            BlockParticleOption grains = new BlockParticleOption(ParticleTypes.FALLING_DUST, ModBlocks.CURSED_SAND.get().defaultBlockState());
            d.level().sendParticles(grains, c.x, c.y + h, c.z, 14, 0.25, 0.15, 0.25, 0);
            d.level().sendParticles(ParticleTypes.ASH, c.x, c.y + h, c.z, 10, 0.3, 0.2, 0.3, 0.02);
            if (t % 3 == 0) d.level().sendParticles(ModParticles.CURSED_ENERGY.get(), c.x, c.y + h, c.z, 6, 0.25, 0.2, 0.25, 0.04);
            if (t >= LENGTH + 6) it.remove();
        }
    }

    public static void clear() { ACTIVE.clear(); }

    static ItemStack unused() { return ItemStack.EMPTY; }
}
