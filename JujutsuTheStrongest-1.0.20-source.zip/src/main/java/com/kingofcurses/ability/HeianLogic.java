package com.kingofcurses.ability;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.block.HeianPortalBlock;
import com.kingofcurses.common.KocWorldData;
import com.kingofcurses.entity.HeianSukunaEntity;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModBlocks;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** v1.0.17 the Heian Era: portals, the throne arena and the first-arrival "video". */
public final class HeianLogic {
    public static final ResourceKey<Level> HEIAN = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(KingOfCurses.MODID, "heian_era"));
    public static final int INTRO_LENGTH = 340;
    private static final String RETURN = "kingofcurses_heian_return";
    private static final String SEEN = "kingofcurses_heian_seen";
    private static final String INTRO_AT = "kingofcurses_heian_intro_at";
    private static final Map<UUID, long[]> PORTAL = new HashMap<>();   // lastTick, insideTicks, cooldownUntil

    private HeianLogic() {}

    // ------------------------------------------------------------------ gate
    /** Torii with a 3x4 portal. {@code base} = bottom centre of the opening, {@code axis} = direction the opening spans. */
    public static void buildGate(ServerLevel sl, BlockPos base, Direction.Axis axis) {
        Direction along = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
        BlockState pillar = ModBlocks.TORII_PILLAR.get().defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y);
        BlockState beam = ModBlocks.TORII_BEAM.get().defaultBlockState();
        BlockState roof = ModBlocks.SHRINE_ROOF_TILES.get().defaultBlockState();
        BlockState portal = ModBlocks.HEIAN_PORTAL.get().defaultBlockState().setValue(HeianPortalBlock.AXIS, axis);
        for (int o = -4; o <= 4; o++) for (int y = 0; y <= 6; y++) safeSet(sl, base.relative(along, o).above(y), Blocks.AIR.defaultBlockState());
        for (int o = -3; o <= 3; o++) { BlockPos g = base.relative(along, o).below(); if (sl.getBlockState(g).canBeReplaced()) safeSet(sl, g, ModBlocks.TEMPLE_STONE_BRICKS.get().defaultBlockState()); }
        for (int y = 0; y <= 4; y++) { safeSet(sl, base.relative(along, -2).above(y), pillar); safeSet(sl, base.relative(along, 2).above(y), pillar); }
        for (int o = -1; o <= 1; o++) safeSet(sl, base.relative(along, o).above(4), beam);            // nuki
        for (int o = -3; o <= 3; o++) safeSet(sl, base.relative(along, o).above(5), beam);            // kasagi
        for (int o = -4; o <= 4; o++) safeSet(sl, base.relative(along, o).above(6), roof);
        for (int o = -1; o <= 1; o++) for (int y = 0; y <= 3; y++) safeSet(sl, base.relative(along, o).above(y), portal);
        safeSet(sl, base.relative(along, -3), ModBlocks.SHRINE_LANTERN.get().defaultBlockState());
        safeSet(sl, base.relative(along, 3), ModBlocks.SHRINE_LANTERN.get().defaultBlockState());
        sl.playSound(null, base, SoundEvents.END_PORTAL_SPAWN, SoundSource.BLOCKS, 1.0f, 1.2f);
    }

    private static void safeSet(ServerLevel sl, BlockPos p, BlockState s) {
        if (sl.isOutsideBuildHeight(p) || sl.getBlockState(p).is(Blocks.BEDROCK)) return;
        sl.setBlock(p, s, 2 | 16);
    }

    // ------------------------------------------------------------------ travel
    public static void inPortal(ServerPlayer sp, BlockPos pos, Direction.Axis axis) {
        long now = sp.serverLevel().getGameTime();
        long[] st = PORTAL.computeIfAbsent(sp.getUUID(), k -> new long[]{0, 0, 0});
        if (now < st[2]) return;
        if (st[0] == now) return;                     // several portal blocks, once per tick
        st[1] = st[0] == now - 1 ? st[1] + 1 : 1;
        st[0] = now;
        int need = sp.getAbilities().instabuild ? 10 : 40;
        if (st[1] == 1) sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0, true, false, false));
        if (st[1] >= need) {
            st[1] = 0;
            st[2] = now + 100;
            travel(sp, pos, axis);
        }
    }

    private static void travel(ServerPlayer sp, BlockPos portalPos, Direction.Axis axis) {
        var server = sp.getServer();
        if (server == null) return;
        if (sp.serverLevel().dimension() == HEIAN) {
            CompoundTag r = sp.getPersistentData().getCompound(RETURN);
            ServerLevel back = null;
            if (r.contains("Dim")) back = server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(r.getString("Dim"))));
            if (back == null) {
                back = server.overworld();
                BlockPos s = back.getSharedSpawnPos();
                sp.teleportTo(back, s.getX() + 0.5, s.getY(), s.getZ() + 0.5, sp.getYRot(), 0);
            } else sp.teleportTo(back, r.getDouble("X"), r.getDouble("Y"), r.getDouble("Z"), r.getFloat("Yaw"), 0);
            sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.4f, 1.4f);
            return;
        }
        ServerLevel heian = server.getLevel(HEIAN);
        if (heian == null) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.heian_missing").withStyle(ChatFormatting.RED), false);
            return;
        }
        // remember where to come back: two blocks in front of the gate, on the side we came from
        Vec3 off = axis == Direction.Axis.X ? new Vec3(0, 0, Math.signum(sp.getZ() - (portalPos.getZ() + 0.5)) * 2.2) : new Vec3(Math.signum(sp.getX() - (portalPos.getX() + 0.5)) * 2.2, 0, 0);
        if (off.lengthSqr() < 0.01) off = axis == Direction.Axis.X ? new Vec3(0, 0, 2.2) : new Vec3(2.2, 0, 0);
        CompoundTag r = new CompoundTag();
        r.putString("Dim", sp.serverLevel().dimension().location().toString());
        r.putDouble("X", portalPos.getX() + 0.5 + off.x); r.putDouble("Y", sp.getY()); r.putDouble("Z", portalPos.getZ() + 0.5 + off.z);
        r.putFloat("Yaw", sp.getYRot() + 180f);
        sp.getPersistentData().put(RETURN, r);
        int y = ensureArena(heian);
        sp.teleportTo(heian, 0.5, y + 1, 7.5, 180f, 0f);
        heian.playSound(null, sp.blockPosition(), SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.4f, 0.8f);
        if (!sp.getPersistentData().getBoolean(SEEN)) {
            sp.getPersistentData().putBoolean(SEEN, true);
            sp.getPersistentData().putLong(INTRO_AT, heian.getGameTime() + 30);   // let the chunks arrive first
            sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, INTRO_LENGTH + 80, 4, true, false, false));
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.LOADING, 30, 0f));
        } else {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.heian_welcome_back").withStyle(ChatFormatting.GOLD), true);
        }
    }

    /** Per player tick: starts the arrival video once the world is there. */
    public static void tick(ServerPlayer sp) {
        long at = sp.getPersistentData().getLong(INTRO_AT);
        if (at == 0 || sp.serverLevel().dimension() != HEIAN) return;
        if (sp.serverLevel().getGameTime() < at) return;
        sp.getPersistentData().remove(INTRO_AT);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.HEIAN_INTRO, INTRO_LENGTH, 0f));
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, INTRO_LENGTH, 10, true, false, false));
    }

    public static void replayIntro(ServerPlayer sp) {
        if (sp.serverLevel().dimension() != HEIAN) return;
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.HEIAN_INTRO, INTRO_LENGTH, 0f));
    }

    // ------------------------------------------------------------------ arena
    /** Builds Sukuna's throne at the centre of the Heian Era once per world. Returns the floor Y. */
    public static int ensureArena(ServerLevel sl) {
        KocWorldData wd = KocWorldData.get(sl.getServer());
        if (wd.heianBuilt()) return wd.heianY();
        for (int cx = -2; cx <= 1; cx++) for (int cz = -2; cz <= 1; cz++) sl.getChunk(cx, cz);
        int y0 = Math.max(64, sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, 0, 0) - 1);
        BlockState floor = ModBlocks.POLISHED_TEMPLE_STONE.get().defaultBlockState();
        BlockState ring = ModBlocks.TEMPLE_STONE_BRICKS.get().defaultBlockState();
        BlockState base = ModBlocks.TEMPLE_STONE.get().defaultBlockState();
        BlockState gold = Blocks.GOLD_BLOCK.defaultBlockState();
        BlockState bones = ModBlocks.CURSED_BONE_PILE.get().defaultBlockState();
        BlockState tatami = ModBlocks.CRIMSON_TATAMI.get().defaultBlockState();
        int R = 18;
        for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) {
            double d = Math.sqrt(x * x + z * z);
            if (d > R + 0.5) continue;
            for (int y = 1; y <= 18; y++) safeSet(sl, new BlockPos(x, y0 + y, z), Blocks.AIR.defaultBlockState());
            safeSet(sl, new BlockPos(x, y0, z), d > R - 1.5 ? ring : floor);
            for (int y = 1; y <= 14; y++) {           // support under the platform
                BlockPos p = new BlockPos(x, y0 - y, z);
                BlockState s = sl.getBlockState(p);
                if (!s.isAir() && s.getFluidState().isEmpty()) break;
                safeSet(sl, p, base);
            }
        }
        for (int z = -8; z <= 16; z++) { safeSet(sl, new BlockPos(0, y0, z), gold); safeSet(sl, new BlockPos(-1, y0, z), tatami); safeSet(sl, new BlockPos(1, y0, z), tatami); }
        // dais
        for (int x = -5; x <= 5; x++) for (int z = -16; z <= -8; z++) safeSet(sl, new BlockPos(x, y0 + 1, z), ring);
        for (int x = -4; x <= 4; x++) for (int z = -15; z <= -9; z++) safeSet(sl, new BlockPos(x, y0 + 1, z), x == 0 ? gold : floor);
        // throne of bones and gold
        for (int x = -2; x <= 2; x++) for (int z = -14; z <= -12; z++) safeSet(sl, new BlockPos(x, y0 + 2, z), bones);
        for (int x = -3; x <= 3; x++) for (int y = 2; y <= 10 - Math.abs(x); y++) safeSet(sl, new BlockPos(x, y0 + y, -15), (x + y) % 3 == 0 ? gold : bones);
        for (int s : new int[]{-3, 3}) for (int z = -14; z <= -10; z++) { safeSet(sl, new BlockPos(s, y0 + 2, z), bones); safeSet(sl, new BlockPos(s, y0 + 3, z), gold); }
        for (int x = -3; x <= 3; x += 2) safeSet(sl, new BlockPos(x, y0 + 11 - Math.abs(x), -15), Blocks.SKELETON_SKULL.defaultBlockState());
        // pillars with lanterns
        BlockState pillar = ModBlocks.TORII_PILLAR.get().defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4 + Math.PI / 8;
            int px = (int) Math.round(Math.cos(a) * 14), pz = (int) Math.round(Math.sin(a) * 14);
            for (int y = 1; y <= 5; y++) safeSet(sl, new BlockPos(px, y0 + y, pz), pillar);
            safeSet(sl, new BlockPos(px, y0 + 6, pz), ModBlocks.SHRINE_LANTERN.get().defaultBlockState());
        }
        // way home
        buildGate(sl, new BlockPos(0, y0 + 1, 15), Direction.Axis.X);
        // the King of Curses
        HeianSukunaEntity sukuna = ModEntities.HEIAN_SUKUNA.get().create(sl);
        if (sukuna != null) {
            sukuna.moveTo(0.5, y0 + 2, -11.5, 0f, 0f);
            sukuna.setThrone(new BlockPos(0, y0 + 2, -12));
            sl.addFreshEntity(sukuna);
        }
        wd.setHeian(y0);
        return y0;
    }

    public static void onLogout(UUID id) { PORTAL.remove(id); }
}
