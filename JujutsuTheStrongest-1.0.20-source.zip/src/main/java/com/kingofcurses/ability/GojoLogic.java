package com.kingofcurses.ability;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModItems;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** v1.0.18 Strongest of Today: Gojo Satoru's techniques, Infinity and Infinite Void. */
@Mod.EventBusSubscriber(modid = KingOfCurses.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class GojoLogic {
    public static final DustParticleOptions BLUE_DUST = new DustParticleOptions(new Vector3f(0.2f, 0.5f, 1.0f), 1.6f);
    public static final DustParticleOptions RED_DUST = new DustParticleOptions(new Vector3f(1.0f, 0.12f, 0.12f), 1.6f);
    public static final DustParticleOptions PURPLE_DUST = new DustParticleOptions(new Vector3f(0.65f, 0.25f, 1.0f), 2.6f);
    public static final DustParticleOptions VOID_DUST = new DustParticleOptions(new Vector3f(0.05f, 0.05f, 0.12f), 2.0f);
    private static final List<Effect> ACTIVE = new ArrayList<>();
    /** True while Gojo's own techniques deal damage. */
    public static boolean dealing = false;

    private GojoLogic() {}

    private static final class Effect {
        final int kind; final ServerLevel level; final UUID owner; Vec3 pos; final Vec3 dir; final float power; int t;
        Effect(int kind, ServerLevel level, UUID owner, Vec3 pos, Vec3 dir, float power) { this.kind = kind; this.level = level; this.owner = owner; this.pos = pos; this.dir = dir; this.power = power; }
    }
    private static final int BLUE_ORB = 0, PURPLE_CHARGE = 1, PURPLE_BEAM = 2, VOID = 3;

    // ------------------------------------------------------------------ techniques
    public static boolean perform(ServerPlayer sp, CursedData d, Ability a, float mult) {
        ServerLevel sl = sp.serverLevel();
        switch (a) {
            case BLUE -> {
                Vec3 p = aimPoint(sp, 14);
                ACTIVE.add(new Effect(BLUE_ORB, sl, sp.getUUID(), p, Vec3.ZERO, mult));
                sl.playSound(null, BlockPos.containing(p), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2f, 1.8f);
                return true;
            }
            case RED -> {
                Vec3 look = sp.getLookAngle();
                Vec3 c = sp.getEyePosition().add(look.scale(3));
                sl.sendParticles(RED_DUST, c.x, c.y, c.z, 120, 1.2, 1.2, 1.2, 0.4);
                sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
                sl.playSound(null, BlockPos.containing(c), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.6f, 0.8f);
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(5), e -> e != sp && e.isAlive())) {
                    hurt(sp, e, 14f * mult);
                    Vec3 push = e.position().subtract(sp.position()).normalize();
                    e.setDeltaMovement(push.x * 3.0, 0.8, push.z * 3.0);
                    e.hurtMarked = true;
                }
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 8, 0.6f));
                return true;
            }
            case HOLLOW_PURPLE -> {
                ACTIVE.add(new Effect(PURPLE_CHARGE, sl, sp.getUUID(), sp.getEyePosition(), sp.getLookAngle(), mult));
                sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 24, 5, true, false, false));
                sp.displayClientMessage(Component.translatable("message.kingofcurses.purple_chant").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.ITALIC), true);
                return true;
            }
            case INFINITY -> {
                d.setInfinity(!d.infinity());
                sp.displayClientMessage(Component.translatable(d.infinity() ? "message.kingofcurses.infinity_on" : "message.kingofcurses.infinity_off").withStyle(ChatFormatting.AQUA), true);
                sl.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.5f, d.infinity() ? 1.6f : 0.8f);
                return true;
            }
            case BLINK -> {
                Vec3 from = sp.getEyePosition();
                Vec3 to = from.add(sp.getLookAngle().scale(12));
                BlockHitResult hit = sl.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
                Vec3 dest = hit.getType() == HitResult.Type.MISS ? to : hit.getLocation().subtract(sp.getLookAngle().scale(0.8));
                sl.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1, sp.getZ(), 20, 0.3, 0.6, 0.3, 0.05);
                sp.teleportTo(dest.x, dest.y - sp.getEyeHeight() + 0.2, dest.z);
                sp.fallDistance = 0;
                sl.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1, sp.getZ(), 20, 0.3, 0.6, 0.3, 0.05);
                sl.playSound(null, sp.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8f, 1.6f);
                return true;
            }
            case INFINITE_VOID -> {
                ACTIVE.add(new Effect(VOID, sl, sp.getUUID(), sp.position(), Vec3.ZERO, mult));
                sl.playSound(null, sp.blockPosition(), ModSounds.DOMAIN_EXPANSION.get(), SoundSource.PLAYERS, 2.0f, 1.4f);
                sp.displayClientMessage(Component.translatable("message.kingofcurses.infinite_void").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
                ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 20, 1.0f));
                KocAdvancements.award(sp, "infinite_void");
                return true;
            }
            default -> { return false; }
        }
    }

    private static Vec3 aimPoint(ServerPlayer sp, double range) {
        Vec3 from = sp.getEyePosition(), to = from.add(sp.getLookAngle().scale(range));
        LivingEntity t = AbilityLogic.lookTarget(sp, range);
        if (t != null) return t.position().add(0, t.getBbHeight() / 2, 0);
        BlockHitResult hit = sp.serverLevel().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, sp));
        return hit.getType() == HitResult.Type.MISS ? to : hit.getLocation();
    }

    private static void hurt(ServerPlayer sp, LivingEntity e, float dmg) {
        dealing = true;
        try { e.invulnerableTime = 0; e.hurt(sp.damageSources().playerAttack(sp), dmg); } finally { dealing = false; }
    }

    // ------------------------------------------------------------------ ticking effects
    public static void tick(MinecraftServer server) {
        Iterator<Effect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Effect e = it.next();
            ServerPlayer sp = server.getPlayerList().getPlayer(e.owner);
            if (sp == null || sp.level() != e.level) { it.remove(); continue; }
            e.t++;
            boolean done = switch (e.kind) {
                case BLUE_ORB -> blue(sp, e);
                case PURPLE_CHARGE -> purpleCharge(sp, e);
                case PURPLE_BEAM -> purpleBeam(sp, e);
                case VOID -> infiniteVoid(sp, e);
                default -> true;
            };
            if (done) it.remove();
        }
    }

    private static boolean blue(ServerPlayer sp, Effect e) {
        ServerLevel sl = e.level;
        sl.sendParticles(BLUE_DUST, e.pos.x, e.pos.y, e.pos.z, 30, 0.4, 0.4, 0.4, 0.02);
        sl.sendParticles(ParticleTypes.PORTAL, e.pos.x, e.pos.y, e.pos.z, 20, 2.5, 2.5, 2.5, -1.0);
        for (LivingEntity v : sl.getEntitiesOfClass(LivingEntity.class, new AABB(e.pos, e.pos).inflate(7), v -> v != sp && v.isAlive())) {
            Vec3 pull = e.pos.subtract(v.position().add(0, v.getBbHeight() / 2, 0));
            double dist = pull.length();
            if (dist > 0.6) v.setDeltaMovement(pull.normalize().scale(Math.min(1.2, 0.35 + dist * 0.12)));
            else v.setDeltaMovement(Vec3.ZERO);
            v.hurtMarked = true;
            if (e.t % 5 == 0) hurt(sp, v, 2.5f * e.power);
        }
        if (e.t == 30) {
            sl.sendParticles(ParticleTypes.EXPLOSION, e.pos.x, e.pos.y, e.pos.z, 4, 0.5, 0.5, 0.5, 0);
            sl.playSound(null, BlockPos.containing(e.pos), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.0f, 1.6f);
            for (LivingEntity v : sl.getEntitiesOfClass(LivingEntity.class, new AABB(e.pos, e.pos).inflate(2.5), v -> v != sp && v.isAlive())) hurt(sp, v, 10f * e.power);
        }
        return e.t >= 30;
    }

    private static boolean purpleCharge(ServerPlayer sp, Effect e) {
        ServerLevel sl = e.level;
        Vec3 look = sp.getLookAngle();
        Vec3 right = new Vec3(-look.z, 0, look.x).normalize();
        Vec3 c = sp.getEyePosition().add(look.scale(1.6));
        double spread = Math.max(0, 1.6 - e.t * 0.08);
        Vec3 r = c.add(right.scale(-spread)), b = c.add(right.scale(spread));
        sl.sendParticles(RED_DUST, r.x, r.y, r.z, 12, 0.15, 0.15, 0.15, 0.01);
        sl.sendParticles(BLUE_DUST, b.x, b.y, b.z, 12, 0.15, 0.15, 0.15, 0.01);
        if (e.t == 2) sl.playSound(null, sp.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.5f, 0.6f);
        if (e.t >= 20) {
            sl.sendParticles(PURPLE_DUST, c.x, c.y, c.z, 80, 0.4, 0.4, 0.4, 0.1);
            sl.playSound(null, sp.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 2.0f, 0.6f);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 10, 0.6f));
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 16, 1.0f));
            ACTIVE.add(new Effect(PURPLE_BEAM, sl, sp.getUUID(), c, look, e.power));
            return true;
        }
        return false;
    }

    /** The beam travels 3 blocks per tick for 18 ticks, erasing what it touches. */
    private static boolean purpleBeam(ServerPlayer sp, Effect e) {
        ServerLevel sl = e.level;
        boolean grief = sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
        for (int s = 0; s < 3; s++) {
            e.pos = e.pos.add(e.dir);
            sl.sendParticles(PURPLE_DUST, e.pos.x, e.pos.y, e.pos.z, 14, 0.9, 0.9, 0.9, 0.02);
            if (s == 0) sl.sendParticles(ParticleTypes.END_ROD, e.pos.x, e.pos.y, e.pos.z, 6, 0.8, 0.8, 0.8, 0.05);
            for (LivingEntity v : sl.getEntitiesOfClass(LivingEntity.class, new AABB(e.pos, e.pos).inflate(2.3), v -> v != sp && v.isAlive())) {
                hurt(sp, v, 70f * e.power);
                if (v.isAlive() && !FinisherLogic.isSorcererOrBoss(v)) v.kill();
            }
            if (grief) {
                BlockPos c = BlockPos.containing(e.pos);
                for (BlockPos p : BlockPos.betweenClosed(c.offset(-2, -2, -2), c.offset(2, 2, 2))) {
                    if (p.distToCenterSqr(e.pos) > 3.2) continue;
                    BlockState st = sl.getBlockState(p);
                    if (st.isAir() || st.getDestroySpeed(sl, p) < 0) continue;
                    sl.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                }
            }
        }
        return e.t >= 18;
    }

    private static boolean infiniteVoid(ServerPlayer sp, Effect e) {
        ServerLevel sl = e.level;
        double R = 14;
        if (e.t % 2 == 0) {
            for (int i = 0; i < 40; i++) {
                double a = sl.random.nextDouble() * Math.PI * 2, b = Math.acos(2 * sl.random.nextDouble() - 1);
                double x = e.pos.x + R * Math.sin(b) * Math.cos(a), y = e.pos.y + R * Math.cos(b), z = e.pos.z + R * Math.sin(b) * Math.sin(a);
                sl.sendParticles(i % 3 == 0 ? ParticleTypes.END_ROD : VOID_DUST, x, y, z, 1, 0, 0, 0, 0);
            }
        }
        for (LivingEntity v : sl.getEntitiesOfClass(LivingEntity.class, new AABB(e.pos, e.pos).inflate(R), v -> v != sp && v.isAlive() && v.distanceToSqr(e.pos) < R * R)) {
            v.setDeltaMovement(Vec3.ZERO);
            v.hurtMarked = true;
            v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 10, true, false, false));
            v.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 4, true, false, false));
            v.addEffect(new MobEffectInstance(ModEffects.SEALED.get(), 10, 0, true, false, false));
            if (v instanceof Mob m) m.setTarget(null);
            if (v instanceof ServerPlayer op && e.t % 20 == 1) {
                op.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 60, 0, true, false, false));
                ModNetwork.sendTo(op, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 14, 0.8f));
            }
            if (e.t % 20 == 0) sl.sendParticles(ParticleTypes.END_ROD, v.getX(), v.getY() + v.getBbHeight(), v.getZ(), 6, 0.3, 0.3, 0.3, 0.02);
        }
        return e.t >= 200;
    }

    // ------------------------------------------------------------------ Infinity
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void attacked(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;
        CursedData d = KocSync.data(sp);
        if (!d.isGojo() || !d.infinity()) return;
        DamageSource src = event.getSource();
        if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || src.is(DamageTypeTags.IS_FALL) || src.is(DamageTypeTags.IS_DROWNING) || src.is(DamageTypeTags.BYPASSES_ARMOR) && src.getEntity() == null) return;
        Entity attacker = src.getEntity();
        if (attacker == null && src.getDirectEntity() == null && !src.is(DamageTypeTags.IS_EXPLOSION) && !src.is(DamageTypeTags.IS_PROJECTILE)) return;
        if (attacker instanceof LivingEntity le && le.getMainHandItem().is(ModItems.INVERTED_SPEAR_OF_HEAVEN.get())) return;   // nullified
        if (attacker != null && attacker.getPersistentData().getBoolean("kingofcurses_in_domain")) return;
        if (attacker != null && attacker.getPersistentData().getBoolean(SukunaBossFight.BOSS_TAG) && sp.getRandom().nextFloat() < 0.35f) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.infinity_cut").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
            return;   // the World Cutting Slash cuts space itself
        }
        float cost = event.getAmount() * 1.5f;
        if (d.energy() < cost) return;
        d.addEnergy(-cost);
        event.setCanceled(true);
        ServerLevel sl = sp.serverLevel();
        Vec3 at = src.getDirectEntity() != null ? src.getDirectEntity().position().add(0, 1, 0) : sp.position().add(0, 1, 0);
        sl.sendParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 4, 0.2, 0.2, 0.2, 0.0);
        if (sp.tickCount % 6 == 0) sl.playSound(null, sp.blockPosition(), SoundEvents.AMETHYST_BLOCK_HIT, SoundSource.PLAYERS, 0.6f, 1.8f);
        if (src.getDirectEntity() instanceof net.minecraft.world.entity.projectile.Projectile pr) { pr.setDeltaMovement(Vec3.ZERO); pr.setNoGravity(false); }
    }

    public static void clear() { ACTIVE.clear(); }
}
