package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedCapability;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.GojoKenjakuEntity;
import com.kingofcurses.entity.NamedSorcererEntity;
import com.kingofcurses.entity.SorcererEntity;
import com.kingofcurses.entity.SukunaEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

/** v1.0.8: who the jujutsu sorcerers (and Gojo/Yuta) fight: anything carrying Sukuna, and hostile mobs. Never ordinary players. */
public final class KocTargets {
    private KocTargets() {}

    public static boolean hasSukuna(LivingEntity e) {
        if (e instanceof Player p) {
            if (p.isCreative() || p.isSpectator()) return false;
            CursedData d = CursedCapability.get(p).orElse(null);
            return d != null && (d.fingers() > 0 || d.ending() == CursedData.ENDING_EMBRACE);
        }
        if (e instanceof SukunaEntity s) return !s.isCinematic();
        return VesselLogic.power(e) > 0;
    }

    public static boolean isFoe(LivingEntity e) {
        if (e == null || !e.isAlive()) return false;
        if (hasSukuna(e)) return true;
        if (e instanceof Player) return false;
        if (e instanceof GojoKenjakuEntity || e instanceof NamedSorcererEntity || e instanceof SorcererEntity) return false;
        return e instanceof Enemy;
    }
}
