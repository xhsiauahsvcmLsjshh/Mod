package com.kingofcurses.ability;

import com.kingofcurses.KocConfig;
import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.DismantleSlashEntity;
import com.kingofcurses.entity.FugaArrowEntity;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEffects;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Server-side execution of every cursed technique. Clients only send requests. */
public final class AbilityLogic {
    private AbilityLogic() {}

    public static void select(ServerPlayer sp, int index) {
        CursedData d = KocSync.data(sp);
        Ability a = Ability.byIndex(index);
        if (Ability.forData(d).contains(a)) { d.setSelected(a.ordinal()); KocSync.sync(sp); }
    }

    public static void cycle(ServerPlayer sp) {
        CursedData d = KocSync.data(sp);
        List<Ability> list = Ability.forData(d);
        if (list.isEmpty()) { sp.displayClientMessage(Component.translatable("message.kingofcurses.no_ability").withStyle(ChatFormatting.DARK_RED), true); return; }
        int cur = list.indexOf(Ability.byIndex(d.selected()));
        Ability next = list.get((cur + 1) % list.size());
        d.setSelected(next.ordinal());
        sp.displayClientMessage(next.displayName().copy().withStyle(ChatFormatting.RED), true);
        KocSync.sync(sp);
    }

    public static void useSelected(ServerPlayer sp) {
        CursedData d = KocSync.data(sp);
        if (d.lostArms() != 0 && !CinematicDirector.isInScene(sp.getUUID())) { ArmLogic.regenerate(sp, d); return; }
        List<Ability> list = Ability.forData(d);
        if (list.isEmpty()) { sp.displayClientMessage(Component.translatable("message.kingofcurses.no_ability").withStyle(ChatFormatting.DARK_RED), true); return; }
        Ability a = Ability.byIndex(d.selected());
        if (!list.contains(a)) a = list.get(0);
        tryUse(sp, a);
    }

    public static boolean tryUse(ServerPlayer sp, Ability a) {
        CursedData d = KocSync.data(sp);
        if (CinematicDirector.isInScene(sp.getUUID()) || GojoIntroDirector.isInScene(sp.getUUID()) || d.takeoverTicks() > 0 || FirstTakeover.active(sp.getUUID())) return false;
        if (d.lostArms() != 0) return ArmLogic.regenerate(sp, d);
        if (sp.hasEffect(ModEffects.SEALED.get())) { msg(sp, Component.translatable("message.kingofcurses.sealed")); return false; }
        boolean rejected = d.ending() == CursedData.ENDING_REJECT;
        if (!Ability.forData(d).contains(a) || (a == Ability.DOMAIN_EXPANSION && rejected)) {
            msg(sp, Component.translatable("message.kingofcurses.ability_locked", a.displayName())); return false;
        }
        if (d.cooldown(a) > 0) {
            msg(sp, Component.translatable("message.kingofcurses.on_cooldown", a.displayName(), (d.cooldown(a) + 19) / 20)); return false;
        }
        float cost = a.isDomain() ? d.maxEnergy() * 0.8f : a.cost;
        if (d.isGojo() && !a.isDomain()) cost *= 0.5f;   // Six Eyes: perfect cursed energy efficiency
        if (sp.isCreative()) cost = 0;
        if (d.energy() < cost) { msg(sp, Component.translatable("message.kingofcurses.not_enough_energy")); return false; }
        boolean ok = perform(sp, d, a, false);
        if (ok) {
            d.addEnergy(-cost);
            d.setCooldown(a, a.cooldown);
            sp.swing(InteractionHand.MAIN_HAND, true);
            ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.ARM_CAST, 12, a.ordinal()));
            KocSync.sync(sp);
        }
        return ok;
    }

    private static void msg(ServerPlayer sp, Component c) {
        sp.displayClientMessage(c.copy().withStyle(ChatFormatting.DARK_RED), true);
    }

    /** @param forced true when Sukuna himself acts during a takeover. */
    public static boolean perform(ServerPlayer sp, CursedData d, Ability a, boolean forced) {
        ServerLevel level = sp.serverLevel();
        float mult = d.powerMultiplier() * (forced ? 1.2f : 1.0f);
        int f = d.effectiveFingers();
        switch (a) {
            case DISMANTLE -> {
                DismantleSlashEntity slash = new DismantleSlashEntity(level, sp, (5.0f + f * 0.6f) * mult, 2 + f / 6);
                slash.shootFromRotation(sp, sp.getXRot(), sp.getYRot(), 0.0f, 2.8f, 0.0f);
                level.addFreshEntity(slash);
                level.playSound(null, sp.blockPosition(), ModSounds.DISMANTLE.get(), SoundSource.PLAYERS, 1.0f, 0.9f + sp.getRandom().nextFloat() * 0.2f);
                return true;
            }
            case CLEAVE -> {
                LivingEntity target = lookTarget(sp, 8.0);
                if (target == null) return false;
                float size = target.getBbWidth() * target.getBbHeight();
                float dmg = (6.0f + f * 0.5f) * mult + target.getMaxHealth() * 0.12f + size * 2.0f;
                SliceLogic.mark(target);
                target.hurt(sp.damageSources().playerAttack(sp), dmg);
                Vec3 c = target.position().add(0, target.getBbHeight() / 2, 0);
                level.sendParticles(ModParticles.SLASH.get(), c.x, c.y, c.z, 6, target.getBbWidth() / 2, target.getBbHeight() / 3, target.getBbWidth() / 2, 0.0);
                level.sendParticles(ModParticles.BLOOD.get(), c.x, c.y, c.z, 30, 0.3, 0.4, 0.3, 0.2);
                level.playSound(null, target.blockPosition(), ModSounds.CLEAVE.get(), SoundSource.PLAYERS, 1.2f, 1.0f);
                return true;
            }
            case REVERSE_CURSED_TECHNIQUE -> {
                sp.heal(6.0f + f * 0.6f);
                List<MobEffectInstance> effects = new ArrayList<>(sp.getActiveEffects());
                for (MobEffectInstance e : effects) {
                    if (e.getEffect().getCategory() == MobEffectCategory.HARMFUL && e.getEffect() != ModEffects.SEALED.get()) sp.removeEffect(e.getEffect());
                }
                sp.clearFire();
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, sp.getX(), sp.getY() + 1, sp.getZ(), 25, 0.5, 0.8, 0.5, 0.05);
                level.sendParticles(ModParticles.CURSED_ENERGY.get(), sp.getX(), sp.getY() + 1, sp.getZ(), 20, 0.5, 0.8, 0.5, 0.02);
                level.playSound(null, sp.blockPosition(), ModSounds.RCT_HEAL.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
                return true;
            }
            case SPIDERWEB -> {
                double r = 4.5 + f * 0.15;
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(r, 2, r), e -> e != sp && e.isAlive())) {
                    if (e.distanceToSqr(sp) > r * r) continue;
                    SliceLogic.mark(e);
                    e.hurt(sp.damageSources().playerAttack(sp), (5.0f + f * 0.4f) * mult);
                    e.setDeltaMovement(e.getDeltaMovement().add(0, 0.45, 0));
                    e.hurtMarked = true;
                }
                for (int i = 0; i < 48; i++) {
                    double ang = i / 48.0 * Math.PI * 2;
                    for (double k = 1; k <= r; k += 1.5) {
                        level.sendParticles(ModParticles.SLASH.get(), sp.getX() + Math.cos(ang) * k, sp.getY() + 0.1, sp.getZ() + Math.sin(ang) * k, 1, 0, 0, 0, 0);
                    }
                }
                level.playSound(null, sp.blockPosition(), ModSounds.CLEAVE.get(), SoundSource.PLAYERS, 1.4f, 0.7f);
                return true;
            }
            case FUGA -> {
                FugaArrowEntity arrow = new FugaArrowEntity(level, sp, (14.0f + f * 0.8f) * mult);
                arrow.shootFromRotation(sp, sp.getXRot(), sp.getYRot(), 0.0f, 2.2f, 0.0f);
                level.addFreshEntity(arrow);
                level.playSound(null, sp.blockPosition(), ModSounds.FUGA_IGNITE.get(), SoundSource.PLAYERS, 1.5f, 1.0f);
                level.sendParticles(ParticleTypes.FLAME, sp.getX(), sp.getEyeY(), sp.getZ(), 30, 0.4, 0.4, 0.4, 0.05);
                return true;
            }
            case WORLD_SLASH -> {
                worldSlash(sp, level, (24.0f + f) * mult);
                return true;
            }
            case DOMAIN_EXPANSION -> {
                return DomainManager.open(sp, d);
            }
            case BLUE, RED, HOLLOW_PURPLE, INFINITY, BLINK, INFINITE_VOID -> {
                return GojoLogic.perform(sp, d, a, mult);
            }
            default -> { return false; }
        }
    }

    private static void worldSlash(ServerPlayer sp, ServerLevel level, float damage) {
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getViewVector(1.0f);
        Set<Integer> hit = new HashSet<>();
        boolean grief = KocConfig.bool(KocConfig.ABILITY_GRIEFING, false);
        for (double t = 1; t <= 48; t += 0.5) {
            Vec3 p = eye.add(look.scale(t));
            if (((int) (t * 2)) % 2 == 0) level.sendParticles(ModParticles.SLASH.get(), p.x, p.y, p.z, 2, 0.6, 0.6, 0.6, 0);
            for (Entity e : level.getEntities(sp, new AABB(p, p).inflate(1.4), e -> e instanceof LivingEntity && e.isAlive())) {
                if (hit.add(e.getId())) {
                    e.invulnerableTime = 0;
                    if (e instanceof LivingEntity le) SliceLogic.mark(le);
                    com.kingofcurses.entity.GojoKenjakuEntity.SURE_HIT = true; // the World Cutting Slash cuts space itself, Infinity included
                    try { e.hurt(sp.damageSources().indirectMagic(sp, sp), damage); }
                    finally { com.kingofcurses.entity.GojoKenjakuEntity.SURE_HIT = false; }
                    level.sendParticles(ModParticles.BLOOD.get(), e.getX(), e.getY() + 1, e.getZ(), 25, 0.3, 0.5, 0.3, 0.2);
                }
            }
            if (grief) {
                BlockPos bp = BlockPos.containing(p);
                BlockState st = level.getBlockState(bp);
                if (!st.isAir() && st.getDestroySpeed(level, bp) >= 0 && st.getDestroySpeed(level, bp) < 30) level.destroyBlock(bp, false, sp);
            }
        }
        level.playSound(null, sp.blockPosition(), ModSounds.WORLD_SLASH.get(), SoundSource.PLAYERS, 2.0f, 1.0f);
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.WHITE_FLASH, 10, 0.6f));
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.SHAKE, 15, 0.6f));
    }

    public static LivingEntity lookTarget(ServerPlayer sp, double range) {
        Vec3 eye = sp.getEyePosition();
        Vec3 look = sp.getViewVector(1.0f);
        Vec3 end = eye.add(look.scale(range));
        AABB box = sp.getBoundingBox().expandTowards(look.scale(range)).inflate(1.5);
        EntityHitResult res = ProjectileUtil.getEntityHitResult(sp, eye, end, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e != sp, range * range);
        return res != null && res.getEntity() instanceof LivingEntity le ? le : null;
    }
}
