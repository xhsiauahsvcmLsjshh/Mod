package com.kingofcurses.ability;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.entity.SukunaEntity;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** v1.0.20 Strongest of Today finale: ten clues joined, four-armed Sukuna claws his way out of the ground. */
@Mod.EventBusSubscriber(modid = KingOfCurses.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SukunaBossFight {
    public static final String BOSS_TAG = "kingofcurses_boss";
    public static final int RISE = 70;
    private static final List<Fight> FIGHTS = new ArrayList<>();

    private static final class Fight {
        final ServerLevel level; final int id; final UUID summoner; final Vec3 base; int t;
        final ServerBossEvent bar = new ServerBossEvent(Component.translatable("boss.kingofcurses.sukuna_four_arms").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD),
                BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);
        Fight(ServerLevel l, int id, UUID s, Vec3 b) { level = l; this.id = id; summoner = s; base = b; bar.setDarkenScreen(true); bar.setPlayBossMusic(true); }
    }

    private SukunaBossFight() {}

    public static boolean summon(ServerPlayer sp) {
        ServerLevel sl = sp.serverLevel();
        for (Fight f : FIGHTS) if (f.level == sl && sl.getEntity(f.id) != null) {
            sp.displayClientMessage(Component.translatable("message.kingofcurses.boss_already").withStyle(ChatFormatting.RED), true);
            return false;
        }
        float y = sp.getYRot() * Mth.DEG_TO_RAD;
        double x = sp.getX() - Mth.sin(y) * 8, z = sp.getZ() + Mth.cos(y) * 8;
        double gy = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
        SukunaEntity s = ModEntities.SUKUNA_TRUE_FORM.get().create(sl);
        if (s == null) return false;
        float face = (float) (Mth.atan2(sp.getZ() - z, sp.getX() - x) * Mth.RAD_TO_DEG) - 90f;
        s.moveTo(x, gy - 3.5, z, face, 0);
        s.setNoAi(true); s.setNoGravity(true); s.noPhysics = true; s.setInvulnerable(true);
        s.setPersistenceRequired();
        s.getPersistentData().putBoolean(BOSS_TAG, true);
        sl.addFreshEntity(s);
        FIGHTS.add(new Fight(sl, s.getId(), sp.getUUID(), new Vec3(x, gy, z)));
        sl.playSound(null, BlockPos.containing(x, gy, z), ModSounds.SUKUNA_ROAR.get(), SoundSource.HOSTILE, 3.0f, 0.5f);
        sl.playSound(null, BlockPos.containing(x, gy, z), ModSounds.TAKEOVER.get(), SoundSource.HOSTILE, 2.0f, 0.6f);
        for (ServerPlayer p : sl.getPlayers(p -> p.distanceToSqr(x, gy, z) < 64 * 64)) {
            p.displayClientMessage(Component.translatable("message.kingofcurses.boss_rise").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
            ModNetwork.sendTo(p, new ScreenFxPacket(ScreenFxPacket.RED_FLASH, 20, 0.8f));
        }
        return true;
    }

    public static void tick(MinecraftServer server) {
        Iterator<Fight> it = FIGHTS.iterator();
        while (it.hasNext()) {
            Fight f = it.next();
            if (!(f.level.getEntity(f.id) instanceof SukunaEntity s) || !s.isAlive()) { f.bar.removeAllPlayers(); it.remove(); continue; }
            f.t++;
            if (f.t <= RISE) {                        // clawing out of the earth
                double k = f.t / (double) RISE;
                s.setPos(f.base.x, f.base.y - 3.5 * (1 - k * k * (3 - 2 * k)), f.base.z);
                BlockState ground = f.level.getBlockState(BlockPos.containing(f.base.x, f.base.y - 1, f.base.z));
                if (!ground.isAir()) f.level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, ground), f.base.x, f.base.y + 0.1, f.base.z, 30, 1.4, 0.2, 1.4, 0.2);
                f.level.sendParticles(ModParticles.CURSED_ENERGY.get(), f.base.x, f.base.y + 1, f.base.z, 10, 1.0, 1.0, 1.0, 0.05);
                if (f.t % 10 == 0) for (ServerPlayer p : f.level.getPlayers(p -> p.distanceToSqr(f.base) < 40 * 40)) ModNetwork.sendTo(p, new ScreenFxPacket(ScreenFxPacket.SHAKE, 10, 0.8f));
                if (f.t == RISE) {
                    s.setNoAi(false); s.setNoGravity(false); s.noPhysics = false; s.setInvulnerable(false);
                    Player target = f.level.getPlayerByUUID(f.summoner);
                    if (target != null) s.setTarget(target);
                    f.level.playSound(null, s.blockPosition(), ModSounds.SUKUNA_LAUGH.get(), SoundSource.HOSTILE, 3.0f, 0.6f);
                    f.level.playSound(null, s.blockPosition(), ModSounds.BOSS_THEME.get(), SoundSource.RECORDS, 1.0f, 1.0f);
                }
            }
            f.bar.setProgress(Mth.clamp(s.getHealth() / s.getMaxHealth(), 0, 1));
            for (ServerPlayer p : f.level.getPlayers(p -> p.distanceToSqr(s) < 64 * 64)) f.bar.addPlayer(p);
            for (ServerPlayer p : new ArrayList<>(f.bar.getPlayers())) if (p.level() != f.level || p.distanceToSqr(s) > 80 * 80) f.bar.removePlayer(p);
        }
    }

    @SubscribeEvent
    public static void death(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof SukunaEntity s) || !s.getPersistentData().getBoolean(BOSS_TAG)) return;
        if (!(s.level() instanceof ServerLevel sl)) return;
        for (ServerPlayer p : sl.getPlayers(p -> p.distanceToSqr(s) < 80 * 80)) {
            p.displayClientMessage(Component.translatable("message.kingofcurses.boss_defeated_gojo").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
            KocAdvancements.award(p, "strongest_of_today");
        }
        sl.sendParticles(ModParticles.CURSED_ENERGY.get(), s.getX(), s.getY() + 2, s.getZ(), 300, 1.5, 2, 1.5, 0.2);
    }

    public static void clear() { for (Fight f : FIGHTS) f.bar.removeAllPlayers(); FIGHTS.clear(); }
}
