# KING OF CURSES: TWENTY FINGERS
*A dark-anime Jujutsu Kaisen inspired mod for Minecraft Java 1.20.1 (Forge 47.4.0 + GeckoLib 4.4.9)*

> Fan-made, non-commercial tribute. All models, textures, sounds and dialogue are original or procedurally generated for this mod. No assets from the anime, manga or games are used.

---

## 1. Name and lore

**Mod name:** King of Curses: Twenty Fingers (`mod_id: kingofcurses`)

A thousand years ago, in the Heian era, **Ryomen Sukuna**, a four-armed, two-faced calamity, ruled as the King of Curses. Even the sorcerers who finally killed him could not destroy his body. His **twenty fingers** were sealed as indestructible special-grade cursed objects and scattered across the world. Each one stayed a beacon of malice that drew curses to it like flies.

Your world begins the day Sukuna returns. You arrive and watch **Gojo Satoru**, the strongest sorcerer alive, standing behind his Infinity. Sukuna is bored. He doesn't attack Gojo. He cuts *the space Gojo stands in*. The strongest falls in two.

Then the King does something strange. He kneels, digs into the earth, buries **one of his own fingers** next to you and dissolves into cursed energy. He wants a vessel. You.

Every finger you eat makes you stronger, and makes him louder. At twenty, the jujutsu world will send its final sealer. After that, only one question is left: **embrace the King, or seal him forever?**

---

## 2. Visual identity

| Role | Name | Hex |
|---|---|---|
| Base / shadows | Abyss Black | `#100A0E` |
| Ink / outlines | Cursed Ink | `#1C1218` |
| Primary accent | Crimson | `#960E20` |
| Blood | Old Blood | `#6E0612` |
| Emissive glow | Cursed Energy Red | `#FF2A40` |
| Secondary | Dark Purple | `#341240` / `#541E62` |
| Light / contrast | Bone White | `#E2DAC4` / `#C4BAA0` |
| Shrine lacquer | Torii Vermilion | `#B01A1E` |
| Ornament | Temple Gold | `#C4A048` |

**Style rules:** 16x16 pixel art with 1 px dark outlines and top-lit shading, kanji-like glyphs (original, not real words) on seals and talismans. Everything that holds cursed energy (eyes, Sukuna's markings, crystals, talisman glyphs, slashes) uses the emissive red on a `_glowmask` layer, so it glows in the dark. Bone white and crimson always sit on black.

---

## 3. Characters, curses and factions

### The King
- **Ryomen Sukuna (vessel form):** salmon hair, a second pair of eyes, black facial markings, white kimono with a crimson obi. Cinematic actor. As a boss he melees and throws Dismantle slashes. *GeckoLib: idle, walk, run, attack, slash, taunt, dig, vanish, domain, eat_finger, cast.*
- **Sukuna (True Form):** 1.3x scale, **four arms**, a second face on the side of his head, black-striped body, crimson hakama. Shows up in both endings and can be spawned as a boss.

### The Strongest
- **Gojo Satoru:** white hair, black blindfold, high-collar uniform. His model is split at the waist so the `cut_in_half` animation can slide the upper body off. Projectiles stop at his Infinity.

### Cursed spirits (hostile)
| Grade | Curse | Behaviour |
|---|---|---|
| 4 | **Fly Head** | Big-headed buzzing curse with flapping wings and a jaw. Swarms. |
| 4 | **Crawling Eye** | A giant eyeball on six legs that leaps at you. |
| 3 | **Roppongi Curse** | Hunched, covered in yellow eyes. Its scream causes Darkness and Weakness. |
| 3 | **Lantern Hag** | Tall and thin, with a burning lantern. Throws fire bolts and sets you alight. Also spawns in the Nether. |
| 2 | **Hanged Bride** | Floating white dress with a veil and noose. Pulls victims toward her. |
| 1 | **Bone Centipede** | Seven-segment bone serpent. Lunges with poison. |

### Special-grade curses (mini-bosses, boss bar, guaranteed finger)
| Curse | Special | Finger |
|---|---|---|
| **Finger Bearer** | Ground slam that launches everything nearby | #8 (curse dens) |
| **Smallpox Deity** | "Coffin": slowness IV, blindness, damage | #10 (cemeteries) |
| **Cursed Womb** | Spawns Fly Head broods | #11 (finger chambers) |
| **Shrine Warden** | Armoured samurai with a naginata. Fast charges. | #15 Nether, #17 End, #19 ruins (set by structure NBT) |

### Factions
- **Curses:** attack players and sorcerers. Weak curses (Grade 4 to 2) **bow** to a player who embraced Sukuna.
- **Jujutsu Sorcerers:** a regular sorcerer hunts at 5+ fingers. A **Grade 1 Sorcerer** (katana) hunts at 3+ fingers once they've noticed you. Both cast sealing talismans that apply *Sealed* (no techniques). They always fight curses.
- **Jujutsu High Students:** neutral, live in Jujutsu High. They only turn hostile if you embrace Sukuna.
- **Tengen's Sealing Master:** the final boss. White and indigo robes, floating talismans, boss bar. At 50 % HP she summons two Grade 1 sorcerers; at 25 % she raises a sealing barrier (Slowness III + Sealed).

---

## 4. Power progression per finger

Stats stack linearly with each finger (*effective* fingers: rejecting Sukuna caps them at 10; embracing him gives a 1.25x multiplier).

| Fingers | Max HP | Attack | Speed | Armor / Toughness | Damage reduction | Max CE | CE regen | Unlocks and events |
|---|---|---|---|---|---|---|---|---|
| 1 | +1 | +0.6 | +1% | +0.5 / +0.25 | 1.5% | 120 | 1.2/s | **Dismantle** (15 CE, 0.5 s cd) |
| 2 | +2 | +1.2 | +2% | +1.0 / +0.50 | 3.0% | 140 | 1.5/s | Sukuna's voice can be heard when you eat |
| 3 | +3 | +1.8 | +4% | +1.5 / +0.75 | 4.5% | 160 | 1.7/s | **Cleave** (30 CE, 2 s cd) |
| 4 | +4 | +2.4 | +5% | +2.0 / +1.00 | 6.0% | 180 | 2.0/s | Strength II on eating lasts longer |
| 5 | +5 | +3.0 | +6% | +2.5 / +1.25 | 7.5% | 200 | 2.2/s | **Reverse Cursed Technique** (40 CE, 10 s cd) · Jujutsu sorcerers start hunting you · markings tier 2 |
| 6 | +6 | +3.6 | +7% | +3.0 / +1.50 | 9.0% | 220 | 2.4/s | Curses' Grade 4 attacks barely scratch you |
| 7 | +7 | +4.2 | +8% | +3.5 / +1.75 | 10.5% | 240 | 2.7/s | Strength boost on eating becomes Strength II |
| 8 | +8 | +4.8 | +10% | +4.0 / +2.00 | 12.0% | 260 | 2.9/s | **Dismantle: Spiderweb** (45 CE, 6 s cd) |
| 9 | +9 | +5.4 | +11% | +4.5 / +2.25 | 13.5% | 280 | 3.2/s | Faster cursed energy regeneration |
| 10 | +10 | +6.0 | +12% | +5.0 / +2.50 | 15.0% | 300 | 3.4/s | **Fuga / Open** (70 CE, 15 s cd) · markings tier 3 · cap for the Reject ending |
| 11 | +11 | +6.6 | +13% | +5.5 / +2.75 | 16.5% | 320 | 3.6/s | Fall damage nearly ignored from 6 blocks |
| 12 | +12 | +7.2 | +14% | +6.0 / +3.00 | 18.0% | 340 | 3.9/s | Hunting parties now include a Grade 1 Sorcerer |
| 13 | +13 | +7.8 | +16% | +6.5 / +3.25 | 19.5% | 360 | 4.1/s | Strength III on eating |
| 14 | +14 | +8.4 | +17% | +7.0 / +3.50 | 21.0% | 380 | 4.4/s | Armor bonus +7 |
| 15 | +15 | +9.0 | +18% | +7.5 / +3.75 | 22.5% | 400 | 4.6/s | **Sukuna takeover risk** begins (4 % per minute per finger above 14) · markings tier 4 |
| 16 | +16 | +9.6 | +19% | +8.0 / +4.00 | 24.0% | 420 | 4.8/s | Takeover chance 8 %/min |
| 17 | +17 | +10.2 | +20% | +8.5 / +4.25 | 25.5% | 440 | 5.1/s | **World Cutting Slash** (120 CE, 30 s cd) |
| 18 | +18 | +10.8 | +22% | +9.0 / +4.50 | 27.0% | 460 | 5.3/s | Takeover chance 16 %/min |
| 19 | +19 | +11.4 | +23% | +9.5 / +4.75 | 28.5% | 480 | 5.6/s | Max cursed energy 480 |
| 20 | +20 | +12.0 | +24% | +10.0 / +5.00 | 30.0% | 500 | 5.8/s | **Domain Expansion: Malevolent Shrine** (80 % of max CE, 5 min cd) · Tengen's Sealing Master arrives · markings tier 5 |

**Also scaling:** jump height (+0.012 per finger), fall-distance forgiveness (0.6 blocks per finger), knockback resistance (2 % per finger, max 60 %), and the damage of every technique (x1.08 per finger, +0.5 when embraced).

### Techniques
- **Dismantle:** a fast, piercing invisible-edge slash projectile (5 + 0.6/finger damage, pierces 2 + f/6 targets).
- **Cleave:** an adaptive slash on the creature you're looking at (8 blocks). Damage adds 12 % of the target's max HP plus a bonus for body size, so it scales against bigger, tougher targets.
- **Reverse Cursed Technique:** heals 6 + 0.6/finger, clears harmful effects (except *Sealed*) and puts out fire.
- **Spiderweb:** slashes radiate through the ground and knock enemies into the air.
- **Fuga (Open):** a fire arrow that erupts in a 5.5-block inferno. It never hurts the caster, and only breaks blocks if `abilityGriefing=true`.
- **World Cutting Slash:** a 48-block line that cuts everything in it and ignores armor.
- **Domain Expansion: Malevolent Shrine:** the shrine (a 5x5 block GeckoLib model with a moving maw) rises behind you. For 20 s every living thing within 24 blocks takes sure-hit slashes 5 times a second. Fog, sky and vignette turn black-red for everyone inside. CE doesn't regenerate while it's open. 5 min cooldown.

### Sukuna's takeover
From 15 fingers, if you haven't chosen an ending yet, Sukuna rolls every minute to seize your body for 10 s. During a takeover he auto-casts Dismantle at the nearest creature, your movement is slowed and inverted, you can't attack or use items, the screen pulses red and "SUKUNA" burns in the centre of the screen.

---

## 5. Finger locations

| # | Where | How it's held |
|---|---|---|
| 1 | Buried near your first spawn by Sukuna in the intro | *Disturbed Soil* block with a resonance particle hint |
| 2 | **Cursed Shrine** (forests, taiga, plains, cherry groves) | Reliquary on the Malevolent Altar |
| 3 | **Torii Crossing** (plains, meadows, cherry groves) | Reliquary at the end of three torii |
| 4 | **Curse Den** (sunken pit, any overworld biome) | Reliquary in the pit |
| 5 | **Cursed Grove** (dark forest, swamp, taiga) | Reliquary in a stone shrine among cursed trees |
| 6 | **Japanese Temple** (mountains, cherry groves, taiga) | Reliquary behind the altar |
| 7 | **Abandoned School** (plains, savanna, forests) | Reliquary in a 2nd-floor classroom |
| 8 | **Finger Bearer** in the Curse Den | Mini-boss drop |
| 9 | **Underground Finger Chamber** (y 10, sealed with spikes and lava) | Reliquary on an altar island |
| 10 | **Smallpox Deity** in the Cursed Cemetery | Mini-boss drop |
| 11 | **Cursed Womb** in the Finger Chamber | Mini-boss drop |
| 12 | **Jujutsu High** vault (behind sealing stone, guarded by sorcerers) | Reliquary |
| 13 | **Cursed Cemetery** | Reliquary buried under a grave slab |
| 14 | **Crimson Shrine** (Nether, enclosed at y 40) | Reliquary |
| 15 | **Shrine Warden** in the Crimson Shrine | Mini-boss drop |
| 16 | **End Reliquary** (End highlands/midlands, y 62) | Reliquary |
| 17 | **Shrine Warden** in the End Reliquary | Mini-boss drop |
| 18 | **Malevolent Ruins** (badlands, desert, savanna, plains, dark forest) | Reliquary |
| 19 | **Shrine Warden** in the Malevolent Ruins | Mini-boss drop |
| 20 | **Sealed Vault** (deep underground, y -42) | Reliquary among spike traps |

The **Cursed Compass** locks onto the nearest structure in the `#kingofcurses:finger_sites` tag in your current dimension. Its glow (4 texture states) and heartbeat speed up as you get closer. Every finger can be eaten **once per player** (a 20-bit mask in a capability), so duplicates never break progression.

---

## 6. Structures and world
13 data-driven jigsaw structures (1.20.1 `worldgen/structure` + `structure_set` + `template_pool` + NBT templates): Cursed Shrine, Torii Crossing, Curse Den, Cursed Grove, Japanese Temple, Abandoned School, Underground Finger Chamber, Cursed Cemetery, Jujutsu High (dorm, main hall, training yard, vault, NPC students and sorcerers), Crimson Shrine (Nether), End Reliquary (End), Malevolent Ruins, Sealed Vault.

Forge biome modifiers add curse spawns (overworld, Nether, End), **Cursed Crystal Ore** (stone and deepslate, y bottom to 48) and **cursed trees** (dark forest, swamp, old-growth spruce taiga).

---

## 7. Progression and endings

1. **Intro cinematic** (first join only, skippable, replayable from the Codex) → dig up Finger #1.
2. **Early (1 to 5):** Dismantle, Cleave and RCT. Craft cursed tools and the Jujutsu uniform. Clear shrines, torii crossings and dens.
3. **Mid (6 to 12):** temples, schools, cemeteries, finger chambers, the Jujutsu High vault. Sorcerer hunts begin. Fuga at 10.
4. **Late (13 to 19):** Nether and End shrines, Shrine Wardens, the Sealed Vault. Takeover risk, World Cutting Slash.
5. **Twenty:** Malevolent Shrine unlocks and **Tengen's Sealing Master** arrives.
6. **The Choice** (opens after the boss dies, one time only, checked on the server):
   - **Embrace Sukuna:** permanent full power (x1.25 stats, +200 max CE, +0.5 technique multiplier), final markings, no more takeovers (you *are* the King). Every sorcerer and student becomes hostile, hunting parties come more often and are larger, and an immediate hunting party arrives. Weak curses bow to you.
   - **Reject Sukuna:** a sealing ritual. Power is capped at 10 fingers (techniques up to Fuga, no Domain), takeovers stop, markings fade to tier 2. Sorcerers and students become **allies**: they never target you and keep hunting curses.
