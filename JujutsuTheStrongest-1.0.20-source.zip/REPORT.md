# Delivery report: King of Curses: Twenty Fingers 1.0.0

## Verified environment (checked online on 2026-10-08)
- **Forge 1.20.1-47.4.0**: Recommended Build 4, MDK coordinate `net.minecraftforge:forge:1.20.1-47.4.0` (files.minecraftforge.net, release forum post).
- **Java 17** (MC 1.18+ target). **Gradle 8.8** (Forge 47.2.36 bumped the MDK to 8.8). **ForgeGradle 6** (`[6.0.16,6.2)`, MDK range).
- **Mappings:** Parchment `2023.09.03-1.20.1` (latest 1.20.1 export) on official names, via `org.parchmentmc.librarian.forgegradle`.
- **GeckoLib:** `software.bernie.geckolib:geckolib-forge-1.20.1:4.4.9` from the GeckoLib Cloudsmith maven. Maven Central also lists 4.7.x/4.8.x artifacts for 1.20.1, but 4.4.9 is the line whose `software.bernie.geckolib.core.*` API this code targets.
- **Practices used:** `DeferredRegister` for everything (including `Registries.CREATIVE_MODE_TAB`), `SimpleChannel` + `messageBuilder().consumerMainThread()`, `CapabilityManager.get(new CapabilityToken<>(){})` + `RegisterCapabilitiesEvent`, client code isolated behind `Dist.CLIENT` subscribers and `DistExecutor`, no mixins, 1.20.1 data formats (`loot_tables/`, `recipes/`, `tags/blocks|items`, `forge/biome_modifier`, jigsaw structures, pack_format 15).

## Content
| Category | Count |
|---|---|
| Blocks | **41** (temple stone family, cursed wood family, torii parts, roof tiles, seals, talisman wall, tatami, soils, crystal + ores, lantern, reliquary with GUI, burial soil, spike trap, altar) |
| Items | **119** registry items: **78** non-block (20 fingers, Codex, Compass, 8 materials, 4 talismans, 3 potions, **8 weapons**, 4 tools, **12 armor pieces** in 3 sets, 17 spawn eggs) + 41 block items |
| Entities | **20** GeckoLib entity types, each with its own model, texture, glowmask and animation file. 17 are living mobs (Sukuna, Sukuna True Form, Gojo, 6 graded curses, 4 special grades, 3 sorcerer types, final boss), plus the Malevolent Shrine, Dismantle and Fuga |
| Structures | 13 (3 dimensions) |
| Sounds / particles / effects | 27 / 5 / 5 |
| Recipes / loot tables / advancements | 80 / 79 / 11 |
| Lang | 312 keys in **en_us** and **it_it** (1:1) |
| Java | 81 classes, about 5,100 lines |

## Controls (all rebindable in Controls → King of Curses)
| Key | Action |
|---|---|
| R | Use the selected technique |
| G | Next technique |
| V (hold) | Radial technique wheel: point and release or click |
| B | Domain Expansion: Malevolent Shrine |
| K | Cursed Codex (also right-click the item) |
| X | Skip the cinematic |
| Right-click (hold) a finger | Eat it |

## Finger locations, powers and endings
See **CONCEPT.md** sections 4, 5 and 7 (the per-finger table, all 20 sources, and both endings).

## Testing and validation: what was and was not done
**Done (automated, in the build sandbox):**
- All **530 JSON files** parse. A custom validator (`tools/assetgen/validate.py`) checks every blockstate → model → texture chain, item models for all 119 items, lang parity (en/it) and coverage (blocks, items, entities, effects, sound subtitles, abilities, keys, every literal translation key in Java), sounds.json → .ogg, particle JSON → textures, GeckoLib geo/animation/texture/glowmask per entity (texture size matches geo, bone parents exist, every animated bone exists, every animation name used in Java exists), loot and recipe item references, worldgen chains (structure → pool → NBT → biome tag → structure set), NBT palette block IDs and properties, and that fingers #2 to #20 each have a placement. **Result: 0 errors.**
- All 81 Java files pass the javac parse and attribution pass with the JDK 17 compiler. Every internal call and registry reference resolves.

**NOT done (be aware):**
- **`./gradlew build` was not run, and no compiled `.jar` exists.** The sandbox has no internet access, so Gradle can't download Forge, ForgeGradle, Parchment or GeckoLib. Because the Minecraft/Forge/GeckoLib classes weren't available, javac couldn't type-check calls into those APIs. Those calls were written and reviewed by hand against the 1.20.1/47.x and GeckoLib 4.4 APIs, but small signature mismatches are possible on the first real build.
- **No in-game testing of any kind:** not the first-join cinematic, finger spawn or eating, the 20-finger progression, techniques, keybinds, HUD, Domain Expansion, mobs, structure generation, endings, or a dedicated server. Nothing here claims those were tested.
- Visual quality of the procedural textures, models and animations was only checked as image files, not in-engine.
- Known design limits: the "slow motion" is emulated (actor animation speed x0.3, slowed camera, tint), because 1.20.1 has no tick-rate control. The player arm animation is a vanilla swing plus a camera kick, not a custom first-person arm keyframe. End-structure placement uses a fixed y 62, so some can float over the void.

**Recommended first-run checklist:** `./gradlew build`, then `runClient` (new world → cinematic → dig Disturbed Soil → eat), `/kingofcurses setfingers @p 20` → Domain (B) and boss → ending, then `runServer` + client to confirm the dedicated server boots.

## Size
See the final message (measured on the delivered archives).
