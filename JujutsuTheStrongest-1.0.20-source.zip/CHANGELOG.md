## 1.0.20
- Strongest of Today: the opening now takes you to the nearest Jujutsu High. Toji attacks you there; after Hollow Purple, Suguru Geto arrives and tells Gojo that Sukuna is back but nobody knows where he is. Geto stays at the institute (right click him: clue progress).
- New structure: Dark Institute of the curse users (Overworld, common). New hostile mob: Curse User (melee + thrown cursed slashes). The altar chest holds a Clue of Sukuna.
- Clue of Sukuna: every clue is the same item. Combine them in the crafting grid (or one per hand + right click): "Clue 2 of 10" ... "Clue 10 of 10".
- With 10 of 10: right click and four-armed Sukuna claws his way out of the ground. Boss fight with boss bar and music. His World Cutting Slash sometimes cuts through Infinity.
- For Gojo the Cursed Compass points to the dark institutes.

## 1.0.19
- Strongest of Today opening: no more Gojo actor standing over the player. YOU are Gojo: Toji stabs your own body, you fall to the ground, get back up with Reverse Cursed Technique (arms and body animated on the player model) and fire Hollow Purple at him.

## 1.0.18 - Jujutsu: The Strongest
- The mod is now "Jujutsu: The Strongest" (Sukuna AND Gojo). Mod id stays kingofcurses, so old worlds keep working.
- Create New World: the KING OF CURSES switch is gone. New PICK YOUR SIDE button (top left): Strongest of History / Strongest of Today.
- Sorcerers (named roamers and hunters) now only appear on Hard difficulty.
- Strongest of History: the Sukuna game, as before.
- Strongest of Today: new opening. You are Gojo, stabbed to death by Toji Fushiguro (Inventory Curse worm on his shoulders, Inverted Spear of Heaven). Toji walks away; Gojo awakens Reverse Cursed Technique, heals, and erases Toji with Hollow Purple. Toji's body stays: right click it to take the worm (Inventory Curse). You get Gojo's blindfold.
- Gojo's powers: Infinity (toggle; blocks attacks and projectiles for cursed energy; the Inverted Spear of Heaven cuts through it), Blue, Red, Hollow Purple (erases blocks if mobGriefing is on), Blink, Reverse Cursed Technique, Domain Expansion: Infinite Void (B). Six Eyes: half cursed energy cost, 600 max energy. Gojo cannot eat fingers.
- Vigor bar for Gojo too, with 6 new finishers: Point-Blank Red, Blue Crush, Purple Erasure, The Wall of Infinity, Gojo's Black Flash, Void Punch.
- New mob: Toji Fushiguro (spawn egg). /kingofcurses side history|today switches side.

## 1.0.17 - The Heian Era
- New dimension: the Heian Era (eternal golden sunset, golden grass, cherry groves, blood-red water, curses roaming).
- Heian Gate Seal (gold ingots + torii beams + eye of ender): use it on the ground to raise a golden torii with a 3x4 portal. Stand inside for 2 seconds. A return gate stands in the throne arena; it brings you back where you left.
- First arrival: a cinematic "video" (aerial shots, the golden road, Sukuna on his throne: "Welcome to the Heian Era. The Golden Era of Jujutsu."), black screen... then a four-armed JUMPSCARE. Skippable with X. /kingofcurses heian replays it.
- Throne arena built once per world at the centre of the dimension: platform, bone-and-gold throne, lantern pillars, return gate.
- Heian Sukuna: four arms, golem sized, sitting on the throne. Right click him once (only the first time, ever): he tears off his lower right arm and hurls it, and you catch it on the fly (catch animation).
- Arm of Heian Sukuna: put it in a crafting grid -> 5 Sukuna fingers.

## 1.0.16
- Compass of Remains can be crafted: 2 sticks one on top of the other (no vanilla recipe uses that shape).
- It now always points at the NEAREST Cursed Sand in the world (same dimension first), updating every second. Broken sand is dropped from the list automatically; right click rescans 32 blocks around you to also find sand placed by older versions.
- HUD shows "Cursed Sand (N fingers)" with exact X Y Z and ahead/behind, left/right, up/down.
- Safety net: if the compass was not handed out on respawn, it is given a second later.

## 1.0.15
- New item: Compass of Remains. A Sukuna host who dies gets it on respawn; it points exactly at the death spot (the Cursed Sand with the fingers and the dropped items). Tooltip shows the coordinates and how many fingers are left there.
- Both compasses now show a precise readout while held: target X Y Z, distance with an 8-way arrow, and Ahead/Behind, Left/Right, Up/Down in blocks, relative to where you are looking.
- Cursed Compass: locks onto the real structure bounds (correct height), then pins the exact chest holding the finger once its chunks are loaded; tells you if the site was already looted.

## 1.0.14
- Vigor bar at the top of the screen (under boss bars). While Sukuna lives in you (1+ finger), every 5 hearts of damage you deal fill it; it slowly drains after 10 s out of combat (never when full).
- Full bar: FINISHER (Z on PC, Sneak + Attack or the FINISHER button in the Battle HUD on mobile).
- 7 finishers on ordinary creatures, picked at random (never the same twice in a row), third-person camera, invulnerable while it plays: Torn Asunder (lifted overhead and ripped in two with bare hands, real left/right halves), Heart Taker, Skull Crusher, Dismantle Storm, Point-Blank Fuga, Heavenly Cleave, Black Flash Barrage.
- Sorcerers, players, vessels and bosses (Ender Dragon, Wither, Elder Guardian, Warden, forge:bosses tag, Special Grades, Gojo/Yuta, 150+ HP mobs) only take one EMPOWERED STRIKE instead.
- Sliced remains now fall with gravity.

## 1.0.13
- New Battle HUD: real on-screen touch buttons (Cast with selected technique and cooldown, Next, Domain, Pad, Rip finger x2, Exit, Codex, Jump, Use) plus a Cursed Energy bar.
- While the Battle HUD is open you can still walk (joystick/WASD forwarded), drag to look around and tap empty space to attack.
- Open it from the Technique Pad ("Buttons HUD") or with O.

# Changelog

## 1.0.12
- Mobile mode no longer uses Technique items in hand (old ones are removed automatically).
- New mobile gestures: Sneak + Attack casts the selected technique (or regrows a lost arm); double tap Sneak opens the Technique Pad.
- New Technique Pad (P on PC): big touch tiles with cooldown and CE cost, tap = instant cast; buttons for Codex/Regrow, Rip finger (double tap), Select, Close.

## 1.0.3
- **Controls choice (PC / Mobile).** After the intro cutscene a screen asks how you play. You can change it later from the Cursed Codex ("Controls" button, top right).
  - **PC:** keybinds (R cast, G next, V wheel, B domain, K codex).
  - **Mobile:** you get a **Technique item** for every unlocked power (Dismantle, Cleave, RCT, Spiderweb, Fuga, World Cutting Slash, Malevolent Shrine). Hold it and press USE to cast. The item shows its cooldown. New items arrive automatically when you unlock a technique, and missing ones are given back on respawn.
- **Gojo's body stays forever.** After your first intro his two halves remain where he fell (saved with the world, even if the cutscene was skipped). They keep bleeding and lie in a pool of blood.
- **Gojo's Blindfold (collectible).** Right-click the body to take it, then Gojo's body shows his glowing blue Six Eyes. You can wear it as a helmet. It gives **no protection and no power**, never breaks, and is purely a collectible.
- **Slash kills cut the victim in half.** Anything killed by Dismantle (and also by Cleave, Spiderweb, World Cutting Slash or the Malevolent Shrine) is split at the waist using its **real model**: vanilla animals and mobs, other mods' mobs and King of Curses mobs alike. The upper half slides off and falls, the lower half sags, both cut faces show flesh, and blood drips for about 5 seconds before the remains dissolve. Drops and XP are unchanged. Players, the Ender Dragon and the Wither are excluded.
- **Crash safety.** The halves renderer catches errors and simply stops drawing that corpse instead of crashing. Nothing in it uses mixins or shaders.

## 1.0.2
**Intro cinematic: a real fight (about 28 s, still skippable)**
- Gojo raises Infinity. Sukuna taunts.
- **Lapse: Blue**: a blue orb hits Sukuna's spot and implodes. Sukuna dashes aside.
- Sukuna **dashes in** with a punch barrage. Every hit stops on Infinity (sparks, blue ripples, light screen shake).
- **Reversal: Red** blasts Sukuna back several blocks (explosion, white flash, dust trail).
- Sukuna laughs, then charges the **World Cutting Slash** (cursed energy spirals in, heartbeat) and cuts in **slow motion**.
- **Gojo is cut in half**: the torso slides off and lands on its side, and the legs give way and fall. The cut surfaces show flesh and spine, blood spurts from both halves and a **pool of blood spreads** under the body. The halves keep bleeding and stay on the ground for 30 s after the scene.
- Sukuna walks to you, buries the finger and dissolves into cursed energy.
- New camera shot list (11 shots) that follows the actual actor positions. New subtitles in en_us and it_it.

**Hills and slopes fix (terrain is never flattened)**
- **Arena search:** the mod scans about 300 layouts around the player and picks the one where Sukuna and Gojo stand at the most similar height, with no hill between them, on solid ground away from water.
- **Fallback:** if the ground is uneven everywhere, Gojo always takes the lower spot and **levitates** with Infinity up to Sukuna's level. When he's cut, he drops to the ground.
- **Movement:** actors follow the real terrain every tick with smoothed height, so there's no popping on slopes.
- **Camera:** it's collision-checked and slides in front of any hill instead of clipping into it.

**All entity models, textures and animations remade**
- **Rigs:** humanoids now have elbows, hands, knees and feet (forearm/shin bones). Gojo has a split rig (separate torso and hips) and hidden blood bones.
- **Textures:** per-material painting (skin, fabric folds and hems, hair strands, bone, mottled curse flesh, metal bands, gore), real faces (eyes, brows, nose shadow, mouth), Sukuna's tattoo bands, uniform buttons and collars.
- **Animations:** every animation is resampled with smooth easing at 20 fps. New ones: dash, combo, recoil, charge (Sukuna), blue and red (Gojo). Idle, walk, run, attack, slash, cast, domain, eat, dig, vanish and taunt are reworked with knee and elbow motion.
- **Curses:** extra parts (claws, tendril tips, centipede legs, fly legs, crawling-eye feet, shrine horns).

**Crash safety**
- **Glowmask:** every entity glowmask is guaranteed to have at least one emissive pixel (this was the 1.0.0 crash with GeckoLib 4.8.4), and the validator now fails the build check if one is empty.
- **Error handling:** errors in the cinematic logic are caught, logged and skip the scene instead of crashing.
- **Animations:** they use only plain keyframe arrays, so they don't depend on easing support in a specific GeckoLib version.

## 1.0.1
- Fixed the empty glowmask crash (Gojo, sorcerer, student).

## 1.0.4
- Every finger is now the same item (Sukuna's Finger, stacks to 20); eating one absorbs the next. Old numbered fingers convert automatically.
- Final boss: Gojo Satoru's body with Kenjaku's stitches, possessed by Yuta (Infinity, Lapse Blue, Reversal Red, blink, Hollow Purple, Unlimited Void).
- Infinity breaks with: Black Rope, Prison Realm, Inverted Spear of Heaven, Malevolent Shrine, World Cutting Slash.
- Real black tattoos from the first finger; four arms at 20 fingers.
- On-screen controls panel with techniques and Domain Expansion (H, or the Codex button).
- New cursed objects: Prison Realm, Black Rope, Death Painting, Cursed Spirit Orb, Inventory Curse, Yuta's Promise Ring.

## 1.0.5
- Rip out your finger (J twice, or the Codex button): it carries ALL your fingers of power (1-20) and you lose your powers.
- Feed it to any creature (vanilla or modded): it gets Sukuna's tattoos and hunts hostile mobs and players with Sukuna's techniques scaled to the power (Dismantle, Cleave, RCT, Spiderweb, Fuga, World Slash, Domain at 20).
- Killing the vessel drops the finger back with the same power; eat it to regain those fingers.

## 1.0.6
- Finger-ripping animation (first and third person): both hands rise to the face, the right hand strains and yanks the finger free with a burst of blood and a camera shake, then the arms drop. You are almost frozen for 1.5 s; the power leaves you at the moment of the tear.

## 1.0.7
- Intro cinematic: the camera now follows the server timeline (no more shots ending before the action when world generation lags) and the scene waits until the world around you has finished generating.
- Four-arm awakening at 20 fingers: 3 s transformation in third person, the new arms tear out of the sides and Heian Sukuna's second pair of eyes opens.
- Black Flash: the 4th consecutive melee hit on the same target (any tool) deals x2.5 +4 damage, restores 25 CE, black-red sparks and a BLACK FLASH title.
- Heavy hits can tear off an arm (vessels only): bloody stump, weak main hand / no off-hand. R (or any technique) regrows it for 30 CE with an animation.

## 1.0.8
- Intro: waits at most 10 s for the world to settle, behind a proper loading screen.
- Boss arrival ritual: Yuta kneels by Gojo's body, stitches his head, uses Kenjaku's technique, collapses, and Gojo's body rises as the boss.
- Gojo (Yuta) only attacks hostile mobs and whoever carries Sukuna (players with fingers, vessel creatures), never ordinary players.
- KING OF CURSES difficulty (game rule kocKingOfCursesMode, Codex button, /kingofcurses mode on|off): Yuta Okkotsu, Kinji Hakari, Maki Zen'in, Megumi Fushiguro, Aoi Todo and Kento Nanami roam the Overworld with their own techniques, hunting Sukuna carriers and hostile mobs.

## 1.0.9
- First finger: Sukuna seizes the body for 8 s (third-person view, arms flung open, laughter, letterboxed lines): "Today begins a new era of slaughter!", then the player wrestles control back. Plays once per player.

## 1.0.10
- KING OF CURSES switch on the Create New World screen (bottom-left), besides the game rule / Codex button / command.
- Gojo (Yuta) rises only once per world: later players reaching 20 fingers are told to find him; once he is defeated, they go straight to the ending choice.

## 1.0.11
- Dying with one or more fingers: the body crumbles to dust from the feet up (third-person view), the block under it becomes Cursed Sand holding all those fingers, and breaking it drops a Ripped Finger worth exactly that many. The fingers leave the player.
