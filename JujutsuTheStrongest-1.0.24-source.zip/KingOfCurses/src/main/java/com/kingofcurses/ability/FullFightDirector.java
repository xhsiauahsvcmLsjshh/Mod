package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.common.KocWorldData;
import com.kingofcurses.entity.GojoEntity;
import com.kingofcurses.entity.MahoragaEntity;
import com.kingofcurses.entity.MalevolentShrineEntity;
import com.kingofcurses.entity.SukunaEntity;
import com.kingofcurses.network.FullFightPacket;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * v1.0.22 FULL FIGHT VIDEO. A new world opens on a loading screen while Shinjuku is raised (flat land, roads,
 * towers). Then the whole Shinjuku Showdown plays, Gojo Satoru against Ryomen Sukuna, following the manga:
 * the first exchange, Blue and Red, Dismantle against Infinity, the domain clash, Mahoraga adapting, the 200%
 * Hollow Purple, the World-Cutting Slash, the airport, and Sukuna's farewell. Afterwards the player IS Sukuna
 * standing in the ruins, and the sorcerers of Shinjuku come for him.
 */
public final class FullFightDirector {
    public static final int LENGTH = 2500;
    public static final int T_WALK_END = 130, T_S1 = 120, T_G1 = 168, T_LAUGH = 215, T_DASH = 250, T_IMPACT = 264, T_TRADE = 270, T_TRADE_END = 405,
            T_BLUE = 420, T_RED = 460, T_IN_TOWER = 478, T_EMERGE = 520, T_S2 = 540, T_DISMANTLE = 590, T_DOMAIN_G = 655, T_DOMAIN_S = 690, T_CLASH = 700,
            T_SHATTER = 780, T_REEXPAND = 820, T_CAUGHT = 870, T_BEAT = 900, T_BLACK_FLASH = 960, T_SUMMON = 1000, T_MAHO = 1030, T_MAHO_GO = 1062,
            T_ADAPT = 1140, T_BREAK = 1180, T_GOJO_OUT = 1240, T_PURPLE = 1320, T_CHANT = 1360, T_FIRE = 1500, T_PURPLE_HIT = 1512, T_LAND = 1560,
            T_RISE_S = 1640, T_WCS = 1720, T_CUT = 1810, T_AIRPORT = 1900, T_BACK = 2170, T_TITLE = 2390, T_END = 2500;

    private static final Map<UUID, Scene> SCENES = new HashMap<>();
    private static final Map<UUID, int[]> PENDING = new HashMap<>();   // {ticks waited, phase 0 = building, 1 = settling}

    private static final class Scene {
        final UUID player; final ServerLevel level; final BlockPos c; final Vec3 watch;
        int tick, gojoId = -1, sukunaId = -1, mahoId = -1, shrineId = -1;
        Vec3 tower1, tower2;
        Scene(UUID p, ServerLevel l, BlockPos c) {
            player = p; level = l; this.c = c;
            watch = new Vec3(c.getX() + 0.5, c.getY() + 26, c.getZ() + 20.5);
        }
        Vec3 at(double u, double y, double v) { return new Vec3(c.getX() + 0.5 + u, c.getY() + 1 + y, c.getZ() + 0.5 + v); }
    }

    private FullFightDirector() {}

    public static boolean isInScene(UUID id) { return SCENES.containsKey(id) || PENDING.containsKey(id) || SendaiDirector.isInScene(id); }

    public static void schedule(ServerPlayer sp) {
        if (isInScene(sp.getUUID())) return;
        PENDING.put(sp.getUUID(), new int[]{0, 0, 0});
        ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.LOADING_PROGRESS, 1, 0f));
    }

    public static void skip(ServerPlayer sp) {
        Scene s = SCENES.remove(sp.getUUID());
        if (s != null) finish(sp, s);
        SendaiDirector.skip(sp);
    }

    public static void clear() { SCENES.clear(); PENDING.clear(); }

    // ------------------------------------------------------------------ loading
    public static void tick(MinecraftServer server) {
        ShinjukuCity.tick(ShinjukuCity.building() && !PENDING.isEmpty() ? 30 : 6);
        Iterator<Map.Entry<UUID, int[]>> pit = PENDING.entrySet().iterator();
        while (pit.hasNext()) {
            Map.Entry<UUID, int[]> en = pit.next();
            int[] v = en.getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(en.getKey());
            if (sp == null) { pit.remove(); continue; }
            ServerLevel ow = server.overworld();
            KocWorldData wd = KocWorldData.get(server);
            v[0]++;
            if (v[1] == 0) {
                // v1.0.23: start ONCE (before, a finished build restarted from 0% in the same tick: the bar went back and forth)
                if (!wd.cityBuilt() && ShinjukuCity.center() == null) {
                    if (sp.level() != ow) { pit.remove(); continue; }
                    ShinjukuCity.begin(ow, ow.getSharedSpawnPos());
                } else if (wd.cityBuilt() && ShinjukuCity.center() == null) ShinjukuCity.restore(ow, wd.cityCenter());
                BlockPos c = ShinjukuCity.center();
                if (c != null) {   // keep the player safe in the air over the plaza while it is built
                    if (sp.level() != ow) sp.teleportTo(ow, c.getX() + 0.5, c.getY() + 40, c.getZ() + 0.5, 0, 0);
                    else if (sp.position().distanceToSqr(c.getX() + 0.5, c.getY() + 40, c.getZ() + 0.5) > 1) sp.connection.teleport(c.getX() + 0.5, c.getY() + 40, c.getZ() + 0.5, 0, 0);
                    sp.setNoGravity(true); sp.setDeltaMovement(Vec3.ZERO); sp.fallDistance = 0;
                }
                float prog = wd.cityBuilt() ? 0.92f : ShinjukuCity.progress() * 0.92f;
                v[2] = Math.max(v[2], Math.round(prog * 1000));   // the bar only ever goes forward
                if (v[0] % 5 == 0) ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.LOADING_PROGRESS, 1, v[2] / 1000f));
                if (!ShinjukuCity.building() && c != null) {
                    if (!wd.cityBuilt()) wd.setCity(c);
                    v[1] = 1; v[0] = 0;
                }
                continue;
            }
            // phase 1: let the client receive and draw the new city before the camera starts moving (no lag spikes in the video)
            if (v[0] % 5 == 0) ModNetwork.sendTo(sp, new ScreenFxPacket(ScreenFxPacket.LOADING_PROGRESS, 1, 0.92f + 0.08f * Math.min(1f, v[0] / 80f)));
            BlockPos c = ShinjukuCity.center();
            sp.connection.teleport(c.getX() + 0.5, c.getY() + 26, c.getZ() + 20.5, 180, 20);
            if (v[0] < 80) continue;
            pit.remove();
            start(sp, c);
        }
        Iterator<Map.Entry<UUID, Scene>> it = SCENES.entrySet().iterator();
        while (it.hasNext()) {
            Scene s = it.next().getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(s.player);
            if (sp == null || sp.level() != s.level) { cleanup(s); it.remove(); continue; }
            s.tick++;
            if (sp.position().distanceToSqr(s.watch) > 0.5) sp.connection.teleport(s.watch.x, s.watch.y, s.watch.z, 180, 20);
            sp.setDeltaMovement(Vec3.ZERO); sp.fallDistance = 0;
            if (s.tick % 20 == 0) ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.SYNC, 0, 0, s.tick, 0, 0, 0));
            if (s.tick % 40 == 0) for (Entity e : s.level.getEntities((Entity) null, new AABB(s.c).inflate(ShinjukuCity.R + 10, 60, ShinjukuCity.R + 10), e -> e instanceof Enemy && !(e instanceof SukunaEntity))) e.discard();
            try { run(s, sp); } catch (RuntimeException ex) {
                com.kingofcurses.KingOfCurses.LOGGER.error("Full fight video error, skipping", ex);
                it.remove(); finish(sp, s); continue;
            }
            if (s.tick >= T_END) { it.remove(); finish(sp, s); }
        }
    }

    private static void start(ServerPlayer sp, BlockPos c) {
        ServerLevel sl = sp.serverLevel();
        if (KocMode.isSendai(sl)) { SendaiDirector.start(sp, c); return; }   // v1.0.24 Sendai Colony video
        Scene s = new Scene(sp.getUUID(), sl, c);
        sl.setDayTime(6000);
        sl.setWeatherParameters(12000, 0, false, false);
        GojoEntity gojo = ModEntities.GOJO_SATORU.get().create(sl);
        SukunaEntity sukuna = ModEntities.RYOMEN_SUKUNA.get().create(sl);
        if (gojo == null || sukuna == null) { finishData(sp, s); return; }
        gojo.setupCinematic(LENGTH + 400); gojo.setBlindfold(false);
        Vec3 g0 = s.at(-26, 0, 0), s0 = s.at(9, 0, 0);
        gojo.moveTo(g0.x, g0.y, g0.z, -90, 0);
        sukuna.setupCinematic(LENGTH + 400);
        sukuna.moveTo(s0.x, s0.y, s0.z, 90, 0);
        sl.addFreshEntity(gojo); sl.addFreshEntity(sukuna);
        s.gojoId = gojo.getId(); s.sukunaId = sukuna.getId();
        s.tower1 = ShinjukuCity.towerCenter(0, 0);
        if (s.tower1 == null) s.tower1 = s.at(16, 4, 16);
        s.tower2 = ShinjukuCity.towerCenter(-1, -1);
        if (s.tower2 == null) s.tower2 = s.at(-16, 4, -16);
        sp.setNoGravity(true);
        sp.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, LENGTH + 60, 0, true, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, LENGTH + 60, 4, true, false, false));
        sp.connection.teleport(s.watch.x, s.watch.y, s.watch.z, 180, 20);
        SCENES.put(sp.getUUID(), s);
        ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.START, s.gojoId, s.sukunaId, 0, c.getX(), c.getY(), c.getZ()));
    }

    // ------------------------------------------------------------------ the choreography
    private static double ease(double t) { t = Mth.clamp(t, 0, 1); return t * t * (3 - 2 * t); }
    private static double k(int t, int a, int b) { return Mth.clamp((t - a) / (double) (b - a), 0, 1); }

    /** Exchange of blows: both circle a moving point. Returns {gojo, sukuna}. */
    private static Vec3[] trade(Scene s, int t) {
        double a = (t - T_TRADE) * 0.045;
        Vec3 m = s.at(Math.sin(t * 0.05) * 3.5, Math.max(0, Math.sin(t * 0.13)) * 1.6, Math.cos(t * 0.04) * 2.0);
        Vec3 d = new Vec3(Math.cos(a), 0, Math.sin(a)).scale(1.3);
        return new Vec3[]{m.subtract(d), m.add(d)};
    }

    private static Vec3 gojoPos(Scene s, int t) {
        if (t < T_WALK_END) return s.at(-26, 0, 0).lerp(s.at(-7, 0, 0), k(t, 0, T_WALK_END - 2));
        if (t < T_DASH) return s.at(-7, 0, 0);
        if (t < T_TRADE) return s.at(-7, 0, 0).lerp(s.at(-1.3, 0, 0), ease(k(t, T_DASH, T_IMPACT)));
        if (t < T_TRADE_END) return trade(s, t)[0];
        if (t < T_BLUE) return trade(s, T_TRADE_END - 1)[0].lerp(s.at(-6, 0, 0), ease(k(t, T_TRADE_END, T_BLUE)));
        if (t < T_BEAT) return s.at(-6, 0, 0);
        if (t < T_BEAT + 10) return s.at(-6, 0, 0).lerp(s.at(7.7, 0, 0), ease(k(t, T_BEAT, T_BEAT + 10)));
        if (t < T_BLACK_FLASH + 30) return s.at(7.7 + 2.0 * k(t, T_BEAT + 10, T_BLACK_FLASH), 0, 0);
        if (t < T_SUMMON + 10) return s.at(9.7, 0, 0).lerp(s.at(-6, 0, 0), ease(k(t, T_BLACK_FLASH + 30, T_SUMMON + 10)));
        if (t < T_BREAK) return s.at(-6, 0, 0);
        if (t < T_GOJO_OUT) return s.at(-6, 0, 0).lerp(s.tower2.add(s.tower2.subtract(s.at(-6, 0, 0)).normalize().scale(1.5)), ease(k(t, T_BREAK, T_BREAK + 16)));
        Vec3 out = s.tower2.add(s.tower2.subtract(s.at(-6, 0, 0)).normalize().scale(1.5));
        if (t < T_PURPLE) return new Vec3(out.x, s.at(0, 0, 0).y, out.z).lerp(s.at(-8, 0, 0), k(t, T_GOJO_OUT, T_GOJO_OUT + 50));
        if (t < T_CHANT) return s.at(-8, 0, 0).lerp(s.at(-8, 12, 0), ease(k(t, T_PURPLE, T_CHANT)));
        if (t < T_LAND) return s.at(-8, 12, 0);
        if (t < T_LAND + 40) return s.at(-8, 12, 0).lerp(s.at(-8, 0, 0), ease(k(t, T_LAND, T_LAND + 40)));
        return s.at(-8, 0, 0);
    }

    private static Vec3 sukunaPos(Scene s, int t) {
        if (t < T_DASH) return s.at(9, 0, 0);
        if (t < T_TRADE) return s.at(9, 0, 0).lerp(s.at(1.3, 0, 0), ease(k(t, T_DASH, T_IMPACT)));
        if (t < T_TRADE_END) return trade(s, t)[1];
        if (t < T_BLUE + 10) return trade(s, T_TRADE_END - 1)[1].lerp(s.at(6, 0, 0), ease(k(t, T_TRADE_END, T_BLUE)));
        if (t < T_RED) return s.at(6, 0, 0).lerp(s.at(-3.6, 0.3, 0), ease(k(t, T_BLUE + 10, T_RED - 4)));
        Vec3 in = s.tower1.add(s.tower1.subtract(s.at(-3.6, 0.3, 0)).normalize().scale(2));
        if (t < T_EMERGE) return s.at(-3.6, 0.3, 0).lerp(in, ease(k(t, T_RED, T_IN_TOWER)));
        if (t < T_EMERGE + 40) return new Vec3(in.x, s.at(0, 0, 0).y, in.z).lerp(s.at(9, 0, 0), k(t, T_EMERGE, T_EMERGE + 40));
        if (t < T_BEAT + 10) return s.at(9, 0, 0);
        if (t < T_BLACK_FLASH) return s.at(9.4 + 2.0 * k(t, T_BEAT + 10, T_BLACK_FLASH), 0, 0);
        if (t < T_PURPLE_HIT) return s.at(11.4, 0, 0).lerp(s.at(14, 0, 0), ease(k(t, T_BLACK_FLASH, T_BLACK_FLASH + 8)));
        if (t < T_RISE_S + 10) return s.at(14, 0, 0).lerp(s.at(16, 0, 7), ease(k(t, T_PURPLE_HIT, T_PURPLE_HIT + 12)));
        if (t < T_BACK) return s.at(16, 0, 7).lerp(s.at(12, 0, 6), k(t, T_RISE_S + 10, T_RISE_S + 50));
        return s.at(12, 0, 6).lerp(s.at(-5.4, 0, 1.0), k(t, T_BACK, T_BACK + 70));
    }

    private static Vec3 mahoPos(Scene s, int t) {
        if (t < T_MAHO_GO) return s.at(11, 0, 3);
        if (t < T_BREAK + 20) return s.at(11, 0, 3).lerp(s.at(-2.4, 0, 0.3), ease(k(t, T_MAHO_GO, T_MAHO_GO + 26)));
        if (t < T_PURPLE) return s.at(-2.4, 0, 0.3).lerp(s.at(8, 0, 2), k(t, T_BREAK + 20, T_BREAK + 60));
        return s.at(8, 0, 2).lerp(s.at(11, 0, 3), k(t, T_PURPLE, T_PURPLE + 30));
    }

    private static void face(LivingEntity e, Vec3 at) {
        float yaw = CinematicDirector.yawTowards(e.position(), at);
        e.setYRot(yaw); e.yRotO = yaw; e.setYBodyRot(yaw); e.setYHeadRot(yaw);
    }

    private static void sound(ServerLevel sl, Vec3 p, SoundEvent e, float vol, float pitch) { sl.playSound(null, BlockPos.containing(p), e, SoundSource.HOSTILE, vol, pitch); }

    /** v1.0.24: a ring of dust and flying debris for the big hits (cheap: one ring of particles and one burst). */
    private static void shockwave(ServerLevel sl, Vec3 c, double r) {
        for (int i = 0; i < 40; i++) {
            double a = i / 40.0 * Math.PI * 2;
            sl.sendParticles(ParticleTypes.CLOUD, c.x + Math.cos(a) * r, c.y + 0.3, c.z + Math.sin(a) * r, 1, 0.1, 0.1, 0.1, 0.02);
        }
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.GRAY_CONCRETE.defaultBlockState()), c.x, c.y, c.z, 30, r * 0.4, 0.3, r * 0.4, 0.3);
    }
    private static void fx(ServerPlayer sp, int type, int dur, float k) { ModNetwork.sendTo(sp, new ScreenFxPacket(type, dur, k)); }

    private static void run(Scene s, ServerPlayer sp) {
        ServerLevel sl = s.level;
        int t = s.tick;
        GojoEntity gojo = sl.getEntity(s.gojoId) instanceof GojoEntity g ? g : null;
        SukunaEntity suk = sl.getEntity(s.sukunaId) instanceof SukunaEntity k ? k : null;
        MahoragaEntity maho = sl.getEntity(s.mahoId) instanceof MahoragaEntity m ? m : null;
        if (gojo == null || suk == null) return;
        Vec3 G = gojoPos(s, t), S = sukunaPos(s, t);
        gojo.moveTo(G.x, G.y, G.z, gojo.getYRot(), 0);
        suk.moveTo(S.x, S.y, S.z, suk.getYRot(), 0);
        face(gojo, maho != null && t >= T_MAHO_GO && t < T_PURPLE ? maho.position() : S);
        face(suk, G);
        if (maho != null && maho.getState() != MahoragaEntity.STATE_DEAD) {
            Vec3 M = mahoPos(s, t);
            maho.moveTo(M.x, M.y, M.z, maho.getYRot(), 0);
            face(maho, G);
        }
        Vec3 mid = G.lerp(S, 0.5).add(0, 1.3, 0);

        // ---- 1. Gojo walks into Shinjuku. "Nah, I'd win."
        if (t == 1) { gojo.setState(GojoEntity.STATE_WALK); suk.setState(SukunaEntity.STATE_IDLE); }
        if (t == T_WALK_END) gojo.setState(GojoEntity.STATE_IDLE);
        if (t == T_S1) sound(sl, S, ModSounds.SUKUNA_VOICE.get(), 1.4f, 0.9f);
        if (t == T_LAUGH) { suk.setState(SukunaEntity.STATE_TAUNT); sound(sl, S, ModSounds.SUKUNA_LAUGH.get(), 1.6f, 1.0f); }
        // ---- 2. the first clash and the exchange
        if (t == T_DASH) { gojo.setState(GojoEntity.STATE_RUN); suk.setState(SukunaEntity.STATE_DASH); sound(sl, mid, ModSounds.BOSS_THEME.get(), 1.0f, 1.0f); }
        if (t == T_IMPACT) {
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
            shockwave(sl, mid, 5);
            sl.sendParticles(ParticleTypes.SWEEP_ATTACK, mid.x, mid.y, mid.z, 12, 1.5, 0.6, 1.5, 0);
            sl.sendParticles(ParticleTypes.CLOUD, mid.x, mid.y - 1.2, mid.z, 40, 2.5, 0.1, 2.5, 0.35);
            sound(sl, mid, SoundEvents.GENERIC_EXPLODE, 2.5f, 0.7f);
            fx(sp, ScreenFxPacket.SHAKE, 20, 1.0f);
            gojo.setState(GojoEntity.STATE_IDLE); suk.setState(SukunaEntity.STATE_COMBO);
        }
        if (t > T_TRADE && t < T_TRADE_END && t % 8 == 0) {
            if ((t / 8) % 2 == 0) gojo.triggerAnim("main", "attack"); else suk.triggerAnim("main", "attack");
            sl.sendParticles(ParticleTypes.CRIT, mid.x, mid.y, mid.z, 14, 0.4, 0.4, 0.4, 0.5);
            if (t % 24 == 0) sl.sendParticles(ParticleTypes.SONIC_BOOM, mid.x, mid.y, mid.z, 1, 0, 0, 0, 0);
            sound(sl, mid, SoundEvents.PLAYER_ATTACK_STRONG, 1.6f, 0.6f + (t % 3) * 0.1f);
            if (t % 16 == 0) fx(sp, ScreenFxPacket.SHAKE, 6, 0.4f);
        }
        if (t == T_TRADE_END) { suk.setState(SukunaEntity.STATE_IDLE); gojo.setState(GojoEntity.STATE_IDLE); }
        // ---- 3. Blue pulls him in, Red blows him through a tower
        if (t == T_BLUE) { gojo.setState(GojoEntity.STATE_BLUE); sound(sl, G, SoundEvents.BEACON_ACTIVATE, 2.0f, 1.8f); }
        if (t > T_BLUE && t < T_RED && t % 2 == 0) {
            Vec3 o = S.add(0, 1.2, 0);
            sl.sendParticles(GojoLogic.BLUE_DUST, o.x, o.y, o.z, 16, 0.5, 0.5, 0.5, 0.02);
            sl.sendParticles(ParticleTypes.PORTAL, o.x, o.y, o.z, 10, 1.5, 1.5, 1.5, -0.8);
        }
        if (t == T_BLUE + 10) suk.setState(SukunaEntity.STATE_RECOIL);
        if (t == T_RED) {
            gojo.setState(GojoEntity.STATE_RED);
            Vec3 o = S.add(0, 1.2, 0);
            sl.sendParticles(GojoLogic.RED_DUST, o.x, o.y, o.z, 120, 1.2, 1.2, 1.2, 0.3);
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, o.x, o.y, o.z, 1, 0, 0, 0, 0);
            sound(sl, o, SoundEvents.GENERIC_EXPLODE, 3.0f, 0.8f);
            fx(sp, ScreenFxPacket.SHAKE, 24, 1.2f);
            Vec3 from = s.at(-3.6, 1.2, 0), to = s.tower1.add(s.tower1.subtract(from).normalize().scale(3));
            ShinjukuCity.carveTube(from.lerp(to, 0.55), to, 2.3);
        }
        if (t == T_IN_TOWER) {
            Vec3 h = s.tower1;
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, h.x, h.y, h.z, 1, 0, 0, 0, 0);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, h.x, h.y, h.z, 60, 2.5, 2.5, 2.5, 0.05);
            sound(sl, h, SoundEvents.GENERIC_EXPLODE, 3.0f, 0.5f);
            sound(sl, h, SoundEvents.GLASS_BREAK, 3.0f, 0.6f);
        }
        if (t == T_EMERGE) suk.setState(SukunaEntity.STATE_WALK);
        if (t == T_EMERGE + 40) { suk.setState(SukunaEntity.STATE_IDLE); gojo.setState(GojoEntity.STATE_IDLE); }
        if (t == T_S2) sound(sl, S, ModSounds.SUKUNA_LAUGH.get(), 1.6f, 0.9f);
        // ---- 4. Dismantle against Infinity: the slashes stop, the towers behind him do not
        if (t == T_DISMANTLE - 5) gojo.setState(GojoEntity.STATE_INFINITY);
        if (t == T_DISMANTLE || t == T_DISMANTLE + 15 || t == T_DISMANTLE + 30) {
            suk.triggerAnim("main", "slash");
            sound(sl, S, ModSounds.DISMANTLE.get(), 2.0f, 1.0f);
            Vec3 a = S.add(0, 1.3, 0), b = G.add(0, 1.3, 0);
            for (int i = 0; i < 8; i++) { Vec3 p = a.lerp(b, i / 8.0 * 0.85); sl.sendParticles(ModParticles.SLASH.get(), p.x, p.y, p.z, 2, 0.2, 0.4, 0.2, 0); }
            Vec3 stop = b.add(a.subtract(b).normalize().scale(0.9));
            sl.sendParticles(ParticleTypes.END_ROD, stop.x, stop.y, stop.z, 20, 0.3, 0.6, 0.3, 0.05);
            sound(sl, G, ModSounds.GOJO_INFINITY.get(), 1.2f, 1.4f);
            if (t == T_DISMANTLE) { ShinjukuCity.carveCut(s.at(-30, 0, 8), s.at(-8, 0, 30), s.c.getY() + 3, s.c.getY() + 34); shockwave(sl, G, 3); }
            if (t == T_DISMANTLE + 15) ShinjukuCity.carveCut(s.at(-30, 0, -8), s.at(-8, 0, -30), s.c.getY() + 5, s.c.getY() + 40);
        }
        // ---- 5. Domain Expansion against Domain Expansion
        if (t == T_DOMAIN_G) { sound(sl, G, ModSounds.DOMAIN_EXPANSION.get(), 2.0f, 1.4f); fx(sp, ScreenFxPacket.WHITE_FLASH, 10, 0.6f); }
        if (t == T_DOMAIN_S) { suk.setState(SukunaEntity.STATE_DOMAIN); suk.triggerAnim("main", "domain"); sound(sl, S, ModSounds.DOMAIN_EXPANSION.get(), 2.0f, 0.7f); fx(sp, ScreenFxPacket.RED_FLASH, 10, 0.6f); }
        if (t == T_CLASH) {
            MalevolentShrineEntity sh = ModEntities.MALEVOLENT_SHRINE.get().create(sl);
            if (sh != null) {
                Vec3 p = s.at(20, 0, 0);
                sh.moveTo(p.x, p.y, p.z, 90, 0);
                sh.setLifetime(T_SUMMON - T_CLASH);
                sl.addFreshEntity(sh);
                s.shrineId = sh.getId();
            }
        }
        if (t >= T_CLASH && t < T_CAUGHT + 20) {
            boolean voidUp = t < T_SHATTER || t >= T_REEXPAND;
            if (voidUp && t % 2 == 0) {
                for (int i = 0; i < 2; i++) {
                    double a = sl.random.nextDouble() * Math.PI * 2, r = 4 + sl.random.nextDouble() * 6;
                    sl.sendParticles(GojoLogic.VOID_DUST, G.x + Math.cos(a) * r, G.y + sl.random.nextDouble() * 6, G.z + Math.sin(a) * r, 3, 0.3, 0.3, 0.3, 0);
                }
                sl.sendParticles(ParticleTypes.END_ROD, G.x, G.y + 3, G.z, 4, 5, 3, 5, 0.01);
            }
            if (t % 3 == 0) {
                double a = sl.random.nextDouble() * Math.PI * 2, r = 2 + sl.random.nextDouble() * 14;
                sl.sendParticles(ModParticles.SLASH.get(), S.x + Math.cos(a) * r, S.y + 0.5 + sl.random.nextDouble() * 4, S.z + Math.sin(a) * r, 2, 0.2, 0.2, 0.2, 0);
            }
            if (t % 10 == 0) sound(sl, mid, ModSounds.DOMAIN_SLASH.get(), 1.4f, 0.8f + sl.random.nextFloat() * 0.4f);
        }
        if (t == T_SHATTER) { fx(sp, ScreenFxPacket.WHITE_FLASH, 14, 1.0f); sound(sl, G, SoundEvents.GLASS_BREAK, 3.0f, 0.5f); sl.sendParticles(ModParticles.BLOOD.get(), G.x, G.y + 1.6, G.z, 20, 0.1, 0.1, 0.1, 0.05); }
        if (t == T_SHATTER + 20) sound(sl, G, ModSounds.RCT_HEAL.get(), 2.0f, 1.2f);
        if (t == T_REEXPAND) { sound(sl, G, ModSounds.DOMAIN_EXPANSION.get(), 2.0f, 1.6f); fx(sp, ScreenFxPacket.WHITE_FLASH, 10, 0.7f); }
        if (t == T_CAUGHT) { suk.setState(SukunaEntity.STATE_RECOIL); sound(sl, S, ModSounds.HEARTBEAT.get(), 2.0f, 0.8f); }
        // ---- 6. inside the Void, Gojo beats him down. Black Flash.
        if (t == T_BEAT) gojo.setState(GojoEntity.STATE_RUN);
        if (t == T_BEAT + 10) gojo.setState(GojoEntity.STATE_IDLE);
        if (t > T_BEAT + 10 && t < T_BLACK_FLASH + 20 && t % 6 == 0) {
            gojo.triggerAnim("main", "attack");
            Vec3 o = S.add(0, 1.3, 0);
            sl.sendParticles(ModParticles.BLOOD.get(), o.x, o.y, o.z, 10, 0.2, 0.3, 0.2, 0.15);
            sl.sendParticles(ParticleTypes.CRIT, o.x, o.y, o.z, 8, 0.3, 0.3, 0.3, 0.4);
            sound(sl, o, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.6f, 0.7f);
        }
        if (t == T_BLACK_FLASH) {
            Vec3 o = S.add(0, 1.3, 0);
            fx(sp, ScreenFxPacket.BLACK_FLASH, 18, 1.0f);
            fx(sp, ScreenFxPacket.SHAKE, 20, 1.3f);
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, o.x, o.y, o.z, 1, 0, 0, 0, 0);
            shockwave(sl, o, 6);
            sl.sendParticles(ModParticles.CURSED_ENERGY.get(), o.x, o.y, o.z, 60, 0.6, 0.6, 0.6, 0.4);
            sound(sl, o, SoundEvents.GENERIC_EXPLODE, 2.5f, 1.3f);
        }
        if (t == T_BLACK_FLASH + 30) gojo.setState(GojoEntity.STATE_RUN);
        if (t == T_SUMMON + 10) gojo.setState(GojoEntity.STATE_INFINITY);
        // ---- 7. "With this treasure, I summon..." Mahoraga
        if (t == T_SUMMON) {
            suk.setState(SukunaEntity.STATE_CHARGE);
            sound(sl, S, ModSounds.SUKUNA_VOICE.get(), 1.6f, 0.75f);
            if (sl.getEntity(s.shrineId) instanceof MalevolentShrineEntity sh) sh.discard();
        }
        if (t == T_MAHO) {
            MahoragaEntity m = ModEntities.MAHORAGA.get().create(sl);
            if (m != null) {
                Vec3 p = s.at(11, 0, 3);
                m.setupCinematic(LENGTH);
                m.moveTo(p.x, p.y, p.z, 90, 0);
                m.setState(MahoragaEntity.STATE_RISE);
                sl.addFreshEntity(m);
                s.mahoId = m.getId();
                ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.MAHORAGA, m.getId(), 0, t, 0, 0, 0));
                sl.sendParticles(ParticleTypes.SQUID_INK, p.x, p.y + 0.2, p.z, 80, 2.0, 0.1, 2.0, 0.05);
                sl.sendParticles(ParticleTypes.LARGE_SMOKE, p.x, p.y + 0.5, p.z, 40, 1.5, 0.5, 1.5, 0.02);
                sound(sl, p, SoundEvents.WARDEN_EMERGE, 3.0f, 0.6f);
                fx(sp, ScreenFxPacket.SHAKE, 30, 0.8f);
            }
            suk.setState(SukunaEntity.STATE_IDLE);
        }
        if (maho != null) {
            if (t == T_MAHO_GO) maho.setState(MahoragaEntity.STATE_WALK);
            if (t == T_MAHO_GO + 26) maho.setState(MahoragaEntity.STATE_IDLE);
            if (t == T_MAHO_GO + 20 || t == T_MAHO_GO + 70 || t == T_BREAK - 12) maho.triggerAnim("main", "spin");   // v1.0.24: the wheel turns again and again
            if (t == T_MAHO_GO + 36 || t == T_BREAK + 4) { maho.triggerAnim("main", "slash"); sound(sl, maho.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 2.0f, 0.6f); }   // v1.0.24: sword strikes
            if (t == T_MAHO_GO + 28 || t == T_MAHO_GO + 58 || t == T_BREAK) {
                maho.triggerAnim("main", "punch");
                Vec3 o = G.add(G.subtract(maho.position()).normalize().scale(-0.9)).add(0, 1.4, 0);
                if (t != T_BREAK) {
                    sl.sendParticles(ParticleTypes.END_ROD, o.x, o.y, o.z, 24, 0.2, 0.5, 0.2, 0.08);
                    sound(sl, o, ModSounds.GOJO_INFINITY.get(), 1.6f, 1.2f);
                } else {   // the wheel has turned: the fist goes through Infinity
                    sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, o.x, o.y, o.z, 1, 0, 0, 0, 0);
                    shockwave(sl, o, 4);
                    sl.sendParticles(ModParticles.BLOOD.get(), o.x, o.y, o.z, 40, 0.3, 0.3, 0.3, 0.3);
                    sound(sl, o, SoundEvents.GENERIC_EXPLODE, 3.0f, 0.6f);
                    fx(sp, ScreenFxPacket.SHAKE, 26, 1.3f);
                    gojo.setState(GojoEntity.STATE_STABBED);
                    Vec3 from = s.at(-6, 1.2, 0), to = s.tower2.add(s.tower2.subtract(from).normalize().scale(3));
                    ShinjukuCity.carveTube(from.lerp(to, 0.5), to, 2.3);
                }
            }
            if (t == T_ADAPT) {
                maho.triggerAnim("main", "adapt");
                Vec3 w = maho.position().add(0, 6.5, 0);
                sound(sl, w, SoundEvents.BELL_BLOCK, 3.0f, 0.5f);
                sl.sendParticles(ParticleTypes.ENCHANT, w.x, w.y, w.z, 60, 1.5, 0.4, 1.5, 0.5);
            }
            if (t == T_BREAK + 20) maho.setState(MahoragaEntity.STATE_WALK);
            if (t == T_BREAK + 60) maho.setState(MahoragaEntity.STATE_IDLE);
        }
        if (t == T_BREAK + 16) { Vec3 h = s.tower2; sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, h.x, h.y, h.z, 1, 0, 0, 0, 0); sound(sl, h, SoundEvents.GLASS_BREAK, 3.0f, 0.5f); }
        if (t == T_GOJO_OUT) gojo.setState(GojoEntity.STATE_WALK);
        if (t == T_GOJO_OUT + 10) sound(sl, G, ModSounds.RCT_HEAL.get(), 2.0f, 1.0f);
        if (t == T_GOJO_OUT + 50) gojo.setState(GojoEntity.STATE_IDLE);
        // ---- 8. Hollow Purple, 200%
        if (t == T_PURPLE) { gojo.setState(GojoEntity.STATE_INFINITY); sound(sl, G, SoundEvents.BEACON_POWER_SELECT, 2.0f, 0.5f); }
        if (t == T_CHANT) gojo.setState(GojoEntity.STATE_PURPLE);
        if (t > T_CHANT && t < T_FIRE) {
            Vec3 dir = S.subtract(G).normalize(), right = new Vec3(-dir.z, 0, dir.x);
            Vec3 c = G.add(0, 1.5, 0).add(dir.scale(1.2));
            double spread = Math.max(0, 2.2 - (t - T_CHANT) * 0.02);
            if (t % 2 == 0) {
                Vec3 r = c.add(right.scale(spread)), b = c.add(right.scale(-spread));
                sl.sendParticles(GojoLogic.RED_DUST, r.x, r.y, r.z, 6, 0.15, 0.15, 0.15, 0);
                sl.sendParticles(GojoLogic.BLUE_DUST, b.x, b.y, b.z, 6, 0.15, 0.15, 0.15, 0);
            }
            if (t > T_FIRE - 40) { double rr = 0.4 + (t - (T_FIRE - 40)) * 0.05; sl.sendParticles(GojoLogic.PURPLE_DUST, c.x, c.y, c.z, 14, rr, rr, rr, 0); }
            if (t % 20 == 0) sound(sl, G, SoundEvents.BEACON_AMBIENT, 2.0f, 0.5f + (t - T_CHANT) / 280f);
        }
        if (t >= T_FIRE && t <= T_PURPLE_HIT) {
            Vec3 a = G.add(0, 1.5, 0), b = s.at(11, 1, 2);
            Vec3 p = a.lerp(b, (t - T_FIRE) / (double) (T_PURPLE_HIT - T_FIRE));
            sl.sendParticles(GojoLogic.PURPLE_DUST, p.x, p.y, p.z, 40, 1.4, 1.4, 1.4, 0.02);
            if (t == T_FIRE) { sound(sl, G, SoundEvents.WARDEN_SONIC_BOOM, 3.0f, 0.5f); fx(sp, ScreenFxPacket.SHAKE, 30, 1.0f); }
        }
        if (t == T_PURPLE_HIT) {
            Vec3 a = G.add(0, 1.5, 0), b = s.at(11, 1, 2);
            Vec3 dir = b.subtract(a).normalize();
            ShinjukuCity.carveTube(a.lerp(b, 0.45), b.add(dir.scale(16)), 4.2);
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, b.x, b.y, b.z, 3, 2, 1, 2, 0);
            shockwave(sl, b, 9);
            sl.sendParticles(GojoLogic.PURPLE_DUST, b.x, b.y, b.z, 200, 3, 2, 3, 0.3);
            sound(sl, b, SoundEvents.GENERIC_EXPLODE, 4.0f, 0.4f);
            fx(sp, ScreenFxPacket.WHITE_FLASH, 22, 1.0f);
            fx(sp, ScreenFxPacket.SHAKE, 40, 1.6f);
            suk.setState(SukunaEntity.STATE_RECOIL);
            if (maho != null) maho.setState(MahoragaEntity.STATE_DEAD);
        }
        if (t > T_PURPLE_HIT && t < T_LAND + 40 && t % 4 == 0) {
            Vec3 b = s.at(11, 1, 2);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, b.x, b.y, b.z, 10, 3, 1.5, 3, 0.02);
        }
        if (t == T_LAND + 40 && maho != null) {
            sl.sendParticles(ParticleTypes.SQUID_INK, maho.getX(), maho.getY() + 1, maho.getZ(), 60, 1.5, 1.0, 1.5, 0.05);
            maho.discard();
        }
        if (t == T_LAND) gojo.setState(GojoEntity.STATE_IDLE);
        // ---- 9. "Mahoraga already showed me the answer." The World-Cutting Slash.
        if (t == T_RISE_S) { suk.setState(SukunaEntity.STATE_IDLE); sound(sl, S, ModSounds.SUKUNA_VOICE.get(), 1.6f, 0.85f); }
        if (t == T_RISE_S + 10) suk.setState(SukunaEntity.STATE_WALK);
        if (t == T_RISE_S + 50) suk.setState(SukunaEntity.STATE_IDLE);
        if (t == T_WCS) { suk.setState(SukunaEntity.STATE_DOMAIN); suk.triggerAnim("main", "domain"); }
        if (t == T_WCS || t == T_WCS + 25 || t == T_WCS + 50) sound(sl, S, ModSounds.CINEMATIC_STING.get(), 1.4f, 0.6f);
        if (t == T_CUT) {
            suk.setState(SukunaEntity.STATE_SLASH); suk.triggerAnim("main", "slash");
            gojo.setState(GojoEntity.STATE_CUT);
            sound(sl, G, ModSounds.WORLD_SLASH.get(), 4.0f, 1.0f);
            sound(sl, G, ModSounds.CINEMATIC_SLASH.get(), 4.0f, 0.8f);
            fx(sp, ScreenFxPacket.WHITE_FLASH, 8, 1.0f);
            fx(sp, ScreenFxPacket.SHAKE, 30, 1.4f);
            double a = Math.toRadians(20);
            Vec3 d = new Vec3(Math.sin(a), 0, Math.cos(a));
            ShinjukuCity.carveCut(G.subtract(d.scale(ShinjukuCity.R)), G.add(d.scale(ShinjukuCity.R)), s.c.getY() + 2, s.c.getY() + 48);
            shockwave(sl, G, 8);
            sl.sendParticles(ModParticles.BLOOD.get(), G.x, G.y + 1.2, G.z, 80, 0.3, 0.4, 0.3, 0.3);
        }
        if (t == T_CUT + 20) { sound(sl, G, ModSounds.BLOOD_SPLATTER.get(), 2.0f, 0.8f); suk.setState(SukunaEntity.STATE_IDLE); }
        if (t > T_CUT && t < T_AIRPORT && t % 5 == 0) sl.sendParticles(ModParticles.BLOOD.get(), G.x, G.y + 0.4, G.z, 6, 0.4, 0.1, 0.4, 0.05);
        // ---- 10. the airport, then Sukuna over the body
        if (t == T_BACK) suk.setState(SukunaEntity.STATE_WALK);
        if (t == T_BACK + 70) suk.setState(SukunaEntity.STATE_IDLE);
        if (t == T_BACK + 45) sound(sl, S, ModSounds.SUKUNA_VOICE.get(), 1.4f, 0.8f);
    }

    // ------------------------------------------------------------------ the end: now you are Sukuna
    private static void finish(ServerPlayer sp, Scene s) {
        ServerLevel sl = s.level;
        Vec3 corpse = s.at(-8, 0, 0);
        if (sl.getEntity(s.gojoId) instanceof GojoEntity g) {
            g.moveTo(corpse.x, corpse.y, corpse.z, 90, 0);
            g.makeCorpse();
        }
        if (sl.getEntity(s.sukunaId) instanceof SukunaEntity k) k.discard();
        if (sl.getEntity(s.mahoId) instanceof MahoragaEntity m) m.discard();
        if (sl.getEntity(s.shrineId) instanceof MalevolentShrineEntity sh) sh.discard();
        ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.STOP, 0, 0, 0, 0, 0, 0));
        finishData(sp, s);
    }

    private static void cleanup(Scene s) {
        ServerLevel sl = s.level;
        if (sl.getEntity(s.sukunaId) instanceof SukunaEntity k) k.discard();
        if (sl.getEntity(s.mahoId) instanceof MahoragaEntity m) m.discard();
        if (sl.getEntity(s.shrineId) instanceof MalevolentShrineEntity sh) sh.discard();
        if (sl.getEntity(s.gojoId) instanceof GojoEntity g) g.makeCorpse();
    }

    private static void finishData(ServerPlayer sp, Scene s) {
        sp.setNoGravity(false);
        sp.removeEffect(MobEffects.INVISIBILITY);
        Vec3 stand = s.at(-5.4, 0, 1.0);
        float yaw = CinematicDirector.yawTowards(stand, s.at(-8, 0, 0));
        sp.connection.teleport(stand.x, stand.y, stand.z, yaw, 10);
        sp.fallDistance = 0;
        CursedData d = KocSync.data(sp);
        d.setSide(CursedData.SIDE_HISTORY);
        d.setFingerMask((1 << 15) - 1);   // Shinjuku: fifteen fingers
        d.setIntroSeen(true);
        PowerScaling.apply(sp, d);
        d.setEnergy(d.maxEnergy());
        MobileControls.giveUnlocked(sp, d);
        KocSync.sync(sp);
        BlockPos home = BlockPos.containing(stand);
        sp.setRespawnPosition(Level.OVERWORLD, home, yaw, true, false);
        s.level.setDefaultSpawnPos(home, yaw);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.fullfight_start").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.fullfight_start2").withStyle(ChatFormatting.GRAY), false);
        if (d.controlMode() == CursedData.CONTROL_NONE)
            ModNetwork.sendTo(sp, new com.kingofcurses.network.OpenScreenPacket(com.kingofcurses.network.OpenScreenPacket.CONTROL_MODE));
    }
}
