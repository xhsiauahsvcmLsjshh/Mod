package com.kingofcurses.ability;

import com.kingofcurses.capability.CursedData;
import com.kingofcurses.entity.CinematicActorEntity;
import com.kingofcurses.entity.NamedSorcererEntity;
import com.kingofcurses.network.FullFightPacket;
import com.kingofcurses.network.ModNetwork;
import com.kingofcurses.network.OpenScreenPacket;
import com.kingofcurses.network.ScreenFxPacket;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModParticles;
import com.kingofcurses.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * v1.0.24 SENDAI COLONY video (world mode 3, Pick Your Side). The same ruined Shinjuku, at night: Yuta Okkotsu vs Ryu Ishigori,
 * with Rika behind Yuta. It opens on the clash of the two beams (Granite Blast against Yuta and Rika), then the exchange,
 * Rika's punch, Yuta's sky-cut, the grab and the crater, and it ends with Ryu's own Granite Blast coming back down on him.
 * Afterwards the player stands in the ruins at night with full energy, and the game goes on from there.
 */
public final class SendaiDirector {
    public static final int LENGTH = 1200;
    public static final int T_YUTA_IN = 60, T_RYU_IN = 115, T_RIKA_CAM = 90, T_CHARGE = 175, T_RING = 200, T_FIRE = 230, T_COUNTER = 236,
            T_CLASH = 262, T_PUSH = 330, T_DASH = 372, T_TRADE = 400, T_TRADE_END = 470, T_SKY = 520, T_HIT = 585, T_RIKA_HIT = 612,
            T_RIKA_VANISH = 636, T_RIKA_GONE = 680, T_GRAB = 692, T_SLAM = 722, T_RETURN = 780, T_RETURN_HIT = 794, T_RYU_DOWN = 830,
            T_BYE = 1000, T_END = LENGTH;

    static final DustParticleOptions RYU_BEAM = new DustParticleOptions(new Vector3f(0.92f, 0.95f, 1.0f), 2.2f);
    static final DustParticleOptions YUTA_BEAM = new DustParticleOptions(new Vector3f(0.42f, 0.28f, 1.0f), 2.2f);

    private static final Map<UUID, Scene> SCENES = new HashMap<>();

    static final class Scene {
        final UUID player; final ServerLevel level; final BlockPos c; final Vec3 watch;
        int tick, yutaId = -1, ryuId = -1, rikaId = -1;
        Scene(UUID p, ServerLevel l, BlockPos c) {
            player = p; level = l; this.c = c;
            watch = new Vec3(c.getX() + 0.5, c.getY() + 22, c.getZ() + 24.5);
        }
        Vec3 at(double u, double y, double v) { return new Vec3(c.getX() + 0.5 + u, c.getY() + 1 + y, c.getZ() + 0.5 + v); }
    }

    private SendaiDirector() {}

    public static boolean isInScene(UUID id) { return SCENES.containsKey(id); }
    public static void clear() { SCENES.clear(); }

    public static void skip(ServerPlayer sp) {
        Scene s = SCENES.remove(sp.getUUID());
        if (s != null) finish(sp, s);
    }

    /** Called by the Shinjuku loader once the city is ready (world mode 3). */
    public static void start(ServerPlayer sp, BlockPos c) {
        ServerLevel sl = sp.serverLevel();
        Scene s = new Scene(sp.getUUID(), sl, c);
        sl.setDayTime(18000);                              // night
        sl.setWeatherParameters(12000, 0, false, false);
        ShinjukuCity.ruin(44);                             // the same city, in ruins
        NamedSorcererEntity yuta = ModEntities.YUTA_OKKOTSU.get().create(sl);
        CinematicActorEntity ryu = ModEntities.RYU_ISHIGORI.get().create(sl);
        CinematicActorEntity rika = ModEntities.RIKA_ORIMOTO.get().create(sl);
        if (yuta == null || ryu == null || rika == null) { finish(sp, s); return; }
        yuta.setActor(NamedSorcererEntity.ACTOR_STITCH);
        ryu.setupActor(); rika.setupActor();
        Vec3 y0 = s.at(-34, 0, 0), r0 = s.at(38, 0, 0), k0 = s.at(-36, 3, 0);
        yuta.moveTo(y0.x, y0.y, y0.z, 90, 0);
        ryu.moveTo(r0.x, r0.y, r0.z, -90, 0);
        rika.moveTo(k0.x, k0.y, k0.z, 90, 0);
        sl.addFreshEntity(yuta); sl.addFreshEntity(ryu); sl.addFreshEntity(rika);
        s.yutaId = yuta.getId(); s.ryuId = ryu.getId(); s.rikaId = rika.getId();
        sp.setNoGravity(true);
        sp.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, LENGTH + 60, 0, true, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, LENGTH + 60, 4, true, false, false));
        sp.connection.teleport(s.watch.x, s.watch.y, s.watch.z, 180, 20);
        SCENES.put(sp.getUUID(), s);
        ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.SENDAI_START, yuta.getId(), ryu.getId(), rika.getId(), c.getX(), c.getY(), c.getZ()));
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Scene>> it = SCENES.entrySet().iterator();
        while (it.hasNext()) {
            Scene s = it.next().getValue();
            ServerPlayer sp = server.getPlayerList().getPlayer(s.player);
            if (sp == null || sp.level() != s.level) { cleanup(s); it.remove(); continue; }
            s.tick++;
            if (sp.position().distanceToSqr(s.watch) > 0.5) sp.connection.teleport(s.watch.x, s.watch.y, s.watch.z, 180, 20);
            sp.setDeltaMovement(Vec3.ZERO); sp.fallDistance = 0;
            if (s.tick % 20 == 0) ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.SYNC, 0, 0, s.tick, 0, 0, 0));
            if (s.tick % 40 == 0) for (Entity e : s.level.getEntities((Entity) null, new AABB(s.c).inflate(ShinjukuCity.R + 10, 60, ShinjukuCity.R + 10), e -> e instanceof Enemy)) e.discard();
            try { run(s); } catch (RuntimeException ex) {
                com.kingofcurses.KingOfCurses.LOGGER.error("Sendai video error, skipping", ex);
                it.remove(); finish(sp, s); continue;
            }
            if (s.tick >= T_END) { it.remove(); finish(sp, s); }
        }
    }

    // ------------------------------------------------------------------ positions
    private static double ease(double t) { t = Mth.clamp(t, 0, 1); return t * t * (3 - 2 * t); }
    private static double k(int t, int a, int b) { return Mth.clamp((t - a) / (double) (b - a), 0, 1); }

    /** The exchange of blows: both circle a point, six blocks apart. Returns {yuta, ryu}. */
    private static Vec3[] trade(Scene s, int t) {
        double a = (t - T_TRADE) * 0.05;
        Vec3 m = s.at(0, Math.max(0, Math.sin(t * 0.12)) * 1.2, Math.cos(t * 0.05) * 1.5);
        Vec3 d = new Vec3(Math.cos(a), 0, Math.sin(a)).scale(3.0);
        return new Vec3[]{m.subtract(d), m.add(d)};
    }

    static Vec3 yutaPos(Scene s, int t) {
        if (t < T_YUTA_IN) return s.at(-34, 0, 0);
        if (t < 110) return s.at(-34, 0, 0).lerp(s.at(-13, 0, 0), ease(k(t, T_YUTA_IN, 110)));
        if (t < T_PUSH) return s.at(-13, 0, 0);
        if (t < T_PUSH + 30) return s.at(-13, 0, 0).lerp(s.at(-22, 0, 0), ease(k(t, T_PUSH, T_PUSH + 30)));
        if (t < T_DASH) return s.at(-22, 0, 0);
        if (t < T_TRADE) return s.at(-22, 0, 0).lerp(s.at(-4, 0, 0), ease(k(t, T_DASH, T_TRADE)));
        if (t < T_TRADE_END) return trade(s, t)[0];
        if (t < T_SKY) return trade(s, T_TRADE_END - 1)[0].lerp(s.at(-4, 0, 0), ease(k(t, T_TRADE_END, T_SKY)));
        if (t < T_HIT - 12) return s.at(-4, 0, 0).add(0, 4.5 * ease(k(t, T_SKY, T_SKY + 30)) * (1 - ease(k(t, T_HIT - 60, T_HIT - 12))), 0);
        if (t < T_HIT) return s.at(-4, 0, 0).lerp(s.at(2.2, 0, 0), ease(k(t, T_HIT - 12, T_HIT)));
        if (t < T_SLAM + 10) return s.at(2.2, 0, 0);
        if (t < T_RETURN) return s.at(2.2, 0, 0).lerp(s.at(-10, 0, 0), ease(k(t, T_SLAM + 10, T_RETURN)));
        if (t < T_BYE) return s.at(-10, 0, 0);
        return s.at(-10, 0, 0).lerp(s.at(-30, 0, 0), ease(k(t, T_BYE, T_END)));
    }

    static Vec3 ryuPos(Scene s, int t) {
        if (t < T_RYU_IN) return s.at(38, 0, 0);
        if (t < 150) return s.at(38, 0, 0).lerp(s.at(13, 0, 0), ease(k(t, T_RYU_IN, 150)));
        if (t < T_PUSH) return s.at(13, 0, 0);
        if (t < T_DASH) return s.at(13, 0, 0).lerp(s.at(8, 0, 0), ease(k(t, T_PUSH, T_DASH)));
        if (t < T_TRADE) return s.at(8, 0, 0);
        if (t < T_TRADE_END) return trade(s, t)[1];
        return trade(s, T_TRADE_END - 1)[1].lerp(s.at(4, 0, 0), ease(k(t, T_TRADE_END, T_SKY)));
    }

    /** Rika floats behind Yuta, a little above him, and bobs. */
    static Vec3 rikaPos(Scene s, int t, Vec3 yuta, Vec3 ryu) {
        Vec3 dir = new Vec3(ryu.x - yuta.x, 0, ryu.z - yuta.z);
        Vec3 back = dir.lengthSqr() < 0.01 ? new Vec3(-1, 0, 0) : dir.normalize().reverse();
        double bob = Math.sin(t * 0.09) * 0.35;
        if (t >= T_RIKA_GONE) return s.at(-36, 3, 0);
        if (t >= T_RIKA_HIT && t < T_RIKA_VANISH) return ryu.add(new Vec3(-3.4, 1.4, 0));   // she is hit by Ryu and flies back
        return yuta.add(back.scale(2.0)).add(0, 2.6 + bob, 0);
    }

    static float yaw(Vec3 from, Vec3 to) { return CinematicDirector.yawTowards(from, to); }

    // ------------------------------------------------------------------ the choreography
    private static void run(Scene s) {
        ServerLevel sl = s.level;
        int t = s.tick;
        NamedSorcererEntity yuta = sl.getEntity(s.yutaId) instanceof NamedSorcererEntity y ? y : null;
        CinematicActorEntity ryu = sl.getEntity(s.ryuId) instanceof CinematicActorEntity r ? r : null;
        CinematicActorEntity rika = sl.getEntity(s.rikaId) instanceof CinematicActorEntity k ? k : null;
        if (yuta == null || ryu == null) return;
        Vec3 Y = yutaPos(s, t), R = ryuPos(s, t);
        Vec3 K = rikaPos(s, t, Y, R);
        float yy = yaw(Y, R), ry = yaw(R, Y);
        yuta.moveTo(Y.x, Y.y, Y.z, yy, 0); yuta.setYHeadRot(yy); yuta.setYBodyRot(yy);
        ryu.moveTo(R.x, R.y, R.z, ry, 0); ryu.setYHeadRot(ry); ryu.setYBodyRot(ry);
        if (rika != null && t < T_RIKA_GONE) { rika.moveTo(K.x, K.y, K.z, yy, 0); rika.setYHeadRot(yy); rika.setYBodyRot(yy); }
        Vec3 mid = Y.lerp(R, 0.5);
        Vec3 clash = s.at(0, 1.6, 0);
        Vec3 ryuMouth = R.add(0, 2.1, 0).add(R.subtract(Y).normalize().scale(-0.4));   // the barrel of the pompadour
        Vec3 yutaHand = Y.add(0, 1.5, 0).add(R.subtract(Y).normalize().scale(1.0));

        // ---- 1. they walk in. Rika stands behind Yuta.
        if (t == 2) { yuta.triggerAnim("main", "cast"); }
        if (t == T_RYU_IN) sound(sl, R, ModSounds.CURSE_AMBIENT.get(), 0.9f, 0.7f);
        // ---- 2. Ryu charges the Granite Blast in the pompadour
        if (t == T_CHARGE) { ryu.triggerAnim("main", "cast"); sound(sl, R, ModSounds.CURSED_ENERGY_BURST.get(), 1.4f, 0.6f); }
        if (t > T_CHARGE && t < T_FIRE && t % 2 == 0) {
            sl.sendParticles(RYU_BEAM, ryuMouth.x, ryuMouth.y, ryuMouth.z, 10, 0.25, 0.25, 0.25, 0.02);
            sl.sendParticles(ParticleTypes.END_ROD, ryuMouth.x, ryuMouth.y, ryuMouth.z, 2, 0.2, 0.2, 0.2, 0.02);
        }
        // Yuta puts on the ring and Rika manifests fully
        if (t == T_RING) {
            yuta.triggerAnim("main", "cast");
            if (rika != null) rika.triggerAnim("main", "cast");
            sl.sendParticles(YUTA_BEAM, Y.x, Y.y + 2.4, Y.z, 60, 0.6, 0.8, 0.6, 0.15);
            sound(sl, Y, ModSounds.RCT_HEAL.get(), 1.4f, 0.6f);
        }
        // ---- 3. the two beams: Granite Blast against Yuta's blast
        if (t == T_FIRE) { sound(sl, R, SoundEvents.WARDEN_SONIC_BOOM, 3.0f, 0.5f); fx(s, ScreenFxPacket.SHAKE, 30, 1.0f); }
        if (t >= T_FIRE && t <= T_PUSH + 30) {
            double f = Mth.clamp((t - T_FIRE) / (double) (T_CLASH - T_FIRE), 0, 1);
            Vec3 ryuFront = t < T_CLASH ? ryuMouth.lerp(clash, f) : ryuMouth.lerp(Y.add(0, 1.5, 0), Mth.clamp((t - T_CLASH) / 30.0, 0, 1));
            beam(sl, ryuMouth, ryuFront, RYU_BEAM, 18);
        }
        if (t >= T_COUNTER && t <= T_CLASH + 2) {
            double f = Mth.clamp((t - T_COUNTER) / (double) (T_CLASH - T_COUNTER), 0, 1);
            beam(sl, yutaHand, yutaHand.lerp(clash, f), YUTA_BEAM, 18);
        }
        if (t == T_CLASH) {
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, clash.x, clash.y, clash.z, 2, 1.5, 0.8, 1.5, 0);
            shock(sl, clash, 6, RYU_BEAM);
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.GRAY_CONCRETE.defaultBlockState()), clash.x, clash.y - 1, clash.z, 60, 2.5, 1.0, 2.5, 0.4);
            ShinjukuCity.carveSphere(s.at(0, 0.5, 0), 3.5);
            sound(sl, clash, SoundEvents.GENERIC_EXPLODE, 4.0f, 0.5f);
            sound(sl, clash, ModSounds.CINEMATIC_SLASH.get(), 2.0f, 0.9f);
            fx(s, ScreenFxPacket.WHITE_FLASH, 14, 1.0f);
            fx(s, ScreenFxPacket.SHAKE, 36, 1.5f);
        }
        if (t > T_CLASH && t < T_PUSH && t % 3 == 0) {
            double a = sl.random.nextDouble() * Math.PI * 2, r = 0.5 + sl.random.nextDouble() * 2.5;
            sl.sendParticles(ParticleTypes.CRIT, clash.x + Math.cos(a) * r, clash.y + sl.random.nextDouble() * 1.5, clash.z + Math.sin(a) * r, 4, 0.1, 0.1, 0.1, 0.4);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, clash.x, clash.y, clash.z, 3, 1.5, 1.0, 1.5, 0.02);
        }
        if (t == T_PUSH) { ryu.triggerAnim("main", "attack"); sound(sl, R, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 2.0f, 0.6f); fx(s, ScreenFxPacket.SHAKE, 20, 0.9f); }
        if (t == T_DASH + 30) { ryu.triggerAnim("main", "attack"); sound(sl, R, SoundEvents.PLAYER_ATTACK_STRONG, 2.0f, 0.7f); }   // Ryu catches the blast with his bare hand
        // ---- 4. the exchange
        if (t > T_TRADE && t < T_TRADE_END && t % 8 == 0) {
            if ((t / 8) % 2 == 0) yuta.triggerAnim("main", "slash"); else ryu.triggerAnim("main", "attack");
            Vec3 m = Y.lerp(R, 0.5).add(0, 1.3, 0);
            sl.sendParticles(ParticleTypes.CRIT, m.x, m.y, m.z, 14, 0.4, 0.4, 0.4, 0.5);
            if (t % 16 == 0) fx(s, ScreenFxPacket.SHAKE, 6, 0.4f);
            sound(sl, m, SoundEvents.PLAYER_ATTACK_STRONG, 1.5f, 0.6f + (t % 3) * 0.1f);
        }
        // ---- 5. Yuta rises into the sky, cuts the space open with Uro's technique, and drives the blow into Ryu's chest
        if (t == T_SKY) { sound(sl, Y, ModSounds.CLEAVE.get(), 2.0f, 0.8f); }
        if (t > T_SKY && t < T_HIT && t % 4 == 0) sl.sendParticles(ParticleTypes.END_ROD, Y.x + sl.random.nextGaussian() * 3, s.c.getY() + 40, Y.z + sl.random.nextGaussian() * 3, 2, 1, 0, 1, 0.05);
        if (t == T_HIT) {
            yuta.triggerAnim("main", "slash");
            ryu.triggerAnim("main", "recoil");
            sl.sendParticles(ParticleTypes.CRIT, R.x, R.y + 1.5, R.z, 60, 0.5, 0.5, 0.5, 0.6);
            sl.sendParticles(ParticleTypes.EXPLOSION, R.x, R.y + 1.5, R.z, 1, 0, 0, 0, 0);
            fx(s, ScreenFxPacket.WHITE_FLASH, 10, 0.8f);
            fx(s, ScreenFxPacket.SHAKE, 26, 1.2f);
            sound(sl, R, SoundEvents.GENERIC_EXPLODE, 2.5f, 0.9f);
        }
        if (t == T_HIT + 30 && rika != null) rika.triggerAnim("main", "attack");
        // ---- 6. Rika's punch: Ryu's head opens up
        if (t == T_RIKA_HIT - 8) ryu.triggerAnim("main", "attack");
        if (t == T_RIKA_HIT) {
            if (rika != null) rika.triggerAnim("main", "recoil");
            sl.sendParticles(ParticleTypes.CRIT, R.x, R.y + 1.9, R.z, 40, 0.3, 0.3, 0.3, 0.5);
            sound(sl, R, ModSounds.BLOOD_SPLATTER.get(), 1.6f, 0.9f);
            fx(s, ScreenFxPacket.RED_FLASH, 8, 0.5f);
        }
        if (t > T_RIKA_HIT && t < T_RIKA_GONE && t % 4 == 0) sl.sendParticles(ModParticles.BLOOD.get(), R.x, R.y + 1.9, R.z, 6, 0.2, 0.2, 0.2, 0.05);
        if (t == T_RIKA_VANISH && rika != null) { rika.triggerAnim("main", "vanish"); sl.sendParticles(ParticleTypes.PORTAL, K.x, K.y, K.z, 80, 0.8, 1.2, 0.8, 0.6); }
        if (t == T_RIKA_GONE && rika != null) { sl.sendParticles(ParticleTypes.SQUID_INK, K.x, K.y, K.z, 40, 1, 1, 1, 0.05); rika.discard(); }
        // ---- 7. one on one. Yuta seizes Ryu in both hands and drives him into the ground.
        if (t == T_GRAB) { yuta.triggerAnim("main", "cast"); ryu.triggerAnim("main", "recoil"); sound(sl, Y, ModSounds.SEAL_RITUAL.get(), 1.4f, 0.8f); }
        if (t == T_SLAM) {
            ShinjukuCity.carveSphere(s.at(4, 0.5, 0), 3.2);
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, R.x, R.y, R.z, 2, 1.2, 0.4, 1.2, 0);
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.GRAY_CONCRETE.defaultBlockState()), R.x, R.y, R.z, 80, 2.0, 0.8, 2.0, 0.5);
            sound(sl, R, SoundEvents.GENERIC_EXPLODE, 3.5f, 0.45f);
            fx(s, ScreenFxPacket.SHAKE, 34, 1.5f);
            fx(s, ScreenFxPacket.WHITE_FLASH, 8, 0.6f);
        }
        // ---- 8. Ryu's own Granite Blast, bounced back down from the sky
        if (t == T_RETURN) sound(sl, R, ModSounds.CINEMATIC_STING.get(), 1.6f, 0.6f);
        if (t >= T_RETURN && t < T_RETURN_HIT) {
            Vec3 from = new Vec3(R.x, s.c.getY() + 60, R.z), to = R.add(0, 1.5, 0);
            beam(sl, from, to, RYU_BEAM, 30);
        }
        if (t == T_RETURN_HIT) {
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, R.x, R.y + 1, R.z, 2, 1.5, 0.5, 1.5, 0);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, R.x, R.y + 1, R.z, 60, 2.5, 1.0, 2.5, 0.05);
            shock(sl, R, 5, RYU_BEAM);
            ryu.triggerAnim("main", "recoil");
            sound(sl, R, SoundEvents.GENERIC_EXPLODE, 4.0f, 0.5f);
            fx(s, ScreenFxPacket.WHITE_FLASH, 18, 1.0f);
            fx(s, ScreenFxPacket.SHAKE, 40, 1.6f);
        }
        if (t == T_RYU_DOWN) sound(sl, R, ModSounds.HEARTBEAT.get(), 1.2f, 0.9f);
        if (t == T_BYE) sound(sl, Y, ModSounds.CURSE_DEATH.get(), 1.2f, 0.8f);
    }

    // ------------------------------------------------------------------ effects
    private static void beam(ServerLevel sl, Vec3 a, Vec3 b, DustParticleOptions dust, int n) {
        for (int i = 0; i <= n; i++) {
            Vec3 p = a.lerp(b, i / (double) n);
            sl.sendParticles(dust, p.x, p.y, p.z, 2, 0.06, 0.06, 0.06, 0.0);
        }
    }

    private static void shock(ServerLevel sl, Vec3 c, double r, DustParticleOptions dust) {
        for (int i = 0; i < 36; i++) {
            double a = i / 36.0 * Math.PI * 2;
            sl.sendParticles(dust, c.x + Math.cos(a) * r, c.y + 0.2, c.z + Math.sin(a) * r, 2, 0.1, 0.2, 0.1, 0.0);
            sl.sendParticles(ParticleTypes.CLOUD, c.x + Math.cos(a) * r * 0.7, c.y + 0.1, c.z + Math.sin(a) * r * 0.7, 1, 0.1, 0.1, 0.1, 0.03);
        }
        sl.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 1, 0, 0, 0, 0);
    }

    private static void sound(ServerLevel sl, Vec3 p, SoundEvent e, float vol, float pitch) { sl.playSound(null, BlockPos.containing(p), e, SoundSource.HOSTILE, vol, pitch); }
    private static void fx(Scene s, int type, int dur, float k) {
        ServerPlayer sp = s.level.getServer().getPlayerList().getPlayer(s.player);
        if (sp != null) ModNetwork.sendTo(sp, new ScreenFxPacket(type, dur, k));
    }

    // ------------------------------------------------------------------ the end: the game goes on
    private static void cleanup(Scene s) {
        ServerLevel sl = s.level;
        if (sl.getEntity(s.yutaId) instanceof NamedSorcererEntity y) y.discard();
        if (sl.getEntity(s.ryuId) instanceof CinematicActorEntity r) r.discard();
        if (sl.getEntity(s.rikaId) instanceof CinematicActorEntity k) k.discard();
    }

    private static void finish(ServerPlayer sp, Scene s) {
        cleanup(s);
        ModNetwork.sendTo(sp, new FullFightPacket(FullFightPacket.STOP, 0, 0, 0, 0, 0, 0));
        sp.setNoGravity(false);
        sp.removeEffect(MobEffects.INVISIBILITY);
        Vec3 stand = s.at(-20, 0, 12);
        float yaw = CinematicDirector.yawTowards(stand, s.at(0, 0, 0));
        sp.connection.teleport(stand.x, stand.y, stand.z, yaw, 10);
        sp.fallDistance = 0;
        CursedData d = KocSync.data(sp);
        d.setIntroSeen(true);
        d.setEnergy(d.maxEnergy());
        PowerScaling.apply(sp, d);
        KocSync.sync(sp);
        BlockPos home = BlockPos.containing(stand);
        sp.setRespawnPosition(Level.OVERWORLD, home, yaw, true, false);
        s.level.setDefaultSpawnPos(home, yaw);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.sendai_end").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        sp.displayClientMessage(Component.translatable("message.kingofcurses.sendai_end2").withStyle(ChatFormatting.GRAY), false);
        if (d.controlMode() == CursedData.CONTROL_NONE) ModNetwork.sendTo(sp, new OpenScreenPacket(OpenScreenPacket.CONTROL_MODE));
    }
}
