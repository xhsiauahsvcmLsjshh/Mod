package com.kingofcurses.client;

import com.kingofcurses.ability.SendaiDirector;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** v1.0.24 client camera, subtitles and titles for the Sendai Colony video. Driven by FullFightCinematic while it is on. */
public final class SendaiCinematic {
    private static int yutaId, ryuId, rikaId;
    private static Vec3 C = Vec3.ZERO, lastY = Vec3.ZERO, lastR = Vec3.ZERO, lastK = Vec3.ZERO;
    /** Cut points: the camera snaps instead of gliding. */
    private static final int[] CUTS = {0, 60, 85, 115, 165, 175, 230, 262, 300, 345, 402, 470, 520, 560, 582, 612, 650, 680, 722, 760, 790, 830, 1000, 1100};

    private SendaiCinematic() {}

    static void begin(int yuta, int ryu, int rika, BlockPos center) {
        yutaId = yuta; ryuId = ryu; rikaId = rika;
        C = new Vec3(center.getX() + 0.5, center.getY() + 1, center.getZ() + 0.5);
        lastY = C.add(-34, 0, 0); lastR = C.add(38, 0, 0); lastK = C.add(-36, 3, 0);
    }

    static Vec3 start() { return C.add(40, 45, 40); }

    /** Frames the video at tick t. Yuta, Ryu and Rika are followed while they move. */
    static void clientTick(int t) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        float pt = mc.getFrameTime();
        Entity ye = mc.level.getEntity(yutaId), re = mc.level.getEntity(ryuId), ke = mc.level.getEntity(rikaId);
        if (ye != null) lastY = ye.getPosition(pt);
        if (re != null) lastR = re.getPosition(pt);
        if (ke != null) lastK = ke.getPosition(pt);
        Vec3 Y = lastY, R = lastR, K = lastK, up = new Vec3(0, 1, 0);
        Vec3 d3 = new Vec3(R.x - Y.x, 0, R.z - Y.z);
        Vec3 dir = d3.lengthSqr() < 0.01 ? new Vec3(1, 0, 0) : d3.normalize();
        Vec3 side = new Vec3(-dir.z, 0, dir.x);
        Vec3 mid = Y.lerp(R, 0.5);
        boolean snap = false;
        for (int c : CUTS) if (c == t) { snap = true; break; }
        Vec3 pos, look;
        if (t < 60) {                                                   // aerial over the ruins at night
            double a = Math.toRadians(40 + t * 0.7);
            pos = C.add(Math.cos(a) * 58, 36 - t * 0.2, Math.sin(a) * 58); look = C.add(0, 4, 0);
        } else if (t < 85) {                                            // Yuta walks in
            pos = Y.subtract(dir.scale(3.6)).add(side.scale(1.8)).add(up.scale(1.6)); look = Y.add(0, 1.5, 0);
        } else if (t < 115) {                                           // Rika, close
            pos = K.add(side.scale(2.6)).add(up.scale(0.4)); look = K;
        } else if (t < 165) {                                           // Ryu comes in
            pos = Y.add(dir.scale(6)).add(side.scale(1.2)).add(up.scale(1.5)); look = R.add(0, 1.7, 0);
        } else if (t < 230) {                                           // the charge in the pompadour
            pos = R.subtract(dir.scale(2.8)).add(side.scale(0.8)).add(up.scale(2.2)); look = R.add(0, 2.1, 0);
        } else if (t < 262) {                                           // the two beams, low side shot
            pos = mid.add(side.scale(12)).add(up.scale(3)); look = mid.add(0, 1.5, 0);
        } else if (t < 300) {                                           // the clash, close
            pos = mid.add(side.scale(4)).add(up.scale(2)); look = mid.add(0, 1.5, 0);
        } else if (t < 345) {                                           // Yuta is pushed back
            pos = Y.subtract(dir.scale(4)).add(up.scale(1.8)); look = Y.add(dir.scale(2)).add(0, 1.5, 0);
        } else if (t < 402) {                                           // the dash, orbiting
            double a = (t - 345) * 0.03;
            pos = mid.add(side.scale(Math.cos(a) * 10)).add(dir.scale(Math.sin(a) * 10)).add(up.scale(2.5)); look = mid.add(0, 1.4, 0);
        } else if (t < 470) {                                           // the exchange
            double a = (t - 402) * 0.05;
            pos = mid.add(side.scale(Math.cos(a) * 7)).add(dir.scale(Math.sin(a) * 7)).add(up.scale(2.5 + Math.sin(t * 0.07))); look = mid.add(0, 1.3, 0);
        } else if (t < 520) {                                           // Ryu catches his breath
            pos = R.add(dir.scale(-3.2)).add(up.scale(1.7)); look = R.add(0, 1.6, 0);
        } else if (t < 560) {                                           // Yuta climbs, low angle
            pos = Y.add(side.scale(3)).add(up.scale(0.2)); look = Y.add(0, 8, 0);
        } else if (t < 582) {                                           // wide, the sky is open
            pos = mid.add(side.scale(11)).add(up.scale(3)); look = mid.add(0, 3, 0);
        } else if (t < 612) {                                           // the blow to the chest
            pos = mid.add(side.scale(3)).add(up.scale(1.6)); look = R.add(0, 1.5, 0);
        } else if (t < 650) {                                           // Rika's punch
            pos = K.add(side.scale(2.2)).add(dir.scale(-0.5)); look = R.add(0, 1.5, 0);
        } else if (t < 680) {                                           // Rika fades
            pos = K.add(side.scale(3)).add(up.scale(1)); look = K;
        } else if (t < 722) {                                           // Yuta seizes Ryu
            pos = mid.add(side.scale(3.5)).add(up.scale(1.7)); look = mid.add(0, 1.2, 0);
        } else if (t < 760) {                                           // the crater, from above
            pos = mid.add(side.scale(9)).add(up.scale(7)); look = mid.add(0, 0.5, 0);
        } else if (t < 790) {                                           // look up at the returning beam
            pos = R.add(side.scale(4)).add(up.scale(2)); look = R.add(0, 20, 0);
        } else if (t < 830) {                                           // Ryu on the ground
            pos = R.add(side.scale(3)).add(up.scale(1.2)); look = R.add(0, 1.2, 0);
        } else if (t < 1000) {                                          // slow orbit over the ruins
            double a = (t - 830) * 0.01;
            pos = mid.add(side.scale(Math.cos(a) * 18)).add(dir.scale(Math.sin(a) * 18)).add(up.scale(6)); look = mid.add(0, 1, 0);
        } else if (t < 1100) {                                          // Yuta walks away
            pos = Y.add(dir.scale(-5)).add(up.scale(1.5)); look = Y.add(0, 1.5, 0);
        } else {                                                        // pull back over the ruins
            double kk = Mth.clamp((t - 1100) / 100.0, 0, 1);
            pos = C.add(-10, 8 + kk * 40, 20 + kk * 30); look = C;
        }
        FullFightCinematic.place(pos, look, snap);
    }

    static String subtitle(int t) {
        if (t >= 60 && t < 104) return "cinematic.kingofcurses.sendai.y1";
        if (t >= 120 && t < 165) return "cinematic.kingofcurses.sendai.r1";
        if (t >= 178 && t < 226) return "cinematic.kingofcurses.sendai.r2";
        if (t >= 236 && t < 258) return "cinematic.kingofcurses.sendai.y2";
        if (t >= 402 && t < 456) return "cinematic.kingofcurses.sendai.r3";
        if (t >= 588 && t < 618) return "cinematic.kingofcurses.sendai.y3";
        if (t >= 624 && t < 668) return "cinematic.kingofcurses.sendai.r4";
        if (t >= 696 && t < 750) return "cinematic.kingofcurses.sendai.y4";
        if (t >= 790 && t < 850) return "cinematic.kingofcurses.sendai.r5";
        if (t >= 1010 && t < 1080) return "cinematic.kingofcurses.sendai.y5";
        return null;
    }

    static String[] title(int t) {
        if (t >= 14 && t < 112) return new String[]{"cinematic.kingofcurses.sendai.title", "FFE6E6"};
        if (t >= 268 && t < 318) return new String[]{"cinematic.kingofcurses.sendai.t_clash", "FFFFFF"};
        if (t >= 800 && t < 836) return new String[]{"cinematic.kingofcurses.sendai.t_dessert", "E0102A"};
        if (t >= 1104 && t < 1192) return new String[]{"cinematic.kingofcurses.sendai.t_end", "B57CFF"};
        return null;
    }

    static float titleAlpha(int t) {
        int[][] r = {{14, 112}, {268, 318}, {800, 836}, {1104, 1192}};
        for (int[] p : r) if (t >= p[0] && t < p[1]) return Mth.clamp(Math.min((t - p[0]) / 8f, (p[1] - t) / 8f), 0, 1);
        return 0;
    }

    static float black(int t) {
        if (t < 12) return 1f - t / 12f;
        if (t >= SendaiDirector.T_END - 20) return Mth.clamp((t - (SendaiDirector.T_END - 20)) / 16f, 0, 1);
        return 0f;
    }
}
