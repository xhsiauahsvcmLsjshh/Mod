package com.kingofcurses.client;

import com.kingofcurses.KingOfCurses;
import com.kingofcurses.client.overlay.KocOverlays;
import com.kingofcurses.client.particle.KocParticle;
import com.kingofcurses.client.renderer.KocGeoRenderer;
import com.kingofcurses.client.renderer.SukunaMarkingsLayer;
import com.kingofcurses.client.screen.ReliquaryScreen;
import com.kingofcurses.registry.ModEntities;
import com.kingofcurses.registry.ModItems;
import com.kingofcurses.registry.ModMenus;
import com.kingofcurses.registry.ModParticles;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Client-only mod-bus registration. This class is never loaded on a dedicated server. */
@Mod.EventBusSubscriber(modid = KingOfCurses.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(ModMenus.RELIQUARY.get(), ReliquaryScreen::new);
            ItemProperties.register(ModItems.CURSED_COMPASS.get(), new ResourceLocation(KingOfCurses.MODID, "resonance"),
                    (stack, level, entity, seed) -> stack.hasTag() ? stack.getTag().getFloat("Resonance") : 0.0f);
        });
    }

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent event) {
        event.register(KeyBindings.USE_ABILITY);
        event.register(KeyBindings.NEXT_ABILITY);
        event.register(KeyBindings.ABILITY_WHEEL);
        event.register(KeyBindings.DOMAIN);
        event.register(KeyBindings.CODEX);
        event.register(KeyBindings.SKIP);
        event.register(KeyBindings.TOGGLE_CONTROLS);
        event.register(KeyBindings.RIP_FINGER);
        event.register(KeyBindings.TOUCH_PAD);
        event.register(KeyBindings.BATTLE_HUD);
        event.register(KeyBindings.FINISHER);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.RYOMEN_SUKUNA.get(), ctx -> new KocGeoRenderer<>(ctx, "ryomen_sukuna", true, 0.36f));
        event.registerEntityRenderer(ModEntities.SUKUNA_TRUE_FORM.get(), ctx -> new KocGeoRenderer<>(ctx, "sukuna_true_form", true, 0.54f));
        event.registerEntityRenderer(ModEntities.GOJO_SATORU.get(), ctx -> new KocGeoRenderer<>(ctx, new com.kingofcurses.client.renderer.GojoGeoModel(), 0.36f));
        event.registerEntityRenderer(ModEntities.FLY_HEAD.get(), ctx -> new KocGeoRenderer<>(ctx, "fly_head", true, 0.42f));
        event.registerEntityRenderer(ModEntities.CRAWLING_EYE.get(), ctx -> new KocGeoRenderer<>(ctx, "crawling_eye", true, 0.54f));
        event.registerEntityRenderer(ModEntities.ROPPONGI_CURSE.get(), ctx -> new KocGeoRenderer<>(ctx, "roppongi_curse", true, 0.60f));
        event.registerEntityRenderer(ModEntities.LANTERN_HAG.get(), ctx -> new KocGeoRenderer<>(ctx, "lantern_hag", true, 0.42f));
        event.registerEntityRenderer(ModEntities.HANGED_BRIDE.get(), ctx -> new KocGeoRenderer<>(ctx, "hanged_bride", true, 0.42f));
        event.registerEntityRenderer(ModEntities.BONE_CENTIPEDE.get(), ctx -> new KocGeoRenderer<>(ctx, "bone_centipede", true, 0.84f));
        event.registerEntityRenderer(ModEntities.FINGER_BEARER.get(), ctx -> new KocGeoRenderer<>(ctx, "finger_bearer", true, 0.96f));
        event.registerEntityRenderer(ModEntities.SMALLPOX_DEITY.get(), ctx -> new KocGeoRenderer<>(ctx, "smallpox_deity", true, 1.08f));
        event.registerEntityRenderer(ModEntities.CURSED_WOMB.get(), ctx -> new KocGeoRenderer<>(ctx, "cursed_womb", true, 0.84f));
        event.registerEntityRenderer(ModEntities.SHRINE_WARDEN.get(), ctx -> new KocGeoRenderer<>(ctx, "shrine_warden", true, 0.84f));
        event.registerEntityRenderer(ModEntities.JUJUTSU_SORCERER.get(), ctx -> new KocGeoRenderer<>(ctx, "jujutsu_sorcerer", true, 0.36f));
        event.registerEntityRenderer(ModEntities.SORCERER_ELITE.get(), ctx -> new KocGeoRenderer<>(ctx, "sorcerer_elite", true, 0.36f));
        event.registerEntityRenderer(ModEntities.JUJUTSU_STUDENT.get(), ctx -> new KocGeoRenderer<>(ctx, "jujutsu_student", true, 0.36f));
        event.registerEntityRenderer(ModEntities.GOJO_KENJAKU.get(), ctx -> new KocGeoRenderer<>(ctx, new com.kingofcurses.client.renderer.GojoKenjakuGeoModel(), 0.36f));
        for (var t : java.util.List.of(ModEntities.YUTA_OKKOTSU, ModEntities.KINJI_HAKARI, ModEntities.MAKI_ZENIN, ModEntities.MEGUMI_FUSHIGURO, ModEntities.AOI_TODO, ModEntities.KENTO_NANAMI)) {
            final String name = t.getId().getPath();
            event.registerEntityRenderer(t.get(), ctx -> new KocGeoRenderer<>(ctx, name, true, 0.4f));
        }
        event.registerEntityRenderer(ModEntities.SEALING_MASTER.get(), ctx -> new KocGeoRenderer<>(ctx, "sealing_master", true, 0.42f));
        event.registerEntityRenderer(ModEntities.MALEVOLENT_SHRINE.get(), ctx -> new KocGeoRenderer<>(ctx, "malevolent_shrine", false, 0.0f));
        event.registerEntityRenderer(ModEntities.DISMANTLE_SLASH.get(), ctx -> new KocGeoRenderer<>(ctx, "dismantle_slash", false, 0.0f));
        event.registerEntityRenderer(ModEntities.FUGA_ARROW.get(), ctx -> new KocGeoRenderer<>(ctx, "fuga_arrow", false, 0.0f));
        event.registerEntityRenderer(ModEntities.SLICED_CORPSE.get(), com.kingofcurses.client.renderer.SlicedCorpseRenderer::new);
        event.registerEntityRenderer(ModEntities.HEIAN_SUKUNA.get(), ctx -> new KocGeoRenderer<>(ctx, new com.kingofcurses.client.renderer.HeianSukunaGeoModel(), 1.4f).withScale(1.6f));
        event.registerEntityRenderer(ModEntities.SUKUNA_ARM_THROWN.get(), com.kingofcurses.client.renderer.SukunaArmRenderer::new);
        event.registerEntityRenderer(ModEntities.TOJI_FUSHIGURO.get(), ctx -> new KocGeoRenderer<>(ctx, "toji_fushiguro", true, 0.36f));
        event.registerEntityRenderer(ModEntities.SUGURU_GETO.get(), ctx -> new KocGeoRenderer<>(ctx, "suguru_geto", true, 0.36f));
        event.registerEntityRenderer(ModEntities.CURSE_USER.get(), ctx -> new KocGeoRenderer<>(ctx, "curse_user", true, 0.36f));
        event.registerEntityRenderer(ModEntities.MAHORAGA.get(), ctx -> new KocGeoRenderer<>(ctx, "mahoraga", true, 0.9f));   // v1.0.22
        event.registerEntityRenderer(ModEntities.RYU_ISHIGORI.get(), ctx -> new KocGeoRenderer<>(ctx, "ryu_ishigori", true, 0.6f));   // v1.0.24 Sendai
        event.registerEntityRenderer(ModEntities.RIKA_ORIMOTO.get(), ctx -> new KocGeoRenderer<>(ctx, "rika_orimoto", true, 0.9f).withScale(1.5f));   // v1.0.24: she is huge
    }

    @SubscribeEvent
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void layers(EntityRenderersEvent.AddLayers event) {
        // v1.0.5: Sukuna's tattoos on every vanilla / modded creature that became a vessel
        for (net.minecraft.world.entity.EntityType<?> type : net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getValues()) {
            if (type == net.minecraft.world.entity.EntityType.PLAYER) continue;
            try {
                net.minecraft.client.renderer.entity.LivingEntityRenderer r = event.getRenderer((net.minecraft.world.entity.EntityType) type);
                if (r != null) r.addLayer(new com.kingofcurses.client.renderer.VesselTattooLayer(r));
            } catch (Exception ignored) { }
        }
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) {
                renderer.addLayer(new SukunaMarkingsLayer(renderer));
                renderer.addLayer(new com.kingofcurses.client.renderer.FourArmsLayer(renderer));
                renderer.addLayer(new com.kingofcurses.client.renderer.RipArmsLayer(renderer));
                renderer.addLayer(new com.kingofcurses.client.renderer.ArmStateLayer(renderer));
            }
        }
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("cursed_fx", KocOverlays.FX);
        event.registerAboveAll("cursed_hud", KocOverlays.HUD);
        event.registerAboveAll("cursed_controls", KocOverlays.CONTROLS);
        event.registerAboveAll("vigor_bar", KocOverlays.VIGOR);
        event.registerAboveAll("compass_nav", KocOverlays.NAV);
        event.registerAboveAll("heian_video", KocOverlays.HEIAN);
        event.registerAboveAll("gojo_intro", KocOverlays.GOJO_INTRO);
        event.registerAboveAll("full_fight", KocOverlays.FULL_FIGHT);
        event.registerAboveAll("cinematic", KocOverlays.CINEMATIC);
        event.registerAboveAll("intro_loading", KocOverlays.LOADING);
    }

    @SubscribeEvent
    public static void particles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.CURSED_ENERGY.get(), s -> new KocParticle.Provider(s, KocParticle.Style.CURSED));
        event.registerSpriteSet(ModParticles.BLOOD.get(), s -> new KocParticle.Provider(s, KocParticle.Style.BLOOD));
        event.registerSpriteSet(ModParticles.SLASH.get(), s -> new KocParticle.Provider(s, KocParticle.Style.SLASH));
        event.registerSpriteSet(ModParticles.DOMAIN_ASH.get(), s -> new KocParticle.Provider(s, KocParticle.Style.ASH));
        event.registerSpriteSet(ModParticles.RESONANCE.get(), s -> new KocParticle.Provider(s, KocParticle.Style.RESONANCE));
    }
}
