package com.kingofcurses.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * v1.0.24 cast actor of the Sendai Colony video (Ryu Ishigori, Rika Orimoto). No AI: the SendaiDirector moves it every tick,
 * and it plays its triggered animations (attack, slash, cast, recoil, vanish). It is never saved.
 */
public class CinematicActorEntity extends PathfinderMob implements GeoEntity {
    private final String model;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle, walk;

    public CinematicActorEntity(EntityType<? extends PathfinderMob> type, Level level, String model) {
        super(type, level);
        this.model = model;
        this.idle = KocAnims.loop(model, "idle");
        this.walk = KocAnims.loop(model, "walk");
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 16.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    /** Cinematic actors stand still on their own: no AI, nothing can hurt them, and they never despawn. */
    public void setupActor() {
        setNoAi(true);
        setInvulnerable(true);
        setNoGravity(true);
        setPersistenceRequired();
    }

    @Override public boolean isInvulnerableTo(net.minecraft.world.damagesource.DamageSource source) { return true; }
    @Override public boolean removeWhenFarAway(double distSqr) { return false; }
    @Override public boolean shouldBeSaved() { return false; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::predicate)
                .triggerableAnim("attack", KocAnims.once(model, "attack"))
                .triggerableAnim("slash", KocAnims.once(model, "slash"))
                .triggerableAnim("cast", KocAnims.once(model, "cast"))
                .triggerableAnim("recoil", KocAnims.once(model, "recoil"))
                .triggerableAnim("vanish", KocAnims.once(model, "vanish")));
    }

    private PlayState predicate(AnimationState<CinematicActorEntity> state) {
        if (state.isMoving()) return state.setAndContinue(walk);
        return state.setAndContinue(idle);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
