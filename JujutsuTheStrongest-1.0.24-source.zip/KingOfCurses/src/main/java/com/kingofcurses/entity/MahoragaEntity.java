package com.kingofcurses.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** v1.0.22 Eight-Handled Sword Divergent Sila Divine General Mahoraga. The wheel turns: it adapts to everything. */
public class MahoragaEntity extends PathfinderMob implements GeoEntity {
    public static final int STATE_AUTO = 0, STATE_IDLE = 1, STATE_RISE = 2, STATE_WALK = 3, STATE_DEAD = 4;
    private static final String M = "mahoraga";
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(MahoragaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> CINEMATIC = SynchedEntityData.defineId(MahoragaEntity.class, EntityDataSerializers.BOOLEAN);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final RawAnimation idle = KocAnims.loop(M, "idle"), walk = KocAnims.loop(M, "walk"), run = KocAnims.loop(M, "run"),
            rise = KocAnims.hold(M, "rise"), dead = KocAnims.hold(M, "dead");
    private int lifetime = -1;

    public MahoragaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.xpReward = 300;
    }

    public static AttributeSupplier.Builder createAttributes(double hp, double dmg, double speed, double armor, double knockback) {
        return PathfinderMob.createMobAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.ATTACK_DAMAGE, dmg)
                .add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ARMOR, armor).add(Attributes.FOLLOW_RANGE, 40.0).add(Attributes.KNOCKBACK_RESISTANCE, knockback);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(STATE, STATE_AUTO);
        entityData.define(CINEMATIC, false);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 16.0f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public void setupCinematic(int ticks) {
        entityData.set(CINEMATIC, true);
        setNoAi(true); setInvulnerable(true); setNoGravity(true); setPersistenceRequired();
        lifetime = ticks;
        entityData.set(STATE, STATE_IDLE);
    }

    public boolean isCinematic() { return entityData.get(CINEMATIC); }
    public void setState(int s) { entityData.set(STATE, s); }
    public int getState() { return entityData.get(STATE); }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && lifetime > 0 && --lifetime == 0) discard();
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (isCinematic()) return !source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY);
        return super.isInvulnerableTo(source);
    }

    /** Every hit it takes turns the wheel: it adapts and takes less from the same kind of damage. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean r = super.hurt(source, amount * Math.max(0.35f, 1f - adapt * 0.08f));
        if (r && !level().isClientSide && random.nextInt(4) == 0) { adapt = Math.min(8, adapt + 1); triggerAnim("main", "adapt"); }
        return r;
    }
    private int adapt;

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean isPushable() { return !isCinematic(); }
    @Override public boolean shouldBeSaved() { return !isCinematic() && super.shouldBeSaved(); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); tag.putInt("Adapt", adapt); }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) { super.readAdditionalSaveData(tag); adapt = tag.getInt("Adapt"); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::predicate)
                .triggerableAnim("punch", KocAnims.once(M, "punch"))
                .triggerableAnim("adapt", KocAnims.once(M, "adapt"))
                .triggerableAnim("attack", KocAnims.once(M, "attack"))
                .triggerableAnim("spin", KocAnims.once(M, "spin"))      // v1.0.24: the Dharma Wheel turns
                .triggerableAnim("slash", KocAnims.once(M, "slash")));  // v1.0.24: Sword of Extermination
    }

    private PlayState predicate(AnimationState<MahoragaEntity> state) {
        switch (getState()) {
            case STATE_RISE: return state.setAndContinue(rise);
            case STATE_DEAD: return state.setAndContinue(dead);
            case STATE_WALK: return state.setAndContinue(walk);
            case STATE_IDLE: return state.setAndContinue(idle);
            default: break;
        }
        if (state.isMoving()) return state.setAndContinue(isAggressive() ? run : walk);
        return state.setAndContinue(idle);
    }

    @Override
    public void swing(InteractionHand hand, boolean update) {
        super.swing(hand, update);
        if (!level().isClientSide) triggerAnim("main", "punch");
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
